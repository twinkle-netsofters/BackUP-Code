import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutterquiz/core/quiz_statistics_notifier.dart';
import 'package:flutterquiz/features/quiz/models/subcategory_statistics.dart';
import 'package:flutterquiz/features/quiz/quiz_repository.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// Helper class to manage quiz statistics storage
class QuizStatisticsStorage {
  QuizStatisticsStorage._();

  static const String _statsBoxName = 'quiz_statistics';
  static const String _statsKeyPrefix = 'quiz_stats_';

  static Box<dynamic>? _box;

  static Future<Box<dynamic>> get _getBox async {
    _box ??= await Hive.openBox<dynamic>(_statsBoxName);
    return _box!;
  }

  /// Get statistics for a subcategory from local Hive storage
  /// 
  /// @deprecated This method uses offline/local storage. 
  /// Use [getStatisticsFromApi] instead to fetch from API.
  /// The API is now the single source of truth for statistics.
  @Deprecated('Use getStatisticsFromApi instead - API is the source of truth')
  static Future<SubcategoryStatistics?> getStatistics({
    required String categoryId,
    required String subcategoryId,
    required String quizType,
  }) async {
    try {
      final box = await _getBox;
      final key = _getStorageKey(categoryId, subcategoryId, quizType);
      final jsonString = box.get(key) as String?;

      if (jsonString == null) return null;

      final json = jsonDecode(jsonString) as Map<String, dynamic>;
      return SubcategoryStatistics.fromJson(json);
    } catch (e) {
      return null;
    }
  }

  /// Save statistics for a subcategory to local Hive storage
  /// 
  /// @deprecated This method saves to offline/local storage. 
  /// Statistics are now managed entirely by the API when quiz results are submitted.
  /// The API is the single source of truth - no local storage needed.
  @Deprecated('Statistics are managed by API - no local storage needed')
  static Future<void> saveStatistics(SubcategoryStatistics stats) async {
    try {
      final box = await _getBox;
      final key = _getStorageKey(
        stats.categoryId,
        stats.subcategoryId,
        stats.quizType,
      );
      
      // Save to storage
      await box.put(key, jsonEncode(stats.toJson()));
      
      // Wait a bit to ensure storage is written
      await Future.delayed(const Duration(milliseconds: 50));
      
      // Notify listeners that statistics were updated
      QuizStatisticsNotifier.instance.notifyStatisticsUpdated(
        categoryId: stats.categoryId,
        subcategoryId: stats.subcategoryId,
      );
      
      // Debug log
      debugPrint('Statistics saved successfully: ${stats.toString()}');
    } catch (e, stackTrace) {
      // Log error
      debugPrint('Error saving statistics: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }

  /// Get all statistics for a category from local Hive storage
  /// 
  /// @deprecated This method uses offline/local storage. 
  /// Use [getCategoryStatisticsFromApi] instead to fetch from API.
  /// The API is now the single source of truth for statistics.
  @Deprecated('Use getCategoryStatisticsFromApi instead - API is the source of truth')
  static Future<Map<String, SubcategoryStatistics>> getCategoryStatistics({
    required String categoryId,
    required String quizType,
  }) async {
    try {
      final box = await _getBox;
      final categoryPrefix = _getCategoryPrefix(categoryId, quizType);

      final Map<String, SubcategoryStatistics> statisticsMap = {};

      for (final key in box.keys) {
        final keyString = key.toString();
        if (keyString.startsWith(categoryPrefix)) {
          final jsonString = box.get(key) as String?;
          if (jsonString != null) {
            try {
              final json = jsonDecode(jsonString) as Map<String, dynamic>;
              final stats = SubcategoryStatistics.fromJson(json);
              statisticsMap[stats.subcategoryId] = stats;
            } catch (e) {
              // Skip invalid entries
              continue;
            }
          }
        }
      }

      return statisticsMap;
    } catch (e) {
      return {};
    }
  }

  /// Helper method to parse integer values from API (handles both String and num types)
  static int? _parseIntValue(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) {
      return int.tryParse(value);
    }
    return null;
  }

  /// Get storage key for a specific subcategory
  static String _getStorageKey(
    String categoryId,
    String subcategoryId,
    String quizType,
  ) {
    return '$_statsKeyPrefix${categoryId}_${subcategoryId}_$quizType';
  }

  /// Get prefix for all keys in a category
  static String _getCategoryPrefix(String categoryId, String quizType) {
    return '$_statsKeyPrefix${categoryId}_';
  }

  /// Clear all statistics (useful for testing or reset)
  static Future<void> clearAllStatistics() async {
    try {
      final box = await _getBox;
      final keysToRemove = box.keys
          .where((key) => key.toString().startsWith(_statsKeyPrefix))
          .toList();
      for (final key in keysToRemove) {
        await box.delete(key);
      }
    } catch (e) {
      // Handle error
    }
  }

  /// Fetch statistics for a single subcategory directly from API (no Hive storage)
  static Future<SubcategoryStatistics?> getStatisticsFromApi({
    required String categoryId,
    required String subcategoryId,
    required String quizType, // 'funAndLearn' or 'quizZone'
  }) async {
    try {
      final quizRepository = QuizRepository();
      List<Map<String, dynamic>> apiStats;

      // Fetch from appropriate API endpoint
      if (quizType == 'funAndLearn') {
        apiStats = await quizRepository.getFunLearnStatistics(
          categoryId: categoryId,
        );
      } else if (quizType == 'quizZone') {
        apiStats = await quizRepository.getQuizZoneStatistics(
          categoryId: categoryId,
        );
      } else {
        debugPrint('Invalid quizType for API fetch: $quizType');
        return null;
      }

      debugPrint('Fetching statistics for subcategory: $subcategoryId, found ${apiStats.length} items');
      if (apiStats.isEmpty) {
        debugPrint('No statistics found in API response for category: $categoryId');
        return null;
      }
      
      // Find the statistics for the specific subcategory
      // API response structure: Each item has a 'subcategories' array containing actual subcategory data
      for (final statData in apiStats) {
        try {
          debugPrint('Processing stat data: $statData');
          
          // Check if this item belongs to the requested category
          final statCategoryId = statData['category_id']?.toString() ?? 
                               statData['categoryId']?.toString() ?? '';
          
          // Skip if category_id doesn't match the requested categoryId
          if (statCategoryId != categoryId) {
            debugPrint('Skipping category ${statCategoryId} - not matching requested ${categoryId}');
            continue;
          }
          
          // Check if this item has a subcategories array
          if (statData['subcategories'] != null && statData['subcategories'] is List) {
            final subcategoriesList = statData['subcategories'] as List;
            
            // Iterate through subcategories array
            for (final subcategoryData in subcategoriesList) {
              if (subcategoryData is! Map<String, dynamic>) continue;
              
              final statSubcategoryId = subcategoryData['subcategory_id']?.toString() ?? 
                                  subcategoryData['subcategoryId']?.toString() ?? '';
          
          debugPrint('Comparing: API subcategoryId=$statSubcategoryId, looking for=$subcategoryId');
              
              if (statSubcategoryId == subcategoryId) {
                // Parse API response with correct field names
                // Handle both String and num types from API
                final correctAnswer = _parseIntValue(subcategoryData['correct_answer']) ?? 
                                    _parseIntValue(subcategoryData['correctAnswer']) ?? 
                                    _parseIntValue(subcategoryData['correct_count']) ?? 0;
                final incorrectAnswer = _parseIntValue(subcategoryData['incorrect_answer']) ?? 
                                      _parseIntValue(subcategoryData['incorrectAnswer']) ?? 
                                      _parseIntValue(subcategoryData['incorrect_count']) ?? 0;
                final totalAnswer = _parseIntValue(subcategoryData['total_answer']) ?? 
                                  _parseIntValue(subcategoryData['totalAnswer']) ?? 0;
                
                // Calculate answered count
                final answeredCount = correctAnswer + incorrectAnswer;
                
                // Use total_answer from API if available, otherwise use answered count
                // Note: totalQuestions will be overridden by subcategory model in UI
                final totalQuestions = totalAnswer > 0 ? totalAnswer : (answeredCount > 0 ? answeredCount : 0);
                // Empty count will be calculated in UI using subcategory's total questions
                final emptyCount = 0; // Will be recalculated in UI
                
                final isCompleted = (subcategoryData['is_completed'] as bool?) ?? 
                                 (subcategoryData['isCompleted'] as bool?) ??
                                 (subcategoryData['is_attempted'] as bool? ?? false) && emptyCount == 0;
                
                debugPrint('Found statistics: correct=$correctAnswer, incorrect=$incorrectAnswer, empty=$emptyCount, total=$totalQuestions, completed=$isCompleted');

                return SubcategoryStatistics(
                  subcategoryId: subcategoryId,
                  categoryId: categoryId,
                  quizType: quizType,
                  totalQuestions: totalQuestions,
                  correctCount: correctAnswer,
                  incorrectCount: incorrectAnswer,
                  emptyCount: emptyCount,
                  isCompleted: isCompleted,
                  lastAttemptedAt: subcategoryData['last_attempted_at'] != null
                      ? DateTime.tryParse(subcategoryData['last_attempted_at'].toString())
                      : null,
                  completedAt: subcategoryData['completed_at'] != null
                      ? DateTime.tryParse(subcategoryData['completed_at'].toString())
                      : null,
                );
              }
            }
          } else {
            // Fallback: Try to parse as flat structure (old format)
            final statSubcategoryId = statData['subcategory_id']?.toString() ?? 
                                statData['subcategoryId']?.toString() ?? '';
          
          if (statSubcategoryId == subcategoryId) {
              final correctCount = _parseIntValue(statData['correct_answer']) ?? 
                                _parseIntValue(statData['correctAnswer']) ?? 
                                _parseIntValue(statData['correct_count']) ?? 0;
              final incorrectCount = _parseIntValue(statData['incorrect_answer']) ?? 
                                  _parseIntValue(statData['incorrectAnswer']) ?? 
                                  _parseIntValue(statData['incorrect_count']) ?? 0;
              final totalAnswer = _parseIntValue(statData['total_answer']) ?? 
                                _parseIntValue(statData['totalAnswer']) ?? 0;
              final answeredCount = correctCount + incorrectCount;
              final totalQuestions = totalAnswer > 0 ? totalAnswer : answeredCount;
              final emptyCount = totalQuestions > answeredCount ? (totalQuestions - answeredCount) : 0;
            final isCompleted = (statData['is_completed'] as bool?) ?? 
                             (statData['isCompleted'] as bool?) ?? 
                             (emptyCount == 0 && totalQuestions > 0);

            return SubcategoryStatistics(
              subcategoryId: subcategoryId,
              categoryId: categoryId,
              quizType: quizType,
              totalQuestions: totalQuestions,
              correctCount: correctCount,
              incorrectCount: incorrectCount,
              emptyCount: emptyCount,
              isCompleted: isCompleted,
            );
            }
          }
        } catch (e) {
          debugPrint('Error processing stat data: $e');
          continue;
        }
      }

      // Subcategory not found in API response
      return null;
    } catch (e, stackTrace) {
      debugPrint('Error fetching statistics from API: $e');
      debugPrint('Stack trace: $stackTrace');
      return null;
    }
  }

  /// Fetch all statistics for a category directly from API (no Hive storage)
  /// Only returns statistics for subcategories that belong to the specified categoryId
  static Future<Map<String, SubcategoryStatistics>> getCategoryStatisticsFromApi({
    required String categoryId,
    required String quizType, // 'funAndLearn' or 'quizZone'
  }) async {
    try {
      final quizRepository = QuizRepository();
      List<Map<String, dynamic>> apiStats;

      // Fetch from appropriate API endpoint
      if (quizType == 'funAndLearn') {
        apiStats = await quizRepository.getFunLearnStatistics(
          categoryId: categoryId,
        );
      } else if (quizType == 'quizZone') {
        apiStats = await quizRepository.getQuizZoneStatistics(
          categoryId: categoryId,
        );
      } else {
        debugPrint('Invalid quizType for API fetch: $quizType');
        return {};
      }

      final Map<String, SubcategoryStatistics> statisticsMap = {};

      // Process each category's statistics (which contains subcategories array)
      // IMPORTANT: Only process items where category_id matches the requested categoryId
      for (final statData in apiStats) {
        try {
          // Check if this item belongs to the requested category
          final statCategoryId = statData['category_id']?.toString() ?? 
                               statData['categoryId']?.toString() ?? '';
          
          // Skip if category_id doesn't match the requested categoryId
          if (statCategoryId != categoryId) {
            debugPrint('Skipping category ${statCategoryId} - not matching requested ${categoryId}');
            continue;
          }

          // Check if this item has a subcategories array
          if (statData['subcategories'] != null && statData['subcategories'] is List) {
            final subcategoriesList = statData['subcategories'] as List;
            
            // Iterate through subcategories array
            for (final subcategoryData in subcategoriesList) {
              if (subcategoryData is! Map<String, dynamic>) continue;
              
              final subcategoryId = subcategoryData['subcategory_id']?.toString() ?? 
                                  subcategoryData['subcategoryId']?.toString() ?? '';
              
              if (subcategoryId.isEmpty) {
                continue;
              }

              // Parse API response with correct field names
              final correctAnswer = _parseIntValue(subcategoryData['correct_answer']) ?? 
                                  _parseIntValue(subcategoryData['correctAnswer']) ?? 
                                  _parseIntValue(subcategoryData['correct_count']) ?? 0;
              final incorrectAnswer = _parseIntValue(subcategoryData['incorrect_answer']) ?? 
                                    _parseIntValue(subcategoryData['incorrectAnswer']) ?? 
                                    _parseIntValue(subcategoryData['incorrect_count']) ?? 0;
              final totalAnswer = _parseIntValue(subcategoryData['total_answer']) ?? 
                                _parseIntValue(subcategoryData['totalAnswer']) ?? 0;
              
              final answeredCount = correctAnswer + incorrectAnswer;
              // Use total_answer from API if available, otherwise use answered count
              // Note: totalQuestions will be overridden by subcategory model in UI
              final totalQuestions = totalAnswer > 0 ? totalAnswer : (answeredCount > 0 ? answeredCount : 0);
              // Empty count will be calculated in UI using subcategory's total questions
              final emptyCount = 0; // Will be recalculated in UI
              
              final isCompleted = (subcategoryData['is_completed'] as bool?) ?? 
                               (subcategoryData['isCompleted'] as bool?) ??
                               (subcategoryData['is_attempted'] as bool? ?? false) && emptyCount == 0;

              final stats = SubcategoryStatistics(
                subcategoryId: subcategoryId,
                categoryId: categoryId,
                quizType: quizType,
                totalQuestions: totalQuestions,
                correctCount: correctAnswer,
                incorrectCount: incorrectAnswer,
                emptyCount: emptyCount,
                isCompleted: isCompleted,
                lastAttemptedAt: subcategoryData['last_attempted_at'] != null
                    ? DateTime.tryParse(subcategoryData['last_attempted_at'].toString())
                    : null,
                completedAt: subcategoryData['completed_at'] != null
                    ? DateTime.tryParse(subcategoryData['completed_at'].toString())
                    : null,
              );

              statisticsMap[subcategoryId] = stats;
            }
          } else {
            // Fallback: Try to parse as flat structure (old format)
            // Only include if category_id matches
            final subcategoryId = statData['subcategory_id']?.toString() ?? 
                                statData['subcategoryId']?.toString() ?? '';
            
            if (subcategoryId.isNotEmpty) {
              final correctCount = _parseIntValue(statData['correct_answer']) ?? 
                                _parseIntValue(statData['correctAnswer']) ?? 
                                _parseIntValue(statData['correct_count']) ?? 0;
              final incorrectCount = _parseIntValue(statData['incorrect_answer']) ?? 
                                  _parseIntValue(statData['incorrectAnswer']) ?? 
                                  _parseIntValue(statData['incorrect_count']) ?? 0;
              final totalAnswer = _parseIntValue(statData['total_answer']) ?? 
                                _parseIntValue(statData['totalAnswer']) ?? 0;
              final answeredCount = correctCount + incorrectCount;
              final totalQuestions = totalAnswer > 0 ? totalAnswer : answeredCount;
              final emptyCount = totalQuestions > answeredCount ? (totalQuestions - answeredCount) : 0;
          final isCompleted = (statData['is_completed'] as bool?) ?? 
                             (statData['isCompleted'] as bool?) ?? 
                             (emptyCount == 0 && totalQuestions > 0);

          final stats = SubcategoryStatistics(
            subcategoryId: subcategoryId,
            categoryId: categoryId,
            quizType: quizType,
            totalQuestions: totalQuestions,
            correctCount: correctCount,
            incorrectCount: incorrectCount,
            emptyCount: emptyCount,
            isCompleted: isCompleted,
          );

          statisticsMap[subcategoryId] = stats;
            }
          }
        } catch (e) {
          debugPrint('Error processing stat data: $e');
          continue;
        }
      }

      debugPrint('Fetched ${statisticsMap.length} subcategory statistics for category $categoryId');
      return statisticsMap;
    } catch (e, stackTrace) {
      debugPrint('Error fetching category statistics from API: $e');
      debugPrint('Stack trace: $stackTrace');
      return {};
    }
  }

  /// Sync statistics from API for a category
  /// This fetches statistics from the API (no longer saves to Hive - API is source of truth)
  static Future<void> syncStatisticsFromApi({
    required String categoryId,
    required String quizType, // 'funAndLearn' or 'quizZone'
  }) async {
    try {
      final quizRepository = QuizRepository();
      List<Map<String, dynamic>> apiStats;

      // Fetch from appropriate API endpoint
      if (quizType == 'funAndLearn') {
        apiStats = await quizRepository.getFunLearnStatistics(
          categoryId: categoryId,
        );
      } else if (quizType == 'quizZone') {
        apiStats = await quizRepository.getQuizZoneStatistics(
          categoryId: categoryId,
        );
      } else {
        debugPrint('Invalid quizType for sync: $quizType');
        return;
      }

      // Notify listeners that statistics were updated (API is source of truth, no Hive storage)
      // This triggers UI refresh
      for (final statData in apiStats) {
        try {
          // Check if this item has a subcategories array
          if (statData['subcategories'] != null && statData['subcategories'] is List) {
            final subcategoriesList = statData['subcategories'] as List;
            
            // Notify for each subcategory in the array
            for (final subcategoryData in subcategoriesList) {
              if (subcategoryData is! Map<String, dynamic>) continue;
              
              final subcategoryId = subcategoryData['subcategory_id']?.toString() ?? 
                                  subcategoryData['subcategoryId']?.toString() ?? '';
              if (subcategoryId.isNotEmpty) {
                QuizStatisticsNotifier.instance.notifyStatisticsUpdated(
                  categoryId: categoryId,
                  subcategoryId: subcategoryId,
                );
              }
            }
          } else {
            // Fallback: Try flat structure
          final subcategoryId = statData['subcategory_id']?.toString() ?? 
                              statData['subcategoryId']?.toString() ?? '';
          if (subcategoryId.isNotEmpty) {
            QuizStatisticsNotifier.instance.notifyStatisticsUpdated(
              categoryId: categoryId,
              subcategoryId: subcategoryId,
            );
            }
          }
        } catch (e) {
          // Continue with next item
        }
      }

      debugPrint('Synced ${apiStats.length} statistics from API for category $categoryId (API is source of truth)');
    } catch (e, stackTrace) {
      debugPrint('Error syncing statistics from API: $e');
      debugPrint('Stack trace: $stackTrace');
      // Don't throw - allow app to continue with local data
    }
  }
}
