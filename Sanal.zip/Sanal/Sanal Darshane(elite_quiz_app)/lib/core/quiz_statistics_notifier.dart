import 'package:flutter/foundation.dart';

/// Notifier to trigger UI refresh when statistics are updated
class QuizStatisticsNotifier extends ChangeNotifier {
  QuizStatisticsNotifier._();
  static final QuizStatisticsNotifier _instance = QuizStatisticsNotifier._();
  static QuizStatisticsNotifier get instance => _instance;

  /// Notify listeners that statistics have been updated
  void notifyStatisticsUpdated({
    required String categoryId,
    String? subcategoryId,
  }) {
    notifyListeners();
  }
}
