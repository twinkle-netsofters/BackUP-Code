import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutterquiz/commons/commons.dart';
import 'package:flutterquiz/core/constants/assets_constants.dart';
import 'package:flutterquiz/core/core.dart';
import 'package:flutterquiz/features/auth/cubits/auth_cubit.dart';
import 'package:flutterquiz/features/continue_play/continue_play_notifier.dart';
import 'package:flutterquiz/features/continue_play/continue_play_storage.dart';
import 'package:flutterquiz/features/continue_play/models/continue_play_session.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutterquiz/features/battle_room/cubits/battle_room_cubit.dart';
import 'package:flutterquiz/features/battle_room/cubits/multi_user_battle_room_cubit.dart';
import 'package:flutterquiz/features/exam/cubits/exam_cubit.dart';
import 'package:flutterquiz/features/profile_management/cubits/update_score_and_coins_cubit.dart';
import 'package:flutterquiz/features/profile_management/profile_management_repository.dart';
import 'package:flutterquiz/features/quiz/cubits/quiz_category_cubit.dart';
import 'package:flutterquiz/features/quiz/cubits/subcategory_cubit.dart';
import 'package:flutterquiz/features/quiz/models/quiz_type.dart';
import 'package:flutterquiz/ui/screens/battle/create_or_join_screen.dart';
import 'package:flutterquiz/ui/screens/home/widgets/continue_play_all_sessions_screen.dart';
import 'package:flutterquiz/ui/screens/quiz/category_screen.dart';
import 'package:flutterquiz/utils/extensions.dart';
import 'package:flutterquiz/utils/ui_utils.dart';

/// Widget to display Continue Play section on home screen
/// Shows the last active quiz session with progress
class ContinuePlayWidget extends StatefulWidget {
  const ContinuePlayWidget({super.key});

  @override
  State<ContinuePlayWidget> createState() => _ContinuePlayWidgetState();
}

// Note: GlobalKey removed - using ContinuePlayNotifier for real-time updates instead

class _ContinuePlayWidgetState extends State<ContinuePlayWidget>
    with WidgetsBindingObserver {
  ContinuePlaySession? _session;
  bool _isLoading = true;
  DateTime? _lastRefreshTime;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Listen to real-time updates - this ensures instant updates from anywhere
    ContinuePlayNotifier.instance.addListener(_onSessionUpdated);
    debugPrint('ContinuePlayWidget: Listener added to ContinuePlayNotifier');
    _loadSession();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    // Remove listener to prevent memory leaks
    ContinuePlayNotifier.instance.removeListener(_onSessionUpdated);
    super.dispose();
  }

  /// Called when a session is updated anywhere in the app
  void _onSessionUpdated() {
    if (!mounted) return;
    
    // Immediately update the session from the notifier
    final newSession = ContinuePlayNotifier.instance.currentSession;
    debugPrint('ContinuePlayWidget: _onSessionUpdated called');
    debugPrint('ContinuePlayWidget: Old session: $_session');
    debugPrint('ContinuePlayWidget: New session: $newSession');
    
    // Always update - let Flutter handle the diff
    // This ensures the UI updates even if the session object reference is the same
    if (mounted) {
      setState(() {
        _session = newSession;
        _isLoading = false;
        _lastRefreshTime = DateTime.now();
      });
      debugPrint('ContinuePlayWidget: State updated immediately with session: $_session');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Refresh session when app resumes
      _loadSession();
    }
  }

  @override
  void didUpdateWidget(ContinuePlayWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Refresh when widget is updated (e.g., when returning to home screen)
    _loadSession();
  }

  Future<void> _loadSession() async {
    if (!mounted) return;
    
    setState(() => _isLoading = true);
    final session = await ContinuePlayStorage.getBestSession();
    final allSessions = await ContinuePlayStorage.getAllSessions();
    
    if (mounted) {
      // Update notifier with latest data - this will trigger _onSessionUpdated
      ContinuePlayNotifier.instance.notifySessionUpdated(
        session: session,
        sessions: allSessions,
      );
      
      // Also update local state directly
      setState(() {
        _session = session;
        _isLoading = false;
        _lastRefreshTime = DateTime.now();
      });
      
      debugPrint('ContinuePlayWidget: Session loaded: $session');
    }
  }

  /// Public method to refresh the session
  void refresh() {
    _loadSession();
  }

  /// Get localized mode name for quiz type
  String _getModeName(QuizTypes quizType) {
    return switch (quizType) {
      QuizTypes.quizZone => context.tr('quizZone') ?? 'Quiz Zone',
      QuizTypes.funAndLearn => context.tr('funAndLearn') ?? 'Fun N Learn',
      QuizTypes.guessTheWord => context.tr('guessTheWord') ?? 'Guess the Word',
      QuizTypes.audioQuestions =>
        context.tr('audioQuestions') ?? 'Audio Question',
      QuizTypes.mathMania => context.tr('mathMania') ?? 'Math Mania',
      QuizTypes.dailyQuiz => context.tr('dailyQuiz') ?? 'Daily Quiz',
      QuizTypes.trueAndFalse => context.tr('truefalse') ?? 'True | False',
      QuizTypes.exam => context.tr('exam') ?? 'Exam',
      QuizTypes.selfChallenge =>
        context.tr('selfChallenge') ?? 'Self Challenge',
      QuizTypes.multiMatch => context.tr('multiMatch') ?? 'Multi match',
      QuizTypes.oneVsOneBattle => context.tr('battleQuiz') ?? '1vs1 battle',
      QuizTypes.groupPlay => context.tr('groupPlay') ?? 'Group battle',
      _ => 'Quiz',
    };
  }

  /// Clean category name by removing the word "Category"
  String _cleanCategoryName(String categoryName) {
    if (categoryName.isEmpty) return categoryName;
    
    // Remove "Category" word (case-insensitive, whole word only)
    String cleaned = categoryName
        .replaceAll(RegExp(r'\bCategory\b', caseSensitive: false), '')
        .trim();
    
    // Clean up any extra spaces, dashes, or punctuation
    cleaned = cleaned
        .replaceAll(RegExp(r'[\s\-_]+'), ' ') // Replace multiple spaces/dashes with single space
        .trim();
    
    return cleaned;
  }

  /// Get the category name to display (top line - main title)
  /// Shows cleaned category name or mode name
  String _getCategoryDisplayName(ContinuePlaySession session) {
    // For quiz types without categories (Daily Quiz, True|False), show mode name
    if (session.quizType == QuizTypes.dailyQuiz ||
        session.quizType == QuizTypes.trueAndFalse) {
      return _getModeName(session.quizType);
    }
    
    // For battle and multiMatch types, always show mode name
    if (session.quizType == QuizTypes.multiMatch ||
        session.quizType == QuizTypes.oneVsOneBattle ||
        session.quizType == QuizTypes.groupPlay) {
      return _getModeName(session.quizType);
    }
    
    // For all quiz types: show cleaned category name as main title
    final cleanedName = _cleanCategoryName(session.categoryName);
    
    // If after cleaning we have nothing, use mode name as fallback
    if (cleanedName.isEmpty) {
      return _getModeName(session.quizType);
    }
    
    return cleanedName;
  }

  /// Get the subcategory name to display (second line - subtitle)
  /// Shows subcategory name if available, otherwise mode name
  String _getSubcategoryDisplayName(ContinuePlaySession session) {
    // For quiz types without categories (Daily Quiz, True|False), show mode name on second line
    if (session.quizType == QuizTypes.dailyQuiz ||
        session.quizType == QuizTypes.trueAndFalse) {
      return _getModeName(session.quizType);
    }
    
    // For battle and multiMatch types, always show mode name
    if (session.quizType == QuizTypes.multiMatch ||
        session.quizType == QuizTypes.oneVsOneBattle ||
        session.quizType == QuizTypes.groupPlay) {
      return _getModeName(session.quizType);
    }
    
    // For Quiz Zone and Fun'N'Learn: show subcategory name if available
    if ((session.quizType == QuizTypes.quizZone ||
         session.quizType == QuizTypes.funAndLearn) &&
        session.subcategoryName != null &&
        session.subcategoryName!.isNotEmpty) {
      return session.subcategoryName!;
    }
    
    // For other quiz types: show subcategory name if available, otherwise mode name
    if (session.subcategoryName != null && session.subcategoryName!.isNotEmpty) {
      return session.subcategoryName!;
    }
    
    return _getModeName(session.quizType);
  }

  /// Get the icon asset path for a quiz type
  String _getModeIcon(QuizTypes quizType) {
    return switch (quizType) {
      QuizTypes.dailyQuiz => Assets.dailyQuizIcon,
      QuizTypes.trueAndFalse => Assets.trueFalseQuizIcon,
      QuizTypes.funAndLearn => Assets.funNLearnIcon,
      QuizTypes.guessTheWord => Assets.guessTheWordIcon,
      QuizTypes.audioQuestions => Assets.audioQuizIcon,
      QuizTypes.mathMania => Assets.mathsQuizIcon,
      QuizTypes.exam => Assets.examQuizIcon,
      QuizTypes.selfChallenge => Assets.selfChallengeIcon,
      QuizTypes.quizZone => Assets.quizZoneNavIcon,
      QuizTypes.multiMatch => Assets.multiMatchIcon,
      QuizTypes.oneVsOneBattle => Assets.oneVsOneIcon,
      QuizTypes.groupPlay => Assets.groupBattleIcon,
      _ => Assets.quizZoneNavIcon,
    };
  }

  /// Get the display image for the session
  /// Returns category/subcategory image if available, otherwise mode icon
  String _getDisplayImage(ContinuePlaySession session) {
    // For quiz types without categories, always use mode icon
    if (session.quizType == QuizTypes.dailyQuiz ||
        session.quizType == QuizTypes.trueAndFalse) {
      return _getModeIcon(session.quizType);
    }

    // For other types, prefer category/subcategory image, fallback to mode icon
    if (session.displayImage.isNotEmpty) {
      return session.displayImage;
    }

    return _getModeIcon(session.quizType);
  }

  /// Check if the image is a local asset (SVG) or network image
  bool _isLocalAsset(String imagePath) {
    return imagePath.startsWith('assets/') || imagePath.endsWith('.svg');
  }

  /// Build the category icon widget
  Widget _buildCategoryIcon(ContinuePlaySession session) {
    final imagePath = _getDisplayImage(session);

    // If it's a local asset (SVG), use SvgPicture
    if (_isLocalAsset(imagePath)) {
      return SvgPicture.asset(
        imagePath,
        fit: BoxFit.contain,
        width: 40,
        height: 40,
        colorFilter: ColorFilter.mode(
          Theme.of(context).primaryColor,
          BlendMode.srcIn,
        ),
      );
    }

    // Otherwise, it's a network image
    return CachedNetworkImage(
      imageUrl: imagePath,
      fit: BoxFit.cover,
      width: 40,
      height: 40,
      errorWidget: (_, __, ___) => SvgPicture.asset(
        _getModeIcon(session.quizType),
        fit: BoxFit.contain,
        width: 40,
        height: 40,
        colorFilter: ColorFilter.mode(
          Theme.of(context).primaryColor,
          BlendMode.srcIn,
        ),
      ),
      placeholder: (_, __) => SvgPicture.asset(
        _getModeIcon(session.quizType),
        fit: BoxFit.contain,
        width: 40,
        height: 40,
        colorFilter: ColorFilter.mode(
          Theme.of(context).primaryColor,
          BlendMode.srcIn,
        ),
      ),
    );
  }

  void _onTapViewAll() {
    if (context.read<AuthCubit>().isGuest) {
      showLoginRequiredDialog(context);
      return;
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const ContinuePlayAllSessionsScreen(),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        if (difference.inMinutes == 0) {
          return 'Just now';
        }
        return '${difference.inMinutes} ${difference.inMinutes == 1 ? 'minute' : 'minutes'} ago';
      }
      return '${difference.inHours} ${difference.inHours == 1 ? 'hour' : 'hours'} ago';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  void _onTapContinue() {
    if (context.read<AuthCubit>().isGuest) {
      showLoginRequiredDialog(context);
      return;
    }

    if (_session == null) return;

    final quizType = _session!.quizType;

    // Navigate based on quiz type
    switch (quizType) {
      case QuizTypes.dailyQuiz:
      case QuizTypes.trueAndFalse:
        // Navigate directly to quiz screen
        Navigator.of(context).pushNamed(
          Routes.quiz,
          arguments: {'quizType': quizType},
        );
        break;

      case QuizTypes.quizZone:
      case QuizTypes.funAndLearn:
      case QuizTypes.guessTheWord:
      case QuizTypes.audioQuestions:
      case QuizTypes.mathMania:
        // Navigate to category screen, then user can select subcategory
        context.read<QuizCategoryCubit>().updateState(QuizCategoryInitial());
        context.read<SubCategoryCubit>().updateState(SubCategoryInitial());
        Navigator.of(context).pushNamed(
          Routes.category,
          arguments: CategoryScreenArgs(quizType: quizType),
        );
        break;

      case QuizTypes.exam:
        context.read<ExamCubit>().updateState(ExamInitial());
        Navigator.of(context).pushNamed(Routes.exams);
        break;

      case QuizTypes.selfChallenge:
        context.read<QuizCategoryCubit>().updateState(QuizCategoryInitial());
        context.read<SubCategoryCubit>().updateState(SubCategoryInitial());
        Navigator.of(context).pushNamed(Routes.selfChallenge);
        break;

      case QuizTypes.multiMatch:
        // Navigate to category screen for multiMatch
        context.read<QuizCategoryCubit>().updateState(QuizCategoryInitial());
        context.read<SubCategoryCubit>().updateState(SubCategoryInitial());
        Navigator.of(context).pushNamed(
          Routes.category,
          arguments: CategoryScreenArgs(quizType: QuizTypes.multiMatch),
        );
        break;

      case QuizTypes.oneVsOneBattle:
        // Navigate to battle room create/join screen
        context.read<BattleRoomCubit>().updateState(
          BattleRoomInitial(),
          cancelSubscription: true,
        );
        Navigator.of(context).push(
          CupertinoPageRoute<void>(
            builder: (_) => BlocProvider<UpdateCoinsCubit>(
              create: (context) =>
                  UpdateCoinsCubit(ProfileManagementRepository()),
              child: CreateOrJoinRoomScreen(
                quizType: QuizTypes.oneVsOneBattle,
                title: context.tr('battleQuiz') ?? 'Battle Quiz',
              ),
            ),
          ),
        );
        break;

      case QuizTypes.groupPlay:
        // Navigate to group battle create/join screen
        context.read<MultiUserBattleRoomCubit>().updateState(
          MultiUserBattleRoomInitial(),
        );
        Navigator.of(context).push(
          CupertinoPageRoute<void>(
            builder: (_) => BlocProvider<UpdateCoinsCubit>(
              create: (context) =>
                  UpdateCoinsCubit(ProfileManagementRepository()),
              child: CreateOrJoinRoomScreen(
                quizType: QuizTypes.groupPlay,
                title: context.tr('groupPlay') ?? 'Group Play',
              ),
            ),
          ),
        );
        break;

      case QuizTypes.contest:
      case QuizTypes.randomBattle:
      case QuizTypes.bookmarkQuiz:
        // These quiz types don't support Continue Play navigation
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    // Don't show for guests
    if (context.read<AuthCubit>().isGuest) {
      return const SizedBox.shrink();
    }

    if (_isLoading) {
      return const SizedBox.shrink();
    }

    if (_session == null) {
      return const SizedBox.shrink();
    }

    final session = _session!;
    final hzMargin = context.width * UiUtils.hzMarginPct;

    return Padding(
      padding: EdgeInsets.only(
        left: hzMargin,
        right: hzMargin,
        top: context.height * 0.02,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section Title with View All button
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                context.tr('Continue Play') ?? 'Continue Play',
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeights.semiBold,
                  color: context.primaryTextColor,
                ),
              ),
              TextButton(
                onPressed: _onTapViewAll,
                style: TextButton.styleFrom(
                  padding: EdgeInsets.zero,
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  context.tr('viewAll') ?? 'View All',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeights.regular,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Continue Play Card
          GestureDetector(
            onTap: _onTapContinue,
            child: Container(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    offset: const Offset(0, 2),
                    blurRadius: 4,
                    color: Colors.black.withValues(alpha: 0.1),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  // Category Icon
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: Theme.of(context).scaffoldBackgroundColor,
                      ),
                    ),
                    padding: const EdgeInsets.all(5),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: _buildCategoryIcon(session),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Category Details
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Line 1: Mode
                        Text(
                          _getModeName(session.quizType),
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeights.semiBold,
                            color: Theme.of(context).colorScheme.onTertiary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),

                        // Line 2: Category Name/Sub-Category Name
                        Text(
                          _getCategorySubcategoryDisplayName(session),
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeights.regular,
                            color: Theme.of(context)
                                .colorScheme
                                .onTertiary
                                .withValues(alpha: 0.6),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 8),

                        // Progress Bar
                        Row(
                          children: [
                            Expanded(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  value: session.progressPercentage / 100,
                                  minHeight: 6,
                                  backgroundColor: Theme.of(context)
                                      .scaffoldBackgroundColor,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    session.isCompleted
                                        ? Colors.green
                                        : Theme.of(context).primaryColor,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            // Progress Text
                            Text(
                              '${session.attemptedQuestions}/${session.totalQuestions}',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeights.regular,
                                color: Theme.of(context)
                                    .colorScheme
                                    .onTertiary
                                    .withValues(alpha: 0.7),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),

                        // Line 3: Last Played Time
                        Text(
                          _formatDate(session.lastPlayedAt),
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeights.regular,
                            color: Theme.of(context)
                                .colorScheme
                                .onTertiary
                                .withValues(alpha: 0.5),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Get Category Name/Sub-Category Name display format
  String _getCategorySubcategoryDisplayName(ContinuePlaySession session) {
    // For quiz types without categories (Daily Quiz, True|False)
    if (session.quizType == QuizTypes.dailyQuiz ||
        session.quizType == QuizTypes.trueAndFalse) {
      return _getModeName(session.quizType);
    }
    
    // For battle and multiMatch types, always show mode name
    if (session.quizType == QuizTypes.multiMatch ||
        session.quizType == QuizTypes.oneVsOneBattle ||
        session.quizType == QuizTypes.groupPlay) {
      return _getModeName(session.quizType);
    }
    
    final categoryName = _getCategoryDisplayName(session);
    final subcategoryName = _getSubcategoryDisplayName(session);
    
    // If we have both category and subcategory, show "Category/Subcategory"
    if (categoryName.isNotEmpty && 
        subcategoryName.isNotEmpty && 
        subcategoryName != categoryName &&
        subcategoryName != _getModeName(session.quizType)) {
      return '$categoryName/$subcategoryName';
    }
    
    // If we only have category name, show just category
    if (categoryName.isNotEmpty && categoryName != _getModeName(session.quizType)) {
      return categoryName;
    }
    
    // If we only have subcategory name, show just subcategory
    if (subcategoryName.isNotEmpty && subcategoryName != _getModeName(session.quizType)) {
      return subcategoryName;
    }
    
    // Fallback to mode name
    return _getModeName(session.quizType);
  }
}
