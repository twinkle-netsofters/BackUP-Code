import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutterquiz/commons/commons.dart';
import 'package:flutterquiz/core/constants/assets_constants.dart';
import 'package:flutterquiz/core/core.dart';
import 'package:flutterquiz/features/auth/cubits/auth_cubit.dart';
import 'package:flutterquiz/features/battle_room/cubits/battle_room_cubit.dart';
import 'package:flutterquiz/features/battle_room/cubits/multi_user_battle_room_cubit.dart';
import 'package:flutterquiz/features/continue_play/continue_play_notifier.dart';
import 'package:flutterquiz/features/continue_play/continue_play_storage.dart';
import 'package:flutterquiz/features/continue_play/models/continue_play_session.dart';
import 'package:flutterquiz/features/exam/cubits/exam_cubit.dart';
import 'package:flutterquiz/features/profile_management/cubits/update_score_and_coins_cubit.dart';
import 'package:flutterquiz/features/profile_management/profile_management_repository.dart';
import 'package:flutterquiz/features/quiz/cubits/quiz_category_cubit.dart';
import 'package:flutterquiz/features/quiz/cubits/subcategory_cubit.dart';
import 'package:flutterquiz/features/quiz/models/quiz_type.dart';
import 'package:flutterquiz/features/quiz/models/subcategory.dart';
import 'package:flutterquiz/features/quiz/quiz_repository.dart';
import 'package:flutterquiz/ui/screens/battle/create_or_join_screen.dart';
import 'package:flutterquiz/ui/screens/quiz/category_screen.dart';
import 'package:flutterquiz/ui/widgets/all.dart';
import 'package:flutterquiz/utils/extensions.dart';
import 'package:flutterquiz/utils/ui_utils.dart';

/// Screen to display all recent Continue Play sessions
class ContinuePlayAllSessionsScreen extends StatefulWidget {
  const ContinuePlayAllSessionsScreen({super.key});

  @override
  State<ContinuePlayAllSessionsScreen> createState() =>
      _ContinuePlayAllSessionsScreenState();
}

class _ContinuePlayAllSessionsScreenState
    extends State<ContinuePlayAllSessionsScreen> {
  List<ContinuePlaySession> _sessions = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    // Listen to real-time updates
    ContinuePlayNotifier.instance.addListener(_onSessionsUpdated);
    _loadSessions();
  }

  @override
  void dispose() {
    // Remove listener to prevent memory leaks
    ContinuePlayNotifier.instance.removeListener(_onSessionsUpdated);
    super.dispose();
  }

  /// Called when sessions are updated anywhere in the app
  void _onSessionsUpdated() {
    if (!mounted) return;
    
    // Immediately update sessions from the notifier
    final newSessions = ContinuePlayNotifier.instance.allSessions;
    final newCurrentSession = ContinuePlayNotifier.instance.currentSession;
    debugPrint('ContinuePlayAllSessionsScreen: _onSessionsUpdated called, ${newSessions.length} sessions');
    
    // Deduplicate by category, keeping only the latest entry for each category
    final deduplicatedSessions = _deduplicateByCategory(newSessions);
    
    // Use WidgetsBinding to ensure setState is called safely
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() {
          _sessions = deduplicatedSessions;
          _isLoading = false;
        });
        debugPrint('ContinuePlayAllSessionsScreen: State updated with ${deduplicatedSessions.length} deduplicated sessions');
      }
    });
  }

  /// Deduplicate sessions by category, keeping only the latest entry for each category
  /// For Quiz Zone and Fun'N'Learn: group by quizType + cleaned categoryName (not categoryId)
  /// For other quiz types: group by quizType + categoryId
  List<ContinuePlaySession> _deduplicateByCategory(List<ContinuePlaySession> sessions) {
    // Create a map to track the latest session for each category
    final Map<String, ContinuePlaySession> categoryMap = {};
    
    // Sort sessions by lastPlayedAt (most recent first) to ensure we keep the latest
    final sortedSessions = List<ContinuePlaySession>.from(sessions)
      ..sort((a, b) => b.lastPlayedAt.compareTo(a.lastPlayedAt));
    
    // For each session, keep only the latest one per category
    for (final session in sortedSessions) {
      String categoryKey;
      
      // For quiz types without categories (dailyQuiz, trueAndFalse), use quizType only
      if (session.quizType == QuizTypes.dailyQuiz ||
          session.quizType == QuizTypes.trueAndFalse) {
        categoryKey = session.quizType.name;
      }
      // For Quiz Zone and Fun'N'Learn: group by quizType + cleaned categoryName
      // This ensures that different category IDs with the same name are treated as one category
      else if (session.quizType == QuizTypes.quizZone ||
               session.quizType == QuizTypes.funAndLearn) {
        final cleanedCategoryName = _cleanCategoryName(session.categoryName);
        categoryKey = '${session.quizType.name}_${cleanedCategoryName.isEmpty ? session.categoryId : cleanedCategoryName}';
      }
      // For other quiz types: use quizType + categoryId
      else {
        categoryKey = '${session.quizType.name}_${session.categoryId}';
      }
      
      // Only add if we haven't seen this category yet (since we sorted by date, first = latest)
      if (!categoryMap.containsKey(categoryKey)) {
        categoryMap[categoryKey] = session;
        debugPrint('ContinuePlayAllSessionsScreen: Added session for category key: $categoryKey (categoryId: ${session.categoryId}, categoryName: ${session.categoryName}, played: ${session.lastPlayedAt})');
      }
    }
    
    // Return deduplicated sessions, sorted by lastPlayedAt (most recent first)
    final deduplicated = categoryMap.values.toList()
      ..sort((a, b) => b.lastPlayedAt.compareTo(a.lastPlayedAt));
    
    debugPrint('ContinuePlayAllSessionsScreen: Deduplication complete: ${sessions.length} -> ${deduplicated.length} sessions');
    return deduplicated;
  }

  /// Fetch missing subcategory names for sessions that have subcategoryId but no subcategoryName
  Future<List<ContinuePlaySession>> _enrichSessionsWithSubcategoryNames(
      List<ContinuePlaySession> sessions) async {
    final enrichedSessions = <ContinuePlaySession>[];
    final quizRepository = QuizRepository();

    for (final session in sessions) {
      // Only fetch for Quiz Zone and Fun'N'Learn that have subcategoryId but no subcategoryName
      if ((session.quizType == QuizTypes.quizZone ||
              session.quizType == QuizTypes.funAndLearn) &&
          (session.subcategoryId != null &&
              session.subcategoryId!.isNotEmpty &&
              session.subcategoryId != '0') &&
          (session.subcategoryName == null ||
              session.subcategoryName!.isEmpty)) {
        try {
          // Fetch subcategories for this category
          final subcategories = await quizRepository.getSubCategory(session.categoryId);
          
          // Find the matching subcategory
          final subcategory = subcategories.firstWhere(
            (s) => s.id == session.subcategoryId,
            orElse: () => const Subcategory(
              isPlayed: false,
              requiredCoins: 0,
            ),
          );

          // If we found a subcategory with a name, create an enriched session
          if (subcategory.subcategoryName != null &&
              subcategory.subcategoryName!.isNotEmpty) {
            final enrichedSession = session.copyWith(
              subcategoryName: subcategory.subcategoryName,
              subcategoryImage: subcategory.image,
            );
            enrichedSessions.add(enrichedSession);
            debugPrint(
                'ContinuePlayAllSessionsScreen: Enriched session ${session.quizType.name} with subcategory name: ${subcategory.subcategoryName}');
            
            // Save the enriched session back to storage
            await ContinuePlayStorage.saveSession(enrichedSession);
            continue;
          }
        } catch (e) {
          debugPrint(
              'ContinuePlayAllSessionsScreen: Error fetching subcategory name: $e');
        }
      }
      
      // Keep the original session if we couldn't enrich it
      enrichedSessions.add(session);
    }

    return enrichedSessions;
  }

  Future<void> _loadSessions() async {
    setState(() => _isLoading = true);
    final allSessions = await ContinuePlayStorage.getAllSessions();
    
    // Enrich sessions with missing subcategory names
    final enrichedSessions = await _enrichSessionsWithSubcategoryNames(allSessions);
    
    // Deduplicate by category, keeping only the latest entry for each category
    final deduplicatedSessions = _deduplicateByCategory(enrichedSessions);
    final bestSession = await ContinuePlayStorage.getBestSession();
    
    if (mounted) {
      // Update notifier with latest data (use enriched sessions for notifier)
      ContinuePlayNotifier.instance.notifySessionUpdated(
        session: bestSession,
        sessions: enrichedSessions,
      );
      
      setState(() {
        _sessions = deduplicatedSessions;
        _isLoading = false;
      });
      
      debugPrint('ContinuePlayAllSessionsScreen: Sessions loaded: ${allSessions.length} total, ${deduplicatedSessions.length} after deduplication');
    }
  }

  /// Get localized mode name for quiz type
  String _getModeName(QuizTypes quizType) {
    return switch (quizType) {
      QuizTypes.quizZone => context.tr('quizZone') ?? 'Quiz Zone',
      QuizTypes.funAndLearn => context.tr('funAndLearn') ?? 'Fun N Learn',
      QuizTypes.guessTheWord => context.tr('guessTheWord') ?? 'Guess the Word',
      QuizTypes.audioQuestions =>
        context.tr('audioQuestions') ?? 'Audio Question',
      QuizTypes.mathMania => context.tr('mathMania') ?? 'Math Mania',
      QuizTypes.dailyQuiz => context.tr('dailyQuiz') ?? 'Daily Quiz',
      QuizTypes.trueAndFalse => context.tr('truefalse') ?? 'True | False',
      QuizTypes.exam => context.tr('exam') ?? 'Exam',
      QuizTypes.selfChallenge =>
        context.tr('selfChallenge') ?? 'Self Challenge',
      QuizTypes.multiMatch => context.tr('multiMatch') ?? 'Multi match',
      QuizTypes.oneVsOneBattle => context.tr('battleQuiz') ?? '1vs1 battle',
      QuizTypes.groupPlay => context.tr('groupPlay') ?? 'Group battle',
      _ => 'Quiz',
    };
  }

  /// Clean category name by removing the word "Category"
  String _cleanCategoryName(String categoryName) {
    if (categoryName.isEmpty) return categoryName;
    
    // Remove "Category" word (case-insensitive, whole word only)
    String cleaned = categoryName
        .replaceAll(RegExp(r'\bCategory\b', caseSensitive: false), '')
        .trim();
    
    // Clean up any extra spaces, dashes, or punctuation
    cleaned = cleaned
        .replaceAll(RegExp(r'[\s\-_]+'), ' ') // Replace multiple spaces/dashes with single space
        .trim();
    
    return cleaned;
  }

  /// Get the category name to display (top line - main title)
  /// Shows cleaned category name or mode name
  String _getCategoryDisplayName(ContinuePlaySession session) {
    // For quiz types without categories (Daily Quiz, True|False), show mode name
    if (session.quizType == QuizTypes.dailyQuiz ||
        session.quizType == QuizTypes.trueAndFalse) {
      return _getModeName(session.quizType);
    }
    
    // For battle and multiMatch types, always show mode name
    if (session.quizType == QuizTypes.multiMatch ||
        session.quizType == QuizTypes.oneVsOneBattle ||
        session.quizType == QuizTypes.groupPlay) {
      return _getModeName(session.quizType);
    }
    
    // For all quiz types: show cleaned category name as main title
    final cleanedName = _cleanCategoryName(session.categoryName);
    
    // If after cleaning we have nothing, use mode name as fallback
    if (cleanedName.isEmpty) {
      return _getModeName(session.quizType);
    }
    
    return cleanedName;
  }

  /// Get the subcategory name to display (second line - subtitle)
  /// Shows subcategory name if available, otherwise mode name
  String _getSubcategoryDisplayName(ContinuePlaySession session) {
    // For quiz types without categories (Daily Quiz, True|False), show mode name on second line
    if (session.quizType == QuizTypes.dailyQuiz ||
        session.quizType == QuizTypes.trueAndFalse) {
      return _getModeName(session.quizType);
    }
    
    // For battle and multiMatch types, always show mode name
    if (session.quizType == QuizTypes.multiMatch ||
        session.quizType == QuizTypes.oneVsOneBattle ||
        session.quizType == QuizTypes.groupPlay) {
      return _getModeName(session.quizType);
    }
    
    // For Quiz Zone and Fun'N'Learn: show subcategory name if available
    if ((session.quizType == QuizTypes.quizZone ||
         session.quizType == QuizTypes.funAndLearn) &&
        session.subcategoryName != null &&
        session.subcategoryName!.isNotEmpty) {
      return session.subcategoryName!;
    }
    
    // For other quiz types: show subcategory name if available, otherwise mode name
    if (session.subcategoryName != null && session.subcategoryName!.isNotEmpty) {
      return session.subcategoryName!;
    }
    
    return _getModeName(session.quizType);
  }

  /// Get the icon asset path for a quiz type
  String _getModeIcon(QuizTypes quizType) {
    return switch (quizType) {
      QuizTypes.dailyQuiz => Assets.dailyQuizIcon,
      QuizTypes.trueAndFalse => Assets.trueFalseQuizIcon,
      QuizTypes.funAndLearn => Assets.funNLearnIcon,
      QuizTypes.guessTheWord => Assets.guessTheWordIcon,
      QuizTypes.audioQuestions => Assets.audioQuizIcon,
      QuizTypes.mathMania => Assets.mathsQuizIcon,
      QuizTypes.exam => Assets.examQuizIcon,
      QuizTypes.selfChallenge => Assets.selfChallengeIcon,
      QuizTypes.quizZone => Assets.quizZoneNavIcon,
      QuizTypes.multiMatch => Assets.multiMatchIcon,
      QuizTypes.oneVsOneBattle => Assets.oneVsOneIcon,
      QuizTypes.groupPlay => Assets.groupBattleIcon,
      _ => Assets.quizZoneNavIcon,
    };
  }

  /// Get the display image for the session
  String _getDisplayImage(ContinuePlaySession session) {
    if (session.quizType == QuizTypes.dailyQuiz ||
        session.quizType == QuizTypes.trueAndFalse) {
      return _getModeIcon(session.quizType);
    }

    if (session.displayImage.isNotEmpty) {
      return session.displayImage;
    }

    return _getModeIcon(session.quizType);
  }

  /// Check if the image is a local asset (SVG) or network image
  bool _isLocalAsset(String imagePath) {
    return imagePath.startsWith('assets/') || imagePath.endsWith('.svg');
  }

  /// Build the category icon widget
  Widget _buildCategoryIcon(ContinuePlaySession session) {
    final imagePath = _getDisplayImage(session);

    if (_isLocalAsset(imagePath)) {
      return SvgPicture.asset(
        imagePath,
        fit: BoxFit.contain,
        width: 50,
        height: 50,
        colorFilter: ColorFilter.mode(
          Theme.of(context).primaryColor,
          BlendMode.srcIn,
        ),
      );
    }

    return CachedNetworkImage(
      imageUrl: imagePath,
      fit: BoxFit.cover,
      width: 50,
      height: 50,
      errorWidget: (_, __, ___) => SvgPicture.asset(
        _getModeIcon(session.quizType),
        fit: BoxFit.contain,
        width: 50,
        height: 50,
        colorFilter: ColorFilter.mode(
          Theme.of(context).primaryColor,
          BlendMode.srcIn,
        ),
      ),
      placeholder: (_, __) => SvgPicture.asset(
        _getModeIcon(session.quizType),
        fit: BoxFit.contain,
        width: 50,
        height: 50,
        colorFilter: ColorFilter.mode(
          Theme.of(context).primaryColor,
          BlendMode.srcIn,
        ),
      ),
    );
  }

  void _onTapSession(ContinuePlaySession session) {
    final quizType = session.quizType;

    switch (quizType) {
      case QuizTypes.dailyQuiz:
      case QuizTypes.trueAndFalse:
        Navigator.of(context).pushNamed(
          Routes.quiz,
          arguments: {'quizType': quizType},
        );
        break;

      case QuizTypes.quizZone:
      case QuizTypes.funAndLearn:
      case QuizTypes.guessTheWord:
      case QuizTypes.audioQuestions:
      case QuizTypes.mathMania:
        context.read<QuizCategoryCubit>().updateState(QuizCategoryInitial());
        context.read<SubCategoryCubit>().updateState(SubCategoryInitial());
        Navigator.of(context).pushNamed(
          Routes.category,
          arguments: CategoryScreenArgs(quizType: quizType),
        );
        break;

      case QuizTypes.exam:
        context.read<ExamCubit>().updateState(ExamInitial());
        Navigator.of(context).pushNamed(Routes.exams);
        break;

      case QuizTypes.selfChallenge:
        context.read<QuizCategoryCubit>().updateState(QuizCategoryInitial());
        context.read<SubCategoryCubit>().updateState(SubCategoryInitial());
        Navigator.of(context).pushNamed(Routes.selfChallenge);
        break;

      case QuizTypes.multiMatch:
        // Navigate to category screen for multiMatch
        context.read<QuizCategoryCubit>().updateState(QuizCategoryInitial());
        context.read<SubCategoryCubit>().updateState(SubCategoryInitial());
        Navigator.of(context).pushNamed(
          Routes.category,
          arguments: CategoryScreenArgs(quizType: QuizTypes.multiMatch),
        );
        break;

      case QuizTypes.oneVsOneBattle:
        // Navigate to battle room create/join screen
        context.read<BattleRoomCubit>().updateState(
          BattleRoomInitial(),
          cancelSubscription: true,
        );
        Navigator.of(context).push(
          CupertinoPageRoute<void>(
            builder: (_) => BlocProvider<UpdateCoinsCubit>(
              create: (context) =>
                  UpdateCoinsCubit(ProfileManagementRepository()),
              child: CreateOrJoinRoomScreen(
                quizType: QuizTypes.oneVsOneBattle,
                title: context.tr('battleQuiz') ?? 'Battle Quiz',
              ),
            ),
          ),
        );
        break;

      case QuizTypes.groupPlay:
        // Navigate to group battle create/join screen
        context.read<MultiUserBattleRoomCubit>().updateState(
          MultiUserBattleRoomInitial(),
        );
        Navigator.of(context).push(
          CupertinoPageRoute<void>(
            builder: (_) => BlocProvider<UpdateCoinsCubit>(
              create: (context) =>
                  UpdateCoinsCubit(ProfileManagementRepository()),
              child: CreateOrJoinRoomScreen(
                quizType: QuizTypes.groupPlay,
                title: context.tr('groupPlay') ?? 'Group Play',
              ),
            ),
          ),
        );
        break;

      default:
        break;
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        if (difference.inMinutes == 0) {
          return 'Just now';
        }
        return '${difference.inMinutes} ${difference.inMinutes == 1 ? 'minute' : 'minutes'} ago';
      }
      return '${difference.inHours} ${difference.inHours == 1 ? 'hour' : 'hours'} ago';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: QAppBar(
        title: Text(context.tr('Continue Play') ?? 'Continue Play'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressContainer())
          : _sessions.isEmpty
              ? Center(
                  child: ErrorContainer(
                    showBackButton: false,
                    errorMessage: 'No recent quiz sessions found',
                    onTapRetry: _loadSessions,
                    showErrorImage: true,
                    errorMessageColor: Theme.of(context).primaryColor,
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadSessions,
                  color: Theme.of(context).primaryColor,
                  child: ListView.builder(
                    padding: EdgeInsets.all(context.width * UiUtils.hzMarginPct),
                    itemCount: _sessions.length,
                    itemBuilder: (context, index) {
                      final session = _sessions[index];
                      return _buildSessionCard(session);
                    },
                  ),
                ),
    );
  }

  Widget _buildSessionCard(ContinuePlaySession session) {
    // Debug: Log session details
    if (session.quizType == QuizTypes.quizZone || session.quizType == QuizTypes.funAndLearn) {
      debugPrint('ContinuePlayAllSessionsScreen: Building card for ${session.quizType.name} - categoryId: ${session.categoryId}, subcategoryId: ${session.subcategoryId}, subcategoryName: ${session.subcategoryName}, categoryName: ${session.categoryName}');
    }
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: InkWell(
        onTap: () => _onTapSession(session),
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              // Category Icon
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Theme.of(context).scaffoldBackgroundColor,
                  ),
                ),
                padding: const EdgeInsets.all(5),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: _buildCategoryIcon(session),
                ),
              ),
              const SizedBox(width: 12),

              // Category Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Line 1: Mode
                    Text(
                      _getModeName(session.quizType),
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeights.semiBold,
                        color: Theme.of(context).colorScheme.onTertiary,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),

                    // Line 2: Category Name/Sub-Category Name
                    Text(
                      _getCategorySubcategoryDisplayName(session),
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeights.regular,
                        color: Theme.of(context)
                            .colorScheme
                            .onTertiary
                            .withValues(alpha: 0.6),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),

                    // Progress Bar
                    Row(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: session.progressPercentage / 100,
                              minHeight: 6,
                              backgroundColor: Theme.of(context)
                                  .scaffoldBackgroundColor,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                session.isCompleted
                                    ? Colors.green
                                    : Theme.of(context).primaryColor,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        // Progress Text
                        Text(
                          '${session.attemptedQuestions}/${session.totalQuestions}',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeights.regular,
                            color: Theme.of(context)
                                .colorScheme
                                .onTertiary
                                .withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),

                    // Line 3: Status and Last Played Time
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Completion Status
                        Text(
                          session.isCompleted
                              ? (context.tr('completed') ?? 'Completed')
                              : (context.tr('inProgress') ?? 'In Progress'),
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeights.regular,
                            color: session.isCompleted
                                ? Colors.green
                                : Theme.of(context).primaryColor,
                          ),
                        ),
                        // Last Played Time
                        Text(
                          _formatDate(session.lastPlayedAt),
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeights.regular,
                            color: Theme.of(context)
                                .colorScheme
                                .onTertiary
                                .withValues(alpha: 0.5),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Get Category Name/Sub-Category Name display format
  String _getCategorySubcategoryDisplayName(ContinuePlaySession session) {
    // For quiz types without categories (Daily Quiz, True|False)
    if (session.quizType == QuizTypes.dailyQuiz ||
        session.quizType == QuizTypes.trueAndFalse) {
      return _getModeName(session.quizType);
    }
    
    // For battle and multiMatch types, always show mode name
    if (session.quizType == QuizTypes.multiMatch ||
        session.quizType == QuizTypes.oneVsOneBattle ||
        session.quizType == QuizTypes.groupPlay) {
      return _getModeName(session.quizType);
    }
    
    final categoryName = _getCategoryDisplayName(session);
    final subcategoryName = _getSubcategoryDisplayName(session);
    
    // If we have both category and subcategory, show "Category/Subcategory"
    if (categoryName.isNotEmpty && 
        subcategoryName.isNotEmpty && 
        subcategoryName != categoryName &&
        subcategoryName != _getModeName(session.quizType)) {
      return '$categoryName/$subcategoryName';
    }
    
    // If we only have category name, show just category
    if (categoryName.isNotEmpty && categoryName != _getModeName(session.quizType)) {
      return categoryName;
    }
    
    // If we only have subcategory name, show just subcategory
    if (subcategoryName.isNotEmpty && subcategoryName != _getModeName(session.quizType)) {
      return subcategoryName;
    }
    
    // Fallback to mode name
    return _getModeName(session.quizType);
  }
}

