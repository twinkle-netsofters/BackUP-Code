// // // import 'package:flutter/material.dart';
// // // import 'package:youtube_player_iframe/youtube_player_iframe.dart';
// // //
// // //
// // // class YoutubePlayerPage extends StatefulWidget {
// // //   final String url;
// // //   const YoutubePlayerPage({required this.url,super.key});
// // //
// // //   @override
// // //   State<YoutubePlayerPage> createState() => _YoutubePlayerPageState();
// // // }
// // //
// // // class _YoutubePlayerPageState extends State<YoutubePlayerPage> {
// // //   late YoutubePlayerController _controller;
// // //   bool _isPlaying = false;
// // //
// // //   @override
// // //   void initState() {
// // //     super.initState();
// // //
// // //     _controller = YoutubePlayerController.fromVideoId(
// // //       videoId: "-2-W-Sa6rWM",
// // //       autoPlay: true,
// // //       params: const YoutubePlayerParams(
// // //         showControls: true,
// // //         showFullscreenButton: true,
// // //         enableCaption: false,   // ⛔ Disable subtitles
// // //       ),
// // //     );
// // //
// // //     // Listen for player state changes
// // //     _controller.listen((event) {
// // //       setState(() {
// // //         _isPlaying = event.playerState == PlayerState.playing;
// // //       });
// // //     });
// // //   }
// // //
// // //   @override
// // //   void dispose() {
// // //     _controller.close();
// // //     super.dispose();
// // //   }
// // //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return Scaffold(
// // //       appBar: AppBar(title: const Text("YouTube Player")),
// // //       body: Column(
// // //         children: [
// // //           // Player
// // //           YoutubePlayer(
// // //             controller: _controller,
// // //             aspectRatio: 16 / 9,
// // //           ),
// // //
// // //           const SizedBox(height: 20),
// // //
// // //           // ▶ / ⏸ Play–Pause Button
// // //           ElevatedButton.icon(
// // //             style: ElevatedButton.styleFrom(
// // //               padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
// // //             ),
// // //             onPressed: () {
// // //               if (_isPlaying) {
// // //                 // _controller.pause();
// // //               } else {
// // //                 // _controller.play();
// // //               }
// // //             },
// // //             icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
// // //             label: Text(_isPlaying ? "Pause" : "Play"),
// // //           ),
// // //         ],
// // //       ),
// // //     );
// // //   }
// // // }
// //
// //
// // import 'package:flutter/material.dart';
// // import 'package:youtube_player_flutter/youtube_player_flutter.dart';
// // class YouTubePlayerPage extends StatefulWidget {
// //   String url;
// //     YouTubePlayerPage({super.key, required this. url});
// //
// //   @override
// //   State<YouTubePlayerPage> createState() => _YouTubePlayerPageState();
// // }
// //
// // class _YouTubePlayerPageState extends State<YouTubePlayerPage> {
// //   late YoutubePlayerController _controller;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //
// //     // Video ID extracted from your URL: -2-W-Sa6rWM
// //     _controller = YoutubePlayerController(
// //       initialVideoId: widget.url,
// //       // initialVideoId: '-2-W-Sa6rWM',
// //       flags: const YoutubePlayerFlags(
// //         autoPlay: false,
// //         mute: false,
// //         enableCaption: true,
// //       ),
// //     );
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     print(">>>>>>>>${widget.url}");
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text('Playing: -2-W-Sa6rWM'),
// //       ),
// //       body: Center(
// //         child: YoutubePlayer(
// //           controller: _controller,
// //           showVideoProgressIndicator: true,
// //           progressColors: const ProgressBarColors(
// //             playedColor: Colors.red,
// //             handleColor: Colors.redAccent,
// //           ),
// //           onReady: () {
// //             print('Video is ready to play');
// //           },
// //         ),
// //       ),
// //     );
// //   }
// //
// //   @override
// //   void dispose() {
// //     _controller.dispose();
// //     super.dispose();
// //   }
// // }
//
// import 'package:flutter/material.dart';
// import 'package:youtube_player_flutter/youtube_player_flutter.dart';
//
//
// void main(){
//   runApp(
//     MaterialApp(
//     home: YouTubePlayerWithControls(videoId: '',),
//     )
//   );
// }
//
//
//
// class YouTubePlayerWithControls extends StatefulWidget {
//   final String videoId;
//
//   const YouTubePlayerWithControls({
//     super.key,
//     required this.videoId,
//   });
//
//   @override
//   State<YouTubePlayerWithControls> createState() => _YouTubePlayerWithControlsState();
// }
//
// class _YouTubePlayerWithControlsState extends State<YouTubePlayerWithControls> {
//   late YoutubePlayerController _controller;
//   bool _isPlaying = false;
//
//   @override
//   void initState() {
//     super.initState();
//     _controller = YoutubePlayerController(
//       initialVideoId: "h0mKvhxky0Q",
//       // initialVideoId: widget.videoId,
//       flags: const YoutubePlayerFlags(
//         autoPlay: false,
//         mute: false,
//       ),
//     )..addListener(() {
//       if (_controller.value.isPlaying != _isPlaying) {
//         setState(() {
//           _isPlaying = _controller.value.isPlaying;
//         });
//       }
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           YoutubePlayer(
//             controller: _controller,
//             showVideoProgressIndicator: true,
//           ),
//           const SizedBox(height: 20),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               IconButton(
//                 onPressed: () {
//                   final current = _controller.value.position;
//                   _controller.seekTo(current - const Duration(seconds: 10));
//                 },
//                 icon: const Icon(Icons.replay_10, size: 40),
//               ),
//               IconButton(
//                 onPressed: () {
//                   if (_isPlaying) {
//                     _controller.pause();
//                   } else {
//                     _controller.play();
//                   }
//                 },
//                 icon: Icon(
//                   _isPlaying ? Icons.pause_circle : Icons.play_circle,
//                   size: 60,
//                   color: Colors.red,
//                 ),
//               ),
//               IconButton(
//                 onPressed: () {
//                   final current = _controller.value.position;
//                   _controller.seekTo(current + const Duration(seconds: 10));
//                 },
//                 icon: const Icon(Icons.forward_10, size: 40),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
//
//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }
// }