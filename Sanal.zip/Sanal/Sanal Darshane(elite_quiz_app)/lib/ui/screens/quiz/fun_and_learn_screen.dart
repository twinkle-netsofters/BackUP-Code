import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cached_pdfview/flutter_cached_pdfview.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:flutterquiz/core/core.dart';
import 'package:flutterquiz/features/quiz/models/comprehension.dart';
import 'package:flutterquiz/features/quiz/models/quiz_type.dart';
import 'package:flutterquiz/ui/widgets/custom_appbar.dart';
import 'package:flutterquiz/ui/widgets/custom_rounded_button.dart';
import 'package:flutterquiz/utils/extensions.dart';
import 'package:flutterquiz/utils/ui_utils.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class FunAndLearnScreen extends StatefulWidget {
  const FunAndLearnScreen({
    required this.quizType,
    required this.comprehension,
    required this.isPremiumCategory,
    required this.categoryId,
    this.subcategoryId,
    super.key,
  });

  final QuizTypes quizType;
  final Comprehension comprehension;
  final bool isPremiumCategory;
  final String categoryId;
  final String? subcategoryId;

  @override
  State<FunAndLearnScreen> createState() => _FunAndLearnScreen();

  static Route<dynamic> route(RouteSettings routeSettings) {
    final arguments = routeSettings.arguments as Map?;
    return CupertinoPageRoute(
      builder: (_) => FunAndLearnScreen(
        quizType: arguments!['quizType'] as QuizTypes,
        comprehension: arguments['comprehension'] as Comprehension,
        isPremiumCategory: arguments['isPremiumCategory'] as bool? ?? false,
        categoryId: arguments['categoryId'] as String,
        subcategoryId: arguments['subcategoryId'] as String? ?? '',
      ),
    );
  }
}

class _FunAndLearnScreen extends State<FunAndLearnScreen>
    with TickerProviderStateMixin {
  YoutubePlayerController? _ytController;
  bool _isInitializing = true;

  @override
  void initState() {
    super.initState();
    // Delay YouTube initialization to prevent AdMob WebView interference
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _initializeYoutubeController();
      }
    });
  }

  String? _extractVideoId(String contentData) {
    final trimmed = contentData.trim();
    if (trimmed.isEmpty) return null;

    // Use the official YoutubePlayer method to convert URL to ID
    final videoId = YoutubePlayer.convertUrlToId(trimmed);
    if (videoId != null && videoId.isNotEmpty) {
      return videoId;
    }

    // If it's already a video ID (11 characters, no URL pattern)
    if (trimmed.length == 11 &&
        !trimmed.contains('youtube.com') &&
        !trimmed.contains('youtu.be') &&
        !trimmed.contains('http')) {
      return trimmed;
    }

    return null;
  }

  void _initializeYoutubeController() {
    if (widget.comprehension.contentType != ContentType.yt) {
      if (mounted) {
        setState(() {
          _isInitializing = false;
        });
      }
      return;
    }

    final contentData = widget.comprehension.contentData.trim();

    if (contentData.isEmpty) {
      if (mounted) {
        setState(() {
          _isInitializing = false;
        });
      }
      return;
    }

    // Extract video ID from URL if needed using official method
    final videoId = _extractVideoId(contentData);
    if (videoId == null || videoId.isEmpty) {
      debugPrint('Failed to extract video ID from: $contentData');
      if (mounted) {
        setState(() {
          _isInitializing = false;
        });
      }
      return;
    }

    debugPrint('Initializing YouTube player with video ID: $videoId');

    try {
      _ytController = YoutubePlayerController(
        initialVideoId: videoId,
        flags: const YoutubePlayerFlags(
          autoPlay: true,
          mute: false,
          enableCaption: false,
          hideControls: false,
          controlsVisibleAtStart: true,
          loop: false,
          isLive: false,
          forceHD: false,
          startAt: 0,
        ),
      );

      // Add listener to catch errors and state changes
      _ytController!.addListener(_youtubeListener);
    } catch (e) {
      debugPrint('Error initializing YouTube controller: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isInitializing = false;
        });
      }
    }
  }

  void _youtubeListener() {
    if (!mounted || _ytController == null) return;

    final value = _ytController!.value;

    if (value.hasError) {
      debugPrint(
        'YouTube player error: ${value.errorCode} for video: ${_ytController!.initialVideoId}',
      );
      debugPrint(
        'Player state: isReady=${value.isReady}, isPlaying=${value.isPlaying}, hasError=${value.hasError}',
      );
    }

    // Update UI when player state changes
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    _ytController?.removeListener(_youtubeListener);
    _ytController?.dispose();
    super.dispose();
  }

  void navigateToQuestionScreen() {
    Navigator.of(context).pushReplacementNamed(
      Routes.quiz,
      arguments: {
        'numberOfPlayer': 1,
        'quizType': QuizTypes.funAndLearn,
        'comprehension': widget.comprehension,
        'isPremiumCategory': widget.isPremiumCategory,
        'categoryId': widget.categoryId,
        'subcategoryId': widget.subcategoryId,
      },
    );
  }

  Widget _buildStartButton() {
    return Padding(
      padding: EdgeInsets.only(
        bottom: 30,
        left: context.width * UiUtils.hzMarginPct,
        right: context.width * UiUtils.hzMarginPct,
      ),
      child: CustomRoundedButton(
        widthPercentage: context.width,
        backgroundColor: Theme.of(context).primaryColor,
        buttonTitle: context.tr(letsStart),
        radius: 8,
        onTap: navigateToQuestionScreen,
        titleColor: Theme.of(context).colorScheme.surface,
        showBorder: false,
        height: 58,
        elevation: 5,
        textSize: 18,
        fontWeight: FontWeights.semiBold,
      ),
    );
  }

  bool showFullPdf = false;

  Future<void> _openVideoInYouTube() async {
    final videoId = _extractVideoId(widget.comprehension.contentData);
    if (videoId != null) {
      final url = Uri.parse('https://www.youtube.com/watch?v=$videoId');
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      }
    }
  }

  Widget _buildErrorWidget() {
    return Container(
      height: 200,
      margin: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Theme.of(context).colorScheme.error,
          width: 1,
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              color: Theme.of(context).colorScheme.error,
              size: 48,
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Video cannot be played in the app.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.error,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _openVideoInYouTube,
              icon: const Icon(Icons.open_in_new, size: 18),
              label: const Text('Watch on YouTube'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildParagraph(Widget player) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(10),
      ),
      height: context.height * .75,
      margin: EdgeInsets.symmetric(
        horizontal: context.width * UiUtils.hzMarginPct,
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Column(
          children: [
            if (widget.comprehension.contentType == ContentType.yt &&
                widget.comprehension.contentData.isNotEmpty)
              _ytController != null && _ytController!.value.hasError
                  ? _buildErrorWidget()
                  : player,
            if (widget.comprehension.contentType == ContentType.pdf &&
                widget.comprehension.contentData.isNotEmpty) ...[
              SizedBox(
                height: context.height * (showFullPdf ? .7 : 0.2),
                child: const PDF(
                  swipeHorizontal: true,
                  fitPolicy: FitPolicy.BOTH,
                ).fromUrl(widget.comprehension.contentData),
              ),
              TextButton(
                onPressed: () => setState(() => showFullPdf = !showFullPdf),
                child: Text(
                  context.tr(showFullPdf ? 'showLess' : 'showFull')!,
                  textAlign: TextAlign.start,
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                        color: Theme.of(context).colorScheme.onTertiary,
                        decoration: TextDecoration.underline,
                      ),
                ),
              ),
            ],
            const SizedBox(height: 10),
            HtmlWidget(
              widget.comprehension.detail,
              onErrorBuilder: (_, e, err) => Text('$e error: $err'),
              onLoadingBuilder: (_, e, l) =>
                  const Center(child: CircularProgressIndicator()),
              textStyle: TextStyle(
                color: Theme.of(context).colorScheme.onTertiary,
                fontWeight: FontWeights.regular,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Show loading while initializing YouTube controller
    if (_isInitializing && widget.comprehension.contentType == ContentType.yt) {
      return Scaffold(
        appBar: QAppBar(
          roundedAppBar: false,
          title: Text(widget.comprehension.title),
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    // Check if YouTube content type and controller is initialized
    if (widget.comprehension.contentType == ContentType.yt &&
        widget.comprehension.contentData.isNotEmpty) {
      if (_ytController == null) {
        // Show error state if controller failed to initialize
        return Scaffold(
          appBar: QAppBar(
            roundedAppBar: false,
            title: Text(widget.comprehension.title),
          ),
          body: Stack(
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: _buildParagraph(
                  Container(
                    height: 200,
                    margin: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: Theme.of(context)
                          .colorScheme
                          .surface
                          .withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Theme.of(context).colorScheme.error,
                        width: 1,
                      ),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.error_outline,
                            color: Theme.of(context).colorScheme.error,
                            size: 48,
                          ),
                          const SizedBox(height: 12),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Text(
                              'Unable to load video. Please check your internet connection or try again later.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.error,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: _buildStartButton(),
              ),
            ],
          ),
        );
      }

      return YoutubePlayerBuilder(
        player: YoutubePlayer(
          controller: _ytController!,
          progressIndicatorColor: Theme.of(context).primaryColor,
          progressColors: ProgressBarColors(
            playedColor: Theme.of(context).primaryColor,
            bufferedColor: Theme.of(context)
                .colorScheme
                .onTertiary
                .withValues(alpha: .5),
            backgroundColor: Theme.of(context)
                .colorScheme
                .surface
                .withValues(alpha: .5),
            handleColor: Theme.of(context).primaryColor,
          ),
          onReady: () {
            debugPrint('YouTube player is ready');
            // Player is ready, ensure it plays if autoplay is enabled
            if (_ytController != null && !_ytController!.value.hasError) {
              Future.delayed(const Duration(milliseconds: 300), () {
                if (mounted &&
                    _ytController != null &&
                    !_ytController!.value.hasError) {
                  _ytController!.play();
                }
              });
            }
          },
        ),
        onExitFullScreen: () {
          SystemChrome.setEnabledSystemUIMode(
            SystemUiMode.manual,
            overlays: SystemUiOverlay.values,
          );
        },
        builder: (context, player) {
          return Scaffold(
            appBar: QAppBar(
              roundedAppBar: false,
              title: Text(widget.comprehension.title),
            ),
            body: RepaintBoundary(
              // Isolate YouTube player rendering from AdMob WebViews
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  // YouTube player layer - isolated and on top
                  Positioned.fill(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: _buildParagraph(player),
                    ),
                  ),
                  // Start button - below player
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: _buildStartButton(),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    // For non-YouTube content (PDF, text, etc.)
    return Scaffold(
      appBar: QAppBar(
        roundedAppBar: false,
        title: Text(widget.comprehension.title),
      ),
      body: Stack(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: _buildParagraph(
              const SizedBox.shrink(), // Placeholder for player
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: _buildStartButton(),
          ),
        ],
      ),
    );
  }
}
