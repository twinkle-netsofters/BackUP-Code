import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterquiz/ui/widgets/custom_back_button.dart';
import 'package:flutterquiz/utils/assets_utils.dart';
import 'package:flutterquiz/utils/ui_utils.dart';
import 'package:url_launcher/url_launcher.dart';

class ChildMenuScreen extends StatefulWidget {
  // final QuizTypes quizType;
  List<dynamic> menuChildrenList;
  String title;

  ChildMenuScreen({required this.menuChildrenList, required this.title});

  @override
  _ChildMenuScreen createState() => _ChildMenuScreen();

}

class _ChildMenuScreen extends State<ChildMenuScreen> {
  final ScrollController scrollController = ScrollController();
  bool doneApi = false;

  List<dynamic> menuList = [];
  List<dynamic> menuChildrenList = [];
  bool isShowChildren = false;
  bool isShowInnerChildren = false;

  @override
  void initState() {
    print(widget.menuChildrenList.toString());
    // getSystemConfiguration();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            color: Color(0xff25184E),
            child: Column(children: [_buildAppBar(), showMenuList()]),
          ),
        ],
      ),
    );
  }

  Widget back() {
    return Padding(
      padding: const EdgeInsetsDirectional.only(top: 30, start: 20, end: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CustomBackButton(
            iconColor: Theme.of(context).primaryColor,
          )
        ],
      ),
    );
  }

  Widget showMenuList() {
    return Expanded(
      child: ListView.builder(
        controller: scrollController,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: widget.menuChildrenList.length,
        physics: AlwaysScrollableScrollPhysics(),
        itemBuilder: (BuildContext context, int index) {
          List<dynamic> menuChildrenList = widget.menuChildrenList[index]["children"] as List<dynamic>? ?? [];
          return GestureDetector(
            onTap: () async {
              if (menuChildrenList.length == 0) {
                print("menuChildrenListEmpty");
                bool canLaunch = await canLaunchUrl(
                    Uri.parse(widget.menuChildrenList[index]["href"].toString()));
                if (canLaunch) {
                  launchUrl(
                    Uri.parse(widget.menuChildrenList[index]["href"].toString()),
                    mode: LaunchMode.externalApplication,
                  );
                }
              } else {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ChildMenuScreen(
                            menuChildrenList: menuChildrenList,
                            title: widget.menuChildrenList[index]['text']
                                .toString())));
              }
            },
            child: Container(
                height: 90,
                alignment: Alignment.center,
                margin: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    color: Colors.white),
                child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: 50,
                        height: 50,
                        child: CachedNetworkImage(
                            fit: BoxFit.cover,
                            placeholder: (context, _) => SizedBox(),
                            imageUrl: widget.menuChildrenList[index]["id"].toString(),
                            errorWidget: (context, imageUrl, _) => Image(
                                image: AssetImage(
                                    AssetsUtils.getImagePath("ic_launcher.png")))),
                      ),
                    ),
                    title: Text(
                      widget.menuChildrenList[index]["text"].toString(),
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                    ),
                    subtitle: Text(
                      widget.menuChildrenList[index]["icon"].toString(),
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                          fontSize: 14),
                    ))),
          );
        },
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      child: Stack(
        children: [
          Align(
            alignment: AlignmentDirectional.bottomStart,
            child: Padding(
              padding: EdgeInsetsDirectional.only(start: 20.0, bottom: 30.0),
              child: CustomBackButton(
                removeSnackBars: false,
                iconColor: Colors.white,
              ),
            ),
          ),
          Align(
            alignment: AlignmentDirectional.bottomCenter,
            child: Padding(
              padding: EdgeInsetsDirectional.only(
                  bottom: 15.0,
                  start: MediaQuery.of(context).size.width * (0.13)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * (0.65),
                    child: Text(
                      widget.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: MediaQuery.of(context).size.width * (0.060),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  // SizedBox(
                  //   height: 2.5,
                  // ),
                  Text(
                    "",
                    style: TextStyle(
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      height:
      MediaQuery.of(context).size.height * (UiUtils.appBarHeightPercentage),
      decoration: BoxDecoration(
          color: Color(0xff2E205E),
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(20.0),
              bottomRight: Radius.circular(20.0))),
    );
  }
}
