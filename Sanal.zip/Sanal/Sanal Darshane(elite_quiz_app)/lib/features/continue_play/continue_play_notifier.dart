import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutterquiz/features/continue_play/models/continue_play_session.dart';

/// Global notifier for Continue Play session updates
/// Allows real-time updates across all screens when sessions change
class ContinuePlayNotifier extends ChangeNotifier {
  ContinuePlayNotifier._();
  
  static final ContinuePlayNotifier instance = ContinuePlayNotifier._();

  ContinuePlaySession? _currentSession;
  List<ContinuePlaySession> _allSessions = [];

  /// Get the current best session
  ContinuePlaySession? get currentSession => _currentSession;

  /// Get all sessions
  List<ContinuePlaySession> get allSessions => List.unmodifiable(_allSessions);

  /// Notify all listeners that a session was updated
  /// This should be called whenever a session is saved
  void notifySessionUpdated({
    ContinuePlaySession? session,
    List<ContinuePlaySession>? sessions,
  }) {
    if (session != null) {
      _currentSession = session;
    }
    if (sessions != null) {
      _allSessions = sessions;
    }
    
    debugPrint('ContinuePlayNotifier: Notifying listeners (hasListeners: $hasListeners)');
    debugPrint('ContinuePlayNotifier: Current session = $_currentSession');
    debugPrint('ContinuePlayNotifier: Total sessions = ${_allSessions.length}');
    
    // Notify listeners immediately - this triggers real-time updates
    // The listeners will handle setState safely using addPostFrameCallback
    notifyListeners();
  }

  /// Refresh the current session
  void refreshCurrentSession(ContinuePlaySession? session) {
    _currentSession = session;
    notifyListeners();
  }

  /// Refresh all sessions
  void refreshAllSessions(List<ContinuePlaySession> sessions) {
    _allSessions = sessions;
    notifyListeners();
  }

  /// Reset/clear all sessions (used on logout/login)
  void reset() {
    _currentSession = null;
    _allSessions = [];
    debugPrint('ContinuePlayNotifier: Reset - cleared all sessions');
    notifyListeners();
  }
}


