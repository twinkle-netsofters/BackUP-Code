import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutterquiz/features/continue_play/continue_play_notifier.dart';
import 'package:flutterquiz/features/continue_play/models/continue_play_session.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// Storage helper for Continue Play sessions
/// Manages the last active quiz session across all game modes
class ContinuePlayStorage {
  ContinuePlayStorage._();

  static const String _boxName = 'continue_play_sessions';
  static const String _lastSessionKey = 'last_continue_play_session';
  static const String _sessionsListKey = 'continue_play_sessions_list';

  static Box<dynamic>? _box;

  static Future<Box<dynamic>> get _getBox async {
    _box ??= await Hive.openBox<dynamic>(_boxName);
    return _box!;
  }

  /// Save or update a Continue Play session
  /// This automatically becomes the most recent session
  static Future<void> saveSession(ContinuePlaySession session) async {
    try {
      final box = await _getBox;

      // Save as the last session
      await box.put(_lastSessionKey, jsonEncode(session.toJson()));

      // Also maintain a list of recent sessions (for fallback when last is completed)
      final sessionsList = await getAllSessions();
      
      // Remove any existing session with the same quizType, categoryId, subcategoryId
      sessionsList.removeWhere((s) =>
          s.quizType == session.quizType &&
          s.categoryId == session.categoryId &&
          s.subcategoryId == session.subcategoryId);

      // Add the new session at the beginning
      sessionsList.insert(0, session);

      // Keep only the last 20 sessions to avoid storage bloat
      if (sessionsList.length > 20) {
        sessionsList.removeRange(20, sessionsList.length);
      }

      // Save the updated list
      await box.put(
        _sessionsListKey,
        jsonEncode(sessionsList.map((s) => s.toJson()).toList()),
      );

      // Get the best session for current display
      final bestSession = await getBestSession();

      // Notify all listeners immediately - this triggers real-time updates
      ContinuePlayNotifier.instance.notifySessionUpdated(
        session: bestSession,
        sessions: sessionsList,
      );

      debugPrint('Continue Play session saved: ${session.toString()}');
      debugPrint('Continue Play notifier updated with best session: $bestSession');
      debugPrint('Continue Play notifier updated with ${sessionsList.length} total sessions');
    } catch (e, stackTrace) {
      debugPrint('Error saving Continue Play session: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }

  /// Get the last active Continue Play session
  /// Returns null if no session exists
  static Future<ContinuePlaySession?> getLastSession() async {
    try {
      final box = await _getBox;
      final jsonString = box.get(_lastSessionKey) as String?;

      if (jsonString == null) return null;

      final json = jsonDecode(jsonString) as Map<String, dynamic>;
      return ContinuePlaySession.fromJson(json);
    } catch (e) {
      debugPrint('Error getting last Continue Play session: $e');
      return null;
    }
  }

  /// Get all stored sessions (for fallback when last is completed)
  static Future<List<ContinuePlaySession>> getAllSessions() async {
    try {
      final box = await _getBox;
      final jsonString = box.get(_sessionsListKey) as String?;

      if (jsonString == null) return [];

      final jsonList = jsonDecode(jsonString) as List<dynamic>;
      return jsonList
          .map((json) => ContinuePlaySession.fromJson(
                json as Map<String, dynamic>,
              ))
          .toList();
    } catch (e) {
      debugPrint('Error getting all Continue Play sessions: $e');
      return [];
    }
  }

  /// Get the best available session for Continue Play
  /// Priority:
  /// 1. Last session if it's in progress (not completed)
  /// 2. Most recent in-progress session (not completed)
  /// 3. Most recent partially completed session (attempted but not completed)
  /// 4. Most recent session (even if completed) - only if no other options
  static Future<ContinuePlaySession?> getBestSession() async {
    try {
      final lastSession = await getLastSession();
      
      // If last session is in progress (not completed), use it
      if (lastSession != null && lastSession.isInProgress) {
        debugPrint('ContinuePlayStorage: Using last session (in progress): $lastSession');
        return lastSession;
      }

      // Otherwise, find the best session from all sessions
      final allSessions = await getAllSessions();

      if (allSessions.isEmpty) {
        debugPrint('ContinuePlayStorage: No sessions found');
        return null;
      }

      // Filter in-progress sessions (not completed and has attempts)
      final inProgressSessions = allSessions
          .where((s) => s.isInProgress) // This checks !isCompleted && attemptedQuestions > 0
          .toList()
        ..sort((a, b) => b.lastPlayedAt.compareTo(a.lastPlayedAt));

      if (inProgressSessions.isNotEmpty) {
        debugPrint('ContinuePlayStorage: Found ${inProgressSessions.length} in-progress sessions, using: ${inProgressSessions.first}');
        return inProgressSessions.first;
      }

      // If no in-progress, find partially completed (attempted but not completed)
      final partialSessions = allSessions
          .where((s) => !s.isCompleted && s.attemptedQuestions > 0)
          .toList()
        ..sort((a, b) => b.lastPlayedAt.compareTo(a.lastPlayedAt));

      if (partialSessions.isNotEmpty) {
        debugPrint('ContinuePlayStorage: Found ${partialSessions.length} partial sessions, using: ${partialSessions.first}');
        return partialSessions.first;
      }

      // Fallback to most recent session (even if completed) - only if no other options
      allSessions.sort((a, b) => b.lastPlayedAt.compareTo(a.lastPlayedAt));
      debugPrint('ContinuePlayStorage: No in-progress sessions, using most recent (may be completed): ${allSessions.first}');
      return allSessions.first;
    } catch (e) {
      debugPrint('Error getting best Continue Play session: $e');
      return null;
    }
  }

  /// Clear all Continue Play sessions
  static Future<void> clearAllSessions() async {
    try {
      final box = await _getBox;
      await box.delete(_lastSessionKey);
      await box.delete(_sessionsListKey);
    } catch (e) {
      debugPrint('Error clearing Continue Play sessions: $e');
    }
  }
}

