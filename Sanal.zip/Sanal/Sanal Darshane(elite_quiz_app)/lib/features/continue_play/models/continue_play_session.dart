import 'package:flutterquiz/features/quiz/models/quiz_type.dart';

/// Model representing a Continue Play session
/// Tracks the last active quiz session for any game mode
class ContinuePlaySession {
  const ContinuePlaySession({
    required this.quizType,
    required this.modeName,
    required this.categoryId,
    required this.categoryName,
    required this.categoryImage,
    this.subcategoryId,
    this.subcategoryName,
    this.subcategoryImage,
    required this.attemptedQuestions,
    required this.totalQuestions,
    required this.lastPlayedAt,
    this.isCompleted = false,
  });

  final QuizTypes quizType;
  final String modeName; // Display name like "Quiz Zone", "Math Mania", etc.
  final String categoryId;
  final String categoryName;
  final String categoryImage;
  final String? subcategoryId;
  final String? subcategoryName;
  final String? subcategoryImage;
  final int attemptedQuestions;
  final int totalQuestions;
  final DateTime lastPlayedAt;
  final bool isCompleted;

  /// Get the display name (subcategory if available, otherwise category)
  String get displayName => subcategoryName ?? categoryName;

  /// Get the display image (subcategory if available, otherwise category)
  String get displayImage => subcategoryImage ?? categoryImage;

  /// Get progress percentage (0.0 to 100.0)
  double get progressPercentage => totalQuestions > 0
      ? (attemptedQuestions / totalQuestions) * 100
      : 0.0;

  /// Whether the session is in progress (not completed)
  bool get isInProgress => !isCompleted && attemptedQuestions > 0;

  /// Create from JSON
  factory ContinuePlaySession.fromJson(Map<String, dynamic> json) {
    return ContinuePlaySession(
      quizType: _parseQuizType(json['quiz_type'] as String? ?? ''),
      modeName: json['mode_name'] as String? ?? '',
      categoryId: json['category_id'] as String? ?? '',
      categoryName: json['category_name'] as String? ?? '',
      categoryImage: json['category_image'] as String? ?? '',
      subcategoryId: json['subcategory_id'] as String?,
      subcategoryName: json['subcategory_name'] as String?,
      subcategoryImage: json['subcategory_image'] as String?,
      attemptedQuestions: (json['attempted_questions'] as num?)?.toInt() ?? 0,
      totalQuestions: (json['total_questions'] as num?)?.toInt() ?? 0,
      lastPlayedAt: json['last_played_at'] != null
          ? DateTime.parse(json['last_played_at'] as String)
          : DateTime.now(),
      isCompleted: (json['is_completed'] as bool?) ?? false,
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'quiz_type': _quizTypeToString(quizType),
      'mode_name': modeName,
      'category_id': categoryId,
      'category_name': categoryName,
      'category_image': categoryImage,
      'subcategory_id': subcategoryId,
      'subcategory_name': subcategoryName,
      'subcategory_image': subcategoryImage,
      'attempted_questions': attemptedQuestions,
      'total_questions': totalQuestions,
      'last_played_at': lastPlayedAt.toIso8601String(),
      'is_completed': isCompleted,
    };
  }

  /// Copy with method for immutable updates
  ContinuePlaySession copyWith({
    QuizTypes? quizType,
    String? modeName,
    String? categoryId,
    String? categoryName,
    String? categoryImage,
    String? subcategoryId,
    String? subcategoryName,
    String? subcategoryImage,
    int? attemptedQuestions,
    int? totalQuestions,
    DateTime? lastPlayedAt,
    bool? isCompleted,
  }) {
    return ContinuePlaySession(
      quizType: quizType ?? this.quizType,
      modeName: modeName ?? this.modeName,
      categoryId: categoryId ?? this.categoryId,
      categoryName: categoryName ?? this.categoryName,
      categoryImage: categoryImage ?? this.categoryImage,
      subcategoryId: subcategoryId ?? this.subcategoryId,
      subcategoryName: subcategoryName ?? this.subcategoryName,
      subcategoryImage: subcategoryImage ?? this.subcategoryImage,
      attemptedQuestions: attemptedQuestions ?? this.attemptedQuestions,
      totalQuestions: totalQuestions ?? this.totalQuestions,
      lastPlayedAt: lastPlayedAt ?? this.lastPlayedAt,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }

  /// Helper to parse QuizTypes from string
  static QuizTypes _parseQuizType(String typeString) {
    return switch (typeString) {
      'quizZone' => QuizTypes.quizZone,
      'funAndLearn' => QuizTypes.funAndLearn,
      'guessTheWord' => QuizTypes.guessTheWord,
      'audioQuestions' => QuizTypes.audioQuestions,
      'mathMania' => QuizTypes.mathMania,
      'dailyQuiz' => QuizTypes.dailyQuiz,
      'trueAndFalse' => QuizTypes.trueAndFalse,
      'exam' => QuizTypes.exam,
      'selfChallenge' => QuizTypes.selfChallenge,
      'multiMatch' => QuizTypes.multiMatch,
      'oneVsOneBattle' => QuizTypes.oneVsOneBattle,
      'groupPlay' => QuizTypes.groupPlay,
      _ => QuizTypes.quizZone,
    };
  }

  /// Helper to convert QuizTypes to string
  static String _quizTypeToString(QuizTypes type) {
    return switch (type) {
      QuizTypes.quizZone => 'quizZone',
      QuizTypes.funAndLearn => 'funAndLearn',
      QuizTypes.guessTheWord => 'guessTheWord',
      QuizTypes.audioQuestions => 'audioQuestions',
      QuizTypes.mathMania => 'mathMania',
      QuizTypes.dailyQuiz => 'dailyQuiz',
      QuizTypes.trueAndFalse => 'trueAndFalse',
      QuizTypes.exam => 'exam',
      QuizTypes.selfChallenge => 'selfChallenge',
      QuizTypes.multiMatch => 'multiMatch',
      QuizTypes.oneVsOneBattle => 'oneVsOneBattle',
      QuizTypes.groupPlay => 'groupPlay',
      _ => 'quizZone',
    };
  }

  @override
  String toString() {
    return 'ContinuePlaySession('
        'quizType: $quizType, '
        'modeName: $modeName, '
        'categoryName: $categoryName, '
        'attempted: $attemptedQuestions/$totalQuestions, '
        'completed: $isCompleted)';
  }
}

