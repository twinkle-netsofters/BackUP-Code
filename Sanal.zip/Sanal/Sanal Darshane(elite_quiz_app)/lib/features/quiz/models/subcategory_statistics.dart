import 'package:flutter/foundation.dart';

/// Model representing statistics for a subcategory quiz attempt
class SubcategoryStatistics {
  const SubcategoryStatistics({
    required this.subcategoryId,
    required this.categoryId,
    required this.quizType,
    required this.totalQuestions,
    this.correctCount = 0,
    this.incorrectCount = 0,
    this.emptyCount = 0,
    this.isCompleted = false,
    this.lastAttemptedAt,
    this.completedAt,
  });

  final String subcategoryId;
  final String categoryId;
  final String quizType; // 'funAndLearn' or 'quizZone' or 'both'
  final int totalQuestions;
  final int correctCount; // True answers
  final int incorrectCount; // False answers
  final int emptyCount; // Unanswered
  final bool isCompleted;
  final DateTime? lastAttemptedAt;
  final DateTime? completedAt;

  /// Total answered questions (correct + incorrect)
  int get answeredCount => correctCount + incorrectCount;

  /// Whether user has attempted at least one question
  bool get hasAttempted =>
      correctCount > 0 || incorrectCount > 0 || emptyCount < totalQuestions;

  /// Completion percentage (0.0 to 100.0)
  double get completionPercentage => totalQuestions > 0
      ? ((correctCount + incorrectCount) / totalQuestions) * 100
      : 0.0;

  /// Create from JSON
  factory SubcategoryStatistics.fromJson(Map<String, dynamic> json) {
    return SubcategoryStatistics(
      subcategoryId: json['subcategory_id'] as String? ?? '',
      categoryId: json['category_id'] as String? ?? '',
      quizType: json['quiz_type'] as String? ?? '',
      totalQuestions: (json['total_questions'] as num?)?.toInt() ?? 0,
      correctCount: (json['correct_count'] as num?)?.toInt() ?? 0,
      incorrectCount: (json['incorrect_count'] as num?)?.toInt() ?? 0,
      emptyCount: (json['empty_count'] as num?)?.toInt() ?? 0,
      isCompleted: (json['is_completed'] as bool?) ?? false,
      lastAttemptedAt: json['last_attempted_at'] != null
          ? DateTime.parse(json['last_attempted_at'] as String)
          : null,
      completedAt: json['completed_at'] != null
          ? DateTime.parse(json['completed_at'] as String)
          : null,
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'subcategory_id': subcategoryId,
      'category_id': categoryId,
      'quiz_type': quizType,
      'total_questions': totalQuestions,
      'correct_count': correctCount,
      'incorrect_count': incorrectCount,
      'empty_count': emptyCount,
      'is_completed': isCompleted,
      'last_attempted_at': lastAttemptedAt?.toIso8601String(),
      'completed_at': completedAt?.toIso8601String(),
    };
  }

  /// Copy with method for immutable updates
  SubcategoryStatistics copyWith({
    String? subcategoryId,
    String? categoryId,
    String? quizType,
    int? totalQuestions,
    int? correctCount,
    int? incorrectCount,
    int? emptyCount,
    bool? isCompleted,
    DateTime? lastAttemptedAt,
    DateTime? completedAt,
  }) {
    return SubcategoryStatistics(
      subcategoryId: subcategoryId ?? this.subcategoryId,
      categoryId: categoryId ?? this.categoryId,
      quizType: quizType ?? this.quizType,
      totalQuestions: totalQuestions ?? this.totalQuestions,
      correctCount: correctCount ?? this.correctCount,
      incorrectCount: incorrectCount ?? this.incorrectCount,
      emptyCount: emptyCount ?? this.emptyCount,
      isCompleted: isCompleted ?? this.isCompleted,
      lastAttemptedAt: lastAttemptedAt ?? this.lastAttemptedAt,
      completedAt: completedAt ?? this.completedAt,
    );
  }

  @override
  String toString() {
    return 'SubcategoryStatistics('
        'subcategoryId: $subcategoryId, '
        'correct: $correctCount, '
        'incorrect: $incorrectCount, '
        'empty: $emptyCount, '
        'completed: $isCompleted)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is SubcategoryStatistics &&
        other.subcategoryId == subcategoryId &&
        other.categoryId == categoryId &&
        other.quizType == quizType;
  }

  @override
  int get hashCode =>
      subcategoryId.hashCode ^ categoryId.hashCode ^ quizType.hashCode;
}

