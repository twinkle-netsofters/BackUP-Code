import 'package:flutter/foundation.dart';
import 'package:flutterquiz/features/quiz/models/subcategory_statistics.dart';

/// Model representing overall progress for a category
class CategoryProgress {
  const CategoryProgress({
    required this.categoryId,
    required this.totalSubcategories,
    this.completedSubcategories = 0,
    Map<String, SubcategoryStatistics>? subcategoryStats,
  }) : subcategoryStats = subcategoryStats ?? const {};

  final String categoryId;
  final int totalSubcategories;
  final int completedSubcategories;
  final Map<String, SubcategoryStatistics> subcategoryStats;

  /// Completion percentage (0.0 to 100.0)
  double get completionPercentage => totalSubcategories > 0
      ? (completedSubcategories / totalSubcategories) * 100
      : 0.0;

  /// Number of subcategories that have been attempted (at least one question)
  int get attemptedSubcategories => subcategoryStats.values
      .where((stat) => stat.hasAttempted)
      .length;

  /// Progress label (e.g., "Completed 5/23")
  String get progressLabel =>
      'Completed $completedSubcategories/$totalSubcategories';

  /// Create from JSON
  factory CategoryProgress.fromJson(Map<String, dynamic> json) {
    final subcategoriesJson = json['subcategories'] as List<dynamic>? ?? [];
    final statsMap = <String, SubcategoryStatistics>{};

    for (final subcategoryJson in subcategoriesJson) {
      final stats = SubcategoryStatistics.fromJson(
        subcategoryJson as Map<String, dynamic>,
      );
      statsMap[stats.subcategoryId] = stats;
    }

    return CategoryProgress(
      categoryId: json['category_id'] as String? ?? '',
      totalSubcategories: (json['total_subcategories'] as num?)?.toInt() ?? 0,
      completedSubcategories:
          (json['completed_subcategories'] as num?)?.toInt() ?? 0,
      subcategoryStats: statsMap,
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'category_id': categoryId,
      'total_subcategories': totalSubcategories,
      'completed_subcategories': completedSubcategories,
      'subcategories': subcategoryStats.values
          .map((stat) => stat.toJson())
          .toList(),
    };
  }

  /// Copy with method for immutable updates
  CategoryProgress copyWith({
    String? categoryId,
    int? totalSubcategories,
    int? completedSubcategories,
    Map<String, SubcategoryStatistics>? subcategoryStats,
  }) {
    return CategoryProgress(
      categoryId: categoryId ?? this.categoryId,
      totalSubcategories: totalSubcategories ?? this.totalSubcategories,
      completedSubcategories:
          completedSubcategories ?? this.completedSubcategories,
      subcategoryStats: subcategoryStats ?? this.subcategoryStats,
    );
  }

  /// Update completion count based on current statistics
  CategoryProgress updateCompletionCount() {
    final completedCount = subcategoryStats.values
        .where((stat) => stat.isCompleted)
        .length;

    return copyWith(completedSubcategories: completedCount);
  }

  /// Get statistics for a specific subcategory
  SubcategoryStatistics? getSubcategoryStats(String subcategoryId) {
    return subcategoryStats[subcategoryId];
  }

  @override
  String toString() {
    return 'CategoryProgress('
        'categoryId: $categoryId, '
        'completed: $completedSubcategories/$totalSubcategories)';
  }
}

