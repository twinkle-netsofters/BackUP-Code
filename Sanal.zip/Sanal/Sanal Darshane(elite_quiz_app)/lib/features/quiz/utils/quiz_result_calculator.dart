import 'package:flutterquiz/features/quiz/models/question.dart';
import 'package:flutterquiz/features/quiz/models/subcategory_statistics.dart';
import 'package:flutterquiz/utils/answer_encryption.dart';

/// Utility class for calculating quiz result statistics
class QuizResultCalculator {
  QuizResultCalculator._(); // Private constructor

  /// Calculate statistics from quiz questions
  static SubcategoryStatistics calculateStatistics({
    required List<Question> questions,
    required String subcategoryId,
    required String categoryId,
    required String quizType,
    required String userId,
  }) {
    int correctCount = 0;
    int incorrectCount = 0;
    int emptyCount = 0;

    for (final question in questions) {
      final submittedAnswer = question.submittedAnswerId;

      if (submittedAnswer == null ||
          submittedAnswer.isEmpty ||
          submittedAnswer == '0') {
        // Empty/Unanswered
        emptyCount++;
      } else {
        // Decrypt and compare with correct answer
        if (question.correctAnswer != null) {
          final correctAnswer = AnswerEncryption.decryptCorrectAnswer(
            rawKey: userId,
            correctAnswer: question.correctAnswer!,
          );

          if (correctAnswer.isNotEmpty && submittedAnswer == correctAnswer) {
            correctCount++;
          } else {
            incorrectCount++;
          }
        } else {
          // If no correct answer available, treat as incorrect
          incorrectCount++;
        }
      }
    }

    final totalQuestions = questions.length;
    // A subcategory is completed when all questions have been answered
    // (correct + incorrect = total, or empty = 0)
    final isCompleted = (correctCount + incorrectCount) == totalQuestions ||
        emptyCount == 0;

    return SubcategoryStatistics(
      subcategoryId: subcategoryId,
      categoryId: categoryId,
      quizType: quizType,
      totalQuestions: totalQuestions,
      correctCount: correctCount,
      incorrectCount: incorrectCount,
      emptyCount: emptyCount,
      isCompleted: isCompleted,
      lastAttemptedAt: DateTime.now(),
      completedAt: isCompleted ? DateTime.now() : null,
    );
  }

  /// Merge statistics from different quiz modes (for syncing)
  static SubcategoryStatistics mergeStatistics({
    required SubcategoryStatistics funAndLearnStats,
    required SubcategoryStatistics quizZoneStats,
  }) {
    // Use the most recent attempt
    final funAndLearnDate = funAndLearnStats.lastAttemptedAt ?? DateTime(1970);
    final quizZoneDate = quizZoneStats.lastAttemptedAt ?? DateTime(1970);
    final mostRecent = funAndLearnDate.isAfter(quizZoneDate)
        ? funAndLearnStats
        : quizZoneStats;

    // Merge counts - take the better/more complete result
    // If both are attempted, prefer the one with more correct answers
    final mergedCorrect = funAndLearnStats.correctCount > quizZoneStats.correctCount
        ? funAndLearnStats.correctCount
        : quizZoneStats.correctCount;

    final mergedIncorrect =
        funAndLearnStats.incorrectCount > quizZoneStats.incorrectCount
            ? funAndLearnStats.incorrectCount
            : quizZoneStats.incorrectCount;

    // Empty count should be: total - (correct + incorrect)
    // But ensure it doesn't go negative
    final mergedEmpty = mostRecent.totalQuestions -
        (mergedCorrect + mergedIncorrect).clamp(0, mostRecent.totalQuestions);
    final finalEmptyCount = mergedEmpty.clamp(0, mostRecent.totalQuestions);

    final mergedCompleted =
        funAndLearnStats.isCompleted || quizZoneStats.isCompleted;

    return SubcategoryStatistics(
      subcategoryId: mostRecent.subcategoryId,
      categoryId: mostRecent.categoryId,
      quizType: 'both', // Mark as synced across both modes
      totalQuestions: mostRecent.totalQuestions,
      correctCount: mergedCorrect,
      incorrectCount: mergedIncorrect,
      emptyCount: finalEmptyCount,
      isCompleted: mergedCompleted,
      lastAttemptedAt: mostRecent.lastAttemptedAt,
      completedAt: funAndLearnStats.completedAt ?? quizZoneStats.completedAt,
    );
  }

  /// Get statistics display string (e.g., "12 True – 6 False – 2 Empty")
  static String getStatisticsDisplay(SubcategoryStatistics stats) {
    return '${stats.correctCount} True – '
        '${stats.incorrectCount} False – '
        '${stats.emptyCount} Empty';
  }
}

