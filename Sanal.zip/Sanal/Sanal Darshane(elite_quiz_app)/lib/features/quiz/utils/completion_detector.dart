import 'package:flutterquiz/features/quiz/models/subcategory_statistics.dart';

/// Utility class for detecting completion status
class CompletionDetector {
  CompletionDetector._(); // Private constructor

  /// Check if a subcategory is completed
  /// Completed means: all questions have been answered (no empty answers)
  static bool isSubcategoryCompleted(SubcategoryStatistics stats) {
    // Completion criteria:
    // 1. All questions have been answered (correct + incorrect = total)
    // 2. OR empty count is 0
    return (stats.correctCount + stats.incorrectCount) == stats.totalQuestions ||
        stats.emptyCount == 0;
  }

  /// Check if subcategory has been attempted (at least one question answered)
  static bool hasSubcategoryBeenAttempted(SubcategoryStatistics stats) {
    return stats.correctCount > 0 ||
        stats.incorrectCount > 0 ||
        stats.emptyCount < stats.totalQuestions;
  }

  /// Get default statistics for an unattempted subcategory
  static SubcategoryStatistics getDefaultStatistics({
    required String subcategoryId,
    required String categoryId,
    required String quizType,
    required int totalQuestions,
  }) {
    return SubcategoryStatistics(
      subcategoryId: subcategoryId,
      categoryId: categoryId,
      quizType: quizType,
      totalQuestions: totalQuestions,
      correctCount: 0,
      incorrectCount: 0,
      emptyCount: totalQuestions, // All unanswered
      isCompleted: false,
    );
  }
}

