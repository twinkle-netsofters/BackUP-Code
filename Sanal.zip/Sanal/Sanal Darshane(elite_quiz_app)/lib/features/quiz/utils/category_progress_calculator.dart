import 'package:flutterquiz/features/quiz/models/category.dart';
import 'package:flutterquiz/features/quiz/models/category_progress.dart';
import 'package:flutterquiz/features/quiz/models/subcategory.dart';
import 'package:flutterquiz/features/quiz/models/subcategory_statistics.dart';
import 'package:flutterquiz/features/quiz/utils/completion_detector.dart';

/// Utility class for calculating category-level progress
class CategoryProgressCalculator {
  CategoryProgressCalculator._(); // Private constructor

  /// Calculate category-level progress from subcategories and their statistics
  static CategoryProgress calculateProgress({
    required String categoryId,
    required List<Subcategory> subcategories,
    required Map<String, SubcategoryStatistics> statisticsMap,
    String quizType = 'both', // Default to both for synced progress
  }) {
    final totalSubcategories = subcategories.length;
    final statsMap = <String, SubcategoryStatistics>{};
    int completedCount = 0;

    // Create or get statistics for each subcategory
    for (final subcategory in subcategories) {
      if (subcategory.id == null) continue;

      final existingStats = statisticsMap[subcategory.id!];

      if (existingStats != null) {
        statsMap[subcategory.id!] = existingStats;
        if (existingStats.isCompleted) {
          completedCount++;
        }
      } else {
        // Create default statistics for unattempted subcategory
        final defaultStats = CompletionDetector.getDefaultStatistics(
          subcategoryId: subcategory.id!,
          categoryId: categoryId,
          quizType: quizType,
          totalQuestions: int.parse(subcategory.noOfQue ?? '0'),
        );
        statsMap[subcategory.id!] = defaultStats;
      }
    }

    return CategoryProgress(
      categoryId: categoryId,
      totalSubcategories: totalSubcategories,
      completedSubcategories: completedCount,
      subcategoryStats: statsMap,
    );
  }

  /// Get progress label (e.g., "Completed 5/23")
  static String getProgressLabel(CategoryProgress progress) {
    return progress.progressLabel;
  }

  /// Get progress percentage (0.0 to 100.0)
  static double getProgressPercentage(CategoryProgress progress) {
    return progress.completionPercentage;
  }

  /// Calculate progress from Category model directly
  static CategoryProgress calculateFromCategory({
    required Category category,
    required List<Subcategory> subcategories,
    required Map<String, SubcategoryStatistics> statisticsMap,
    String quizType = 'both',
  }) {
    if (category.id == null) {
      return CategoryProgress(
        categoryId: '',
        totalSubcategories: 0,
      );
    }

    return calculateProgress(
      categoryId: category.id!,
      subcategories: subcategories,
      statisticsMap: statisticsMap,
      quizType: quizType,
    );
  }
}

