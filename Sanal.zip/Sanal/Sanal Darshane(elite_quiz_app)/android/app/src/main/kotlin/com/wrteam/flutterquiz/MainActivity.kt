package com.auzefcocukgelism.quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
