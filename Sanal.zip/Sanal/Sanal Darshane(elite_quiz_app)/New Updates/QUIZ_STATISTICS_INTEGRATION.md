# Quiz Statistics Integration Guide

## Overview

This guide explains how to integrate the quiz statistics tracking system that displays:
- **Category Progress**: "Completed X/Y" label with progress bar
- **Subcategory Statistics**: "X True – Y False – Z Empty" for each subcategory

---

## ✅ What's Already Implemented

### 1. UI Display Components

#### Category Screen (`lib/ui/screens/quiz/category_screen.dart`)
- ✅ Shows progress bar for categories with subcategories
- ✅ Displays "Completed X/Y" label
- ✅ Automatically calculates from stored statistics

#### Subcategory Screen (`lib/ui/screens/quiz/subcategory_screen.dart`)
- ✅ Shows statistics row at bottom of each subcategory card
- ✅ Format: "X True – Y False – Z Empty"
- ✅ Shows default "0 True – 0 False – [Total] Empty" for unattempted

### 2. Storage System

#### Statistics Storage (`lib/core/quiz_statistics_storage.dart`)
- ✅ Hive-based storage for quiz statistics
- ✅ Methods to save/load statistics
- ✅ Methods to get category-level statistics

### 3. Data Models

- ✅ `SubcategoryStatistics` - Model for tracking statistics
- ✅ Utility classes for calculations and completion detection

---

## 🔧 How to Save Statistics After Quiz Completion

### Step 1: Update Result Screen

In `lib/ui/screens/quiz/result_screen.dart`, add this after quiz completion:

```dart
import 'package:flutterquiz/core/quiz_statistics_storage.dart';
import 'package:flutterquiz/features/quiz/models/subcategory_statistics.dart';
import 'package:flutterquiz/features/quiz/utils/quiz_result_calculator.dart';
import 'package:flutterquiz/features/quiz/utils/completion_detector.dart';

// In the _updateResult() method or after quiz completion:

if (widget.questions != null && widget.questions!.isNotEmpty) {
  // Get quiz type string
  final quizTypeString = widget.quizType == QuizTypes.funAndLearn 
      ? 'funAndLearn' 
      : 'quizZone';
  
  // Get category and subcategory IDs
  final categoryId = widget.questions!.first.categoryId ?? '';
  final subcategoryId = widget.subcategoryId ?? '';
  
  if (categoryId.isNotEmpty && subcategoryId.isNotEmpty) {
    // Calculate statistics from quiz questions
    final userId = context.read<UserDetailsCubit>().getUserFirebaseId();
    
    final statistics = QuizResultCalculator.calculateStatistics(
      questions: widget.questions!,
      subcategoryId: subcategoryId,
      categoryId: categoryId,
      quizType: quizTypeString,
      userId: userId,
    );
    
    // Save statistics
    await QuizStatisticsStorage.saveStatistics(statistics);
    
    // Sync with other mode (if needed)
    // You can also merge with existing statistics from the other mode
  }
}
```

### Step 2: For Fun N Learn Mode

Fun N Learn uses `Comprehension` model. You'll need to:

1. Track which questions were answered
2. Calculate statistics from comprehension questions
3. Save using the same method above

### Step 3: Refresh UI After Saving

After saving statistics, refresh the category/subcategory screens:

```dart
// In subcategory screen, after returning from quiz:
@override
void didChangeDependencies() {
  super.didChangeDependencies();
  // Refresh subcategory list if needed
}

// Or use a state management solution to notify listeners
```

---

## 📝 Testing the UI Display

### Test Data Creation

You can create test statistics to see the UI in action:

```dart
import 'package:flutterquiz/core/quiz_statistics_storage.dart';
import 'package:flutterquiz/features/quiz/models/subcategory_statistics.dart';

// Create test statistics
final testStats = SubcategoryStatistics(
  subcategoryId: '123',
  categoryId: '45',
  quizType: 'funAndLearn',
  totalQuestions: 20,
  correctCount: 12,
  incorrectCount: 6,
  emptyCount: 2,
  isCompleted: false,
);

// Save test statistics
await QuizStatisticsStorage.saveStatistics(testStats);

// Create completed statistics
final completedStats = SubcategoryStatistics(
  subcategoryId: '124',
  categoryId: '45',
  quizType: 'funAndLearn',
  totalQuestions: 10,
  correctCount: 8,
  incorrectCount: 2,
  emptyCount: 0,
  isCompleted: true,
  completedAt: DateTime.now(),
);

await QuizStatisticsStorage.saveStatistics(completedStats);
```

---

## 🔄 Sync Across Quiz Modes

The system supports syncing statistics across Fun N Learn and Quiz Zone:

```dart
import 'package:flutterquiz/features/quiz/utils/quiz_result_calculator.dart';

// Get statistics from both modes
final funAndLearnStats = await QuizStatisticsStorage.getStatistics(
  categoryId: '45',
  subcategoryId: '123',
  quizType: 'funAndLearn',
);

final quizZoneStats = await QuizStatisticsStorage.getStatistics(
  categoryId: '45',
  subcategoryId: '123',
  quizType: 'quizZone',
);

// Merge statistics
if (funAndLearnStats != null && quizZoneStats != null) {
  final merged = QuizResultCalculator.mergeStatistics(
    funAndLearnStats: funAndLearnStats,
    quizZoneStats: quizZoneStats,
  );
  
  // Save merged statistics to both modes
  await QuizStatisticsStorage.saveStatistics(
    merged.copyWith(quizType: 'funAndLearn'),
  );
  await QuizStatisticsStorage.saveStatistics(
    merged.copyWith(quizType: 'quizZone'),
  );
}
```

---

## 🎯 Key Integration Points

### 1. Quiz Completion Flow

```
User Completes Quiz
    ↓
Calculate Statistics (QuizResultCalculator.calculateStatistics)
    ↓
Save Statistics (QuizStatisticsStorage.saveStatistics)
    ↓
UI Automatically Updates (FutureBuilder loads new statistics)
```

### 2. Display Flow

```
Screen Opens
    ↓
FutureBuilder loads statistics (QuizStatisticsStorage.getStatistics/getCategoryStatistics)
    ↓
Calculate Progress (count completed subcategories)
    ↓
Display UI (progress bar, labels, statistics)
```

---

## 🐛 Troubleshooting

### Statistics Not Showing

1. **Check Hive Box Initialization**: Ensure `quiz_statistics` box is opened in `app.dart`
2. **Check Storage Keys**: Verify category/subcategory IDs are correct
3. **Check Quiz Type**: Ensure quiz type matches ('funAndLearn' or 'quizZone')

### Progress Not Updating

1. **Verify Completion Status**: Check if `isCompleted` is set correctly
2. **Check Total Count**: Ensure `totalSubcategories` matches stored statistics
3. **Refresh UI**: Try hot reload or restart app

### Statistics Not Persisting

1. **Check Hive Permissions**: Ensure app has storage permissions
2. **Check Errors**: Look for exceptions in console
3. **Verify Save Call**: Ensure `saveStatistics()` is actually being called

---

## 📱 UI Behavior

### Category Screen

- **Has Subcategories**: Shows progress bar and "Completed X/Y"
- **No Subcategories**: Shows question count only (no progress)

### Subcategory Screen

- **Unattempted**: "0 True – 0 False – [Total] Empty"
- **Attempted**: "X True – Y False – Z Empty"
- **Completed**: Same format, but can show completion badge (if implemented)

---

## ✅ Next Steps

1. ✅ UI Display - **COMPLETE**
2. ⏳ Integrate statistics saving in result screen
3. ⏳ Add completion badge to subcategory cards
4. ⏳ Add backend sync (optional)
5. ⏳ Add reset/clear statistics option (optional)

---

## 📚 Files Reference

- **Storage**: `lib/core/quiz_statistics_storage.dart`
- **Models**: `lib/features/quiz/models/subcategory_statistics.dart`
- **Utils**: `lib/features/quiz/utils/quiz_result_calculator.dart`
- **UI**: 
  - `lib/ui/screens/quiz/category_screen.dart`
  - `lib/ui/screens/quiz/subcategory_screen.dart`

---

For any questions or issues, refer to the specification documents:
- `SUBCATEGORY_TRACKING_SPECIFICATION.md`
- `IMPLEMENTATION_SUMMARY.md`
- `UI_QUICK_REFERENCE.md`

