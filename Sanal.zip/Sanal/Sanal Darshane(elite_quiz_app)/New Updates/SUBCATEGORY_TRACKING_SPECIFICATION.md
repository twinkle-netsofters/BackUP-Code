# Subcategory Tracking System Specification

## Overview

This document provides a complete specification for tracking quiz subcategory progress, including True/False/Empty question counts and completion status, synchronized across Fun N Learn and Quiz Zone modes.

---

## 1. Data Structure / JSON Model

### 1.1 Core Data Models

#### Subcategory Statistics Model

```dart
class SubcategoryStatistics {
  final String subcategoryId;
  final String categoryId;
  final String quizType; // 'funAndLearn' or 'quizZone'
  final int totalQuestions;
  final int correctCount;      // True
  final int incorrectCount;    // False
  final int emptyCount;        // Unanswered
  final bool isCompleted;
  final DateTime? lastAttemptedAt;
  final DateTime? completedAt;

  SubcategoryStatistics({
    required this.subcategoryId,
    required this.categoryId,
    required this.quizType,
    required this.totalQuestions,
    this.correctCount = 0,
    this.incorrectCount = 0,
    this.emptyCount = 0,
    this.isCompleted = false,
    this.lastAttemptedAt,
    this.completedAt,
  });

  // Getters
  int get answeredCount => correctCount + incorrectCount;
  bool get hasAttempted => correctCount > 0 || incorrectCount > 0 || emptyCount < totalQuestions;
  double get completionPercentage => totalQuestions > 0 
    ? ((correctCount + incorrectCount) / totalQuestions) * 100 
    : 0.0;

  // Copy with method for updates
  SubcategoryStatistics copyWith({
    String? subcategoryId,
    String? categoryId,
    String? quizType,
    int? totalQuestions,
    int? correctCount,
    int? incorrectCount,
    int? emptyCount,
    bool? isCompleted,
    DateTime? lastAttemptedAt,
    DateTime? completedAt,
  }) {
    return SubcategoryStatistics(
      subcategoryId: subcategoryId ?? this.subcategoryId,
      categoryId: categoryId ?? this.categoryId,
      quizType: quizType ?? this.quizType,
      totalQuestions: totalQuestions ?? this.totalQuestions,
      correctCount: correctCount ?? this.correctCount,
      incorrectCount: incorrectCount ?? this.incorrectCount,
      emptyCount: emptyCount ?? this.emptyCount,
      isCompleted: isCompleted ?? this.isCompleted,
      lastAttemptedAt: lastAttemptedAt ?? this.lastAttemptedAt,
      completedAt: completedAt ?? this.completedAt,
    );
  }
}
```

#### Category Progress Model

```dart
class CategoryProgress {
  final String categoryId;
  final int totalSubcategories;
  final int completedSubcategories;
  final Map<String, SubcategoryStatistics> subcategoryStats; // key: subcategoryId

  CategoryProgress({
    required this.categoryId,
    required this.totalSubcategories,
    this.completedSubcategories = 0,
    Map<String, SubcategoryStatistics>? subcategoryStats,
  }) : subcategoryStats = subcategoryStats ?? {};

  // Getters
  double get completionPercentage => totalSubcategories > 0
    ? (completedSubcategories / totalSubcategories) * 100
    : 0.0;

  int get attemptedSubcategories => subcategoryStats.values
    .where((stat) => stat.hasAttempted)
    .length;

  // Update completion count
  void updateCompletionCount() {
    completedSubcategories = subcategoryStats.values
      .where((stat) => stat.isCompleted)
      .length;
  }
}
```

### 1.2 JSON Structure for API/Local Storage

#### Subcategory Statistics JSON

```json
{
  "subcategory_id": "123",
  "category_id": "45",
  "quiz_type": "funAndLearn", // or "quizZone"
  "total_questions": 20,
  "correct_count": 12,
  "incorrect_count": 6,
  "empty_count": 2,
  "is_completed": false,
  "last_attempted_at": "2024-01-15T10:30:00Z",
  "completed_at": null
}
```

#### Category Progress JSON

```json
{
  "category_id": "45",
  "category_name": "İSTATİSTİK",
  "total_subcategories": 23,
  "completed_subcategories": 5,
  "subcategories": [
    {
      "subcategory_id": "123",
      "subcategory_name": "2024 Vize Soruları",
      "total_questions": 20,
      "correct_count": 12,
      "incorrect_count": 6,
      "empty_count": 2,
      "is_completed": false,
      "last_attempted_at": "2024-01-15T10:30:00Z"
    },
    {
      "subcategory_id": "124",
      "subcategory_name": "2024 Final Soruları",
      "total_questions": 4,
      "correct_count": 3,
      "incorrect_count": 1,
      "empty_count": 0,
      "is_completed": true,
      "completed_at": "2024-01-15T11:00:00Z"
    }
    // ... more subcategories
  ]
}
```

#### Local Storage Structure (SharedPreferences/DB)

```json
{
  "user_quiz_progress": {
    "category_45": {
      "funAndLearn": {
        "subcategory_123": {
          "correct": 12,
          "incorrect": 6,
          "empty": 2,
          "total": 20,
          "completed": false,
          "last_attempt": "2024-01-15T10:30:00Z"
        },
        "subcategory_124": {
          "correct": 3,
          "incorrect": 1,
          "empty": 0,
          "total": 4,
          "completed": true,
          "completed_at": "2024-01-15T11:00:00Z"
        }
      },
      "quizZone": {
        // Same structure, synced with funAndLearn
      }
    }
  }
}
```

---

## 2. Logic / Algorithm

### 2.1 Calculate True/False/Empty Counts

```dart
class QuizResultCalculator {
  /// Calculate statistics from quiz questions
  static SubcategoryStatistics calculateStatistics({
    required List<Question> questions,
    required String subcategoryId,
    required String categoryId,
    required String quizType,
    required String userId,
  }) {
    int correctCount = 0;
    int incorrectCount = 0;
    int emptyCount = 0;

    for (final question in questions) {
      final submittedAnswer = question.submittedAnswerId;
      
      if (submittedAnswer == null || submittedAnswer.isEmpty || submittedAnswer == '0') {
        // Empty/Unanswered
        emptyCount++;
      } else {
        // Decrypt and compare with correct answer
        final correctAnswer = AnswerEncryption.decryptCorrectAnswer(
          rawKey: userId,
          correctAnswer: question.correctAnswer!,
        );
        
        if (submittedAnswer == correctAnswer) {
          correctCount++;
        } else {
          incorrectCount++;
        }
      }
    }

    final totalQuestions = questions.length;
    final isCompleted = (correctCount + incorrectCount) == totalQuestions;

    return SubcategoryStatistics(
      subcategoryId: subcategoryId,
      categoryId: categoryId,
      quizType: quizType,
      totalQuestions: totalQuestions,
      correctCount: correctCount,
      incorrectCount: incorrectCount,
      emptyCount: emptyCount,
      isCompleted: isCompleted,
      lastAttemptedAt: DateTime.now(),
      completedAt: isCompleted ? DateTime.now() : null,
    );
  }

  /// Merge statistics (for syncing across quiz modes)
  static SubcategoryStatistics mergeStatistics({
    required SubcategoryStatistics funAndLearnStats,
    required SubcategoryStatistics quizZoneStats,
  }) {
    // Use the most recent attempt
    final mostRecent = funAndLearnStats.lastAttemptedAt?.isAfter(
      quizZoneStats.lastAttemptedAt ?? DateTime(1970),
    ) ?? false
      ? funAndLearnStats
      : quizZoneStats;

    // Merge counts (take maximum for each)
    final mergedCorrect = funAndLearnStats.correctCount > quizZoneStats.correctCount
      ? funAndLearnStats.correctCount
      : quizZoneStats.correctCount;
    
    final mergedIncorrect = funAndLearnStats.incorrectCount > quizZoneStats.incorrectCount
      ? funAndLearnStats.incorrectCount
      : quizZoneStats.incorrectCount;

    // Empty count should be: total - (correct + incorrect)
    final mergedEmpty = mostRecent.totalQuestions - (mergedCorrect + mergedIncorrect);

    final mergedCompleted = funAndLearnStats.isCompleted || quizZoneStats.isCompleted;

    return SubcategoryStatistics(
      subcategoryId: mostRecent.subcategoryId,
      categoryId: mostRecent.categoryId,
      quizType: 'both', // or keep original
      totalQuestions: mostRecent.totalQuestions,
      correctCount: mergedCorrect,
      incorrectCount: mergedIncorrect,
      emptyCount: mergedEmpty,
      isCompleted: mergedCompleted,
      lastAttemptedAt: mostRecent.lastAttemptedAt,
      completedAt: funAndLearnStats.completedAt ?? quizZoneStats.completedAt,
    );
  }
}
```

### 2.2 Detect Completion

```dart
class CompletionDetector {
  /// Check if a subcategory is completed
  static bool isSubcategoryCompleted(SubcategoryStatistics stats) {
    // Completion criteria:
    // 1. All questions have been answered (correct + incorrect = total)
    // 2. OR user has answered all questions (empty = 0)
    return (stats.correctCount + stats.incorrectCount) == stats.totalQuestions
        || stats.emptyCount == 0;
  }

  /// Check if subcategory has been attempted
  static bool hasSubcategoryBeenAttempted(SubcategoryStatistics stats) {
    return stats.correctCount > 0 
        || stats.incorrectCount > 0 
        || stats.emptyCount < stats.totalQuestions;
  }

  /// Get default statistics for unattempted subcategory
  static SubcategoryStatistics getDefaultStatistics({
    required String subcategoryId,
    required String categoryId,
    required String quizType,
    required int totalQuestions,
  }) {
    return SubcategoryStatistics(
      subcategoryId: subcategoryId,
      categoryId: categoryId,
      quizType: quizType,
      totalQuestions: totalQuestions,
      correctCount: 0,
      incorrectCount: 0,
      emptyCount: totalQuestions, // All unanswered
      isCompleted: false,
    );
  }
}
```

### 2.3 Category Progress Calculation

```dart
class CategoryProgressCalculator {
  /// Calculate category-level progress
  static CategoryProgress calculateProgress({
    required String categoryId,
    required List<Subcategory> subcategories,
    required Map<String, SubcategoryStatistics> statisticsMap,
  }) {
    final totalSubcategories = subcategories.length;
    int completedCount = 0;

    // Create statistics for each subcategory (default if not found)
    final statsMap = <String, SubcategoryStatistics>{};

    for (final subcategory in subcategories) {
      final existingStats = statisticsMap[subcategory.id!];
      
      if (existingStats != null) {
        statsMap[subcategory.id!] = existingStats;
        if (existingStats.isCompleted) {
          completedCount++;
        }
      } else {
        // Create default statistics for unattempted subcategory
        statsMap[subcategory.id!] = CompletionDetector.getDefaultStatistics(
          subcategoryId: subcategory.id!,
          categoryId: categoryId,
          quizType: 'both', // Will be synced
          totalQuestions: int.parse(subcategory.noOfQue ?? '0'),
        );
      }
    }

    return CategoryProgress(
      categoryId: categoryId,
      totalSubcategories: totalSubcategories,
      completedSubcategories: completedCount,
      subcategoryStats: statsMap,
    );
  }

  /// Get progress label (e.g., "Completed 5/23")
  static String getProgressLabel(CategoryProgress progress) {
    return 'Completed ${progress.completedSubcategories}/${progress.totalSubcategories}';
  }

  /// Get progress percentage
  static double getProgressPercentage(CategoryProgress progress) {
    return progress.completionPercentage;
  }
}
```

### 2.4 Sync Across Quiz Modes

```dart
class ProgressSyncManager {
  /// Sync progress between Fun N Learn and Quiz Zone
  static Future<void> syncProgress({
    required String categoryId,
    required String subcategoryId,
    required SubcategoryStatistics funAndLearnStats,
    required SubcategoryStatistics quizZoneStats,
  }) async {
    // Merge statistics from both modes
    final mergedStats = QuizResultCalculator.mergeStatistics(
      funAndLearnStats: funAndLearnStats,
      quizZoneStats: quizZoneStats,
    );

    // Save merged stats for both modes
    await _saveStatistics(
      categoryId: categoryId,
      subcategoryId: subcategoryId,
      quizType: 'funAndLearn',
      statistics: mergedStats,
    );

    await _saveStatistics(
      categoryId: categoryId,
      subcategoryId: subcategoryId,
      quizType: 'quizZone',
      statistics: mergedStats,
    );
  }

  static Future<void> _saveStatistics({
    required String categoryId,
    required String subcategoryId,
    required String quizType,
    required SubcategoryStatistics statistics,
  }) async {
    // Implementation: Save to local storage or sync with backend
    // This would typically use SharedPreferences, SQLite, or API call
  }
}
```

---

## 3. UI Layout Description

### 3.1 Category List with Progress Bar

#### Location
- **Fun N Learn**: Category selection screen (after selecting Fun N Learn from Play Zone)
- **Quiz Zone**: Category selection screen (after selecting Quiz Zone from Play Zone)

#### Layout Structure

```
┌─────────────────────────────────────────┐
│  ← Çocuk Gelişimi 1. Sınıf              │  ← AppBar
├─────────────────────────────────────────┤
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  [Icon]  İSTATİSTİK              →│ │
│  │         (Bahar Dönemi)            │ │
│  │         Kapsayıcı: 23             │ │
│  │         Completed                 │ │
│  │         ┌─────────────────────┐   │ │  ← Progress Bar
│  │         │███████░░░░░░░░░░░░░░│   │ │  (Green fill = completed %)
│  │         └─────────────────────┘   │ │
│  │         5/23                       │ │  ← Completed Count Label
│  └───────────────────────────────────┘ │
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  [Icon]  ANNE ÇOCUK BESLENMESİ  →│ │
│  │         (Bahar Dönemi)            │ │
│  │         Kapsayıcı: 23             │ │
│  │         Completed                 │ │
│  │         ┌─────────────────────┐   │ │
│  │         │████░░░░░░░░░░░░░░░░░│   │ │
│  │         └─────────────────────┘   │ │
│  │         2/22                       │ │
│  └───────────────────────────────────┘ │
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  [Icon]  GELİŞİM PSİKOLOJİSİ   →│ │
│  │         (Bahar Dönemi)            │ │
│  │         Kapsayıcı: 21             │ │
│  │         Completed                 │ │
│  │         ┌─────────────────────┐   │ │
│  │         │░░░░░░░░░░░░░░░░░░░░░│   │ │
│  │         └─────────────────────┘   │ │
│  │         0/21                       │ │
│  └───────────────────────────────────┘ │
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  [Icon]  YAŞAM BECERİLERİ       →│ │
│  │         (Bahar Dönemi)            │ │
│  │         Kapsayıcı: 17             │ │
│  │         Completed                 │ │
│  │         ┌─────────────────────┐   │ │
│  │         │█████████████████████│   │ │  ← Fully completed
│  │         └─────────────────────┘   │ │
│  │         17/17                      │ │
│  └───────────────────────────────────┘ │
│                                         │
└─────────────────────────────────────────┘
```

#### Widget Specifications

**Category Card Widget:**
```dart
Container(
  decoration: BoxDecoration(
    color: Theme.of(context).colorScheme.surface,
    borderRadius: BorderRadius.circular(10),
  ),
  padding: EdgeInsets.all(12),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // Header Row
      Row(
        children: [
          // Icon
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(...),
            child: CachedNetworkImage(...),
          ),
          SizedBox(width: 10),
          // Title and Subtitle
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(category.categoryName, ...),
                Text("(Bahar Dönemi)", ...),
                Text("Kapsayıcı: ${category.subcategoriesCount}", ...),
                Text("Completed", ...), // Status
              ],
            ),
          ),
          // Arrow
          Icon(Icons.keyboard_arrow_right),
        ],
      ),
      SizedBox(height: 12),
      // Progress Section
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Progress Bar
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progress.completionPercentage / 100,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
              minHeight: 8,
            ),
          ),
          SizedBox(height: 4),
          // Completed Count Label
          Text(
            "Completed ${progress.completedSubcategories}/${progress.totalSubcategories}",
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).primaryTextColor.withOpacity(0.6),
            ),
          ),
        ],
      ),
    ],
  ),
)
```

### 3.2 Subcategory Cards with Stats

#### Location
- **Subcategory Screen**: Displayed after selecting a category (e.g., İSTATİSTİK)

#### Layout Structure

```
┌─────────────────────────────────────────┐
│  ← İSTATİSTİK                      ⋮    │  ← AppBar
├─────────────────────────────────────────┤
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  [Icon]  2024 Vize Soruları     →│ │
│  │          Soru: 20                 │ │
│  │          ───────────────────────  │ │  ← Divider
│  │          12 True – 6 False – 2 Empty │ ← Stats (bottom)
│  └───────────────────────────────────┘ │
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  [Icon]  2024 Final Soruları    →│ │
│  │          Soru: 4                  │ │
│  │          ✅ Completed             │ │  ← Completion Badge
│  │          ───────────────────────  │ │
│  │          3 True – 1 False – 0 Empty │
│  └───────────────────────────────────┘ │
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  [Icon]  2023 Vize Çıkmış Sorular→│ │
│  │          Soru: 22                 │ │
│  │          ───────────────────────  │ │
│  │          0 True – 0 False – 22 Empty │ ← Default (unattempted)
│  └───────────────────────────────────┘ │
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  [Icon]  1. Ünite...            →│ │
│  │          Soru: 15                 │ │
│  │          ───────────────────────  │ │
│  │          0 True – 0 False – 15 Empty │
│  └───────────────────────────────────┘ │
│                                         │
└─────────────────────────────────────────┘
```

#### Widget Specifications

**Subcategory Card Widget:**
```dart
Container(
  decoration: BoxDecoration(
    color: Theme.of(context).colorScheme.surface,
    borderRadius: BorderRadius.circular(10),
  ),
  padding: EdgeInsets.all(12),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // Header Row
      Row(
        children: [
          // Icon
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(...),
            child: CachedNetworkImage(
              imageUrl: subcategory.image,
              ...
            ),
          ),
          SizedBox(width: 10),
          // Title and Question Count
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        subcategory.subcategoryName,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: context.primaryTextColor,
                        ),
                      ),
                    ),
                    // Completion Badge (if completed)
                    if (statistics.isCompleted)
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.check, size: 16, color: Colors.white),
                            SizedBox(width: 4),
                            Text(
                              "Completed",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                SizedBox(height: 4),
                Text(
                  "Soru: ${statistics.totalQuestions}",
                  style: TextStyle(
                    fontSize: 14,
                    color: context.primaryTextColor.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 10),
          // Arrow
          Icon(Icons.keyboard_arrow_right),
        ],
      ),
      // Divider
      Divider(height: 24, thickness: 1),
      // Statistics Row (Bottom)
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // True Count
          _buildStatItem(
            label: "True",
            count: statistics.correctCount,
            color: Colors.green,
          ),
          SizedBox(width: 16),
          // False Count
          _buildStatItem(
            label: "False",
            count: statistics.incorrectCount,
            color: Colors.red,
          ),
          SizedBox(width: 16),
          // Empty Count
          _buildStatItem(
            label: "Empty",
            count: statistics.emptyCount,
            color: Colors.grey,
          ),
        ],
      ),
    ],
  ),
)

// Helper Widget for Stat Item
Widget _buildStatItem({
  required String label,
  required int count,
  required Color color,
}) {
  return Row(
    children: [
      Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
        ),
      ),
      SizedBox(width: 4),
      Text(
        "$count $label",
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: Theme.of(context).primaryTextColor,
        ),
      ),
    ],
  );
}
```

#### Display Rules

1. **Unattempted Subcategory:**
   - Show: `"0 True – 0 False – [Total Questions] Empty"`
   - No completion badge

2. **Partially Attempted:**
   - Show: `"X True – Y False – Z Empty"`
   - No completion badge
   - Empty count = Total - (Correct + Incorrect)

3. **Completed Subcategory:**
   - Show: `"X True – Y False – 0 Empty"` (or Z Empty if some were skipped)
   - Display green "Completed" badge with checkmark icon
   - Progress bar (if shown) should be 100% filled

---

## 4. Implementation Flow

### 4.1 When User Starts a Quiz

1. Load existing statistics for the subcategory (if any)
2. If no statistics exist, create default (all empty)
3. Start quiz session

### 4.2 When User Completes a Quiz

1. Calculate True/False/Empty counts from questions
2. Update subcategory statistics
3. Check if subcategory is completed
4. Sync statistics across Fun N Learn and Quiz Zone
5. Update category-level progress
6. Save to local storage and sync with backend

### 4.3 When Displaying Categories

1. Load all subcategory statistics for the category
2. Calculate completed subcategory count
3. Calculate progress percentage
4. Display progress bar and "Completed X/Y" label

### 4.4 When Displaying Subcategories

1. Load statistics for each subcategory
2. For unattempted subcategories, show default (0/0/Total Empty)
3. For attempted subcategories, show actual counts
4. Show completion badge if completed

---

## 5. Data Persistence Strategy

### 5.1 Local Storage

- **Primary**: SQLite database (recommended for complex queries)
- **Alternative**: SharedPreferences (for simple key-value storage)
- **Structure**: Store statistics by categoryId + subcategoryId + quizType

### 5.2 Backend Sync

- Send statistics to backend after each quiz completion
- Fetch latest statistics when app starts or category is opened
- Sync across devices for same user account

### 5.3 Cache Strategy

- Cache statistics in memory for current session
- Refresh cache when user completes a quiz
- Invalidate cache when navigating away from category

---

## 6. API Endpoints (Recommended)

### 6.1 Save Statistics

```
POST /api/quiz/subcategory/statistics
Body: {
  "category_id": "45",
  "subcategory_id": "123",
  "quiz_type": "funAndLearn", // or "quizZone"
  "correct_count": 12,
  "incorrect_count": 6,
  "empty_count": 2,
  "total_questions": 20,
  "is_completed": false
}
```

### 6.2 Get Statistics

```
GET /api/quiz/category/{categoryId}/statistics
Response: {
  "category_id": "45",
  "total_subcategories": 23,
  "completed_subcategories": 5,
  "subcategories": [
    {
      "subcategory_id": "123",
      "correct_count": 12,
      "incorrect_count": 6,
      "empty_count": 2,
      "total_questions": 20,
      "is_completed": false
    },
    ...
  ]
}
```

### 6.3 Sync Progress

```
POST /api/quiz/sync-progress
Body: {
  "category_id": "45",
  "sync_mode": "both" // Syncs both funAndLearn and quizZone
}
```

---

## 7. Testing Scenarios

1. **First Attempt**: User opens a subcategory for the first time
   - Should show: `0 True – 0 False – [Total] Empty`

2. **Partial Completion**: User answers some questions but exits
   - Should save progress and show partial counts

3. **Full Completion**: User answers all questions
   - Should mark as completed and show completion badge

4. **Cross-Mode Sync**: User completes in Fun N Learn, then checks Quiz Zone
   - Should show same statistics in both modes

5. **Category Progress**: Multiple subcategories completed
   - Should update "Completed X/23" label and progress bar

---

## 8. Edge Cases

1. **Question Count Mismatch**: If backend adds/removes questions
   - Recalculate statistics on next quiz attempt

2. **Network Failure**: Save locally, sync when connection restored

3. **Multiple Devices**: Use backend as source of truth, sync on login

4. **Quiz Reset**: Allow user to reset statistics (optional feature)

---

This specification provides a complete foundation for implementing the subcategory tracking system. All components are designed to work together seamlessly across both Fun N Learn and Quiz Zone modes.

