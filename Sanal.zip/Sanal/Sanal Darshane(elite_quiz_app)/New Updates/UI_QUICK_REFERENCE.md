# UI Quick Reference Guide

## 📱 Exact Display Requirements

### Category Card Display (Left Panel - İSTATİSTİK Example)

```
┌─────────────────────────────────────────┐
│  [Icon]  İSTATİSTİK                →   │
│         (Bahar Dönemi)                  │
│         Kapsayıcı: 23                   │
│         Completed                       │
│         ┌─────────────────────────────┐ │
│         │███████░░░░░░░░░░░░░░░░░░░░░░│ │  ← Progress Bar
│         └─────────────────────────────┘ │
│         Completed 5/23                  │  ← Label
└─────────────────────────────────────────┘
```

**Data Needed:**
- Category name: `category.categoryName`
- Subtitle: Hardcoded or from category data
- Total subcategories: `category.subcategoriesCount`
- Completed count: `progress.completedSubcategories`
- Progress percentage: `progress.completionPercentage`

**Display Format:**
- Status: "Completed" (always shown if category exists)
- Progress bar: Green fill = `completionPercentage / 100`
- Label: `"Completed ${completedCount}/${totalCount}"`

---

### Subcategory Card Display (Right Panel)

#### Case 1: Completed Subcategory (2024 Final Soruları)

```
┌─────────────────────────────────────────┐
│  [Icon]  2024 Final Soruları        →  │
│         Soru: 4                         │
│         ✅ Completed                    │  ← Badge
│         ──────────────────────────────  │  ← Divider
│         3 True – 1 False – 0 Empty      │  ← Stats at bottom
└─────────────────────────────────────────┘
```

**Display:**
- Name: `subcategory.subcategoryName`
- Question count: `statistics.totalQuestions`
- Completion badge: Green badge with checkmark (only if `statistics.isCompleted == true`)
- Statistics: `"${correctCount} True – ${incorrectCount} False – ${emptyCount} Empty"`

#### Case 2: Partially Attempted (2024 Vize Soruları)

```
┌─────────────────────────────────────────┐
│  [Icon]  2024 Vize Soruları         →  │
│         Soru: 20                        │
│         ──────────────────────────────  │  ← Divider (no badge)
│         12 True – 6 False – 2 Empty     │  ← Stats
└─────────────────────────────────────────┘
```

**Display:**
- Same structure as above
- **No completion badge** (because `statistics.isCompleted == false`)
- Statistics show actual counts

#### Case 3: Unattempted (2023 Vize Çıkmış Sorular)

```
┌─────────────────────────────────────────┐
│  [Icon]  2023 Vize Çıkmış Sorular   →  │
│         Soru: 22                        │
│         ──────────────────────────────  │
│         0 True – 0 False – 22 Empty     │  ← Default display
└─────────────────────────────────────────┘
```

**Display:**
- Statistics: `"0 True – 0 False – ${totalQuestions} Empty"`
- **No completion badge**

---

## 🎨 Visual Specifications

### Progress Bar (Category Card)

```dart
LinearProgressIndicator(
  value: progress.completionPercentage / 100.0,
  backgroundColor: Colors.grey[300],
  valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
  minHeight: 8,
  borderRadius: BorderRadius.circular(4),
)
```

**Color Scheme:**
- Background: `Colors.grey[300]`
- Fill: `Colors.green`
- Height: 8px

### Completion Badge (Subcategory Card)

```dart
if (statistics.isCompleted)
  Container(
    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(
      color: Colors.green,
      borderRadius: BorderRadius.circular(12),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.check, size: 16, color: Colors.white),
        SizedBox(width: 4),
        Text(
          "Completed",
          style: TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    ),
  ),
```

**Styling:**
- Background: Green
- Icon: White checkmark
- Text: White, bold, 12px
- Border radius: 12px
- Padding: 8px horizontal, 4px vertical

### Statistics Row (Bottom of Subcategory Card)

```dart
Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
  children: [
    _buildStatItem("True", statistics.correctCount, Colors.green),
    SizedBox(width: 16),
    _buildStatItem("False", statistics.incorrectCount, Colors.red),
    SizedBox(width: 16),
    _buildStatItem("Empty", statistics.emptyCount, Colors.grey),
  ],
)

Widget _buildStatItem(String label, int count, Color color) {
  return Row(
    children: [
      Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
        ),
      ),
      SizedBox(width: 4),
      Text(
        "$count $label",
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
    ],
  );
}
```

**Display Format:**
- Three items separated by spaces
- Format: `"[Count] [Label]"`
- Each with colored indicator dot
- Colors: Green (True), Red (False), Grey (Empty)

---

## 🔄 State Logic

### When to Show Completion Badge

```dart
bool shouldShowBadge = statistics.isCompleted;

// Completion is true when:
// - All questions answered (correct + incorrect = total)
// OR
// - Empty count = 0
```

### When to Show Default Stats

```dart
bool isUnattempted = !statistics.hasAttempted;

// Unattempted when:
// - correctCount == 0
// AND
// - incorrectCount == 0
// AND
// - emptyCount == totalQuestions
```

### Statistics Display String

```dart
String getStatisticsDisplay(SubcategoryStatistics stats) {
  return '${stats.correctCount} True – '
      '${stats.incorrectCount} False – '
      '${stats.emptyCount} Empty';
}
```

---

## 📊 Progress Calculation

### Category Progress Label

```dart
String getProgressLabel(CategoryProgress progress) {
  return 'Completed ${progress.completedSubcategories}/${progress.totalSubcategories}';
}
```

**Example Outputs:**
- `"Completed 0/23"` - No subcategories completed
- `"Completed 5/23"` - 5 out of 23 completed
- `"Completed 23/23"` - All completed

### Progress Bar Value

```dart
double progressValue = progress.completionPercentage / 100.0;

// Examples:
// 0/23 = 0.0 (0%)
// 5/23 = 0.217 (21.7%)
// 23/23 = 1.0 (100%)
```

---

## ✅ Checklist for Implementation

### Category Card
- [ ] Display category name
- [ ] Display subtitle (if applicable)
- [ ] Display "Kapsayıcı: X"
- [ ] Display "Completed" status text
- [ ] Show progress bar with correct fill percentage
- [ ] Show "Completed X/Y" label below progress bar

### Subcategory Card
- [ ] Display subcategory name
- [ ] Display "Soru: X" (total questions)
- [ ] Show completion badge ONLY if completed
- [ ] Add divider line
- [ ] Show statistics row: "X True – Y False – Z Empty"
- [ ] Use default stats (0/0/Total) for unattempted

### Data Loading
- [ ] Load statistics when category opens
- [ ] Create default stats for unattempted subcategories
- [ ] Calculate category progress from subcategory stats
- [ ] Refresh after quiz completion

### Synchronization
- [ ] Sync statistics across Fun N Learn and Quiz Zone
- [ ] Update both modes when quiz completed in either
- [ ] Merge statistics if both modes have data

---

## 🎯 Key Points to Remember

1. **Progress is based on completed SUBcategories, not questions**
   - "Completed 5/23" means 5 subcategories completed out of 23

2. **Statistics are shown for each subcategory**
   - True/False/Empty counts per subcategory

3. **Completion badge appears ONLY when all questions answered**
   - Not just when partially attempted

4. **Default display for unattempted:**
   - Always show "0 True – 0 False – [Total] Empty"

5. **Synchronization is key:**
   - Progress in Fun N Learn must reflect in Quiz Zone and vice versa

---

This quick reference provides exact specifications for implementing the UI as shown in your requirements image.

