package com.example.dev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
