// // import 'package:dev/pages/Tables.dart';
// // import 'package:flutter/material.dart';
// // import 'package:flutter/services.dart';
// // import 'package:flutter_localizations/flutter_localizations.dart';
// // import 'package:provider/provider.dart';
// //
// // import 'config.dart';
// // import 'helpers/AppTheme.dart';
// // import 'helpers/routes.dart';
// // import 'locale/MyLocalizations.dart';
// // import 'models/database.dart';
// //
// // void main() async {
// //   WidgetsFlutterBinding.ensureInitialized();
// //   //orientation setting
// //   //SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
// //   SystemChrome.setPreferredOrientations([
// //     DeviceOrientation.portraitUp,
// //     DeviceOrientation.portraitDown,
// //     DeviceOrientation.landscapeLeft,
// //     DeviceOrientation.landscapeRight,
// //   ]);
// //
// //   AppLanguage appLanguage = AppLanguage();
// //   await appLanguage.fetchLocale();
// //   await ShareInt().init();
// //   await AppConstants.getData();
// //
// //   // Initialize empty database (fast)
// //   await DbProvider().initializeDatabase(null);
// //
// //   runApp(MyApp(
// //     appLanguage: appLanguage,
// //   ));
// // }
// //
// // class MyApp extends StatelessWidget {
// //   final AppLanguage? appLanguage;
// //
// //   MyApp({this.appLanguage});
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return ChangeNotifierProvider<AppLanguage>(
// //       create: (_) => appLanguage!,
// //       child: Consumer<AppLanguage>(builder: (context, model, child) {
// //         return MaterialApp(
// //           routes: Routes.generateRoute(),
// //           initialRoute: '/splash',
// //           debugShowCheckedModeBanner: false,
// //           //Turns on a little "DEBUG" banner in checked mode to indicate that the app is in checked mode.
// //           theme: AppTheme.getThemeFromThemeMode(1),
// //           locale: model.appLocal,
// //           supportedLocales: Config().supportedLocales,
// //           localizationsDelegates: [
// //             AppLocalizations.delegate,
// //             GlobalMaterialLocalizations.delegate,
// //             GlobalCupertinoLocalizations.delegate,
// //             GlobalWidgetsLocalizations.delegate,
// //           ],
// //         );
// //       }),
// //     );
// //   }
// // }


/// New Changes
import 'package:dev/pages/Tables.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:device_preview/device_preview.dart';
import 'config.dart';
import 'firebase_options.dart';
import 'helpers/AppTheme.dart';
import 'helpers/routes.dart';
import 'locale/MyLocalizations.dart';
import 'models/database.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  //orientation setting
  //SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);

  // Initialize app language first (lightweight)
  AppLanguage appLanguage = AppLanguage();
  await appLanguage.fetchLocale();

  // Start the app immediately with minimal initialization
  runApp(MyApp(
    appLanguage: appLanguage,
  ));
  // runApp(
  //   DevicePreview(
  //     enabled: true,
  //     builder: (context) => MyApp(appLanguage: appLanguage),
  //   ),
  // );

  // Initialize heavy components in background
  _initializeInBackground();
}

// Initialize heavy components asynchronously without blocking startup
void _initializeInBackground() async {
  try {
    // Initialize SharedPreferences and AppConstants in parallel
    await Future.wait([
      ShareInt().init(),
      AppConstants.getData(),
    ]);

    // Initialize database in background (non-blocking)
    await DbProvider().initializeDatabase(null);
  } catch (e) {
    print('Background initialization error: $e');
  }
}

class MyApp extends StatelessWidget {
  final AppLanguage? appLanguage;

  MyApp({this.appLanguage});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<AppLanguage>(
      create: (_) => appLanguage!,
      child: Consumer<AppLanguage>(builder: (context, model, child) {
        return MaterialApp(
          routes: Routes.generateRoute(),
          initialRoute: '/splash',
          debugShowCheckedModeBanner: false,
          //Turns on a little "DEBUG" banner in checked mode to indicate that the app is in checked mode.
          theme: AppTheme.getThemeFromThemeMode(1),
          locale: model.appLocal,
          supportedLocales: Config().supportedLocales,
          localizationsDelegates: [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
        );
      }),
    );
  }
}


//
// ///This is for device_preview dependency when you enable from Pubspec.ymal
// import 'package:dev/pages/Tables.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_localizations/flutter_localizations.dart';
// import 'package:provider/provider.dart';
// import 'package:device_preview/device_preview.dart'; // 👈 add this
//
// import 'config.dart';
// import 'helpers/AppTheme.dart';
// import 'helpers/routes.dart';
// import 'locale/MyLocalizations.dart';
// import 'models/database.dart';
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//
// await Firebase.initializeApp(
// // options: DefaultFirebaseOptions.currentPlatform,
// );
//
//   SystemChrome.setPreferredOrientations([
//     DeviceOrientation.portraitUp,
//     DeviceOrientation.portraitDown,
//     DeviceOrientation.landscapeLeft,
//     DeviceOrientation.landscapeRight,
//   ]);
//
//   AppLanguage appLanguage = AppLanguage();
//   await appLanguage.fetchLocale();
//
//   runApp(
//     DevicePreview( // 👈 wrap your app here
//       enabled: true, // set to false in production
//       builder: (context) => MyApp(appLanguage: appLanguage),
//     ),
//   );
//
//   _initializeInBackground();
// }
//
// void _initializeInBackground() async {
//   try {
//     await Future.wait([
//       ShareInt().init(),
//       AppConstants.getData(),
//     ]);
//     await DbProvider().initializeDatabase(null);
//   } catch (e) {
//     print('Background initialization error: $e');
//   }
// }
//
// class MyApp extends StatelessWidget {
//   final AppLanguage? appLanguage;
//
//   MyApp({this.appLanguage});
//
//   @override
//   Widget build(BuildContext context) {
//     return ChangeNotifierProvider<AppLanguage>(
//       create: (_) => appLanguage!,
//       child: Consumer<AppLanguage>(
//         builder: (context, model, child) {
//           return MaterialApp(
//             useInheritedMediaQuery: true, // 👈 required for DevicePreview
//             builder: DevicePreview.appBuilder, // 👈 required
//             routes: Routes.generateRoute(),
//             initialRoute: '/splash',
//             debugShowCheckedModeBanner: false,
//             theme: AppTheme.getThemeFromThemeMode(1),
//             locale: model.appLocal,
//             supportedLocales: Config().supportedLocales,
//             localizationsDelegates: [
//               AppLocalizations.delegate,
//               GlobalMaterialLocalizations.delegate,
//               GlobalCupertinoLocalizations.delegate,
//               GlobalWidgetsLocalizations.delegate,
//             ],
//           );
//         },
//       ),
//     );
//   }
// }
