// import 'dart:async';
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import '../models/sellDatabase.dart';
// import '../models/system.dart';
// import 'api.dart';
//
// class SellApi extends Api {
//   Future<Map<String, dynamic>?> create(data) async {
//     String sellUrl = apiUrl + "sell";
//     print('SellApi.create: Preparing to send data to $sellUrl');
//
// // Validate payload
//     if (data['sells'] == null ||
//         data['sells'] is! List ||
//         data['sells'].isEmpty) {
//       print(
//           'SellApi.create: Invalid payload: Expected non-empty "sells" list, got: $data');
//       return null;
//     }
//
// // Format tip_amount in sells
//     for (var sell in data['sells']) {
//       sell['tip_amount'] = sell['tip_amount']?.toString() ?? '0.00';
//       print('SellApi.create: Formatted sell data: ${jsonEncode(sell)}');
//     }
//
// // Get authentication token
//     var token = await System().getToken();
//     if (token == null) {
//       print('SellApi.create: Error: No token available for API request');
//       return null;
//     }
//     print('SellApi.create: Token used for API request: $token');
//
//     try {
//       print(
//           'SellApi.create: Sending POST to $sellUrl with body: ${jsonEncode(data)}');
//       var response = await http
//           .post(
//         Uri.parse(sellUrl),
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Authorization': 'Bearer $token',
//         },
//         body: jsonEncode(data),
//       )
//           .timeout(Duration(seconds: 30), onTimeout: () {
//         print('SellApi.create: API request timed out after 30 seconds');
//         throw TimeoutException('API request timed out after 30 seconds');
//       });
//
//       print('SellApi.create: API Response Status: ${response.statusCode}');
//       print('SellApi.create: API Response Body: ${response.body}');
//
//       if (response.body.isEmpty) {
//         print('SellApi.create: API Error: Empty response body');
//         return null;
//       }
//
//       Map<String, dynamic> info;
//       try {
//         info = jsonDecode(response.body);
//       } catch (e) {
//         print('SellApi.create: JSON Decode Error: $e');
//         return null;
//       }
//       print('SellApi.create: Parsed API Response: ${jsonEncode(info)}');
//
//       if (response.statusCode == 200) {
//         Map<String, dynamic> result;
//         if (info.containsKey('data') &&
//             info['data'] is List &&
//             info['data'].isNotEmpty) {
//           var sellData = info['data'];
//           result = {
//             'transaction_id': sellData[0]['id'],
//             'payment_lines': sellData[0]['payment_lines'] ?? [],
//             'invoice_url': sellData[0]['invoice_url'] ?? '',
//             'tip_type': sellData[0]['tip_type'] ?? 'fixed',
//             'tip_amount': sellData[0]['tip_amount']?.toString() ?? '0.00',
//           };
//         } else if (info.containsKey('data') && info['data'] is Map) {
//           var firstSell = info['data'].values.isNotEmpty
//               ? info['data'].values.first
//               : info['data'];
//           if (firstSell is Map<String, dynamic>) {
//             result = {
//               'transaction_id': firstSell['id'],
//               'payment_lines': firstSell['payment_lines'] ?? [],
//               'invoice_url': firstSell['invoice_url'] ?? '',
//               'tip_type': firstSell['tip_type'] ?? 'fixed',
//               'tip_amount': firstSell['tip_amount']?.toString() ?? '0.00',
//             };
//           } else {
//             print(
//                 'SellApi.create: Unexpected data format in info[\'data\']: ${info['data']}');
//             return null;
//           }
//         } else if (info is Map) {
//           result = {
//             'transaction_id': info['id'],
//             'payment_lines': info['payment_lines'] ?? [],
//             'invoice_url': info['invoice_url'] ?? '',
//             'tip_type': info['tip_type'] ?? 'fixed',
//             'tip_amount': info['tip_amount']?.toString() ?? '0.00',
//           };
//         } else {
//           print('SellApi.create: Unexpected response format: $info');
//           return null;
//         }
//         print('SellApi.create: Parsed API Result: $result');
//         return result;
//       } else {
//         print(
//             'SellApi.create: API Error: ${response.statusCode} - ${response.body}');
//         return null;
//       }
//     } catch (e, stackTrace) {
//       print('SellApi.create: Error: $e');
//       print('SellApi.create: Stack Trace: $stackTrace');
//       return null;
//     }
//   }
//
//   Future<Map<String, dynamic>?> update(transactionId, data) async {
//     String url = apiUrl + "sell/$transactionId";
// // Validate payload
//     if (data == null || data.isEmpty) {
//       print('SellApi.update: Invalid payload: $data');
//       return null;
//     }
// // Ensure tip_amount is formatted as a string
//     data['tip_amount'] = data['tip_amount']?.toString() ?? '0.00';
//     var token = await System().getToken();
//     if (token == null) {
//       print('SellApi.update: Error: No token available for API request');
//       return null;
//     }
//     print('SellApi.update: Updating API: $url, Body: ${jsonEncode(data)}');
//
//     try {
//       var response = await http
//           .put(
//         Uri.parse(url),
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Authorization': 'Bearer $token',
//         },
//         body: jsonEncode(data),
//       )
//           .timeout(Duration(seconds: 30), onTimeout: () {
//         print('SellApi.update: API request timed out after 30 seconds');
//         throw TimeoutException('API request timed out after 30 seconds');
//       });
//
//       print('SellApi.update: API Response Status: ${response.statusCode}');
//       print('SellApi.update: API Response Body: ${response.body}');
//
//       if (response.body.isEmpty) {
//         print('SellApi.update: API Error: Empty response body');
//         return null;
//       }
//
//       Map<String, dynamic> sellResponse;
//       try {
//         sellResponse = jsonDecode(response.body);
//       } catch (e) {
//         print('SellApi.update: JSON Decode Error: $e');
//         return null;
//       }
//
//       if (response.statusCode == 200) {
//         print('SellApi.update: Successfully updated sell: $transactionId');
//         return {
//           'payment_lines': sellResponse['payment_lines'] ?? [],
//           'invoice_url': sellResponse['invoice_url'] ?? '',
//           'tip_amount': sellResponse['tip_amount']?.toString() ?? '0.00',
//           'tip_type': sellResponse['tip_type'] ?? 'fixed',
//         };
//       } else {
//         print(
//             'SellApi.update: API Error: ${response.statusCode} - ${response.body}');
//         return null;
//       }
//     } catch (e, stackTrace) {
//       print('SellApi.update: Error: $e');
//       print('SellApi.update: Stack Trace: $stackTrace');
//       return null;
//     }
//   }
//
//   Future<Map<String, dynamic>?> delete(transactionId) async {
//     String url = apiUrl + "sell/$transactionId";
//     var token = await System().getToken();
//     if (token == null) {
//       print('SellApi.delete: Error: No token available for API request');
//       return null;
//     }
//     print('SellApi.delete: Deleting API: $url');
//
//     try {
//       var response = await http.delete(
//         Uri.parse(url),
//         headers: {
//           'Accept': 'application/json',
//           'Authorization': 'Bearer $token',
//         },
//       ).timeout(Duration(seconds: 30), onTimeout: () {
//         print('SellApi.delete: API request timed out after 30 seconds');
//         throw TimeoutException('API request timed out after 30 seconds');
//       });
//
//       print('SellApi.delete: API Response Status: ${response.statusCode}');
//       print('SellApi.delete: API Response Body: ${response.body}');
//
//       if (response.body.isEmpty) {
//         print('SellApi.delete: API Error: Empty response body');
//         return null;
//       }
//
//       if (response.statusCode == 200) {
//         print('SellApi.delete: Successfully deleted sell: $transactionId');
//         try {
//           return jsonDecode(response.body);
//         } catch (e) {
//           print('SellApi.delete: JSON Decode Error: $e');
//           return null;
//         }
//       } else {
//         print(
//             'SellApi.delete: API Error: ${response.statusCode} - ${response.body}');
//         return null;
//       }
//     } catch (e, stackTrace) {
//       print('SellApi.delete: Error: $e');
//       print('SellApi.delete: Stack Trace: $stackTrace');
//       return null;
//     }
//   }
//
//   Future<List> getSpecifiedSells(List transactionIds) async {
//     String ids = transactionIds.join(",");
//     String url = apiUrl + "sell/$ids";
//     var token = await System().getToken();
//     if (token == null) {
//       print(
//           'SellApi.getSpecifiedSells: Error: No token available for API request');
//       return [];
//     }
//     print('SellApi.getSpecifiedSells: Fetching sells for IDs: $ids, URL: $url');
//
//     List response = [];
//     try {
//       var httpResponse = await http.get(
//         Uri.parse(url),
//         headers: {
//           'Accept': 'application/json',
//           'Authorization': 'Bearer $token',
//         },
//       ).timeout(Duration(seconds: 30), onTimeout: () {
//         print(
//             'SellApi.getSpecifiedSells: API request timed out after 30 seconds');
//         throw TimeoutException('API request timed out after 30 seconds');
//       });
//
//       print(
//           'SellApi.getSpecifiedSells: API Response Status: ${httpResponse.statusCode}');
//       print(
//           'SellApi.getSpecifiedSells: API Response Body: ${httpResponse.body}');
//
//       if (httpResponse.body.isEmpty) {
//         print('SellApi.getSpecifiedSells: API Error: Empty response body');
//         return response;
//       }
//
//       if (httpResponse.body.contains('data')) {
//         try {
//           response = jsonDecode(httpResponse.body)['data'];
//           var responseTransactionIds =
//               response.map((element) => element['id']).toList();
//           print(
//               'SellApi.getSpecifiedSells: Received transaction IDs: $responseTransactionIds');
//
//           for (var id in transactionIds) {
//             if (!responseTransactionIds.contains(id)) {
//               var sell = await SellDatabase().getSellByTransactionId(id);
//               if (sell.isNotEmpty) {
//                 print(
//                     'SellApi.getSpecifiedSells: Deleting outdated sell with transaction ID: $id');
//                 await SellDatabase().deleteSell(sell[0]['id']);
//               }
//             }
//           }
//         } catch (e) {
//           print('SellApi.getSpecifiedSells: JSON Decode Error: $e');
//         }
//       }
//     } catch (e, stackTrace) {
//       print('SellApi.getSpecifiedSells: Error: $e');
//       print('SellApi.getSpecifiedSells: Stack Trace: $stackTrace');
//     }
//     return response;
//   }
// }


import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import '../models/sellDatabase.dart';
import '../models/system.dart';
import 'api.dart';

class SellApi extends Api {
  // Helper method to get standardized headersz
  Map<String, String> getHeader(String? token) {
    return {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  Future<Map<String, dynamic>?> create(data) async {
    String sellUrl = apiUrl + "sell";                               //API
    print('SellApi.create: Preparing to send to $sellUrl');

    // Validate payload
    if (data['sells'] == null || data['sells'] is! List || data['sells'].isEmpty) {
      print('SellApi.create: Invalid payload: Expected non-empty "sells" list, got: $data');
      return {'error': 'Invalid payload: No sells provided'};
    }

    // Ensure products are present and card_details is serialized
    for (var sell in data['sells']) {
      sell['tip_amount'] = sell['tip_amount']?.toString() ?? '0.00';
      if (sell['products'] == null || sell['products'].isEmpty) {
        print('SellApi.create: Error: No products in sell: ${jsonEncode(sell)}');
        return {'error': 'No products added'};
      }
      for (var payment in sell['payments']) {
        if (payment['card_details'] != null && payment['card_details'] is Map) {
          payment['card_details'] = jsonEncode(payment['card_details']);
        }
      }
      print('SellApi.create: Formatted sell: ${jsonEncode(sell)}');
    }

    // Get token
    var token = await System().getToken();
    if (token == null) {
      print('SellApi.create: Error: No token available for API request');
      return {'error': 'No authentication token available'};
    }
    log('SellApi.create: Token: $token');

    try {
      log('SellApi.create: Sending POST to $sellUrl, \nBody: ${jsonEncode(data)}');
      var response = await http
          .post(
        Uri.parse(sellUrl),
        headers: getHeader(token),
        body: jsonEncode(data),
      )
          .timeout(Duration(seconds: 30), onTimeout: () {
        print('SellApi.create: API request timed out after 30 seconds');
        throw TimeoutException('API request timed out after 30 seconds');
      });

      print('SellApi.create: Response Status: ${response.statusCode}');
      print('SellApi.create: Response Body: ${response.body}');

      if (response.body.isEmpty) {
        print('SellApi.create: Error: Empty response body');
        return {'error': 'Empty response from server'};
      }

      dynamic info;
      try {
        info = jsonDecode(response.body);
      } catch (e) {
        print('SellApi.create: JSON Decode Error: $e');
        return {'error': 'Invalid response format: $e'};
      }
      print('SellApi.create: Parsed Response: ${jsonEncode(info)}');

      if (response.statusCode == 200) {
        Map<String, dynamic> result;
        if (info is List && info.isNotEmpty) {
          // Handle list response
          var firstItem = info[0];
          if (firstItem is Map && firstItem.containsKey('original') && firstItem['original'].containsKey('error')) {
            print('SellApi.create: Server error: ${firstItem['original']['error']['message']}');
            return {'error': firstItem['original']['error']['message']};
          }
          var sellData = firstItem is Map && firstItem.containsKey('data') ? firstItem['data'] : firstItem;
          if (sellData is Map) {
            result = {
              'transaction_id': sellData['id'],
              'payment_lines': sellData['payment_lines'] ?? [],
              'invoice_url': sellData['invoice_url'] ?? '',
              'tip_type': sellData['tip_type'] ?? 'fixed',
              'tip_amount': sellData['tip_amount']?.toString() ?? '0.00',
            };
          } else if (sellData is List && sellData.isNotEmpty) {
            result = {
              'transaction_id': sellData[0]['id'],
              'payment_lines': sellData[0]['payment_lines'] ?? [],
              'invoice_url': sellData[0]['invoice_url'] ?? '',
              'tip_type': sellData[0]['tip_type'] ?? 'fixed',
              'tip_amount': sellData[0]['tip_amount']?.toString() ?? '0.00',
            };
          } else {
            print('SellApi.create: Unexpected sellData format: $sellData');
            return {'error': 'Unexpected data format'};
          }
        } else if (info is Map && info.containsKey('data')) {
          var sellData = info['data'];
          if (sellData is Map) {
            result = {
              'transaction_id': sellData['id'],
              'payment_lines': sellData['payment_lines'] ?? [],
              'invoice_url': sellData['invoice_url'] ?? '',
              'tip_type': sellData['tip_type'] ?? 'fixed',
              'tip_amount': sellData['tip_amount']?.toString() ?? '0.00',
            };
          } else if (sellData is List && sellData.isNotEmpty) {
            result = {
              'transaction_id': sellData[0]['id'],
              'payment_lines': sellData[0]['payment_lines'] ?? [],
              'invoice_url': sellData[0]['invoice_url'] ?? '',
              'tip_type': sellData[0]['tip_type'] ?? 'fixed',
              'tip_amount': sellData[0]['tip_amount']?.toString() ?? '0.00',
            };
          } else {
            print('SellApi.create: Unexpected sellData format: $sellData');
            return {'error': 'Unexpected data format'};
          }
        } else if (info is Map) {
          result = {
            'transaction_id': info['id'],
            'payment_lines': info['payment_lines'] ?? [],
            'invoice_url': info['invoice_url'] ?? '',
            'tip_type': info['tip_type'] ?? 'fixed',
            'tip_amount': info['tip_amount']?.toString() ?? '0.00',
          };
        } else {
          print('SellApi.create: Unexpected response format: $info');
          return {'error': 'Unexpected response format'};
        }
        print('SellApi.create: Success: $result');
        return result;
      } else {
        print('SellApi.create: Error: ${response.statusCode} - ${response.body}');
        return {'error': 'Server error: ${response.statusCode} - ${response.body}'};
      }
    } catch (e, stackTrace) {
      print('SellApi.create: Error: $e');
      print('SellApi.create: Stack Trace: $stackTrace');
      return {'error': 'Request failed: $e'};
    }
  }

  Future<Map<String, dynamic>?> update(transactionId, data) async {
    String url = apiUrl + "sell/$transactionId";

    // Validate and clean data before sending
    // Ensure all string fields are actually strings, not Maps
    Map<String, dynamic> cleanedData = Map<String, dynamic>.from(data);

    // List of fields that should be strings (not Maps)
    List<String> stringFields = ['sale_note', 'staff_note', 'order_note', 'shipping_details', 'status', 'sub_status', 'discount_type', 'tip_type', 'transaction_date'];

    // Ensure order_note is always present (API requires it)
    if (!cleanedData.containsKey('order_note')) {
      cleanedData['order_note'] = cleanedData['sale_note'] ?? '';
      print('SellApi.update: Added missing order_note field (using sale_note as fallback)');
    }

    for (String field in stringFields) {
      if (cleanedData.containsKey(field) && cleanedData[field] != null) {
        if (cleanedData[field] is Map) {
          print('SellApi.update: WARNING - Converting Map to JSON string for field "$field"');
          cleanedData[field] = jsonEncode(cleanedData[field]);
        } else if (cleanedData[field] is! String) {
          cleanedData[field] = cleanedData[field].toString();
        }
      } else if (field == 'order_note' && !cleanedData.containsKey(field)) {
        // Ensure order_note is always a string, even if null
        cleanedData[field] = '';
      }
    }

    // Serialize card_details in payments (only if payments exists and is a list)
    if (cleanedData['payments'] != null && cleanedData['payments'] is List) {
      for (var payment in cleanedData['payments']) {
        if (payment != null && payment is Map && payment['card_details'] != null && payment['card_details'] is Map) {
          payment['card_details'] = jsonEncode(payment['card_details']);
        }
      }
    }
    cleanedData['tip_amount'] = cleanedData['tip_amount']?.toString() ?? '0.00';

    var token = await System().getToken();
    if (token == null) {
      print('SellApi.update: Error: No token available for API request');
      return {'error': 'No authentication token available'};
    }
    print('SellApi.update: Sending PUT to $url, Body: ${jsonEncode(cleanedData)}');

    try {
      var response = await http
          .put(
        Uri.parse(url),
        headers: getHeader(token),
        body: jsonEncode(cleanedData),
      )
          .timeout(Duration(seconds: 30), onTimeout: () {
        print('SellApi.update: API request timed out after 30 seconds');
        throw TimeoutException('API request timed out after 30 seconds');
      });

      print('SellApi.update: Response Status: ${response.statusCode}');
      print('SellApi.update: Response Body: ${response.body}');

      if (response.body.isEmpty) {
        print('SellApi.update: Error: Empty response body');
        return {'error': 'Empty response from server'};
      }

      Map<String, dynamic> sellResponse;
      try {
        sellResponse = jsonDecode(response.body);
      } catch (e) {
        print('SellApi.update: JSON Decode Error: $e');
        return {'error': 'Invalid response format: $e'};
      }

      if (response.statusCode == 200) {
        print('SellApi.update: Success: Updated transaction $transactionId');
        return {
          'payment_lines': sellResponse['payment_lines'] ?? [],
          'invoice_url': sellResponse['invoice_url'] ?? '',
          'tip_type': sellResponse['tip_type'] ?? 'fixed',
          'tip_amount': sellResponse['tip_amount']?.toString() ?? '0.00',
        };
      } else {
        print('SellApi.update: Error: ${response.statusCode} - ${response.body}');
        return {'error': 'Server error: ${response.statusCode} - ${response.body}'};
      }
    } catch (e, stackTrace) {
      print('SellApi.update: Error: $e');
      print('SellApi.update: Stack Trace: $stackTrace');
      return {'error': 'Request failed: $e'};
    }
  }

  Future<Map<String, dynamic>?> delete(transactionId) async {
    String url = apiUrl + "sell/$transactionId";
    var token = await System().getToken();
    if (token == null) {
      print('SellApi.delete: Error: No token available for API request');
      return {'error': 'No authentication token available'};
    }
    print('SellApi.delete: Sending DELETE to $url');

    try {
      var response = await http
          .delete(
        Uri.parse(url),
        headers: getHeader(token),
      )
          .timeout(Duration(seconds: 30), onTimeout: () {
        print('SellApi.delete: API request timed out after 30 seconds');
        throw TimeoutException('API request timed out after 30 seconds');
      });

      print('SellApi.delete: Response Status: ${response.statusCode}');
      print('SellApi.delete: Response Body: ${response.body}');

      if (response.body.isEmpty) {
        print('SellApi.delete: Error: Empty response body');
        return {'error': 'Empty response from server'};
      }

      Map<String, dynamic> responseBody;
      try {
        responseBody = jsonDecode(response.body);
      } catch (e) {
        print('SellApi.delete: JSON Decode Error: $e');
        return {'error': 'Invalid response format: $e'};
      }

      if (response.statusCode == 200) {
        print('SellApi.delete: Success: Deleted transaction $transactionId');
        return responseBody;
      } else {
        print('SellApi.delete: Error: ${response.statusCode} - ${response.body}');
        return {'error': 'Server error: ${response.statusCode} - ${response.body}'};
      }
    } catch (e, stackTrace) {
      print('SellApi.delete: Error: $e');
      print('SellApi.delete: Stack Trace: $stackTrace');
      return {'error': 'Request failed: $e'};
    }
  }

  Future<List> getSpecifiedSells(List transactionIds) async {
    String ids = transactionIds.join(",");
    String url = apiUrl + "sell/$ids";
    var token = await System().getToken();
    if (token == null) {
      print('SellApi.getSpecifiedSells: Error: No token available for API request');
      return [];
    }
    print('SellApi.getSpecifiedSells: Sending GET to $url');

    List response = [];
    try {
      var httpResponse = await http
          .get(
        Uri.parse(url),
        headers: getHeader(token),
      )
          .timeout(Duration(seconds: 30), onTimeout: () {
        print('SellApi.getSpecifiedSells: API request timed out after 30 seconds');
        throw TimeoutException('API request timed out after 30 seconds');
      });

      print('SellApi.getSpecifiedSells: Response Status: ${httpResponse.statusCode}');
      print('SellApi.getSpecifiedSells: Response Body: ${httpResponse.body}');

      if (httpResponse.body.contains('data')) {
        response = jsonDecode(httpResponse.body)['data'] ?? [];
        var responseTransactionIds = response.map((element) => element['id']).toList();
        print('SellApi.getSpecifiedSells: Received transaction IDs: $responseTransactionIds');

        for (var id in transactionIds) {
          if (!responseTransactionIds.contains(id)) {
            var sell = await SellDatabase().getSellByTransactionId(id);
            if (sell.isNotEmpty) {
              print('SellApi.getSpecifiedSells: Deleting outdated sell with transaction ID: $id');
              await SellDatabase().deleteSell(sell[0]['id']);
            }
          }
        }
      } else {
        print('SellApi.getSpecifiedSells: No data field in response');
      }
    } catch (e, stackTrace) {
      print('SellApi.getSpecifiedSells: Error: $e');
      print('SellApi.getSpecifiedSells: Stack Trace: $stackTrace');
    }
    return response;
  }

  Future<Map<String, dynamic>?> getCustomerById(int contactId) async {
    try {
      final response = await http.get(
        Uri.parse('https://api.example.com/customers/$contactId'),
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      return null;
    } catch (e) {
      print('Error fetching customer from API: $e');
      return null;
    }
  }
}