// import 'dart:convert';
//
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../apis/tax.dart';
// import '../models/system.dart';
// import 'api.dart';
// import 'contact.dart';
//
// class SystemApi {
//
//   /// Fetch only the payment details / balances quickly for Home screen
//   Future<List> fetchPaymentDetailsQuick([String? accessToken]) async {
//     try {
//       String token = accessToken ?? (await System().getToken()) ?? '';
//       if (token.isEmpty) throw Exception('No token found');
//
//       // Call only the payment methods endpoint
//       String url = Api().apiUrl + "payment-methods";
//       var response = await http.get(Uri.parse(url), headers: Api().getHeader(token));
//
//       final paymentData = jsonDecode(response.body);
//
//       // Store in local DB so Home can use it right away
//       List paymentList = [];
//       paymentData.forEach((key, value) {
//         paymentList.add({key: value});
//       });
//       await System().insert('payment_methods', jsonEncode(paymentList));
//
//       return paymentList;
//     } catch (e) {
//       print("fetchPaymentDetailsQuick error: $e");
//       return [];
//     }
//   }
//
//   Future<String?> getToken() async {
//     final prefs = await SharedPreferences.getInstance();
//     final token = prefs.getString('token');
//     print('System.getToken: Retrieved token: $token');
//     return token;
//   }
//
//   Future<void> insertToken(String token) async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.setString('token', token);
//     print('System.insertToken: Stored token: $token');
//   }
//
//   Future<void> store() async {
//     await Business().get();
//     await Permissions().get();
//     await ActiveSubscription().get();
//     await CustomerApi().get();
//     await Brand().get();
//     await Category().get();
//     await Payment().get();
//     await Tax().get();
//     await Location().get();
//     await PaymentAccounts().get();
//   }
// }
//
// class Brand extends Api {
//   var brands;
//
//   Future<List> get() async {
//     try {
//       String url = this.apiUrl + "brand";
//       var token = await System().getToken();
//       var response =
//           await http.get(Uri.parse(url), headers: this.getHeader('$token'));
//       brands = jsonDecode(response.body);
//       var brandList = brands['data'];
//       System().insert('brand', jsonEncode(brandList));
//       return brandList;
//     } catch (e) {
//       return [];
//     }
//   }
// }
//
// class Category extends Api {
//   var taxonomy;
//
//   Future<List> get() async {
//     try {
//       String url = this.apiUrl + "taxonomy?type=product";
//       var token = await System().getToken();
//       var response =
//       await http.get(Uri.parse(url), headers: this.getHeader('$token'));
//       taxonomy = jsonDecode(response.body);
//       var categoryList = taxonomy['data'];
//       System().insert('taxonomy', jsonEncode(categoryList));
//       taxonomy['data'].forEach((element) {
//         if (element['sub_categories'].isNotEmpty) {
//           element['sub_categories'].forEach((value) {
//             System().insert(
//                 'sub_categories',
//                 jsonEncode({'id': value['id'], 'name': value['name']}),
//                 value['parent_id']);
//           });
//         }
//       });
//       return categoryList;
//     } catch (e) {
//       return [];
//     }
//   }
// }
//
// class Payment extends Api {
//   late Map payment;
//
//   Future<List> get() async {
//     try {
//       String url = this.apiUrl + "payment-methods";
//       var token = await System().getToken();
//       var response =
//           await http.get(Uri.parse(url), headers: this.getHeader('$token'));
//       payment = jsonDecode(response.body);
//       List paymentList = [];
//       payment.forEach((key, value) {
//         paymentList.add({key: value});
//       });
//       System().insert('payment_methods', jsonEncode(paymentList));
//       return paymentList;
//     } catch (e) {
//       return [];
//     }
//   }
// }
//
// class Permissions extends Api {
//   get() async {
//     try {
//       String url = apiUrl + "user/loggedin";
//       var token = await System().getToken();
//       var response =
//           await http.get(Uri.parse(url), headers: this.getHeader(token));
//       var userDetails = jsonDecode(response.body);
//       Map userDetailsMap = userDetails['data'];
//       if (userDetailsMap.containsKey('all_permissions')) {
//         var userData = jsonEncode(userDetailsMap['all_permissions']);
//         await System().insert('user_permissions', userData);
//       }
//     } catch (e) {}
//   }
// }
//
// class Location extends Api {
//   var locations;
//
//   Future<List?> get() async {
//     try {
//       String url = this.apiUrl + "business-location";
//       var token = await System().getToken();
//       var response =
//           await http.get(Uri.parse(url), headers: this.getHeader('$token'));
//       locations = jsonDecode(response.body);
//
//       List? locationList = locations['data'];
//       System().insert('location', jsonEncode(locationList));
//       if (locationList != null) {
//         locationList.forEach((element) {
//           System().insert('payment_method',
//               jsonEncode(element['payment_methods']), element['id']);
//         });
//       }
//       return locationList;
//     } catch (e) {
//       return [];
//     }
//   }
// }
//
// class Business extends Api {
//   var business;
//
//   Future<List> get() async {
//     try {
//       String url = this.apiUrl + "business-details";
//       var token = await System().getToken();
//       var response =
//           await http.get(Uri.parse(url), headers: this.getHeader('$token'));
//       business = jsonDecode(response.body);
//       List businessDetails = [business['data']];
//       System().insert('business', jsonEncode(businessDetails));
//       return businessDetails;
//     } catch (e) {
//       return [];
//     }
//   }
// }
//
// class ActiveSubscription extends Api {
//   var activeSubscription;
//
//   Future<List> get() async {
//     try {
//       String url = this.apiUrl + "active-subscription";
//       var token = await System().getToken();
//       var response =
//           await http.get(Uri.parse(url), headers: this.getHeader('$token'));
//       activeSubscription = jsonDecode(response.body);
//       List activeSubscriptionDetails = (activeSubscription['data'].isNotEmpty)
//           ? [activeSubscription['data']]
//           : [];
//       System()
//           .insert('active-subscription', jsonEncode(activeSubscriptionDetails));
//       return activeSubscriptionDetails;
//     } catch (e) {
//       return [];
//     }
//   }
// }
//
// class PaymentAccounts extends Api {
//   Future<List> get() async {
//     try {
//       var accounts;
//       String url = this.apiUrl + "payment-accounts";
//       var token = await System().getToken();
//       var response =
//           await http.get(Uri.parse(url), headers: this.getHeader('$token'));
//       accounts = jsonDecode(response.body);
//       List paymentAccounts = accounts['data'];
//       System().insert('payment_accounts', jsonEncode(paymentAccounts));
//       return paymentAccounts;
//     } catch (e) {
//       return [];
//     }
//   }
//
//
// }
import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../apis/tax.dart';
import '../models/system.dart';
import 'api.dart';
import 'contact.dart';

class SystemApi {

  /// Fetch only the payment details / balances quickly for Home screen
  Future<List> fetchPaymentDetailsQuick([String? accessToken]) async {
    try {
      String token = accessToken ?? (await System().getToken()) ?? '';
      if (token.isEmpty) throw Exception('No token found');

      // Call only the payment methods endpoint
      String url = Api().apiUrl + "payment-methods";
      var response = await http.get(Uri.parse(url), headers: Api().getHeader(token));

      final paymentData = jsonDecode(response.body);

      // Store in local DB so Home can use it right away
      List paymentList = [];
      paymentData.forEach((key, value) {
        paymentList.add({key: value});
      });
      await System().insert('payment_methods', jsonEncode(paymentList));

      return paymentList;
    } catch (e) {
      print("fetchPaymentDetailsQuick error: $e");
      return [];
    }
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    print('System.getToken: Retrieved token: $token');
    return token;
  }

  Future<void> insertToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
    print('System.insertToken: Stored token: $token');
  }

  Future<void> store() async {
    // Load essential data first (parallel execution)
    await Future.wait<void>([
      Business().get(),
      Permissions().get(),
      Location().get(),
      Payment().get(),
    ]);

    // Load non-essential data in background (parallel execution)
    unawaited(Future.wait<void>([
      ActiveSubscription().get(),
      CustomerApi().get(),
      Brand().get(),
      Category().get(),
      Tax().get(),
      PaymentAccounts().get(),
    ]));
  }

  /// Load only essential data for fast startup
  Future<void> storeEssential() async {
    await Future.wait<void>([
      Business().get(),
      Location().get(),
      Payment().get(),
    ]);
  }
}

class Brand extends Api {
  var brands;

  Future<List> get() async {
    try {
      String url = this.apiUrl + "brand";
      var token = await System().getToken();
      var response =
      await http.get(Uri.parse(url), headers: this.getHeader('$token'));
      brands = jsonDecode(response.body);
      var brandList = brands['data'];
      System().insert('brand', jsonEncode(brandList));
      return brandList;
    } catch (e) {
      return [];
    }
  }
}

class Category extends Api {
  var taxonomy;

  Future<List> get() async {
    try {
      String url = this.apiUrl + "taxonomy?type=product";
      var token = await System().getToken();
      var response =
      await http.get(Uri.parse(url), headers: this.getHeader('$token'));
      taxonomy = jsonDecode(response.body);
      var categoryList = taxonomy['data'];
      System().insert('taxonomy', jsonEncode(categoryList));
      taxonomy['data'].forEach((element) {
        if (element['sub_categories'].isNotEmpty) {
          element['sub_categories'].forEach((value) {
            System().insert(
                'sub_categories',
                jsonEncode({'id': value['id'], 'name': value['name']}),
                value['parent_id']);
          });
        }
      });
      return categoryList;
    } catch (e) {
      return [];
    }
  }
}

class Payment extends Api {
  late Map payment;

  Future<List> get() async {
    try {
      String url = this.apiUrl + "payment-methods";
      var token = await System().getToken();
      var response =
      await http.get(Uri.parse(url), headers: this.getHeader('$token'));
      payment = jsonDecode(response.body);
      List paymentList = [];
      payment.forEach((key, value) {
        paymentList.add({key: value});
      });
      System().insert('payment_methods', jsonEncode(paymentList));
      return paymentList;
    } catch (e) {
      return [];
    }
  }
}

class Permissions extends Api {
  get() async {
    try {
      String url = apiUrl + "user/loggedin";
      var token = await System().getToken();
      var response =
      await http.get(Uri.parse(url), headers: this.getHeader(token));
      var userDetails = jsonDecode(response.body);
      Map userDetailsMap = userDetails['data'];
      if (userDetailsMap.containsKey('all_permissions')) {
        var userData = jsonEncode(userDetailsMap['all_permissions']);
        await System().insert('user_permissions', userData);
      }
    } catch (e) {}
  }
}

class Location extends Api {
  var locations;

  Future<List?> get() async {
    try {
      String url = this.apiUrl + "business-location";
      var token = await System().getToken();
      var response =
      await http.get(Uri.parse(url), headers: this.getHeader('$token'));
      locations = jsonDecode(response.body);

      List? locationList = locations['data'];
      System().insert('location', jsonEncode(locationList));
      if (locationList != null) {
        locationList.forEach((element) {
          System().insert('payment_method',
              jsonEncode(element['payment_methods']), element['id']);
        });
      }
      return locationList;
    } catch (e) {
      return [];
    }
  }
}

class Business extends Api {
  var business;

  Future<List> get() async {
    try {
      String url = this.apiUrl + "business-details";
      var token = await System().getToken();
      var response =
      await http.get(Uri.parse(url), headers: this.getHeader('$token'));
      business = jsonDecode(response.body);
      List businessDetails = [business['data']];
      System().insert('business', jsonEncode(businessDetails));
      return businessDetails;
    } catch (e) {
      return [];
    }
  }
}

class ActiveSubscription extends Api {
  var activeSubscription;

  Future<List> get() async {
    try {
      String url = this.apiUrl + "active-subscription";
      var token = await System().getToken();
      var response =
      await http.get(Uri.parse(url), headers: this.getHeader('$token'));
      activeSubscription = jsonDecode(response.body);
      List activeSubscriptionDetails = (activeSubscription['data'].isNotEmpty)
          ? [activeSubscription['data']]
          : [];
      System()
          .insert('active-subscription', jsonEncode(activeSubscriptionDetails));
      return activeSubscriptionDetails;
    } catch (e) {
      return [];
    }
  }
}

class PaymentAccounts extends Api {
  Future<List> get() async {
    try {
      var accounts;
      String url = this.apiUrl + "payment-accounts";
      var token = await System().getToken();
      var response =
      await http.get(Uri.parse(url), headers: this.getHeader('$token'));
      accounts = jsonDecode(response.body);
      List paymentAccounts = accounts['data'];
      System().insert('payment_accounts', jsonEncode(paymentAccounts));
      return paymentAccounts;
    } catch (e) {
      return [];
    }
  }
}
