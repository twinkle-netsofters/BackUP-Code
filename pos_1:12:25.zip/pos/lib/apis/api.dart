import 'dart:convert' as convert;
import 'dart:convert';
import 'dart:developer';

import 'package:http/http.dart' as http;

import '../config.dart';

class Api {
  String baseUrl = Config.baseUrl,
      apiUrl = Config.baseUrl + 'connector/api/',
      clientId = Config().clientId,
      clientSecret = Config().clientSecret;



  //validate the login details
  Future<Map?> login(String username, String password) async {
    String url = baseUrl + "oauth/token";

    print("demo");
    print("token url : ${url}");


    Map body = {
      'grant_type': 'password',
      'client_id': clientId,
      'client_secret': clientSecret,
      'username': username,
      'password': password
      // , "scope":"*"
    };
    
    print("body : $body");


    var response = await http.post(Uri.parse(url),
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: jsonEncode(body));




    // var headers = {
    //   'Content-Type': 'application/json'
    // };
    // var request = http.Request('POST', Uri.parse('https://myubm.netsofters.net/oauth/token'));
    // request.body = json.encode({
    //   "grant_type": "password",
    //   "client_id": "16",
    //   "client_secret": "JASnnOM5IYDlj5qhFSSyU4Pp9OBZpwT8745mvV8J",
    //   "username": "admina",
    //   "password": "12345678",
    //   "scope": "*"
    // });
    // request.headers.addAll(headers);
    //
    // http.StreamedResponse response = await request.send();
    //
    // if (response.statusCode == 200) {
    //   print(await response.stream.bytesToString());
    // }
    // else {
    //   print(response.reasonPhrase);
    // }






    print("bodyresponse : ${response.body}");

    var jsonResponse = convert.jsonDecode(response.body);

    print('Response States Code: ${response.statusCode}');

    if (response.statusCode == 200) {

      log("TOKEN::::${ jsonResponse['access_token']}");
      //logged in successfully
      return {'success': true, 'access_token': jsonResponse['access_token']};

    }
    else if (response.statusCode == 401) {
      //Invalid credentials
      return {'success': false, 'error': jsonResponse['error']};
    } else {
      return null;
    }
  }

  getHeader(String token) {
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer $token'
    };
  }
}
