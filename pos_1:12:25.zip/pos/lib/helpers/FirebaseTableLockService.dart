import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../config.dart';

/// Service to manage table locks in Firebase Firestore for real-time synchronization
/// across multiple users/devices
class FirebaseTableLockService {
  static final FirebaseTableLockService _instance = FirebaseTableLockService._internal();
  factory FirebaseTableLockService() => _instance;
  FirebaseTableLockService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // Collection path for table locks
  static const String _collectionPath = 'table_locks';
  
  // Stream subscriptions for real-time updates
  final Map<String, StreamSubscription> _subscriptions = {};
  
  // Callback for table status changes
  Function(int tableId, bool isLocked, int? lockedByUserId, String? lockedByUserName)? onTableStatusChanged;

  /// Get the current user ID
  int? get _currentUserId => Config.userId;

  /// Lock a table for the current user
  /// Returns true if lock was successful, false if table is already locked
  Future<bool> lockTable({
    required int tableId,
    required int locationId,
    String? tableName,
  }) async {
    try {
      if (_currentUserId == null) {
        debugPrint('FirebaseTableLockService: Cannot lock table - user not logged in');
        return false;
      }

      final docId = _getDocumentId(tableId, locationId);
      final docRef = _firestore.collection(_collectionPath).doc(docId);

      // Use transaction to ensure atomic lock acquisition
      return await _firestore.runTransaction<bool>((transaction) async {
        final doc = await transaction.get(docRef);
        
        if (doc.exists) {
          final data = doc.data()!;
          final isLocked = data['isLocked'] as bool? ?? false;
          final lockedByUserId = data['lockedByUserId'] as int?;
          
          // If table is already locked by another user, return false
          if (isLocked && lockedByUserId != _currentUserId) {
            debugPrint('FirebaseTableLockService: Table $tableId is already locked by user $lockedByUserId');
            return false;
          }
        }

        // Lock the table
        final existingData = doc.exists ? doc.data() : null;
        transaction.set(docRef, {
          'tableId': tableId,
          'locationId': locationId,
          'isLocked': true,
          'lockedByUserId': _currentUserId,
          'lockedByUserName': existingData?['lockedByUserName'] ?? 'User $_currentUserId',
          'tableName': tableName ?? 'Table $tableId',
          'lockedAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        debugPrint('FirebaseTableLockService: Successfully locked table $tableId for user $_currentUserId');
        return true;
      });
    } catch (e) {
      debugPrint('FirebaseTableLockService: Error locking table $tableId: $e');
      return false;
    }
  }

  /// Unlock a table (called when payment is completed)
  Future<void> unlockTable({
    required int tableId,
    required int locationId,
  }) async {
    try {
      final docId = _getDocumentId(tableId, locationId);
      final docRef = _firestore.collection(_collectionPath).doc(docId);

      await docRef.update({
        'isLocked': false,
        'lockedByUserId': null,
        'lockedByUserName': null,
        'unlockedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      debugPrint('FirebaseTableLockService: Successfully unlocked table $tableId');
    } catch (e) {
      debugPrint('FirebaseTableLockService: Error unlocking table $tableId: $e');
    }
  }

  /// Check if a table is currently locked
  Future<bool> isTableLocked({
    required int tableId,
    required int locationId,
  }) async {
    try {
      final docId = _getDocumentId(tableId, locationId);
      final doc = await _firestore.collection(_collectionPath).doc(docId).get();
      
      if (!doc.exists) {
        return false;
      }

      final data = doc.data()!;
      final isLocked = data['isLocked'] as bool? ?? false;
      final lockedByUserId = data['lockedByUserId'] as int?;
      
      // Table is locked if isLocked is true and it's not locked by current user
      return isLocked && lockedByUserId != _currentUserId;
    } catch (e) {
      debugPrint('FirebaseTableLockService: Error checking lock status for table $tableId: $e');
      return false; // Default to not locked on error
    }
  }

  /// Get lock information for a table
  Future<Map<String, dynamic>?> getTableLockInfo({
    required int tableId,
    required int locationId,
  }) async {
    try {
      final docId = _getDocumentId(tableId, locationId);
      final doc = await _firestore.collection(_collectionPath).doc(docId).get();
      
      if (!doc.exists) {
        return null;
      }

      final data = doc.data()!;
      final isLocked = data['isLocked'] as bool? ?? false;
      
      if (!isLocked) {
        return null;
      }

      return {
        'isLocked': true,
        'lockedByUserId': data['lockedByUserId'] as int?,
        'lockedByUserName': data['lockedByUserName'] as String?,
        'tableName': data['tableName'] as String?,
        'lockedAt': data['lockedAt'],
      };
    } catch (e) {
      debugPrint('FirebaseTableLockService: Error getting lock info for table $tableId: $e');
      return null;
    }
  }

  /// Listen to real-time updates for a specific table
  /// This allows the UI to update immediately when another user locks/unlocks a table
  StreamSubscription? listenToTableStatus({
    required int tableId,
    required int locationId,
    required Function(bool isLocked, int? lockedByUserId, String? lockedByUserName) onStatusChanged,
  }) {
    try {
      final docId = _getDocumentId(tableId, locationId);
      final subscriptionKey = docId;

      // Cancel existing subscription if any
      _subscriptions[subscriptionKey]?.cancel();

      final subscription = _firestore
          .collection(_collectionPath)
          .doc(docId)
          .snapshots()
          .listen((snapshot) {
        if (!snapshot.exists) {
          onStatusChanged(false, null, null);
          return;
        }

        final data = snapshot.data()!;
        final isLocked = data['isLocked'] as bool? ?? false;
        final lockedByUserId = data['lockedByUserId'] as int?;
        final lockedByUserName = data['lockedByUserName'] as String?;

        // Only consider it locked if it's locked by another user
        final isLockedByOther = isLocked && lockedByUserId != _currentUserId;

        onStatusChanged(isLockedByOther, lockedByUserId, lockedByUserName);
      });

      _subscriptions[subscriptionKey] = subscription;
      return subscription;
    } catch (e) {
      debugPrint('FirebaseTableLockService: Error setting up listener for table $tableId: $e');
      return null;
    }
  }

  /// Listen to all tables for a specific location
  StreamSubscription? listenToAllTablesInLocation({
    required int locationId,
    required Function(int tableId, bool isLocked, int? lockedByUserId, String? lockedByUserName) onTableStatusChanged,
  }) {
    try {
      final subscriptionKey = 'location_$locationId';

      // Cancel existing subscription if any
      _subscriptions[subscriptionKey]?.cancel();

      final subscription = _firestore
          .collection(_collectionPath)
          .where('locationId', isEqualTo: locationId)
          .snapshots()
          .listen((snapshot) {
        for (var change in snapshot.docChanges) {
          final data = change.doc.data()!;
          final tableId = data['tableId'] as int?;
          if (tableId == null) continue;

          final isLocked = data['isLocked'] as bool? ?? false;
          final lockedByUserId = data['lockedByUserId'] as int?;
          final lockedByUserName = data['lockedByUserName'] as String?;

          // // Only consider it locked if it's locked by another user
          // final isLockedByOther = isLocked && lockedByUserId != _currentUserId;
          // onTableStatusChanged(tableId, isLockedByOther, lockedByUserId, lockedByUserName);

          // Pass the actual isLocked state so that Device A can detect when it locks a table
          // The callback can use lockedByUserId to determine if it's locked by current user or another user
          onTableStatusChanged(tableId, isLocked, lockedByUserId, lockedByUserName);
        }
      });

      _subscriptions[subscriptionKey] = subscription;
      return subscription;
    } catch (e) {
      debugPrint('FirebaseTableLockService: Error setting up listener for location $locationId: $e');
      return null;
    }
  }

  /// Cancel all subscriptions
  void cancelAllSubscriptions() {
    for (var subscription in _subscriptions.values) {
      subscription.cancel();
    }
    _subscriptions.clear();
    debugPrint('FirebaseTableLockService: Cancelled all subscriptions');
  }

  /// Cancel subscription for a specific table
  void cancelTableSubscription(int tableId, int locationId) {
    final docId = _getDocumentId(tableId, locationId);
    _subscriptions[docId]?.cancel();
    _subscriptions.remove(docId);
  }

  /// Cancel subscription for a location
  void cancelLocationSubscription(int locationId) {
    final subscriptionKey = 'location_$locationId';
    _subscriptions[subscriptionKey]?.cancel();
    _subscriptions.remove(subscriptionKey);
  }

  /// Generate document ID from tableId and locationId
  String _getDocumentId(int tableId, int locationId) {
    return 'table_${tableId}_loc_$locationId';
  }

  /// Cleanup: unlock all tables locked by current user (useful on logout)
  Future<void> unlockAllTablesForCurrentUser() async {
    try {
      if (_currentUserId == null) {
        return;
      }

      final querySnapshot = await _firestore
          .collection(_collectionPath)
          .where('lockedByUserId', isEqualTo: _currentUserId)
          .where('isLocked', isEqualTo: true)
          .get();

      final batch = _firestore.batch();
      for (var doc in querySnapshot.docs) {
        batch.update(doc.reference, {
          'isLocked': false,
          'lockedByUserId': null,
          'lockedByUserName': null,
          'unlockedAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }

      await batch.commit();
      debugPrint('FirebaseTableLockService: Unlocked all tables for user $_currentUserId');
    } catch (e) {
      debugPrint('FirebaseTableLockService: Error unlocking all tables for user: $e');
    }
  }
}

