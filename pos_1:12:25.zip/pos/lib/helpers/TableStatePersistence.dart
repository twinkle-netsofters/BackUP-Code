import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';

/// Helper class to persist table and shipping availability states across app restarts
class TableStatePersistence {
  static const String _tableStatesKey = 'table_availability_states';
  static const String _shippingStateKey = 'shipping_availability_state';
  static const String _lastSavedTimestampKey = 'table_states_last_saved';

  /// Save table availability states to persistent storage
  static Future<void> saveTableStates(Map<int, bool> tableStates) async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Convert Map<int, bool> to Map<String, bool> for JSON serialization
      final Map<String, bool> stringKeyMap = tableStates.map(
            (key, value) => MapEntry(key.toString(), value),
      );

      await prefs.setString(_tableStatesKey, jsonEncode(stringKeyMap));
      await prefs.setInt(_lastSavedTimestampKey, DateTime.now().millisecondsSinceEpoch);

      debugPrint('TableStatePersistence: Saved ${tableStates.length} table states');
    } catch (e) {
      debugPrint('Error saving table states: $e');
    }
  }

  /// Save shipping availability state to persistent storage
  static Future<void> saveShippingState(bool isAvailable) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_shippingStateKey, isAvailable);
      await prefs.setInt(_lastSavedTimestampKey, DateTime.now().millisecondsSinceEpoch);

      debugPrint('TableStatePersistence: Saved shipping state: $isAvailable');
    } catch (e) {
      debugPrint('Error saving shipping state: $e');
    }
  }

  /// Load table availability states from persistent storage
  static Future<Map<int, bool>> loadTableStates() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? statesJson = prefs.getString(_tableStatesKey);

      if (statesJson == null) {
        debugPrint('TableStatePersistence: No saved table states found');
        return {};
      }

      final Map<String, dynamic> stringKeyMap = jsonDecode(statesJson);

      // Convert Map<String, bool> back to Map<int, bool>
      final Map<int, bool> tableStates = stringKeyMap.map(
            (key, value) => MapEntry(int.parse(key), value as bool),
      );

      debugPrint('TableStatePersistence: Loaded ${tableStates.length} table states');
      return tableStates;
    } catch (e) {
      debugPrint('Error loading table states: $e');
      return {};
    }
  }

  /// Load shipping availability state from persistent storage
  static Future<bool?> loadShippingState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final bool? isAvailable = prefs.getBool(_shippingStateKey);

      debugPrint('TableStatePersistence: Loaded shipping state: $isAvailable');
      return isAvailable;
    } catch (e) {
      debugPrint('Error loading shipping state: $e');
      return null;
    }
  }

  /// Save both table and shipping states together
  static Future<void> saveAllStates(Map<int, bool> tableStates, bool shippingAvailable) async {
    await Future.wait([
      saveTableStates(tableStates),
      saveShippingState(shippingAvailable),
    ]);
  }

  /// Load both table and shipping states together
  static Future<Map<String, dynamic>> loadAllStates() async {
    final tableStates = await loadTableStates();
    final shippingState = await loadShippingState();

    return {
      'tableStates': tableStates,
      'shippingAvailable': shippingState,
    };
  }

  /// Clear all saved states (useful for testing or reset)
  static Future<void> clearAllStates() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_tableStatesKey);
      await prefs.remove(_shippingStateKey);
      await prefs.remove(_lastSavedTimestampKey);

      debugPrint('TableStatePersistence: Cleared all saved states');
    } catch (e) {
      debugPrint('Error clearing states: $e');
    }
  }

  /// Get the timestamp when states were last saved
  static Future<int?> getLastSavedTimestamp() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getInt(_lastSavedTimestampKey);
    } catch (e) {
      debugPrint('Error getting last saved timestamp: $e');
      return null;
    }
  }

  /// Check if saved states are recent (within last 24 hours)
  static Future<bool> areStatesRecent() async {
    try {
      final timestamp = await getLastSavedTimestamp();
      if (timestamp == null) return false;

      final lastSaved = DateTime.fromMillisecondsSinceEpoch(timestamp);
      final now = DateTime.now();
      final difference = now.difference(lastSaved);

      // Consider states recent if saved within last 24 hours
      return difference.inHours < 24;
    } catch (e) {
      debugPrint('Error checking if states are recent: $e');
      return false;
    }
  }
}
