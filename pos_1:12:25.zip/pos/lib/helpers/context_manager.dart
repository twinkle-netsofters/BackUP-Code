// import 'dart:convert';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:flutter/foundation.dart';
//
// /// Manages persistent context for table/shipping selection across screen navigation
// class ContextManager {
//   static const String _contextKey = 'current_table_shipping_context';
//
//   /// Save the current table/shipping context
//   static Future<void> saveContext({
//     required int? sellId,
//     required int? resTableId,
//     required int? isShipping,
//     required String? tableName,
//     required int? locationId,
//   }) async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       final context = {
//         'sellId': sellId,
//         'res_table_id': resTableId,
//         'is_shipping': isShipping ?? 0,
//         'tableName': tableName,
//         'locationId': locationId,
//         'timestamp': DateTime.now().millisecondsSinceEpoch,
//       };
//
//       await prefs.setString(_contextKey, jsonEncode(context));
//       debugPrint('ContextManager: Saved context - sellId: $sellId, res_table_id: $resTableId, is_shipping: $isShipping, tableName: $tableName');
//     } catch (e) {
//       debugPrint('ContextManager: Error saving context: $e');
//     }
//   }
//
//   /// Get the current table/shipping context
//   static Future<Map<String, dynamic>?> getContext() async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       final contextString = prefs.getString(_contextKey);
//
//       if (contextString != null) {
//         final context = jsonDecode(contextString);
//         debugPrint('ContextManager: Retrieved context: $context');
//         return context;
//       }
//     } catch (e) {
//       debugPrint('ContextManager: Error retrieving context: $e');
//     }
//     return null;
//   }
//
//   /// Clear the current context
//   static Future<void> clearContext() async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       await prefs.remove(_contextKey);
//       debugPrint('ContextManager: Cleared context');
//     } catch (e) {
//       debugPrint('ContextManager: Error clearing context: $e');
//     }
//   }
//
//   /// Update context with new values while preserving existing ones
//   static Future<void> updateContext({
//     int? sellId,
//     int? resTableId,
//     int? isShipping,
//     String? tableName,
//     int? locationId,
//   }) async {
//     try {
//       final currentContext = await getContext();
//       final updatedContext = {
//         ...?currentContext,
//         if (sellId != null) 'sellId': sellId,
//         if (resTableId != null) 'res_table_id': resTableId,
//         if (isShipping != null) 'is_shipping': isShipping,
//         if (tableName != null) 'tableName': tableName,
//         if (locationId != null) 'locationId': locationId,
//         'timestamp': DateTime.now().millisecondsSinceEpoch,
//       };
//
//       final prefs = await SharedPreferences.getInstance();
//       await prefs.setString(_contextKey, jsonEncode(updatedContext));
//       debugPrint('ContextManager: Updated context: $updatedContext');
//     } catch (e) {
//       debugPrint('ContextManager: Error updating context: $e');
//     }
//   }
//
//   /// Check if context is valid (not too old)
//   static bool isContextValid(Map<String, dynamic> context) {
//     try {
//       final timestamp = context['timestamp'] as int?;
//       if (timestamp == null) return false;
//
//       final contextAge = DateTime.now().millisecondsSinceEpoch - timestamp;
//       // Consider context valid for 1 hour (3600000 ms)
//       return contextAge < 3600000;
//     } catch (e) {
//       return false;
//     }
//   }
//
//   /// Get context with validation
//   static Future<Map<String, dynamic>?> getValidContext() async {
//     final context = await getContext();
//     if (context != null && isContextValid(context)) {
//       return context;
//     }
//     return null;
//   }
//
//   /// Debug method to log current context state
//   static Future<void> debugContextState() async {
//     try {
//       final context = await getContext();
//       if (context != null) {
//         debugPrint('ContextManager: Current context state:');
//         debugPrint('  - sellId: ${context['sellId']}');
//         debugPrint('  - res_table_id: ${context['res_table_id']}');
//         debugPrint('  - is_shipping: ${context['is_shipping']}');
//         debugPrint('  - tableName: ${context['tableName']}');
//         debugPrint('  - locationId: ${context['locationId']}');
//         debugPrint('  - timestamp: ${context['timestamp']}');
//         debugPrint('  - isValid: ${isContextValid(context)}');
//       } else {
//         debugPrint('ContextManager: No context found');
//       }
//     } catch (e) {
//       debugPrint('ContextManager: Error debugging context state: $e');
//     }
//   }
// }



import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';

/// Manages persistent context for table/shipping selection across screen navigation
/// Now supports multiple table contexts to prevent data mixing
class ContextManager {
  static const String _contextKeyPrefix = 'table_context_';
  static const String _currentContextKey = 'current_table_context_id';

  /// Save the current table/shipping context with table-specific key
  static Future<void> saveContext({
    required int? sellId,
    required int? resTableId,
    required int? isShipping,
    required String? tableName,
    required int? locationId,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Create a unique key for this table context
      String contextKey = _getContextKey(resTableId, isShipping);

      final context = {
        'sellId': sellId,
        'res_table_id': resTableId,
        'is_shipping': isShipping ?? 0,
        'tableName': tableName,
        'locationId': locationId,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'contextKey': contextKey, // Store the key for reference
      };

      await prefs.setString(contextKey, jsonEncode(context));

      // Also store which context is currently active
      await prefs.setString(_currentContextKey, contextKey);

      debugPrint('ContextManager: Saved context for key: $contextKey - sellId: $sellId, res_table_id: $resTableId, is_shipping: $isShipping, tableName: $tableName');
    } catch (e) {
      debugPrint('ContextManager: Error saving context: $e');
    }
  }

  /// Get the current table/shipping context for a specific table
  static Future<Map<String, dynamic>?> getContextForTable(int? resTableId, int? isShipping) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String contextKey = _getContextKey(resTableId, isShipping);
      final contextString = prefs.getString(contextKey);

      if (contextString != null) {
        final context = jsonDecode(contextString);
        debugPrint('ContextManager: Retrieved context for key: $contextKey - $context');

        if (isContextValid(context)) {
          return context;
        } else {
          // Remove expired context
          await prefs.remove(contextKey);
          debugPrint('ContextManager: Removed expired context for key: $contextKey');
        }
      }
    } catch (e) {
      debugPrint('ContextManager: Error retrieving context: $e');
    }
    return null;
  }

  /// Get context for the currently active table (for backward compatibility)
  static Future<Map<String, dynamic>?> getContext() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final currentContextKey = prefs.getString(_currentContextKey);

      if (currentContextKey != null) {
        final contextString = prefs.getString(currentContextKey);
        if (contextString != null) {
          final context = jsonDecode(contextString);
          debugPrint('ContextManager: Retrieved current context: $context');

          if (isContextValid(context)) {
            return context;
          } else {
            // Remove expired context
            await prefs.remove(currentContextKey);
            await prefs.remove(_currentContextKey);
          }
        }
      }
    } catch (e) {
      debugPrint('ContextManager: Error retrieving current context: $e');
    }
    return null;
  }

  /// Get valid context for navigation - prioritizes table-specific context
  static Future<Map<String, dynamic>?> getValidContext({
    int? resTableId,
    int? isShipping,
  }) async {
    // First try to get table-specific context
    if (resTableId != null || isShipping != null) {
      final tableContext = await getContextForTable(resTableId, isShipping);
      if (tableContext != null) {
        return tableContext;
      }
    }

    // Fall back to current context
    return await getContext();
  }

  /// Clear the current context
  static Future<void> clearContext() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_currentContextKey);
      debugPrint('ContextManager: Cleared current context');
    } catch (e) {
      debugPrint('ContextManager: Error clearing context: $e');
    }
  }

  /// Clear context for a specific table
  static Future<void> clearTableContext(int? resTableId, int? isShipping) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String contextKey = _getContextKey(resTableId, isShipping);
      await prefs.remove(contextKey);
      debugPrint('ContextManager: Cleared context for key: $contextKey');
    } catch (e) {
      debugPrint('ContextManager: Error clearing table context: $e');
    }
  }

  /// Update context with new values while preserving existing ones
  static Future<void> updateContext({
    int? sellId,
    int? resTableId,
    int? isShipping,
    String? tableName,
    int? locationId,
  }) async {
    try {
      final currentContext = await getContextForTable(resTableId, isShipping);
      final updatedContext = {
        ...?currentContext,
        if (sellId != null) 'sellId': sellId,
        if (resTableId != null) 'res_table_id': resTableId,
        if (isShipping != null) 'is_shipping': isShipping,
        if (tableName != null) 'tableName': tableName,
        if (locationId != null) 'locationId': locationId,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'contextKey': _getContextKey(resTableId, isShipping),
      };

      final prefs = await SharedPreferences.getInstance();
      String contextKey = _getContextKey(resTableId, isShipping);
      await prefs.setString(contextKey, jsonEncode(updatedContext));

      // Update current context
      await prefs.setString(_currentContextKey, contextKey);

      debugPrint('ContextManager: Updated context for key: $contextKey');
    } catch (e) {
      debugPrint('ContextManager: Error updating context: $e');
    }
  }

  /// Check if context is valid (not too old)
  static bool isContextValid(Map<String, dynamic> context) {
    try {
      final timestamp = context['timestamp'] as int?;
      if (timestamp == null) return false;

      final contextAge = DateTime.now().millisecondsSinceEpoch - timestamp;
      // Consider context valid for 1 hour (3600000 ms)
      return contextAge < 3600000;
    } catch (e) {
      return false;
    }
  }

  /// Generate a unique key for table context
  static String _getContextKey(int? resTableId, int? isShipping) {
    if (isShipping == 1) {
      return '${_contextKeyPrefix}shipping';
    } else if (resTableId != null && resTableId > 0) {
      return '${_contextKeyPrefix}table_$resTableId';
    } else {
      return '${_contextKeyPrefix}default';
    }
  }

  /// Clean up all expired contexts
  static Future<void> cleanupExpiredContexts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final keys = prefs.getKeys().where((key) => key.startsWith(_contextKeyPrefix));

      for (String key in keys) {
        final contextString = prefs.getString(key);
        if (contextString != null) {
          final context = jsonDecode(contextString);
          if (!isContextValid(context)) {
            await prefs.remove(key);
            debugPrint('ContextManager: Cleaned up expired context: $key');
          }
        }
      }
    } catch (e) {
      debugPrint('ContextManager: Error cleaning up expired contexts: $e');
    }
  }

  /// Debug method to log current context state
  static Future<void> debugContextState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final currentContextKey = prefs.getString(_currentContextKey);
      final keys = prefs.getKeys().where((key) => key.startsWith(_contextKeyPrefix));

      debugPrint('ContextManager: All table contexts:');
      for (String key in keys) {
        final contextString = prefs.getString(key);
        if (contextString != null) {
          final context = jsonDecode(contextString);
          debugPrint('  - $key: ${context['res_table_id']} (${context['tableName']}) - valid: ${isContextValid(context)}');
        }
      }

      debugPrint('ContextManager: Current context key: $currentContextKey');

      final currentContext = await getContext();
      if (currentContext != null) {
        debugPrint('ContextManager: Current active context:');
        debugPrint('  - sellId: ${currentContext['sellId']}');
        debugPrint('  - res_table_id: ${currentContext['res_table_id']}');
        debugPrint('  - is_shipping: ${currentContext['is_shipping']}');
        debugPrint('  - tableName: ${currentContext['tableName']}');
        debugPrint('  - locationId: ${currentContext['locationId']}');
        debugPrint('  - isValid: ${isContextValid(currentContext)}');
      } else {
        debugPrint('ContextManager: No active context found');
      }
    } catch (e) {
      debugPrint('ContextManager: Error debugging context state: $e');
    }
  }


  /// Save shipping-specific context
  static Future<void> saveShippingContext({
    required int? sellId,
    required int? locationId,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Create a unique key for shipping context
      String contextKey = _getContextKey(null, 1); // is_shipping = 1

      final context = {
        'sellId': sellId,
        'res_table_id': 0, // Shipping orders have res_table_id = 0
        'is_shipping': 1,
        'tableName': 'Shipping Order',
        'locationId': locationId,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'contextKey': contextKey,
      };

      await prefs.setString(contextKey, jsonEncode(context));

      // Also store which context is currently active
      await prefs.setString(_currentContextKey, contextKey);

      debugPrint('ContextManager: Saved shipping context - sellId: $sellId');
    } catch (e) {
      debugPrint('ContextManager: Error saving shipping context: $e');
    }
  }

  /// Get shipping-specific context
  static Future<Map<String, dynamic>?> getShippingContext() async {
    return await getContextForTable(null, 1); // is_shipping = 1
  }

  /// Clear shipping context
  static Future<void> clearShippingContext() async {
    await clearTableContext(null, 1); // is_shipping = 1
  }

}