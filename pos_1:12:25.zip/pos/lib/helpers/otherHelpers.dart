// import 'dart:math';
//
// import 'package:barcode_scan2/barcode_scan2.dart';
// import 'package:cached_network_image/cached_network_image.dart';
//
// // import 'package:call_log/call_log.dart';
// import 'package:connectivity/connectivity.dart';
// import 'package:cron/cron.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_html_to_pdf/flutter_html_to_pdf.dart';
// import 'package:intl/intl.dart';
// import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:pdf/pdf.dart';
// import 'package:pdf/widgets.dart' as pw;
// import 'package:permission_handler/permission_handler.dart';
// import 'package:printing/printing.dart';
// import 'package:share/share.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// import '../config.dart';
// import '../locale/MyLocalizations.dart';
// import '../models/invoice.dart';
// import '../models/system.dart';
// import 'AppTheme.dart';
// import 'SizeConfig.dart';
//
// class Helper {
//   static int themeType = 1;
//   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
//   CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);
//
//   Widget loadingIndicator(context) {
//     return Center(
//       child: Card(
//         elevation: MySize.size10,
//         child: Container(
//           padding: EdgeInsets.all(MySize.size28!),
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(MySize.size8!),
//           ),
//           child: CircularProgressIndicator(),
//         ),
//       ),
//     );
//   }
//
//   //format currency
//   String formatCurrency(amount) {
//     double convertAmount = double.parse(amount.toString());
//
//     var amt = NumberFormat.currency(
//         symbol: '', decimalDigits: Config.currencyPrecision)
//         .format(convertAmount);
//     return amt;
//   }
//
//   double validateInput(String val) {
//     try {
//       double value = double.parse(val.toString());
//       return value;
//     } catch (e) {
//       return 0.00;
//     }
//   }
//
//   //format quantity
//   String formatQuantity(amount) {
//     double quantity = double.parse(amount.toString());
//     var amt = NumberFormat.currency(
//         symbol: '', decimalDigits: Config.quantityPrecision)
//         .format(quantity);
//     return amt;
//   }
//
//   //argument model
//   Map argument(
//       {int? sellId,
//         int? locId,
//         int? taxId,
//         String? discountType,
//         double? discountAmount,
//         double? invoiceAmount,
//         int? customerId,
//         int? isQuotation,
//         required List<Map> products}) {
//     Map args = {
//       'sellId': sellId,
//       'locationId': locId,
//       'taxId': taxId,
//       'discountType': discountType,
//       'discountAmount': discountAmount,
//       'invoiceAmount': invoiceAmount,
//       'customerId': customerId,
//       'is_quotation': isQuotation
//     };
//     print('Helper.argument created: $args'); // Debug print
//
//
//     return args;
//   }
//
//   //check internet connectivity
//   Future<bool> checkConnectivity() async {
//     var connectivityResult = await (Connectivity().checkConnectivity());
//     if (connectivityResult == ConnectivityResult.mobile ||
//         connectivityResult == ConnectivityResult.wifi) {
//       return true;
//     } else {
//       return false;
//     }
//   }
//
//   //get location name by location_id
//   Future<String?> getLocationNameById(var id) async {
//     String? locationName;
//     var response = await System().get('location');
//     response.forEach((element) {
//       if (element['id'] == int.parse(id.toString())) {
//         locationName = element['name'];
//       }
//     });
//     return locationName;
//   }
//
//   //calculate inline tax and discount amount
//   calculateTaxAndDiscount(
//       {discountAmount, discountType, taxId, unitPrice}) async {
//     double disAmt = 0.0, tax = 0.00, taxAmt = 0.00;
//     await System().get('tax').then((value) {
//       value.forEach((element) {
//         if (element['id'] == taxId) {
//           tax = double.parse(element['amount'].toString()) * 1.0;
//         }
//       });
//     });
//
//     if (discountType == 'fixed') {
//       disAmt = discountAmount;
//       taxAmt = ((unitPrice - discountAmount) * tax / 100);
//     } else {
//       disAmt = (unitPrice * discountAmount / 100);
//       taxAmt = ((unitPrice - (unitPrice * discountAmount / 100)) * tax / 100);
//     }
//     return {'discountAmount': disAmt, 'taxAmount': taxAmt};
//   }
//
//   //calculate price including tax
//   calculateTotal({unitPrice, discountType, discountAmount, taxId}) async {
//     double tax = 0.00;
//     double subTotal = 0.00;
//     double amount = 0.0;
//     unitPrice = double.parse(unitPrice.toString());
//     discountAmount = double.parse(discountAmount.toString());
//     //set tax
//     await System().get('tax').then((value) {
//       value.forEach((element) {
//         if (element['id'] == taxId) {
//           tax = double.parse(element['amount'].toString()) * 1.0;
//         }
//       });
//     });
//     //calculate subTotal according to discount type
//     if (discountType == 'fixed') {
//       amount = unitPrice - discountAmount;
//     } else {
//       amount = unitPrice - (unitPrice * discountAmount / 100);
//     }
//     //calculate subtotal
//     subTotal = (amount + (amount * tax / 100));
//     return subTotal.toStringAsFixed(2);
//   }
//
//   Future<String> barcodeScan() async {
//     var result = await BarcodeScanner.scan();
//     return result.rawContent.trimRight();
//   }
//
//   //function for formatting invoice
//   Future<void> printDocument(sellId, taxId, context, {invoice}) async {
//     String _invoice = (invoice != null)
//         ? invoice
//         : await InvoiceFormatter().generateInvoice(sellId, taxId, context);
//     Printing.layoutPdf(onLayout: (pageFormat) async {
//       final doc = pw.Document();
//       await Printing.layoutPdf(
//           onLayout: (PdfPageFormat format) async => await Printing.convertHtml(
//             format: format,
//             html: _invoice,
//           ));
//
//       return doc.save();
//     });
//   }
//
//   // //request permissions
//   requestAppPermission() async {
//     Map<Permission, PermissionStatus> statuses = await [
//       Permission.location,
//       Permission.storage,
//       Permission.camera,
//       // Permission.phone
//     ].request();
//     return statuses;
//   }
//
//   //job scheduler
//   jobScheduler() {
//     if (Config().syncCallLog) {
//       final cron = Cron();
//       cron.schedule(Schedule.parse('*/${Config.callLogSyncDuration} * * * *'),
//               () async {
//             syncCallLogs();
//           });
//     }
//   }
//
//   //post call_logs in api
//   syncCallLogs() async {
//     if (await Permission.phone.status == PermissionStatus.granted) {
//       if (Config().syncCallLog && await Helper().checkConnectivity()) {
//         // ignore: unused_local_variable
//         List recentLogs = [];
//         //get last sync time
//         var lastSync = await System().callLogLastSyncDateTime();
//         //difference between time now and last sync
//         int getLogBefore = (lastSync != null)
//             ? DateTime.now().difference(DateTime.parse(lastSync)).inMinutes
//             : 1440;
//         //set 'from' duration for call_log query
//         // ignore: unused_local_variable
//         int from = DateTime.now()
//             .subtract(
//             Duration(minutes: (getLogBefore > 1440) ? 1440 : getLogBefore))
//             .millisecondsSinceEpoch;
//         try {
//           // //fetch call_log
//           // await CallLog.query(dateFrom: from).then((value) async {
//           //   if (value.isNotEmpty) {
//           //     value.forEach((element) {
//           //       recentLogs.add(CallLogModel().createLog(element));
//           //     });
//           //     //     //save call_log in api
//           //     await FollowUpApi()
//           //         .syncCallLog({'call_logs': recentLogs}).then((value) async {
//           //       if (value == true) {
//           //         System().callLogLastSyncDateTime(true);
//           //       }
//           //     });
//           //   }
//           // });
//         } catch (e) {}
//       }
//     }
//   }
//
//   //share invoice
//   savePdf(sellId, taxId, context, invoiceNo, {invoice}) async {
//     String _invoice = (invoice != null)
//         ? invoice
//         : await InvoiceFormatter().generateInvoice(sellId, taxId, context);
//     var targetPath = await getTemporaryDirectory();
//     var targetFileName = "invoice_no: ${Random().nextInt(100)}";
//
//     var generatedPdfFile = await FlutterHtmlToPdf.convertFromHtmlContent(
//         _invoice, targetPath.path, targetFileName);
//
//     await Share.shareFiles([generatedPdfFile.path]);
//     //to get file path use generatedPdfFile.path
//   }
//
//   //fetch formatted business details
//   Future<Map<String, dynamic>> getFormattedBusinessDetails() async {
//     List business = await System().get('business');
//     String? symbol = business[0]['currency']['symbol'],
//         name = business[0]['name'],
//         logo = business[0]['logo'],
//         taxLabel = business[0]['tax_label_1'],
//         taxNumber = business[0]['tax_number_1'];
//     int? currencyPrecision = business[0]['currency_precision'],
//         quantityPrecision = business[0]['quantity_precision'];
//     return {
//       'symbol': symbol ?? '',
//       'name': name ?? '',
//       'logo': logo ?? Config().defaultBusinessImage,
//       'currencyPrecision': currencyPrecision ?? Config.currencyPrecision,
//       'quantityPrecision': quantityPrecision ?? Config.quantityPrecision,
//       'taxLabel': (taxLabel != null) ? '$taxLabel : ' : '',
//       'taxNumber': (taxNumber != null) ? '$taxNumber' : ''
//     };
//   }
//
//   //Fetch permission from database
//   Future<bool> getPermission(String permissionFor) async {
//     bool permission = false;
//     await System().getPermission().then((value) {
//       if (value[0] == 'all' || value.contains("$permissionFor")) {
//         permission = true;
//       }
//     });
//     return permission;
//   }
//
//   //call widget
//   Widget callDropdown(context, followUpDetails, List numbers,
//       {required String type}) {
//     numbers.removeWhere((element) => element.toString() == 'null');
//     return Container(
//       height: MySize.size36,
//       child: PopupMenuButton<String>(
//         icon: Icon(
//           (type == 'call') ? MdiIcons.phone : MdiIcons.whatsapp,
//           color:
//           (type == 'call') ? themeData.colorScheme.primary : Colors.green,
//         ),
//         onSelected: (value) async {
//           if (type == 'call') {
//             await launch('tel:$value');
//           }
//
//           if (type == 'whatsApp') {
//             await launch("https://wa.me/$value");
//           }
//         },
//         itemBuilder: (BuildContext context) {
//           return numbers.map((item) {
//             return PopupMenuItem<String>(
//               value: item,
//               child: Text(
//                 '$item',
//                 style: TextStyle(color: Colors.black),
//               ),
//             );
//           }).toList();
//         },
//       ),
//     );
//   }
//
//   //noData widget
//   noDataWidget(context) {
//     return Column(
//       children: [
//         Expanded(
//           flex: 5,
//           child: CachedNetworkImage(
//             imageUrl: Config().noDataImage,
//             errorWidget: (context, url, error) =>
//                 Image.asset('assets/images/noData.png'),
//           ),
//         ),
//         Expanded(
//           flex: 1,
//           child: Text(
//             AppLocalizations.of(context).translate('no_data'),
//             style: AppTheme.getTextStyle(
//               themeData.textTheme.headline5,
//               fontWeight: 600,
//               color: themeData.colorScheme.onBackground,
//             ),
//           ),
//         )
//       ],
//     );
//   }
// }

import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:barcode_scan2/barcode_scan2.dart';
import 'package:cached_network_image/cached_network_image.dart';
// import 'package:connectivity/connectivity.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:cron/cron.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html_to_pdf/flutter_html_to_pdf.dart';
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:permission_handler/permission_handler.dart';
import 'package:printing/printing.dart';
import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:dio/dio.dart';
import '../config.dart';
import '../locale/MyLocalizations.dart';
import '../models/invoice.dart';
import '../models/sell.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import 'AppTheme.dart';
import 'SizeConfig.dart';
import 'context_manager.dart';

class Helper {
  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
  CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);

  Widget loadingIndicator(context) {
    return Center(
      child: Card(
        elevation: MySize.size10,
        child: Container(
          padding: EdgeInsets.all(MySize.size28!),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(MySize.size8!),
          ),
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }

  String formatCurrency(amount) {
    if (amount == null) return '0.00';

    double convertAmount = double.tryParse(amount.toString()) ?? 0.0;
    var amt = NumberFormat.currency(
        symbol: '', decimalDigits: Config.currencyPrecision)
        .format(convertAmount);
    return amt;
  }

  double validateInput(String val) {
    try {
      double value = double.parse(val.toString());
      return value;
    } catch (e) {
      return 0.00;
    }
  }

  String formatQuantity(amount) {
    double quantity = double.parse(amount.toString());
    var amt = NumberFormat.currency(
        symbol: '', decimalDigits: Config.quantityPrecision)
        .format(quantity);
    return amt;
  }

  // Map argument({
  //   int? sellId,
  //   int? locId,
  //   int? taxId,
  //   String? discountType,
  //   double? discountAmount,
  //   double? invoiceAmount,
  //   int? customerId,
  //   int? isQuotation,
  //   required List<Map> products,
  // }) {
  //   Map args = {
  //     'sellId': sellId,
  //     'locationId': locId,
  //     'taxId': taxId,
  //     'discountType': discountType,
  //     'discountAmount': discountAmount,
  //     'invoiceAmount': invoiceAmount,
  //     'customerId': customerId,
  //     'is_quotation': isQuotation,
  //     'products': products,
  //   };
  //   print('Helper.argument created: $args'); // Debug print
  //   return args;
  // }
  Map argument({
    int? res_table_id,
    String? cartKey,
    int? is_shipping,
    bool? isShipping, // Add isShipping flag parameter
    int? sellId,
    int? locId,
    int? taxId,
    String? discountType,
    double? discountAmount,
    double? invoiceAmount,
    int? customerId,
    int? isQuotation,
    required List<Map> products,
    bool? clearFields, // Add clearFields parameter
    bool? isQuotationFlow, // Add this new parameter
    String? tableName, // Add this new parameter
    bool saleEdit=false,
    bool? fromSalesScreen,
    bool? fromCustomerScreen, // Add fromSalesScreen parameter
    String? invoice_no, // Add invoice_no parameter
    // Additional sale data fields for Sales → Checkout navigation
    String? transaction_id, // Transaction ID from API
    String? status, // Sale status (draft, ordered, partial, due, final)
    String? payment_status, // Payment status
    String? transaction_date, // Transaction date
    String? sale_note, // Sale note
    String? staff_note, // Staff note
    double? shipping_charges, // Shipping charges
    String? shipping_details, // Shipping details
    double? tip_amount, // Tip amount
    String? tip_type, // Tip type (fixed, percentage)
  }
      ) {
    Map args = {
      'res_table_id': res_table_id,
      'cartKey': cartKey,
      'is_shipping': is_shipping,
      'isShipping': isShipping, // Include isShipping flag in returned map
      'sellId': sellId,
      'locationId': locId,
      'taxId': taxId,
      'discountType': discountType ?? 'fixed', // Ensure default value
      'discountAmount': discountAmount ?? 0.0, // Ensure default value
      'invoiceAmount': invoiceAmount,
      'customerId': customerId,
      'is_quotation': isQuotation,
      'products': products,
      'clearFields': clearFields, // Include in returned map
      'isQuotationFlow': isQuotationFlow, // Include the new flag
      'tableName': tableName, // Include in returned map
      'saleEdit': saleEdit, // Include in returned map
      'fromSalesScreen': fromSalesScreen, // Include fromSalesScreen flag
      'fromCustomerScreen' : fromCustomerScreen,
      'invoice_no': invoice_no, // Include invoice_no in returned map
      // Additional sale data fields
      'transaction_id': transaction_id,
      'status': status,
      'payment_status': payment_status,
      'transaction_date': transaction_date,
      'sale_note': sale_note,
      'staff_note': staff_note,
      'shipping_charges': shipping_charges,
      'shipping_details': shipping_details,
      'tip_amount': tip_amount,
      'tip_type': tip_type,
    };

    // Save context for persistence across navigation
    if (sellId != null && locId != null) {
      ContextManager.saveContext(
        sellId: sellId,
        resTableId: res_table_id,
        isShipping: is_shipping,
        tableName: tableName,
        locationId: locId,
      );
    }

    print('Helper.argument created: $args'); // Debug print
    return args;
  }

  Future<String?> getTableNameById(int? tableId) async {
    if (tableId == null || tableId == 0) return null;
    print("DEBUG: getTableNameById called with tableId = $tableId");

    // First try to get from local storage
    var tables = await System().get('res-tables');
    print("DEBUG: Retrieved tables from System().get('res-tables'): $tables");

    // Check if the requested table ID exists in local data
    bool tableExistsLocally = tables.any((table) => table['id'] == tableId);

    // If no tables found locally OR the specific table ID is not found, fetch from API
    if (tables.isEmpty || !tableExistsLocally) {
      print("DEBUG: Table $tableId not found locally, fetching from API...");
      tables = await _fetchTablesFromAPI();
      if (tables.isNotEmpty) {
        // Store the tables locally for future use
        await System().insert('res-tables', jsonEncode(tables));
        print("DEBUG: Stored ${tables.length} tables locally");
      }
    }

    for (var table in tables) {
      print("DEBUG: Checking table: id=${table['id']}, name=${table['name']}");
      if (table['id'] == tableId) {
        print("DEBUG: Found matching table: ${table['name']}");
        return table['name'];
      }
    }
    print("DEBUG: No matching table found for tableId = $tableId");
    return null;
  }

  /// Ensure proper sales record selection and data isolation
  /// This method validates that the selected sales record is properly isolated
  static Future<Map<String, dynamic>> ensureSalesRecordIsolation({
    required int sellId,
    required int? resTableId,
    required String? tableName,
  }) async {
    try {
      print('ensureSalesRecordIsolation: Starting validation for sellId: $sellId, resTableId: $resTableId, tableName: $tableName');

      // Clear any existing context to prevent conflicts
      await ContextManager.clearContext();

      // Validate the sales record exists and is properly isolated
      var validationResult = await SellDatabase().validateSalesRecordIsolation(sellId, resTableId);

      if (!validationResult['isValid']) {
        print('ensureSalesRecordIsolation: Local validation failed - ${validationResult['error']}');

        // Check if this might be an API-only record (exists in sales list but not in local DB)
        // For such cases, we'll allow navigation to proceed with a warning
        print('ensureSalesRecordIsolation: Allowing navigation for potentially API-only record: $sellId');

        // Save minimal context for API-only records
        await ContextManager.saveContext(
          sellId: sellId,
          resTableId: resTableId,
          isShipping: 0, // Assuming table-based sales
          tableName: tableName,
          locationId: 1, // Default location ID
        );

        return {
          'success': true,
          'isValid': true,  // Allow navigation for API-only records
          'sellRecord': null, // Will be loaded from API if needed
          'cartItems': [], // Will be loaded from API if needed
          'contextSaved': true,
          'isApiOnly': true, // Flag to indicate this is an API-only record
          // 'warning': 'Record exists in API but not in local database - proceeding with API data',
        };
      }

      // Save the validated context for local records
      await ContextManager.saveContext(
        sellId: sellId,
        resTableId: resTableId,
        isShipping: 0, // Assuming table-based sales
        tableName: tableName,
        locationId: validationResult['sellRecord']['location_id'],
      );

      print('ensureSalesRecordIsolation: Successfully validated and saved context for sellId: $sellId');

      return {
        'success': true,
        'isValid': true,  // Add isValid for compatibility with sales.dart
        'sellRecord': validationResult['sellRecord'],
        'cartItems': validationResult['cartItems'],
        'contextSaved': true,
        'isApiOnly': false,
      };
    } catch (e) {
      print('ensureSalesRecordIsolation: Error - $e');
      return {
        'success': false,
        'isValid': false,  // Add isValid for compatibility with sales.dart
        'error': e.toString(),
        'sellRecord': null,
        'cartItems': [],
      };
    }
  }

  /// Clear the table cache and force refresh from API
  Future<void> clearTableCache() async {
    try {
      await System().delete('res-tables');
      print("DEBUG: Cleared table cache");
    } catch (e) {
      print("DEBUG: Error clearing table cache: $e");
    }
  }

  Future<List> _fetchTablesFromAPI() async {
    try {
      print("DEBUG: Fetching tables from API...");
      final dio = Dio();
      final token = await System().getToken();
      dio.options.headers['Authorization'] = "Bearer $token";

      final response = await dio.get(
        Config.baseUrl + 'connector/api/table',
        options: Options(receiveTimeout: Duration(seconds: 10)),
      );

      if (response.statusCode == 200) {
        final tables = response.data['data']
            .where((table) => table['deleted_at'] == null)
            .map((table) => {
          'id': table['id'],
          'name': table['name'],
        })
            .toList();
        print("DEBUG: Fetched ${tables.length} tables from API: $tables");
        return tables;
      } else {
        print("DEBUG: API request failed with status: ${response.statusCode}");
        return [];
      }
    } catch (e) {
      print("DEBUG: Error fetching tables from API: $e");
      return [];
    }
  }

  Future<bool> checkConnectivity() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile ||
        connectivityResult == ConnectivityResult.wifi) {
      return true;
    } else {
      return false;
    }
  }

  Future<String?> getLocationNameById(var id) async {
    String? locationName;
    var response = await System().get('location');
    response.forEach((element) {
      if (element['id'] == int.parse(id.toString())) {
        locationName = element['name'];
      }
    });
    return locationName;
  }

  calculateTaxAndDiscount(
      {discountAmount, discountType, taxId, unitPrice}) async {
    double disAmt = 0.0, tax = 0.00, taxAmt = 0.00;
    await System().get('tax').then((value) {
      value.forEach((element) {
        if (element['id'] == taxId) {
          tax = double.parse(element['amount'].toString()) * 1.0;
        }
      });
    });

    if (discountType == 'fixed') {
      disAmt = discountAmount;
      taxAmt = ((unitPrice - discountAmount) * tax / 100);
    } else {
      disAmt = (unitPrice * discountAmount / 100);
      taxAmt = ((unitPrice - (unitPrice * discountAmount / 100)) * tax / 100);
    }
    return {'discountAmount': disAmt, 'taxAmount': taxAmt};
  }

  calculateTotal({unitPrice, discountType, discountAmount, taxId}) async {
    double tax = 0.00;
    double subTotal = 0.00;
    double amount = 0.0;
    unitPrice = double.parse(unitPrice.toString());
    discountAmount = double.parse(discountAmount.toString());
    await System().get('tax').then((value) {
      value.forEach((element) {
        if (element['id'] == taxId) {
          tax = double.parse(element['amount'].toString()) * 1.0;
        }
      });
    });
    if (discountType == 'fixed') {
      amount = unitPrice - discountAmount;
    } else {
      amount = unitPrice - (unitPrice * discountAmount / 100);
    }
    subTotal = (amount + (amount * tax / 100));
    return subTotal.toStringAsFixed(2);
  }

  Future<String> barcodeScan() async {
    var result = await BarcodeScanner.scan();
    return result.rawContent.trimRight();
  }

  // Future<void> printDocument(sellId, taxId, context, {invoice}) async {
  //   String _invoice = (invoice != null)
  //       ? invoice
  //       : await InvoiceFormatter().generateInvoice(sellId, taxId, context);
  //   Printing.layoutPdf(onLayout: (pageFormat) async {
  //     final doc = pw.Document();
  //     await Printing.layoutPdf(
  //         onLayout: (PdfPageFormat format) async => await Printing.convertHtml(
  //           format: format,
  //           html: _invoice,
  //         ));
  //     return doc.save();
  //   });
  // }
  Future<void> printDocument(sellId, taxId, context, {invoice}) async {
    try {
      // Get a writable directory
      final directory = await getTemporaryDirectory();
      final filePath = '${directory.path}/invoice_$sellId.pdf';

      // Generate PDF
      final pdf = await Printing.convertHtml(
        format: PdfPageFormat.a4,
        html: invoice ?? await InvoiceFormatter().generateInvoice(sellId, taxId, context),
      );

      // Save to temporary file
      final file = File(filePath);
      await file.writeAsBytes(pdf);

      // Print the file
      await Printing.layoutPdf(
        onLayout: (_) => file.readAsBytes(),
      );

    } catch (e) {
      debugPrint('Printing error: $e');
      rethrow;
    }
  }

  requestAppPermission() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.location,
      Permission.storage,
      Permission.camera,
    ].request();
    return statuses;
  }

  jobScheduler() {
    if (Config().syncCallLog) {
      final cron = Cron();
      cron.schedule(Schedule.parse('*/${Config.callLogSyncDuration} * * * *'),
              () async {
            syncCallLogs();
          });
    }
  }

  syncCallLogs() async {
    if (await Permission.phone.status == PermissionStatus.granted) {
      if (Config().syncCallLog && await Helper().checkConnectivity()) {
        List recentLogs = [];
        var lastSync = await System().callLogLastSyncDateTime();
        int getLogBefore = (lastSync != null)
            ? DateTime.now().difference(DateTime.parse(lastSync)).inMinutes
            : 1440;
        int from = DateTime.now()
            .subtract(
            Duration(minutes: (getLogBefore > 1440) ? 1440 : getLogBefore))
            .millisecondsSinceEpoch;
        try {
// Call log syncing logic (commented out in original)
        } catch (e) {}
      }
    }
  }

  savePdf(sellId, taxId, context, invoiceNo, {invoice, Future<void> Function()? onBeforeShare}) async {
    String _invoice = (invoice != null)
        ? invoice
        : await InvoiceFormatter().generateInvoice(sellId, taxId, context);
    var targetPath = await getTemporaryDirectory();
    var targetFileName = "invoice_no: ${Random().nextInt(100)}";
    var generatedPdfFile = await FlutterHtmlToPdf.convertFromHtmlContent(
        _invoice, targetPath.path, targetFileName);

    // Dismiss loading dialog right before sharing (if callback provided)
    if (onBeforeShare != null) {
      await onBeforeShare();
    }

    await Share.shareFiles([generatedPdfFile.path]);
  }

  // Future<Map<String, dynamic>> getFormattedBusinessDetails() async {
  //   List business = await System().get('business');
  //    String? symbol = business[0]['currency']['symbol'],
  //       name = business[0]['name'],
  //       logo = business[0]['logo'],
  //       taxLabel = business[0]['tax_label_1'],
  //       taxNumber = business[0]['tax_number_1'];
  //   int? currencyPrecision = business[0]['currency_precision'],
  //       quantityPrecision = business[0]['quantity_precision'];
  //   return {
  //     'symbol': symbol ?? '',
  //     'name': name ?? '',
  //     'logo': logo ?? Config().defaultBusinessImage,
  //     'currencyPrecision': currencyPrecision ?? Config.currencyPrecision,
  //     'quantityPrecision': quantityPrecision ?? Config.quantityPrecision,
  //     'taxLabel': (taxLabel != null) ? '$taxLabel : ' : '',
  //     'taxNumber': (taxNumber != null) ? '$taxNumber' : '',
  //     'max_tip_value': '',
  //   };
  // }
  Future<Map<String, dynamic>> getFormattedBusinessDetails() async {
    try {
      List business = await System().get('business');
      if (business.isEmpty) {
        return {
          'symbol': '',
          'name': '',
          'logo': Config().defaultBusinessImage,
          'currencyPrecision': Config.currencyPrecision,
          'quantityPrecision': Config.quantityPrecision,
          'taxLabel': '',
          'taxNumber': '',
          'max_tip_value': '',
        };
      }

      var businessData = business.first;
      return {
        'symbol': businessData['currency']?['symbol'] ?? '',
        'name': businessData['name'] ?? '',
        'logo': businessData['logo'] ?? Config().defaultBusinessImage,
        'currencyPrecision': businessData['currency_precision'] ?? Config.currencyPrecision,
        'quantityPrecision': businessData['quantity_precision'] ?? Config.quantityPrecision,
        'taxLabel': (businessData['tax_label_1'] != null) ? '${businessData['tax_label_1']} : ' : '',
        'taxNumber': businessData['tax_number_1']?.toString() ?? '',
        'max_tip_value': '',
      };
    } catch (e) {
      print('Error getting business details: $e');
      return {
        'symbol': '',
        'name': '',
        'logo': Config().defaultBusinessImage,
        'currencyPrecision': Config.currencyPrecision,
        'quantityPrecision': Config.quantityPrecision,
        'taxLabel': '',
        'taxNumber': '',
        'max_tip_value': '',
      };
    }
  }

  Future<bool> getPermission(String permissionFor) async {
    bool permission = false;
    await System().getPermission().then((value) {
      if (value[0] == 'all' || value.contains("$permissionFor")) {
        permission = true;
      }
    });
    return permission;
  }

  Widget callDropdown(context, followUpDetails, List numbers,
      {required String type}) {
    numbers.removeWhere((element) => element.toString() == 'null');
    return Container(
      height: MySize.size36,
      child: PopupMenuButton<String>(
        icon: Icon(
          (type == 'call') ? MdiIcons.phone : MdiIcons.whatsapp,
          color: (type == 'call') ? themeData.colorScheme.primary : Colors.green,
        ),
        onSelected: (value) async {
          if (type == 'call') {
            await launch('tel:$value');
          }
          if (type == 'whatsApp') {
            await launch("https://wa.me/$value");
          }
        },
        itemBuilder: (BuildContext context) {
          return numbers.map((item) {
            return PopupMenuItem<String>(
              value: item,
              child: Text(
                '$item',
                style: TextStyle(color: Colors.black),
              ),
            );
          }).toList();
        },
      ),
    );
  }

  noDataWidget(context) {
    return Column(
      children: [
        Expanded(
          flex: 5,
          child: CachedNetworkImage(
            imageUrl: Config().noDataImage,
            errorWidget: (context, url, error) =>
                Image.asset('assets/images/noData.png'),
          ),
        ),
        Expanded(
          flex: 1,
          child: Text(
            AppLocalizations.of(context).translate('no_data'),
            style: AppTheme.getTextStyle(
              themeData.textTheme.headline5,
              fontWeight: 600,
              color: themeData.colorScheme.onBackground,
            ),
          ),
        )
      ],
    );
  }

  Future<void> showLoginDialog(BuildContext context) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Session Expired'),
          content: Text('Please log in again.'),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  // Add these methods to your Helper class in otherHelpers.dart

  static Future<void> saveCartData(int sellId, Map<String, dynamic> cartData) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('cart_data_$sellId', jsonEncode(cartData));
      debugPrint('Saved cart data for sellId: $sellId');
    } catch (e) {
      debugPrint('Error saving cart data: $e');
    }
  }

  static Future<Map<String, dynamic>?> getCartData(int sellId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cartDataString = prefs.getString('cart_data_$sellId');
      if (cartDataString != null) {
        return jsonDecode(cartDataString);
      }
    } catch (e) {
      debugPrint('Error retrieving cart data: $e');
    }
    return null;
  }

  static Future<void> removeCartData(int sellId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('cart_data_$sellId');
      debugPrint('Removed cart data for sellId: $sellId');
    } catch (e) {
      debugPrint('Error removing cart data: $e');
    }
  }






  /// Helper method specifically for Sales → Checkout navigation flow
  static Future<void> prepareSalesToCheckoutNavigation({
    required int sellId,
    required int? resTableId,
    required int? isShipping,
    required List<Map<String, dynamic>> products,
  }) async {
    try {
      debugPrint('prepareSalesToCheckoutNavigation: Preparing Sales → Checkout navigation for sellId: $sellId');

      // Ensure cart items are saved
      await Sell().ensureCartItemsForSalesToCheckout(
        sellId: sellId,
        resTableId: resTableId,
        isShipping: isShipping,
        products: products,
      );

      // Save context for persistence
      await ContextManager.saveContext(
        sellId: sellId,
        resTableId: resTableId,
        isShipping: isShipping ?? 0,
        tableName: null, // Will be set from sales data
        locationId: 1, // Default, will be overridden by actual data
      );

      debugPrint('prepareSalesToCheckoutNavigation: Preparation completed successfully');
    } catch (e) {
      debugPrint('prepareSalesToCheckoutNavigation: Error - $e');
    }
  }
}