import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/sellDatabase.dart';

class TableAvailabilityManager {
  static final TableAvailabilityManager _instance = TableAvailabilityManager._internal();
  factory TableAvailabilityManager() => _instance;
  TableAvailabilityManager._internal();

  final SellDatabase _sellDatabase = SellDatabase();

  // Cache for table/shipping availability status
  Map<String, bool> _availabilityCache = {};

  // Forced enabled tables/shipping (persists until new order is started)
  Set<int> _forcedEnabledTables = {};
  bool _forcedEnabledShipping = false;

  /// Check if a table is available (not in use by draft/quotation orders)
  Future<bool> isTableAvailable(int tableId, {int? locationId}) async {
    final cacheKey = locationId != null ? 'table_${tableId}_loc_$locationId' : 'table_$tableId';
    try {
      // Always validate against database to ensure consistency
      // This prevents tables from getting stuck in disabled state
      final actualAvailability = await _validateTableAvailabilityFromDatabase(tableId, locationId: locationId);

      // Update cache with validated result
      _availabilityCache[cacheKey] = actualAvailability;

      debugPrint('Table $tableId availability (validated): $actualAvailability');
      return actualAvailability;
    } catch (e) {
      debugPrint('Error checking table availability: $e');
      // On error, clear cache for this table and default to available
      _availabilityCache.remove(cacheKey);
      return true; // Default to available if error occurs
    }
  }

  /// Validate table availability directly from database
  /// This method ensures we always have the most accurate state
  Future<bool> _validateTableAvailabilityFromDatabase(int tableId, {int? locationId}) async {
    try {
      // Check forced availability first
      if (_forcedEnabledTables.contains(tableId)) {
        debugPrint('Table $tableId is forced enabled, skipping database validation');
        return true;
      }

      // Query database for active orders on this table
      // Use sale_status field to get draft and quotation orders
      final allOrders = await _sellDatabase.getSells(all: true);

      // Filter orders that are actually for this table and not shipping
      // Only consider draft and quotation orders (not final)
      // Now also filter by location if locationId is provided
      final tableActiveOrders = allOrders.where((order) =>
      order['res_table_id'] == tableId &&
          (order['is_shipping'] ?? 0) == 0 &&
          (order['sale_status'] == 'draft') && // Only draft orders
          (order['is_synced'] != 1) && // Exclude synced orders
          (locationId == null || order['location_id'] == locationId) // Filter by location if provided
      ).toList();

      final tableQuotationOrders = allOrders.where((order) =>
      order['res_table_id'] == tableId &&
          (order['is_shipping'] ?? 0) == 0 &&
          (order['sale_status'] == 'quotation') && // Only quotation orders
          (order['is_synced'] != 1) && // Exclude synced orders
          (locationId == null || order['location_id'] == locationId) // Filter by location if provided
      ).toList();

      final isInUse = tableActiveOrders.isNotEmpty || tableQuotationOrders.isNotEmpty;
      final isAvailable = !isInUse;

      final locationStr = locationId != null ? " for location $locationId" : "";
      debugPrint('Database validation for table $tableId$locationStr: isInUse=$isInUse, isAvailable=$isAvailable');
      if (isInUse) {
        debugPrint('Active orders found for table $tableId$locationStr: $tableActiveOrders');
        debugPrint('Quotation orders found for table $tableId$locationStr: $tableQuotationOrders');
      } else {
        debugPrint('No active orders found for table $tableId$locationStr - table is available');
      }

      return isAvailable;
    } catch (e) {
      debugPrint('Error validating table availability from database: $e');
      return true; // Default to available if error occurs
    }
  }

  /// Check if shipping is available (not in use by draft/quotation orders)
  Future<bool> isShippingAvailable({int? locationId}) async {
    final cacheKey = locationId != null ? 'shipping_loc_$locationId' : 'shipping';
    try {
      debugPrint('isShippingAvailable: Method called');

      // Always validate against database to ensure consistency
      // This prevents shipping from getting stuck in disabled state
      final actualAvailability = await _validateShippingAvailabilityFromDatabase(locationId: locationId);

      // Update cache with validated result
      _availabilityCache[cacheKey] = actualAvailability;

      debugPrint('Shipping availability (validated): $actualAvailability');
      return actualAvailability;
    } catch (e) {
      debugPrint('Error checking shipping availability: $e');
      // On error, clear cache for shipping and default to available
      _availabilityCache.remove(cacheKey);
      return true; // Default to available if error occurs
    }
  }

  /// Validate shipping availability directly from database
  /// This method ensures we always have the most accurate state
  Future<bool> _validateShippingAvailabilityFromDatabase({int? locationId}) async {
    try {
      // Check forced availability first
      if (_forcedEnabledShipping) {
        debugPrint('Shipping is forced enabled, skipping database validation');
        return true;
      }

      // Query database for all orders
      final allOrders = await _sellDatabase.getSells(all: true);

      // Filter draft shipping orders, now also filter by location if provided
      final draftShippingOrders = allOrders.where((order) =>
      (order['is_shipping'] ?? 0) == 1 &&
          (order['sale_status'] == 'draft') && // Only draft orders
          (order['is_synced'] != 1) && // Exclude synced orders
          (locationId == null || order['location_id'] == locationId) // Filter by location if provided
      ).toList();

      // Filter quotation shipping orders, now also filter by location if provided
      final quotationShippingOrders = allOrders.where((order) =>
      (order['is_shipping'] ?? 0) == 1 &&
          (order['sale_status'] == 'quotation') && // Only quotation orders
          (order['is_synced'] != 1) && // Exclude synced orders
          (locationId == null || order['location_id'] == locationId) // Filter by location if provided
      ).toList();

      final isInUse = draftShippingOrders.isNotEmpty || quotationShippingOrders.isNotEmpty;
      final isAvailable = !isInUse;

      final locationStr = locationId != null ? " for location $locationId" : "";
      debugPrint('Shipping availability validation$locationStr:');
      debugPrint('  - All orders: ${allOrders.length} total');
      debugPrint('  - Draft shipping orders: ${draftShippingOrders.length}');
      debugPrint('  - Quotation shipping orders: ${quotationShippingOrders.length}');
      debugPrint('  - isInUse: $isInUse, isAvailable: $isAvailable');

      if (isInUse) {
        debugPrint('Active shipping orders found$locationStr: $draftShippingOrders');
        debugPrint('Active quotation shipping orders found$locationStr: $quotationShippingOrders');
      } else {
        debugPrint('No active shipping orders found$locationStr - shipping is available');
      }

      return isAvailable;
    } catch (e) {
      debugPrint('Error validating shipping availability from database: $e');
      return true; // Default to available if error occurs
    }
  }

  /// Mark a table as unavailable (when order is created)
  /// This method now validates that the table should actually be unavailable
  Future<void> markTableUnavailable(int tableId) async {
    try {
      // Clear forced enabled state when marking unavailable (starting new order)
      _forcedEnabledTables.remove(tableId);

      // Always validate against database first to ensure consistency
      final actualAvailability = await _validateTableAvailabilityFromDatabase(tableId);

      if (!actualAvailability) {
        // Table is actually unavailable in database, update cache
        final cacheKey = 'table_$tableId';
        _availabilityCache[cacheKey] = false;
        debugPrint('Marked table $tableId as unavailable (validated against database)');
      } else {
        debugPrint('Warning: Attempted to mark table $tableId as unavailable but database shows it is available');
        // Don't mark as unavailable if database shows it's available
        // This prevents tables from getting stuck in disabled state
      }
    } catch (e) {
      debugPrint('Error marking table $tableId as unavailable: $e');
      // On error, don't mark as unavailable to prevent stuck states
    }
  }

  /// Mark shipping as unavailable (when order is created)
  /// This method now validates that shipping should actually be unavailable
  Future<void> markShippingUnavailable() async {
    try {
      // Clear forced enabled state when marking unavailable (starting new order)
      _forcedEnabledShipping = false;

      // Always validate against database first to ensure consistency
      final actualAvailability = await _validateShippingAvailabilityFromDatabase();

      if (!actualAvailability) {
        // Shipping is actually unavailable in database, update cache
        const cacheKey = 'shipping';
        _availabilityCache[cacheKey] = false;
        debugPrint('Marked shipping as unavailable (validated against database)');
      } else {
        debugPrint('Warning: Attempted to mark shipping as unavailable but database shows it is available');
        // Don't mark as unavailable if database shows it's available
        // This prevents shipping from getting stuck in disabled state
      }
    } catch (e) {
      debugPrint('Error marking shipping as unavailable: $e');
      // On error, don't mark as unavailable to prevent stuck states
    }
  }

  /// Check if a table has active orders
  Future<bool> _hasActiveOrdersForTable(int tableId) async {
    try {
      final allOrders = await _sellDatabase.getSells(all: true);

      final hasActiveOrders = allOrders.any((order) =>
      order['res_table_id'] == tableId &&
          (order['is_shipping'] ?? 0) == 0 &&
          ((order['sale_status'] == 'draft') || (order['sale_status'] == 'quotation')) &&
          (order['is_synced'] != 1));

      debugPrint('Table $tableId has active orders: $hasActiveOrders');
      return hasActiveOrders;
    } catch (e) {
      debugPrint('Error checking active orders for table $tableId: $e');
      return false; // Default to no active orders if error occurs
    }
  }

  /// Check if shipping has active orders
  Future<bool> _hasActiveOrdersForShipping() async {
    try {
      final allOrders = await _sellDatabase.getSells(all: true);

      final hasActiveOrders = allOrders.any((order) =>
      (order['is_shipping'] ?? 0) == 1 &&
          ((order['sale_status'] == 'draft') || (order['sale_status'] == 'quotation')) &&
          (order['is_synced'] != 1));

      debugPrint('Shipping has active orders: $hasActiveOrders');
      return hasActiveOrders;
    } catch (e) {
      debugPrint('Error checking active orders for shipping: $e');
      return false; // Default to no active orders if error occurs
    }
  }

  /// Mark a table as available (when order is finalized)
  void markTableAvailable(int tableId) {
    final cacheKey = 'table_$tableId';
    _availabilityCache[cacheKey] = true;
    debugPrint('Marked table $tableId as available');
  }

  /// Mark shipping as available (when order is finalized)
  void markShippingAvailable() {
    const cacheKey = 'shipping';
    _availabilityCache[cacheKey] = true;
    debugPrint('Marked shipping as available');
  }

  /// Clear cache and refresh availability status
  Future<void> refreshAvailability() async {
    _availabilityCache.clear();
    // Do NOT clear forced enabled states here - they should persist until new order
    debugPrint('refreshAvailability: Cleared availability cache');
  }

  /// Force refresh all table availability by clearing cache and re-validating
  /// This method helps recover from stuck table states
  Future<Map<int, bool>> forceRefreshAllTables(List<int> tableIds) async {
    try {
      debugPrint('forceRefreshAllTables: Starting forced refresh for ${tableIds.length} tables');

      // Clear all table-related cache entries
      for (int tableId in tableIds) {
        _availabilityCache.remove('table_$tableId');
      }
      _availabilityCache.remove('shipping');

      // Clear forced states on full force refresh
      _forcedEnabledTables.clear();
      _forcedEnabledShipping = false;

      // Re-validate all tables from database
      final Map<int, bool> refreshedAvailability = {};
      for (int tableId in tableIds) {
        refreshedAvailability[tableId] = await _validateTableAvailabilityFromDatabase(tableId);
      }

      // Update cache with fresh data
      for (int tableId in tableIds) {
        _availabilityCache['table_$tableId'] = refreshedAvailability[tableId]!;
      }

      // Also refresh shipping availability
      final shippingAvailable = await _validateShippingAvailabilityFromDatabase();
      _availabilityCache['shipping'] = shippingAvailable;

      debugPrint('forceRefreshAllTables: Completed forced refresh');
      debugPrint('forceRefreshAllTables: Refreshed availability: $refreshedAvailability');
      debugPrint('forceRefreshAllTables: Shipping available: $shippingAvailable');

      return refreshedAvailability;
    } catch (e) {
      debugPrint('Error in forceRefreshAllTables: $e');
      // Return default availability (all available) if error occurs
      return Map.fromEntries(tableIds.map((id) => MapEntry(id, true)));
    }
  }

  /// Force clear shipping cache specifically
  void clearShippingCache() {
    _availabilityCache.remove('shipping');
    debugPrint('clearShippingCache: Cleared shipping cache');
  }

  /// Force enable table or shipping - bypasses all validation
  /// This method should be used when we know for certain that a table/shipping should be available
  /// (e.g., after order finalization, cancellation, or payment completion)
  Future<void> forceEnableTableOrShipping({int? tableId, bool isShipping = false, int? locationId}) async {
    try {
      if (isShipping) {
        // Force enable shipping - clear all shipping cache entries
        _availabilityCache.removeWhere((key, value) => key.startsWith('shipping'));
        _availabilityCache['shipping'] = true;
        if (locationId != null) {
          _availabilityCache['shipping_loc_$locationId'] = true;
        }
        debugPrint('forceEnableTableOrShipping: Force enabled shipping (cleared all shipping cache)');

        // Add to forced enabled set
        _forcedEnabledShipping = true;

        // CRITICAL: After force enabling, we should NOT let database validation override it
        // because there might be other draft orders that would mark it as unavailable again
        // The force enable should take precedence - if a specific order was finalized,
        // that shipping should be available for new orders
        final actualAvailability = await _validateShippingAvailabilityFromDatabase(locationId: locationId);
        debugPrint('forceEnableTableOrShipping: Shipping database validation after force enable: $actualAvailability');
        if (!actualAvailability) {
          debugPrint('forceEnableTableOrShipping: NOTE - Database shows other draft orders for shipping, but keeping force enabled for finalized order');
          // Keep the force enable - don't revert it
          _availabilityCache['shipping'] = true;
          if (locationId != null) {
            _availabilityCache['shipping_loc_$locationId'] = true;
          }
        }
      } else if (tableId != null) {
        // Force enable table - clear all cache entries for this table (including location-specific ones)
        _availabilityCache.removeWhere((key, value) => key == 'table_$tableId' || key.startsWith('table_${tableId}_loc_'));
        _availabilityCache['table_$tableId'] = true;
        if (locationId != null) {
          _availabilityCache['table_${tableId}_loc_$locationId'] = true;
        }
        debugPrint('forceEnableTableOrShipping: Force enabled table $tableId (cleared all table cache entries)');

        // Add to forced enabled set
        _forcedEnabledTables.add(tableId);

        // CRITICAL: After force enabling, we should NOT let database validation override it
        // because there might be other draft orders that would mark it as unavailable again
        // The force enable should take precedence - if a specific order was finalized,
        // that table should be available for new orders
        final actualAvailability = await _validateTableAvailabilityFromDatabase(tableId, locationId: locationId);
        debugPrint('forceEnableTableOrShipping: Table $tableId database validation after force enable: $actualAvailability');
        if (!actualAvailability) {
          debugPrint('forceEnableTableOrShipping: NOTE - Database shows other draft orders for table $tableId, but keeping force enabled for finalized order');
          // Keep the force enable - don't revert it
          _availabilityCache['table_$tableId'] = true;
          if (locationId != null) {
            _availabilityCache['table_${tableId}_loc_$locationId'] = true;
          }
        }
      }
    } catch (e) {
      debugPrint('Error in forceEnableTableOrShipping: $e');
    }
  }

  /// Force enable all tables and shipping - emergency method
  /// This should be called when tables are stuck in disabled state
  Future<void> forceEnableAllTablesAndShipping(List<int> tableIds) async {
    try {
      debugPrint('forceEnableAllTablesAndShipping: Force enabling all tables and shipping');

      // Clear all cache entries
      _availabilityCache.clear();

      // Mark shipping as available
      _availabilityCache['shipping'] = true;

      // Mark all tables as available
      for (int tableId in tableIds) {
        _availabilityCache['table_$tableId'] = true;
      }

      debugPrint('forceEnableAllTablesAndShipping: All tables and shipping force enabled');
    } catch (e) {
      debugPrint('Error in forceEnableAllTablesAndShipping: $e');
    }
  }

  /// Get availability status for multiple tables
  Future<Map<int, bool>> getTablesAvailability(List<int> tableIds) async {
    final Map<int, bool> availability = {};

    for (int tableId in tableIds) {
      availability[tableId] = await isTableAvailable(tableId);
    }

    return availability;
  }

  /// Check if any table is available
  Future<bool> hasAnyTableAvailable(List<int> tableIds) async {
    for (int tableId in tableIds) {
      if (await isTableAvailable(tableId)) {
        return true;
      }
    }
    return false;
  }

  /// Force enable all tables and shipping on login
  /// This ensures all tables are available when any user logs in
  void forceEnableAllOnLogin() {
    try {
      debugPrint('forceEnableAllOnLogin: Starting to enable all tables and shipping');

      // Clear all cache entries
      _availabilityCache.clear();

      // Mark shipping as available
      _availabilityCache['shipping'] = true;
      _forcedEnabledShipping = true;
      debugPrint('forceEnableAllOnLogin: Marked shipping as available');

      debugPrint('forceEnableAllOnLogin: All tables and shipping enabled for new login session');
    } catch (e) {
      debugPrint('Error in forceEnableAllOnLogin: $e');
    }
  }

  /// Emergency method to force enable all tables and shipping
  /// This should be called when tables are stuck in disabled state
  Future<void> emergencyEnableAllTables(List<int> tableIds) async {
    try {
      debugPrint('emergencyEnableAllTables: Emergency enabling all tables and shipping');

      // Clear all cache entries
      _availabilityCache.clear();

      // Mark shipping as available
      _availabilityCache['shipping'] = true;

      // Mark all tables as available
      for (int tableId in tableIds) {
        _availabilityCache['table_$tableId'] = true;
      }

      debugPrint('emergencyEnableAllTables: Emergency enable completed - all tables and shipping enabled');
    } catch (e) {
      debugPrint('Error in emergencyEnableAllTables: $e');
    }
  }

  /// Force enable all tables and shipping when no active orders exist
  /// This method helps recover from stuck table states
  Future<void> forceEnableAllWhenNoActiveOrders() async {
    try {
      debugPrint('forceEnableAllWhenNoActiveOrders: Checking for active orders');

      // Check if there are any active orders at all
      final allOrders = await _sellDatabase.getSells(all: true);

      final hasAnyActiveOrders = allOrders.any((order) =>
      ((order['sale_status'] == 'draft') || (order['sale_status'] == 'quotation')) &&
          (order['is_synced'] != 1));

      if (!hasAnyActiveOrders) {
        debugPrint('forceEnableAllWhenNoActiveOrders: No active orders found, enabling all tables and shipping');

        // Clear all cache entries
        _availabilityCache.clear();

        // Mark shipping as available
        _availabilityCache['shipping'] = true;

        debugPrint('forceEnableAllWhenNoActiveOrders: All tables and shipping enabled');
      } else {
        debugPrint('forceEnableAllWhenNoActiveOrders: Active orders found, not forcing enable');
      }
    } catch (e) {
      debugPrint('Error in forceEnableAllWhenNoActiveOrders: $e');
    }
  }

  /// Validate and fix any inconsistent table states
  /// This method should be called periodically to ensure table states are correct
  Future<void> validateAndFixTableStates(List<int> tableIds) async {
    try {
      debugPrint('validateAndFixTableStates: Starting validation for ${tableIds.length} tables');

      // Check if there are any active orders at all
      final allOrders = await _sellDatabase.getSells(all: true);

      final hasAnyActiveOrders = allOrders.any((order) =>
      ((order['sale_status'] == 'draft') || (order['sale_status'] == 'quotation')) &&
          (order['is_synced'] != 1));

      if (!hasAnyActiveOrders) {
        debugPrint('validateAndFixTableStates: No active orders found, enabling all tables and shipping');

        // Clear all cache entries
        _availabilityCache.clear();

        // Mark shipping as available
        _availabilityCache['shipping'] = true;
        _forcedEnabledShipping = true;

        // Mark all tables as available
        for (int tableId in tableIds) {
          _availabilityCache['table_$tableId'] = true;
          _forcedEnabledTables.add(tableId);
        }

        debugPrint('validateAndFixTableStates: All tables and shipping enabled');
        return;
      }

      // If there are active orders, validate each table individually
      for (int tableId in tableIds) {
        final actualAvailability = await _validateTableAvailabilityFromDatabase(tableId);
        _availabilityCache['table_$tableId'] = actualAvailability;

        if (!actualAvailability) {
          debugPrint('validateAndFixTableStates: Table $tableId is correctly marked as unavailable');
        } else {
          debugPrint('validateAndFixTableStates: Table $tableId is correctly marked as available');
        }
      }

      // Validate shipping
      final shippingAvailability = await _validateShippingAvailabilityFromDatabase();
      _availabilityCache['shipping'] = shippingAvailability;

      debugPrint('validateAndFixTableStates: Validation completed');
    } catch (e) {
      debugPrint('Error in validateAndFixTableStates: $e');
      // On error, enable all tables to prevent stuck states
      _availabilityCache.clear();
      _availabilityCache['shipping'] = true;
      for (int tableId in tableIds) {
        _availabilityCache['table_$tableId'] = true;
      }
    }
  }

  /// Auto-validate table states to prevent stuck disabled tables
  /// This method should be called when the Tables page loads to ensure consistency
  Future<Map<int, bool>> autoValidateTableStates(List<int> tableIds, {int? locationId}) async {
    try {
      final locationStr = locationId != null ? " for location $locationId" : "";
      debugPrint('autoValidateTableStates: Starting auto-validation for ${tableIds.length} tables$locationStr');

      // First, check if there are any active orders at all
      final allOrders = await _sellDatabase.getSells(all: true);

      final hasAnyActiveOrders = allOrders.any((order) =>
      ((order['sale_status'] == 'draft') || (order['sale_status'] == 'quotation')) &&
          (order['is_synced'] != 1) &&
          (locationId == null || order['location_id'] == locationId)); // Filter by location

      if (!hasAnyActiveOrders) {
        debugPrint('autoValidateTableStates: No active orders found$locationStr, enabling all tables and shipping');

        // Clear cache entries for this location and mark everything as available
        final cacheKeyPrefix = locationId != null ? "_loc_$locationId" : "";
        _availabilityCache['shipping$cacheKeyPrefix'] = true;
        _forcedEnabledShipping = true;

        final Map<int, bool> result = {};
        for (int tableId in tableIds) {
          final tableCacheKey = locationId != null ? 'table_${tableId}_loc_$locationId' : 'table_$tableId';
          _availabilityCache[tableCacheKey] = true;
          _forcedEnabledTables.add(tableId);
          result[tableId] = true;
        }

        debugPrint('autoValidateTableStates: All tables and shipping enabled$locationStr');
        return result;
      }

      // If there are active orders, validate each table individually
      final Map<int, bool> result = {};
      for (int tableId in tableIds) {
        final actualAvailability = await _validateTableAvailabilityFromDatabase(tableId, locationId: locationId);
        final tableCacheKey = locationId != null ? 'table_${tableId}_loc_$locationId' : 'table_$tableId';
        _availabilityCache[tableCacheKey] = actualAvailability;
        result[tableId] = actualAvailability;

        if (!actualAvailability) {
          debugPrint('autoValidateTableStates: Table $tableId is correctly unavailable (has active orders)$locationStr');
        } else {
          debugPrint('autoValidateTableStates: Table $tableId is available$locationStr');
        }
      }

      // Validate
      // shipping
      final shippingAvailability = await _validateShippingAvailabilityFromDatabase(locationId: locationId);
      final shippingCacheKey = locationId != null ? 'shipping_loc_$locationId' : 'shipping';
      _availabilityCache[shippingCacheKey] = shippingAvailability;

      debugPrint('autoValidateTableStates: Auto-validation completed$locationStr');
      return result;
    } catch (e) {
      debugPrint('Error in autoValidateTableStates: $e');
      // On error, enable all tables to prevent stuck states
      _availabilityCache.clear();
      _availabilityCache['shipping'] = true;

      final Map<int, bool> result = {};
      for (int tableId in tableIds) {
        _availabilityCache['table_$tableId'] = true;
        result[tableId] = true;
      }
      return result;
    }
  }
}
