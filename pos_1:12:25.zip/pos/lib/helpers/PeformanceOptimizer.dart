import 'dart:async';
import 'dart:ui';

/// Performance optimization utilities for the POS app
class PerformanceOptimizer {
  static final Map<String, Completer> _loadingTasks = {};
  static final Map<String, dynamic> _cache = {};
  static const Duration _cacheExpiry = Duration(minutes: 5);

  /// Execute a task only once, even if called multiple times
  static Future<T> executeOnce<T>(String key, Future<T> Function() task) async {
    if (_loadingTasks.containsKey(key)) {
      return await _loadingTasks[key]!.future as T;
    }

    final completer = Completer<T>();
    _loadingTasks[key] = completer;

    try {
      final result = await task();
      completer.complete(result);
      return result;
    } catch (e) {
      completer.completeError(e);
      rethrow;
    } finally {
      _loadingTasks.remove(key);
    }
  }

  /// Cache data with automatic expiry
  static T? getCached<T>(String key) {
    final cached = _cache[key];
    if (cached == null) return null;

    final timestamp = cached['timestamp'] as DateTime;
    if (DateTime.now().difference(timestamp) > _cacheExpiry) {
      _cache.remove(key);
      return null;
    }

    return cached['data'] as T;
  }

  /// Set cached data with timestamp
  static void setCached<T>(String key, T data) {
    _cache[key] = {
      'data': data,
      'timestamp': DateTime.now(),
    };
  }

  /// Clear all cache
  static void clearCache() {
    _cache.clear();
  }

  /// Clear specific cache entry
  static void clearCached(String key) {
    _cache.remove(key);
  }

  /// Execute tasks in parallel with error handling
  static Future<List<T>> executeInParallel<T>(
      List<Future<T> Function()> tasks, {
        bool continueOnError = true,
      }) async {
    final futures = tasks.map((task) async {
      try {
        return await task();
      } catch (e) {
        if (continueOnError) {
          print('PerformanceOptimizer: Task failed but continuing: $e');
          return null;
        }
        rethrow;
      }
    });

    final results = await Future.wait(futures);
    return results.where((result) => result != null).cast<T>().toList();
  }

  /// Debounce function calls
  static Timer? _debounceTimer;
  static void debounce(String key, VoidCallback callback, Duration delay) {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(delay, () {
      callback();
    });
  }

  /// Throttle function calls
  static DateTime? _lastThrottleCall;
  static void throttle(String key, VoidCallback callback, Duration interval) {
    final now = DateTime.now();
    if (_lastThrottleCall == null ||
        now.difference(_lastThrottleCall!) > interval) {
      _lastThrottleCall = now;
      callback();
    }
  }
}

/// Extension for easier performance optimization
extension PerformanceOptimizerExtension<T> on Future<T> Function() {
  Future<T> executeOnce(String key) {
    return PerformanceOptimizer.executeOnce(key, this);
  }
}
