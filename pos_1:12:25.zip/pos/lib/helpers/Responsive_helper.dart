import 'package:flutter/material.dart';

class ResponsiveHelper {
  // Breakpoints for different device types
  static const double mobileBreakpoint = 600;
  static const double tabletBreakpoint = 900;
  static const double desktopBreakpoint = 1200;

  // Check if current screen is mobile
  static bool isMobile(BuildContext context) {
    try {
      return MediaQuery.of(context).size.width < mobileBreakpoint;
    } catch (e) {
      // Fallback to mobile if context is not available
      return true;
    }
  }

  // Check if current screen is tablet
  static bool isTablet(BuildContext context) {
    try {
      final width = MediaQuery.of(context).size.width;
      return width >= mobileBreakpoint && width < tabletBreakpoint;
    } catch (e) {
      // Fallback to mobile if context is not available
      return false;
    }
  }

  // Check if current screen is desktop
  static bool isDesktop(BuildContext context) {
    try {
      return MediaQuery.of(context).size.width >= tabletBreakpoint;
    } catch (e) {
      // Fallback to mobile if context is not available
      return false;
    }
  }

  // Get appropriate cross axis count for grids based on screen size
  static int getCrossAxisCount(BuildContext context, {int? mobileCount, int? tabletCount, int? desktopCount}) {
    try {
      if (isMobile(context)) {
        return mobileCount ?? 2;
      } else if (isTablet(context)) {
        return tabletCount ?? 3;
      } else {
        return desktopCount ?? 4;
      }
    } catch (e) {
      // Fallback to mobile layout if context is not available
      return mobileCount ?? 2;
    }
  }

  // Get appropriate padding based on screen size
  static EdgeInsets getResponsivePadding(BuildContext context, {
    double? mobilePadding,
    double? tabletPadding,
    double? desktopPadding,
  }) {
    try {
      double padding;
      if (isMobile(context)) {
        padding = mobilePadding ?? 16.0;
      } else if (isTablet(context)) {
        padding = tabletPadding ?? 24.0;
      } else {
        padding = desktopPadding ?? 32.0;
      }
      return EdgeInsets.all(padding);
    } catch (e) {
      // Fallback to mobile padding if context is not available
      return EdgeInsets.all(mobilePadding ?? 16.0);
    }
  }

  // Get appropriate child aspect ratio for grids
  static double getChildAspectRatio(BuildContext context, {
    double? mobileRatio,
    double? tabletRatio,
    double? desktopRatio,
  }) {
    try {
      if (isMobile(context)) {
        return mobileRatio ?? 0.8;
      } else if (isTablet(context)) {
        return tabletRatio ?? 1.0;
      } else {
        return desktopRatio ?? 1.2;
      }
    } catch (e) {
      // Fallback to mobile ratio if context is not available
      return mobileRatio ?? 0.8;
    }
  }

  // Get appropriate font size based on screen size
  static double getResponsiveFontSize(BuildContext context, {
    double? mobileSize,
    double? tabletSize,
    double? desktopSize,
  }) {
    try {
      if (isMobile(context)) {
        return mobileSize ?? 14.0;
      } else if (isTablet(context)) {
        return tabletSize ?? 16.0;
      } else {
        return desktopSize ?? 18.0;
      }
    } catch (e) {
      // Fallback to mobile font size if context is not available
      return mobileSize ?? 14.0;
    }
  }

  // Get appropriate spacing between grid items
  static double getResponsiveSpacing(BuildContext context, {
    double? mobileSpacing,
    double? tabletSpacing,
    double? desktopSpacing,
  }) {
    try {
      if (isMobile(context)) {
        return mobileSpacing ?? 16.0;
      } else if (isTablet(context)) {
        return tabletSpacing ?? 20.0;
      } else {
        return desktopSpacing ?? 24.0;
      }
    } catch (e) {
      // Fallback to mobile spacing if context is not available
      return mobileSpacing ?? 16.0;
    }
  }

  // Get appropriate container width for content
  static double getContentWidth(BuildContext context, {double? maxWidth}) {
    try {
      final screenWidth = MediaQuery.of(context).size.width;
      final maxContentWidth = maxWidth ?? 1200.0;

      if (isDesktop(context)) {
        return screenWidth > maxContentWidth ? maxContentWidth : screenWidth;
      }
      return screenWidth;
    } catch (e) {
      // Fallback to a reasonable width if context is not available
      return maxWidth ?? 1200.0;
    }
  }

  // Check if we should use a centered layout for larger screens
  static bool shouldCenterContent(BuildContext context) {
    try {
      return isTablet(context) || isDesktop(context);
    } catch (e) {
      // Fallback to mobile layout if context is not available
      return false;
    }
  }

  // Get appropriate number of columns for data tables
  static int getDataTableColumns(BuildContext context) {
    try {
      if (isMobile(context)) {
        return 1;
      } else if (isTablet(context)) {
        return 2;
      } else {
        return 3;
      }
    } catch (e) {
      // Fallback to mobile layout if context is not available
      return 1;
    }
  }

  // Get appropriate card elevation based on screen size
  static double getCardElevation(BuildContext context) {
    try {
      if (isMobile(context)) {
        return 2.0;
      } else if (isTablet(context)) {
        return 4.0;
      } else {
        return 6.0;
      }
    } catch (e) {
      // Fallback to mobile elevation if context is not available
      return 2.0;
    }
  }

  // Get appropriate border radius based on screen size
  static double getBorderRadius(BuildContext context) {
    try {
      if (isMobile(context)) {
        return 8.0;
      } else if (isTablet(context)) {
        return 12.0;
      } else {
        return 16.0;
      }
    } catch (e) {
      // Fallback to mobile border radius if context is not available
      return 8.0;
    }
  }
}
