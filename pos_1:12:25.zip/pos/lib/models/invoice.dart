import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import '../helpers/otherHelpers.dart';
import '../locale/MyLocalizations.dart';
import '../models/paymentDatabase.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import 'contact_model.dart';

class InvoiceFormatter {
  double subTotal = 0.0;
  String taxName = 'taxRates';
  double inlineDiscountAmount = 0.0;
  double inlineTaxAmount = 0.0;
  double tax = 0.0;
  final int? sellId;

  InvoiceFormatter({this.sellId});

  Future<Map<String, dynamic>> getPdf(String invoiceType, BuildContext context) async {
    String html = await generateInvoice(sellId!, null, context);
    final pdf = await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => (await Printing.convertHtml(
        format: format,
        html: html,
      )).buffer.asUint8List(),
    );
    return {
      'html': html,
      'pdf': pdf,
    };
  }

  Future<String> generateProductDetails(int sellId, BuildContext context) async {
    // Fetch products from sellLine by sellId
    List products = await SellDatabase().get(sellId: sellId);
    String product = '''
      <tr class="bb-lg">
        <th width="30%">
          <p>${AppLocalizations.of(context).translate('products')}</p>
        </th>
        <th width="20%">
          <p>${AppLocalizations.of(context).translate('quantity')}</p>
        </th>
        <th width="20%">
          <p>${AppLocalizations.of(context).translate('unit_price')}</p>
        </th>
        <th width="20%">
          <p>${AppLocalizations.of(context).translate('sub_total')}</p>
        </th>
      </tr>
    ''';
    subTotal = 0.0;
    for (int i = 0; i < products.length; i++) {
      String productName = products[i]['name'] ?? 'Unknown Product';
      String productSku = products[i]['sub_sku'] ?? '';
      String productQuantity = products[i]['quantity']?.toString() ?? '0';
      Map<String, dynamic> inlineAmounts = await Helper().calculateTaxAndDiscount(
        discountAmount: products[i]['discount_amount'] ?? 0.0,
        discountType: products[i]['discount_type'] ?? 'fixed',
        unitPrice: products[i]['unit_price'] ?? 0.0,
        taxId: products[i]['tax_rate_id'],
      );
      inlineDiscountAmount += inlineAmounts['discountAmount'] ?? 0.0;
      inlineTaxAmount += inlineAmounts['taxAmount'] ?? 0.0;
      String productPrice = await Helper().calculateTotal(
        taxId: products[i]['tax_rate_id'],
        discountAmount: products[i]['discount_amount'] ?? 0.0,
        discountType: products[i]['discount_type'] ?? 'fixed',
        unitPrice: products[i]['unit_price'] ?? 0.0,
      );
      String totalProductsPrice = (products[i]['quantity'] * double.parse(productPrice)).toStringAsFixed(2);
      subTotal += double.parse(totalProductsPrice);
      product += '''
        <tr class="bb-lg">
          <td width="30%">
            <p>$productName, $productSku</p>
          </td>
          <td width="20%">
            <p>${Helper().formatQuantity(productQuantity)}</p>
          </td>
          <td width="20%">
            <p>${Helper().formatCurrency(productPrice)}</p>
          </td>
          <td width="20%">
            <p>${Helper().formatCurrency(totalProductsPrice)}</p>
          </td>
        </tr>
      ''';
    }
    return product;
  }

  Future<void> setTax(int? taxId) async {
    List taxList = await System().get('tax');
    for (var element in taxList) {
      if (element['id'] == taxId) {
        taxName = element['name'] ?? 'taxRates';
        tax = double.tryParse(element['amount']?.toString() ?? '0.0') ?? 0.0;
      }
    }
  }

  // Map<String, dynamic> getTotalAmount({
  //   required String discountType,
  //   required double discountAmount,
  //   required String symbol,
  // }) {
  //   Map<String, dynamic> allAmounts = {};
  //   String formattedDiscountType = discountType;
  //   double calculatedDiscountAmount = discountAmount;
  //
  //   if (discountType == "fixed") {
  //     formattedDiscountType = "$symbol $discountAmount";
  //     String tAmount = (subTotal - discountAmount).toStringAsFixed(2);
  //     allAmounts['taxAmount'] = Helper().formatCurrency(
  //       (double.parse(tAmount) * (tax / 100)).toStringAsFixed(2),
  //     );
  //     allAmounts['totalAmount'] = (double.parse(tAmount) + double.parse(allAmounts['taxAmount'])).toStringAsFixed(2);
  //     allAmounts['discountAmount'] = discountAmount;
  //     allAmounts['discountType'] = formattedDiscountType;
  //   } else if (discountType == "percentage") {
  //     formattedDiscountType = "$discountAmount %";
  //     calculatedDiscountAmount = subTotal * (discountAmount / 100);
  //     String tAmount = (subTotal - calculatedDiscountAmount).toStringAsFixed(2);
  //     allAmounts['taxAmount'] = Helper().formatCurrency(
  //       (double.parse(tAmount) * (tax / 100)).toStringAsFixed(2),
  //     );
  //     allAmounts['totalAmount'] = (double.parse(tAmount) + double.parse(allAmounts['taxAmount'])).toStringAsFixed(2);
  //     allAmounts['discountAmount'] = calculatedDiscountAmount;
  //     allAmounts['discountType'] = formattedDiscountType;
  //   }
  //   return allAmounts;
  // }
  Map<String, dynamic> getTotalAmount({
    required String discountType,
    required double discountAmount,
    required String symbol,
  }) {
    Map<String, dynamic> allAmounts = {};
    String formattedDiscountType = discountType;
    double calculatedDiscountAmount = 0.0;
    double subTotalAfterDiscount = 0.0;

    // Calculate discount based on type
    if (discountType == "fixed") {
      formattedDiscountType = "$symbol $discountAmount";
      calculatedDiscountAmount = discountAmount;
      subTotalAfterDiscount = subTotal - calculatedDiscountAmount;
    } else if (discountType == "percentage") {
      formattedDiscountType = "$discountAmount %";
      calculatedDiscountAmount = subTotal * (discountAmount / 100);
      subTotalAfterDiscount = subTotal - calculatedDiscountAmount;
    }

    // Calculate tax on the discounted subtotal
    String taxAmount = Helper().formatCurrency(
      (subTotalAfterDiscount * (tax / 100)).toStringAsFixed(2),
    );

    // Calculate total amount (subtotal after discount + tax)
    String totalAmount = (subTotalAfterDiscount + double.parse(taxAmount)).toStringAsFixed(2);

    allAmounts['taxAmount'] = taxAmount;
    allAmounts['totalAmount'] = totalAmount;
    allAmounts['discountAmount'] = calculatedDiscountAmount;
    allAmounts['discountType'] = formattedDiscountType;
    allAmounts['subTotalAfterDiscount'] = subTotalAfterDiscount.toStringAsFixed(2);

    return allAmounts;
  }
  Future<String> generateInvoice(int sellId, int? taxId, BuildContext? context) async {
    if (context == null) {
      return '<p>Error: Context is required</p>';
    }
    String symbol = '';
    String businessName = '';
    String taxHtml = '';
    String inlineTaxesHtml = '';
    String inlineDiscountHtml = '';
    String discountHtml = '';
    String dueHtml = '';
    String shippingHtml = '';
    String taxLabel = '';
    String taxNumber = '';
    String tipAmountHtml = '';

    await setTax(taxId);
    String products = await generateProductDetails(sellId, context);
    List sells = await SellDatabase().getSellBySellId(sellId);
    if (sells.isEmpty) {
      return '<p>Error: Sell not found</p>';
    }
    var sell = sells[0];
    var customer = await Contact().getCustomerDetailById(sell['contact_id']);
    String landmark = '', city = '', state = '', zipCode = '', country = '', businessMobile = '';
    List locations = await System().get('location');
    var location;
    for (var element in locations) {
      if (element['id'] == sell['location_id']) {
        location = element;
        landmark = (location['landmark'] != null) ? location['landmark'] + ',' : '';
        city = (location['city'] != null) ? location['city'] + ',' : '';
        state = (location['state'] != null) ? location['state'] + ',' : '';
        zipCode = (location['zip_code'] != null) ? location['zip_code'] + ',' : '';
        country = (location['country'] != null) ? location['country'] + ',' : '';
        businessMobile = (location['mobile'] != null) ? location['mobile'] + ',' : '';
      }
    }
    String invoiceNo = sell['invoice_no'] ?? 'Unknown';
    var dateTime = DateTime.parse(sell['transaction_date'] ?? DateTime.now().toString());
    var date = DateFormat("dd/MM/yyyy").format(dateTime);
    var discountType = sell['discount_type'] ?? 'fixed';
    var discountAmount = sell['discount_amount']?.toDouble() ?? 0.0;
    var tipAmount = sell['tip_amount']?.toDouble() ?? 0.0;
    var shippingCharges = sell['shipping_charges']?.toDouble() ?? 0.0;

    var businessDetails = await Helper().getFormattedBusinessDetails();
    symbol = businessDetails['symbol'] ?? '';
    businessName = businessDetails['name'] ?? '';
    taxLabel = businessDetails['taxLabel'] ?? '';
    taxNumber = businessDetails['taxNumber'] ?? '';

    var customerName = customer['name'] ?? 'Unknown';
    var customerAddress1 = (customer['address_line_1'] != null) ? customer['address_line_1'] + ',' : '';
    var customerAddress2 = (customer['address_line_2'] != null) ? customer['address_line_2'] + ',' : '';
    var customerCity = (customer['city'] != null) ? customer['city'] + ',' : '';
    var customerState = (customer['state'] != null) ? customer['state'] + ',' : '';
    var customerCountry = (customer['country'] != null) ? customer['country'] : '';
    var customerMobile = customer['mobile'] ?? '';

    List paymentList = await PaymentDatabase().get(sell['id'], allColumns: true, res_table_id: null);
    double totalPaidAmount = 0.0;
    String payments = '';
    for (var element in paymentList) {
      var sign = element['is_return'] == 0 ? '+' : '-';
      var paidAmount = element['amount']?.toDouble() ?? 0.0;
      totalPaidAmount += element['is_return'] == 0 ? paidAmount : -paidAmount;
      var method = element['method'] ?? 'Unknown';
      if (paidAmount > 0) {
        payments += '''
        <div class="flex-box">
          <p class="width-50 text-left">$method ($sign) ($date)</p>
          <p class="width-50 text-right">$symbol ${Helper().formatCurrency(paidAmount)}</p>
        </div>
      ''';
      }
    }

    Map<String, dynamic> getAmounts = getTotalAmount(
      discountType: discountType,
      discountAmount: discountAmount,
      symbol: symbol,
    );

    discountAmount = getAmounts['discountAmount'] ?? 0.0;
    String discountTypeFormatted = getAmounts['discountType'] ?? 'fixed';
    String taxAmount = getAmounts['taxAmount'] ?? '0.00';
    String subTotalAfterDiscount = getAmounts['subTotalAfterDiscount'] ?? '0.00';
    String totalAmount = (double.parse(getAmounts['totalAmount']) + shippingCharges + tipAmount).toStringAsFixed(2);

    String sTotal = subTotal.toStringAsFixed(2);
    double returnAmount = 0.0;
    double dueAmount = 0.0;

    // Calculate due and return amounts
    if (totalPaidAmount > double.parse(totalAmount)) {
      returnAmount = totalPaidAmount - double.parse(totalAmount);
      totalPaidAmount = double.parse(totalAmount);
      dueAmount = 0.0;
    } else if (double.parse(totalAmount) > totalPaidAmount) {
      dueAmount = double.parse(totalAmount) - totalPaidAmount;
      returnAmount = 0.0;
    } else {
      dueAmount = 0.0;
      returnAmount = 0.0;
    }
    String formattedReturnAmount = Helper().formatCurrency(returnAmount);
    String formattedTotalAmount = Helper().formatCurrency(totalAmount);
    String formattedTotalReceived = Helper().formatCurrency(totalPaidAmount);

    if (discountAmount > 0) {
      String formattedDiscountAmount = Helper().formatCurrency(discountAmount);
      discountHtml = '''
      <div class="flex-box">
        <p class="width-50 text-left">
          ${AppLocalizations.of(context).translate('discount')} <small>($discountTypeFormatted)</small> :
        </p>
        <p class="width-50 text-right">
          (-) $symbol $formattedDiscountAmount
        </p>
      </div>
    ''';
    }

    if (inlineDiscountAmount > 0) {
      String inlineDiscount = Helper().formatCurrency(inlineDiscountAmount);
      inlineDiscountHtml = '''
      <div class="flex-box">
        <p class="width-50 text-left">
          ${AppLocalizations.of(context).translate('inline_discount')} :
        </p>
        <p class="width-50 text-right">
          (-) $symbol $inlineDiscount
        </p>
      </div>
    ''';
    }

    if (shippingCharges >= 0.01) {
      shippingHtml = '''
      <div class="flex-box">
        <p class="width-50 text-left">
          ${AppLocalizations.of(context).translate('shipping_charges')} :
        </p>
        <p class="width-50 text-right">
          $symbol ${Helper().formatCurrency(shippingCharges)}
        </p>
      </div>
    ''';
    }

    if (tipAmount >= 0.01) {
      tipAmountHtml = '''
      <div class="flex-box">
        <p class="width-50 text-left">
          ${AppLocalizations.of(context).translate('tip_amount')} :
        </p>
        <p class="width-50 text-right">
          $symbol ${Helper().formatCurrency(tipAmount)}
        </p>
      </div>
    ''';
    }

    if (taxName != "taxRates") {
      taxHtml = '''
      <div class="flex-box">
        <p class="width-50 text-left">
          ${AppLocalizations.of(context).translate('tax')} ($taxName) :
        </p>
        <p class="width-50 text-right">
          (+) $symbol $taxAmount
        </p>
      </div>
    ''';
    }

    if (inlineTaxAmount > 0) {
      String inlineTax = Helper().formatCurrency(inlineTaxAmount);
      inlineTaxesHtml = '''
      <div class="flex-box">
        <p class="width-50 text-left">
          ${AppLocalizations.of(context).translate('inline_tax')} :
        </p>
        <p class="width-50 text-right">
          (+) $symbol $inlineTax
        </p>
      </div>
    ''';
    }

    if (dueAmount > 0) {
      String formattedDueAmount = Helper().formatCurrency(dueAmount);
      dueHtml = '''
      <div class="flex-box">
        <p class="width-50 text-left">
          ${AppLocalizations.of(context).translate('total')} ${AppLocalizations.of(context).translate('due')}
        </p>
        <p class="width-50 text-right">
          $symbol $formattedDueAmount
        </p>
      </div>
    ''';
    }

    String address = "$customerAddress1 $customerAddress2 $customerCity $customerState $customerCountry";
    String totalTax = (inlineTaxAmount + double.parse(taxAmount)).toStringAsFixed(2);
    String totalDiscount = (inlineDiscountAmount + discountAmount).toStringAsFixed(2);

    String invoice = '''
    <section class="invoice print_section" id="receipt_section">
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Receipt-$invoiceNo</title>
      <div class="ticket">
        <div class="text-box">
          <p class="centered">
            <span class="headings">$businessName</span><br>
            $landmark $city $state $zipCode $country $businessMobile<br>
            <b>$taxLabel</b> $taxNumber
          </p>
        </div>
        <div class="border-top textbox-info">
          <p class="f-left"><strong>${AppLocalizations.of(context).translate('invoice_no')}</strong> $invoiceNo</p>
        </div>
        <div class="textbox-info">
          <p class="f-left"><strong>${AppLocalizations.of(context).translate('date')}</strong> $date</p>
        </div>
        <div class="textbox-info">
          <p style="vertical-align: top;"><strong>${AppLocalizations.of(context).translate('customer')}</strong></p>
          <p>$customerName</p>
          <div class="bw">$customerAddress1 $customerAddress2 $customerCity $customerState $customerCountry<br>$customerMobile</div>
          <p></p>
        </div>
        <div class="bb-lg mb-10"></div>
        <table style="padding-top: 5px !important" class="border-bottom width-100 table-f-12 mb-10">
          <tbody>$products</tbody>
        </table>
        <div class="flex-box">
          <p class="left text-left"><strong>${AppLocalizations.of(context).translate('sub_total')}:</strong></p>
          <p class="width-50 text-right"><strong>$symbol ${Helper().formatCurrency(sTotal)}</strong></p>
        </div>
        $inlineDiscountHtml
        $discountHtml
        $inlineTaxesHtml
        $taxHtml
        $shippingHtml
        $tipAmountHtml
        <div class="flex-box">
          <p class="width-50 text-left"><strong>${AppLocalizations.of(context).translate('total')}:</strong></p>
          <p class="width-50 text-right"><strong>$symbol $formattedTotalAmount</strong></p>
        </div>
        $payments
        <div class="flex-box">
          <p class="width-50 text-left">${AppLocalizations.of(context).translate('total')} ${AppLocalizations.of(context).translate('paid')}</p>
          <p class="width-50 text-right">$symbol $formattedTotalReceived</p>
        </div>
        $dueHtml
        <div class="border-bottom width-100"></div>
      </div>
      <style type="text/css">
        @media print {
          * {
            font-size: 12px;
            font-family: 'Times New Roman';
            word-break: break-all;
          }
          .headings {
            font-size: 16px;
            font-weight: 700;
            text-transform: uppercase;
          }
          .sub-headings {
            font-size: 15px;
            font-weight: 700;
          }
          .border-top {
            border-top: 1px solid #242424;
          }
          .border-bottom {
            border-bottom: 1px solid #242424;
          }
          .border-bottom-dotted {
            border-bottom: 1px dotted darkgray;
          }
          .serial_number, th.serial_number {
            width: 5%;
            max-width: 5%;
          }
          .description, th.description {
            width: 35%;
            max-width: 35%;
            word-break: break-all;
          }
          .quantity, th.quantity {
            width: 15%;
            max-width: 15%;
            word-break: break-all;
          }
          .unit_price, th.unit_price {
            width: 25%;
            max-width: 25%;
            word-break: break-all;
          }
          .price, th.price {
            width: 20%;
            max-width: 20%;
            word-break: break-all;
          }
          .centered {
            text-align: center;
            align-content: center;
          }
          .ticket {
            width: 100%;
            max-width: 100%;
          }
          img {
            max-width: inherit;
            width: auto;
          }
          .hidden-print, .hidden-print * {
            display: none !important;
          }
        }
        .table-info {
          width: 100%;
        }
        .table-info tr:first-child td, .table-info tr:first-child th {
          padding-top: 8px;
        }
        .table-info th {
          text-align: left;
        }
        .table-info td {
          text-align: right;
        }
        .logo {
          float: left;
          width: 35%;
          padding: 10px;
        }
        .text-with-image {
          float: left;
          width: 65%;
        }
        .text-box {
          width: 100%;
          height: auto;
        }
        .m-0 {
          margin: 0;
        }
        .textbox-info {
          clear: both;
        }
        .textbox-info p {
          margin-bottom: 0px;
        }
        .flex-box {
          display: flex;
          width: 100%;
        }
        .flex-box p {
          width: 50%;
          margin-bottom: 0px;
          white-space: nowrap;
        }
        .table-f-12 th, .table-f-12 td {
          font-size: 12px;
          word-break: break-word;
        }
        .bw {
          word-break: break-word;
        }
        .bb-lg {
          border-bottom: 1px solid lightgray;
        }
      </style>
    </section>
  ''';
    return invoice;
  }
  // Future<String> generateInvoice(int sellId, int? taxId, BuildContext? context) async {
  //   if (context == null) {
  //     return '<p>Error: Context is required</p>';
  //   }
  //   String symbol = '';
  //   String businessName = '';
  //   String taxHtml = '';
  //   String inlineTaxesHtml = '';
  //   String inlineDiscountHtml = '';
  //   String discountHtml = '';
  //   String dueHtml = '';
  //   String shippingHtml = '';
  //   String taxLabel = '';
  //   String taxNumber = '';
  //   String tipAmountHtml = '';
  //
  //   await setTax(taxId);
  //   String products = await generateProductDetails(sellId, context);
  //   List sells = await SellDatabase().getSellBySellId(sellId);
  //   if (sells.isEmpty) {
  //     return '<p>Error: Sell not found</p>';
  //   }
  //   var sell = sells[0];
  //   var customer = await Contact().getCustomerDetailById(sell['contact_id']);
  //   String landmark = '', city = '', state = '', zipCode = '', country = '', businessMobile = '';
  //   List locations = await System().get('location');
  //   var location;
  //   for (var element in locations) {
  //     if (element['id'] == sell['location_id']) {
  //       location = element;
  //       landmark = (location['landmark'] != null) ? location['landmark'] + ',' : '';
  //       city = (location['city'] != null) ? location['city'] + ',' : '';
  //       state = (location['state'] != null) ? location['state'] + ',' : '';
  //       zipCode = (location['zip_code'] != null) ? location['zip_code'] + ',' : '';
  //       country = (location['country'] != null) ? location['country'] + ',' : '';
  //       businessMobile = (location['mobile'] != null) ? location['mobile'] + ',' : '';
  //     }
  //   }
  //   String invoiceNo = sell['invoice_no'] ?? 'Unknown';
  //   var dateTime = DateTime.parse(sell['transaction_date'] ?? DateTime.now().toString());
  //   var date = DateFormat("dd/MM/yyyy").format(dateTime);
  //   var discountType = sell['discount_type'] ?? 'fixed';
  //   var discountAmount = sell['discount_amount']?.toDouble() ?? 0.0;
  //   var tipAmount = sell['tip_amount']?.toDouble() ?? 0.0;
  //
  //   var businessDetails = await Helper().getFormattedBusinessDetails();
  //   symbol = businessDetails['symbol'] ?? '';
  //   businessName = businessDetails['name'] ?? '';
  //   taxLabel = businessDetails['taxLabel'] ?? '';
  //   taxNumber = businessDetails['taxNumber'] ?? '';
  //
  //   var customerName = customer['name'] ?? 'Unknown';
  //   var customerAddress1 = (customer['address_line_1'] != null) ? customer['address_line_1'] + ',' : '';
  //   var customerAddress2 = (customer['address_line_2'] != null) ? customer['address_line_2'] + ',' : '';
  //   var customerCity = (customer['city'] != null) ? customer['city'] + ',' : '';
  //   var customerState = (customer['state'] != null) ? customer['state'] + ',' : '';
  //   var customerCountry = (customer['country'] != null) ? customer['country'] : '';
  //   var customerMobile = customer['mobile'] ?? '';
  //
  //   List paymentList = await PaymentDatabase().get(sell['id'], allColumns: true);
  //   double totalPaidAmount = 0.0;
  //   String payments = '';
  //   for (var element in paymentList) {
  //     var sign = element['is_return'] == 0 ? '+' : '-';
  //     var paidAmount = element['amount']?.toDouble() ?? 0.0;
  //     totalPaidAmount += element['is_return'] == 0 ? paidAmount : -paidAmount;
  //     var method = element['method'] ?? 'Unknown';
  //     if (paidAmount > 0) {
  //       payments += '''
  //         <div class="flex-box">
  //           <p class="width-50 text-left">$method ($sign) ($date)</p>
  //           <p class="width-50 text-right">$symbol ${Helper().formatCurrency(paidAmount)}</p>
  //         </div>
  //       ''';
  //     }
  //   }
  //
  //   Map<String, dynamic> getAmounts = getTotalAmount(
  //     discountType: discountType,
  //     discountAmount: discountAmount,
  //     symbol: symbol,
  //   );
  //
  //   discountAmount = getAmounts['discountAmount'] ?? 0.0;
  //   discountType = getAmounts['discountType'] ?? 'fixed';
  //   String taxAmount = getAmounts['taxAmount'] ?? '0.00';
  //   String totalAmount = (double.parse(getAmounts['totalAmount']) + (sell['shipping_charges']?.toDouble() ?? 0.0) + tipAmount).toStringAsFixed(2);
  //
  //   String sTotal = subTotal.toStringAsFixed(2);
  //   double returnAmount = 0.0;
  //   double dueAmount = 0.0;
  //   if (totalPaidAmount > double.parse(totalAmount)) {
  //     returnAmount = totalPaidAmount - double.parse(totalAmount);
  //     totalPaidAmount = double.parse(totalAmount);
  //     dueAmount = 0.0;
  //   } else if (double.parse(totalAmount) > totalPaidAmount) {
  //     dueAmount = double.parse(totalAmount) - totalPaidAmount;
  //     returnAmount = 0.0;
  //   } else {
  //     dueAmount = 0.0;
  //     returnAmount = 0.0;
  //   }
  //   String formattedReturnAmount = Helper().formatCurrency(returnAmount);
  //   String formattedTotalAmount = Helper().formatCurrency(totalAmount);
  //   String formattedTotalReceived = Helper().formatCurrency(totalPaidAmount);
  //
  //   if (discountAmount > 0) {
  //     String formattedDiscountAmount = Helper().formatCurrency(discountAmount);
  //     discountHtml = '''
  //       <div class="flex-box">
  //         <p class="width-50 text-left">
  //           ${AppLocalizations.of(context).translate('discount')} <small>($discountType)</small> :
  //         </p>
  //         <p class="width-50 text-right">
  //           (-) $symbol $formattedDiscountAmount
  //         </p>
  //       </div>
  //     ''';
  //   }
  //
  //   if (inlineDiscountAmount > 0) {
  //     String inlineDiscount = Helper().formatCurrency(inlineDiscountAmount);
  //     inlineDiscountHtml = '''
  //       <div class="flex-box">
  //         <p class="width-50 text-left">
  //           ${AppLocalizations.of(context).translate('discount')} :
  //         </p>
  //         <p class="width-50 text-right">
  //           (-) $symbol $inlineDiscount
  //         </p>
  //       </div>
  //     ''';
  //   }
  //
  //   if (sell['shipping_charges']?.toDouble() ?? 0.0 >= 0.01) {
  //     shippingHtml = '''
  //       <div class="flex-box">
  //         <p class="width-50 text-left">
  //           ${AppLocalizations.of(context).translate('shipping_charges')} :
  //         </p>
  //         <p class="width-50 text-right">
  //           $symbol ${Helper().formatCurrency(sell['shipping_charges'])}
  //         </p>
  //       </div>
  //     ''';
  //   }
  //
  //   if (tipAmount >= 0.01) {
  //     tipAmountHtml = '''
  //       <div class="flex-box">
  //         <p class="width-50 text-left">
  //           ${AppLocalizations.of(context).translate('tip_amount')} :
  //         </p>
  //         <p class="width-50 text-right">
  //           $symbol ${Helper().formatCurrency(tipAmount)}
  //         </p>
  //       </div>
  //     ''';
  //   }
  //
  //   if (taxName != "taxRates") {
  //     taxHtml = '''
  //       <div class="flex-box">
  //         <p class="width-50 text-left">
  //           ${AppLocalizations.of(context).translate('tax')} ($taxName) :
  //         </p>
  //         <p class="width-50 text-right">
  //           (+) $symbol $taxAmount
  //         </p>
  //       </div>
  //     ''';
  //   }
  //
  //   if (inlineTaxAmount > 0) {
  //     String inlineTax = Helper().formatCurrency(inlineTaxAmount);
  //     inlineTaxesHtml = '''
  //       <div class="flex-box">
  //         <p class="width-50 text-left">
  //           ${AppLocalizations.of(context).translate('tax')} :
  //         </p>
  //         <p class="width-50 text-right">
  //           (+) $symbol $inlineTax
  //         </p>
  //       </div>
  //     ''';
  //   }
  //
  //   if (dueAmount > 0) {
  //     String formattedDueAmount = Helper().formatCurrency(dueAmount);
  //     dueHtml = '''
  //       <div class="flex-box">
  //         <p class="width-50 text-left">
  //           ${AppLocalizations.of(context).translate('total')} ${AppLocalizations.of(context).translate('due')}
  //         </p>
  //         <p class="width-50 text-right">
  //           $symbol $formattedDueAmount
  //         </p>
  //       </div>
  //     ''';
  //   }
  //
  //   String address = "$customerAddress1 $customerAddress2 $customerCity $customerState $customerCountry";
  //   String totalTax = (inlineTaxAmount + double.parse(taxAmount)).toStringAsFixed(2);
  //   String totalDiscount = (inlineDiscountAmount + discountAmount).toStringAsFixed(2);
  //
  //   String invoice = '''
  //     <section class="invoice print_section" id="receipt_section">
  //       <meta charset="UTF-8">
  //       <meta name="viewport" content="width=device-width, initial-scale=1.0">
  //       <meta http-equiv="X-UA-Compatible" content="ie=edge">
  //       <title>Receipt-$invoiceNo</title>
  //       <div class="ticket">
  //         <div class="text-box">
  //           <p class="centered">
  //             <span class="headings">$businessName</span><br>
  //             $landmark $city $state $zipCode $country $businessMobile<br>
  //             <b>$taxLabel</b> $taxNumber
  //           </p>
  //         </div>
  //         <div class="border-top textbox-info">
  //           <p class="f-left"><strong>${AppLocalizations.of(context).translate('invoice_no')}</strong> $invoiceNo</p>
  //         </div>
  //         <div class="textbox-info">
  //           <p class="f-left"><strong>${AppLocalizations.of(context).translate('date')}</strong> $date</p>
  //         </div>
  //         <div class="textbox-info">
  //           <p style="vertical-align: top;"><strong>${AppLocalizations.of(context).translate('customer')}</strong></p>
  //           <p>$customerName</p>
  //           <div class="bw">$customerAddress1 $customerAddress2 $customerCity $customerState $customerCountry<br>$customerMobile</div>
  //           <p></p>
  //         </div>
  //         <div class="bb-lg mb-10"></div>
  //         <table style="padding-top: 5px !important" class="border-bottom width-100 table-f-12 mb-10">
  //           <tbody>$products</tbody>
  //         </table>
  //         <div class="flex-box">
  //           <p class="left text-left"><strong>${AppLocalizations.of(context).translate('sub_total')}:</strong></p>
  //           <p class="width-50 text-right"><strong>$symbol ${Helper().formatCurrency(sTotal)}</strong></p>
  //         </div>
  //         $shippingHtml
  //         $tipAmountHtml
  //         $discountHtml
  //         $inlineDiscountHtml
  //         $taxHtml
  //         $inlineTaxesHtml
  //         <div class="flex-box">
  //           <p class="width-50 text-left"><strong>${AppLocalizations.of(context).translate('total')}:</strong></p>
  //           <p class="width-50 text-right"><strong>$symbol $formattedTotalAmount</strong></p>
  //         </div>
  //         $payments
  //         <div class="flex-box">
  //           <p class="width-50 text-left">${AppLocalizations.of(context).translate('total')} ${AppLocalizations.of(context).translate('paid')}</p>
  //           <p class="width-50 text-right">$symbol $formattedTotalReceived</p>
  //         </div>
  //         $dueHtml
  //         <div class="border-bottom width-100"></div>
  //       </div>
  //       <style type="text/css">
  //         @media print {
  //           * {
  //             font-size: 12px;
  //             font-family: 'Times New Roman';
  //             word-break: break-all;
  //           }
  //           .headings {
  //             font-size: 16px;
  //             font-weight: 700;
  //             text-transform: uppercase;
  //           }
  //           .sub-headings {
  //             font-size: 15px;
  //             font-weight: 700;
  //           }
  //           .border-top {
  //             border-top: 1px solid #242424;
  //           }
  //           .border-bottom {
  //             border-bottom: 1px solid #242424;
  //           }
  //           .border-bottom-dotted {
  //             border-bottom: 1px dotted darkgray;
  //           }
  //           .serial_number, th.serial_number {
  //             width: 5%;
  //             max-width: 5%;
  //           }
  //           .description, th.description {
  //             width: 35%;
  //             max-width: 35%;
  //             word-break: break-all;
  //           }
  //           .quantity, th.quantity {
  //             width: 15%;
  //             max-width: 15%;
  //             word-break: break-all;
  //           }
  //           .unit_price, th.unit_price {
  //             width: 25%;
  //             max-width: 25%;
  //             word-break: break-all;
  //           }
  //           .price, th.price {
  //             width: 20%;
  //             max-width: 20%;
  //             word-break: break-all;
  //           }
  //           .centered {
  //             text-align: center;
  //             align-content: center;
  //           }
  //           .ticket {
  //             width: 100%;
  //             max-width: 100%;
  //           }
  //           img {
  //             max-width: inherit;
  //             width: auto;
  //           }
  //           .hidden-print, .hidden-print * {
  //             display: none !important;
  //           }
  //         }
  //         .table-info {
  //           width: 100%;
  //         }
  //         .table-info tr:first-child td, .table-info tr:first-child th {
  //           padding-top: 8px;
  //         }
  //         .table-info th {
  //           text-align: left;
  //         }
  //         .table-info td {
  //           text-align: right;
  //         }
  //         .logo {
  //           float: left;
  //           width: 35%;
  //           padding: 10px;
  //         }
  //         .text-with-image {
  //           float: left;
  //           width: 65%;
  //         }
  //         .text-box {
  //           width: 100%;
  //           height: auto;
  //         }
  //         .m-0 {
  //           margin: 0;
  //         }
  //         .textbox-info {
  //           clear: both;
  //         }
  //         .textbox-info p {
  //           margin-bottom: 0px;
  //         }
  //         .flex-box {
  //           display: flex;
  //           width: 100%;
  //         }
  //         .flex-box p {
  //           width: 50%;
  //           margin-bottom: 0px;
  //           white-space: nowrap;
  //         }
  //         .table-f-12 th, .table-f-12 td {
  //           font-size: 12px;
  //           word-break: break-word;
  //         }
  //         .bw {
  //           word-break: break-word;
  //         }
  //         .bb-lg {
  //           border-bottom: 1px solid lightgray;
  //         }
  //       </style>
  //     </section>
  //   ''';
  //   return invoice;
  // }
}