// import 'dart:convert';
//
// import '../apis/sell.dart';
// import '../models/paymentDatabase.dart';
// import '../models/sellDatabase.dart';
// import '../models/system.dart';
//
// class Sell {
//   // Sync sell
//   Future<dynamic> createApiSell({int? sellId, bool? syncAll, Map<String, dynamic>? payload}) async {
//     if (payload != null) {
//       // Use the provided payload for the API call
//       print('Using provided payload for API call: ${jsonEncode(payload)}');
//       var result = await SellApi().create(payload);
//       print('API call result with payload: $result');
//       return result;
//     }
//
//     // Existing logic for syncing from database
//     List sales;
//     if (syncAll != null && syncAll) {
//       sales = await SellDatabase().getNotSyncedSells();
//     } else if (sellId != null) {
//       sales = await SellDatabase().getSellBySellId(sellId);
//     } else {
//       print('Error: Either sellId or syncAll must be provided when payload is null');
//       return false;
//     }
//     print('Sales to sync: ${jsonEncode(sales)}');
//
//     for (var element in sales) {
//       List products = await SellDatabase().getSellLines(element['id']);
//       List payments = await PaymentDatabase().get(element['id']);
//
//       // Add product_order_category to products
//       for (var product in products) {
//         product['product_order_category'] = product['product_order_category'] ?? 'BAR';
//       }
//       // Add received_amount and change_return to payments
//       for (var payment in payments) {
//         payment['received_amount'] = payment['received_amount'] ?? null;
//         payment['change_return'] = payment['change_return'] ?? null;
//       }
//
//       // Model map for creating new sell
//       Map<String, dynamic> sale = {
//         'location_id': element['location_id'],
//         'contact_id': element['contact_id'],
//         'transaction_date': element['transaction_date'],
//         'invoice_no': element['invoice_no'],
//         'status': element['status'],
//         'sub_status': (element['is_quotation'].toString() == '1') ? 'quotation' : null,
//         'tax_rate_id': (element['tax_rate_id'] == 0) ? null : element['tax_rate_id'],
//         'discount_amount': element['discount_amount'],
//         'discount_type': element['discount_type'],
//         'change_return': element['change_return'],
//         'products': products,
//         'sale_note': element['sale_note'],
//         'staff_note': element['staff_note'],
//         'shipping_charges': element['shipping_charges'],
//         'shipping_details': element['shipping_details'],
//         'tip_amount': element['tip_amount']?.toString() ?? '0.00',
//         'tip_type': element['tip_type'] ?? 'fixed',
//         'is_quotation': element['is_quotation'],
//         'payments': payments,
//       };
//
//       print('Prepared Sale Data: ${jsonEncode(sale)}');
//
//       // Fetch paymentLine where is_return = 1
//       List paymentDetail = await PaymentDatabase().getPaymentLineByReturnValue(element['id'], 1);
//       var returnId = paymentDetail.isNotEmpty ? paymentDetail[0]['payment_id'] : null;
//
//       // Model map for updating an existing sell
//       Map<String, dynamic> editedSale = {
//         'contact_id': element['contact_id'],
//         'transaction_date': element['transaction_date'],
//         'status': element['status'],
//         'tax_rate_id': (element['tax_rate_id'] == 0) ? null : element['tax_rate_id'],
//         'discount_amount': element['discount_amount'],
//         'discount_type': element['discount_type'],
//         'sale_note': element['sale_note'],
//         'staff_note': element['staff_note'],
//         'shipping_charges': element['shipping_charges'],
//         'shipping_details': element['shipping_details'],
//         'tip_amount': element['tip_amount']?.toString() ?? '0.00',
//         'tip_type': element['tip_type'] ?? 'fixed',
//         'is_quotation': element['is_quotation'],
//         'change_return': element['change_return'],
//         'change_return_id': returnId,
//         'products': products,
//         'payments': payments,
//       };
//
//       if (element['is_synced'] == 0) {
//         if (element['transaction_id'] != null) {
//           print('Updating existing sell: ${element['transaction_id']}');
//           Map<String, dynamic>? updatedResult = await SellApi().update(element['transaction_id'], editedSale);
//           if (updatedResult != null) {
//             var result = updatedResult['payment_lines'];
//             if (result != null) {
//               await SellDatabase().updateSells(element['id'], {
//                 'is_synced': 1,
//                 'invoice_url': updatedResult['invoice_url'],
//                 'tip_type': updatedResult['tip_type'] ?? 'fixed',
//               });
//               // Delete existing payment lines
//               await PaymentDatabase().delete(element['id']);
//               for (var paymentLine in result) {
//                 await PaymentDatabase().store({
//                   'sell_id': element['id'],
//                   'method': paymentLine['method'],
//                   'amount': paymentLine['amount'],
//                   'note': paymentLine['note'],
//                   'payment_id': paymentLine['id'],
//                   'is_return': paymentLine['is_return'],
//                   'account_id': paymentLine['account_id'],
//                   'received_amount': paymentLine['received_amount'],
//                   'change_return': paymentLine['change_return'],
//                 });
//               }
//             }
//           } else {
//             print('Failed to update sell: ${element['transaction_id']}');
//           }
//         } else {
//           print('Creating new sell: ${element['invoice_no']}');
//           var sellPayload = {'sells': [sale]};
//           var result = await SellApi().create(sellPayload);
//           if (result != null) {
//             await SellDatabase().updateSells(element['id'], {
//               'is_synced': 1,
//               'transaction_id': result['transaction_id'],
//               'invoice_url': result['invoice_url'],
//               'tip_type': result['tip_type'] ?? 'fixed',
//             });
//             if (result['payment_lines'] != null) {
//               await PaymentDatabase().delete(element['id']);
//               for (var paymentLine in result['payment_lines']) {
//                 await PaymentDatabase().store({
//                   'sell_id': element['id'],
//                   'method': paymentLine['method'],
//                   'amount': paymentLine['amount'],
//                   'note': paymentLine['note'],
//                   'payment_id': paymentLine['id'],
//                   'is_return': paymentLine['is_return'],
//                   'account_id': paymentLine['account_id'],
//                   'received_amount': paymentLine['received_amount'],
//                   'change_return': paymentLine['change_return'],
//                 });
//               }
//             }
//             return result; // Return the result for the new sell
//           } else {
//             print('Failed to create sell: ${element['invoice_no']}');
//           }
//         }
//       }
//     }
//     return true;
//   }
//
//   // ToMap for creating payment
//   Future<void> makePayment(List payments, int sellId) async {
//     for (var element in payments) {
//       Map<String, dynamic> payment = {
//         'sell_id': sellId,
//         'method': element['method'],
//         'amount': element['amount'],
//         'note': element['note'],
//         'account_id': element['account_id'],
//         'received_amount': element['received_amount'],
//         'change_return': element['change_return'],
//       };
//       await PaymentDatabase().store(payment);
//     }
//   }
//
//   // ToMap create sell
//   Future<Map<String, dynamic>> createSell({
//     String? invoiceNo,
//     String? transactionDate,
//     int? contactId,
//     int? locId,
//     int? taxId,
//     String? discountType,
//     double? discountAmount,
//     double? invoiceAmount,
//     double? changeReturn,
//     double? pending,
//     String? saleNote,
//     String? staffNote,
//     double? shippingCharges,
//     String? shippingDetails,
//     required double tip_amount,
//     String? tip_type,
//     String? saleStatus,
//     int? isQuotation,
//     int? sellId,
//   }) async {
//     Map<String, dynamic> sale;
//     if (sellId == null) {
//       sale = {
//         'transaction_date': transactionDate,
//         'invoice_no': invoiceNo,
//         'contact_id': contactId,
//         'location_id': locId,
//         'status': saleStatus,
//         'tax_rate_id': taxId,
//         'discount_amount': discountAmount ?? 0.00,
//         'discount_type': discountType,
//         'invoice_amount': invoiceAmount,
//         'change_return': changeReturn,
//         'sale_note': saleNote,
//         'staff_note': staffNote,
//         'shipping_charges': shippingCharges,
//         'shipping_details': shippingDetails,
//         'tip_amount': tip_amount,
//         'tip_type': tip_type ?? 'fixed',
//         'is_quotation': isQuotation ?? 0,
//         'is_synced': 0,
//       };
//     } else {
//       sale = {
//         'contact_id': contactId,
//         'transaction_date': transactionDate,
//         'location_id': locId,
//         'status': saleStatus,
//         'tax_rate_id': taxId,
//         'discount_amount': discountAmount ?? 0.00,
//         'discount_type': discountType,
//         'invoice_amount': invoiceAmount,
//         'change_return': changeReturn,
//         'sale_note': saleNote,
//         'staff_note': staffNote,
//         'shipping_charges': shippingCharges,
//         'shipping_details': shippingDetails,
//         'tip_amount': tip_amount,
//         'tip_type': tip_type ?? 'fixed',
//         'pending_amount': pending,
//         'is_quotation': isQuotation ?? 0,
//         'is_synced': 0,
//       };
//     }
//     print('Created Sell Map: ${jsonEncode(sale)}');
//     return sale;
//   }
//
//   // Get unit_price
//   Future<double> getUnitPrice(double unitPrice, int? taxId) async {
//     double price = 0.00;
//     await System().get('tax').then((value) {
//       for (var element in value) {
//         if (element['id'] == taxId) {
//           price = (unitPrice * 100) / (double.parse(element['amount'].toString()) + 100);
//         }
//       }
//     });
//     return price;
//   }
//
//   // ToMap create sellLine
//   Future<void> addToCart(Map product, int? sellId) async {
//     // Convert product to create sellLine
//     double price = (product['tax_rate_id'] != 0 && product['tax_rate_id'] != null)
//         ? await getUnitPrice(double.parse(product['unit_price'].toString()), product['tax_rate_id'])
//         : product['unit_price'];
//     var sellLine = {
//       'sell_id': sellId,
//       'product_id': product['product_id'],
//       'variation_id': product['variation_id'],
//       'quantity': 1,
//       'unit_price': price,
//       'tax_rate_id': (product['tax_rate_id'] == 0) ? null : product['tax_rate_id'],
//       'discount_amount': 0.00,
//       'discount_type': 'fixed',
//       'note': '',
//       'is_completed': 0,
//       'product_order_category': product['product_order_category'] ?? 'BAR',
//     };
//
//     // Check if item is added to cart/not
//     List checkSellLine = await SellDatabase().checkSellLine(sellLine['variation_id'], sellId: sellId);
//     // If added, increase quantity; else add to cart
//     if (checkSellLine.isNotEmpty) {
//       // Update in database
//       // var quantity = checkSellLine[0]['quantity'] + 1;
//       // await SellDatabase().update(checkSellLine[0]['id'], {'quantity': quantity});
//     } else {
//       // Insert in database
//       await SellDatabase().store(sellLine);
//     }
//   }
//
//   // Reset cart
//   Future<void> resetCart() async {
//     await SellDatabase().deleteInComplete();
//   }
//
//   // Cart item count
//   Future<String> cartItemCount({int? isCompleted, int? sellId}) async {
//     return await SellDatabase().countSellLines(isCompleted: isCompleted, sellId: sellId);
//   }
//
//   // Add this method to the Sell class from product.dart
//   Future<List<Map>> getCartItems(int? sellId) async {
//     if (sellId == null) return [];
//     List<Map> cartItems = await SellDatabase().getSellLineBySellId(sellId);
//     return cartItems.map((item) {
//       return {
//         'product_id': item['product_id'],
//         'variation_id': item['variation_id'],
//         'quantity': item['quantity'],
//         'unit_price': item['unit_price'],
//         'tax_rate_id': item['tax_rate_id'],
//         'discount_amount': item['discount_amount'] ?? 0.0,
//         'discount_type': item['discount_type'] ?? 'fixed',
//         'note': item['note'] ?? '',
//         'product_order_category': item['product_order_category'] ?? 'BAR',
//       };
//     }).toList();
//   }
//
//   // Refresh sale
//   Map<String, dynamic> createSellMap(Map sell, double change, double pending) {
//     Map<String, dynamic> sale = {
//       'transaction_date': sell['transaction_date'],
//       'invoice_no': sell['invoice_no'],
//       'contact_id': sell['contact_id'],
//       'location_id': sell['location_id'],
//       'status': sell['status'],
//       'tax_rate_id': (sell['tax_id'] != 0) ? sell['tax_id'] : null,
//       'discount_amount': (sell['discount_amount'] != null) ? sell['discount_amount'] : 0.00,
//       'discount_type': sell['discount_type'],
//       'invoice_amount': sell['final_total'],
//       'change_return': change,
//       'sale_note': sell['additional_notes'],
//       'staff_note': sell['staff_note'],
//       'shipping_charges': double.parse(sell['shipping_charges'].toString()),
//       'shipping_details': sell['shipping_details'],
//       'tip_amount': double.parse(sell['tip_amount'].toString()),
//       'tip_type': sell['tip_type'] ?? 'fixed',
//       'pending_amount': pending,
//       'is_synced': 1,
//     };
//     return sale;
//   }
//
// }


import 'dart:convert';

import 'package:dev/helpers/otherHelpers.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path/path.dart';

import '../apis/sell.dart';
import '../helpers/TableAvailabilityManager.dart';
import '../helpers/FirebaseTableLockService.dart';
import '../locale/MyLocalizations.dart';
import '../pages/event_bus.dart';
import '../models/paymentDatabase.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';

class Sell {
  Future<dynamic> createApiSell({int? sellId, int? res_table_id, bool? syncAll, Map<String, dynamic>? payload, required bool isDraft, required bool isQuotation}) async {
    try {
      bool allSynced = true;

      if (payload != null) {
        // FIXED: Check for existing transaction_id before creating new record
        // This prevents duplicate creation when editing existing quotations/drafts
        String? transactionId;

        if (sellId != null) {
          // Check if this sell already has a transaction_id in the database
          var existingSell = await SellDatabase().getSellBySellId(sellId);
          if (existingSell.isNotEmpty && existingSell[0]['transaction_id'] != null) {
            // Handle both int and String types for transaction_id
            var tid = existingSell[0]['transaction_id'];
            if (tid is int) {
              transactionId = tid.toString();
            } else if (tid is String) {
              transactionId = tid;
            } else {
              transactionId = tid?.toString();
            }
            print('createApiSell: Found existing transaction_id: $transactionId for sellId: $sellId');
          }
        }

        // Create mutable copy of payload
        final mutablePayload = Map<String, dynamic>.from(payload);

        // Get the first sell from payload
        List<Map<String, dynamic>> sells = List<Map<String, dynamic>>.from(mutablePayload['sells']);
        if (sells.isEmpty) {
          print('createApiSell: Error - payload contains no sells');
          return {'error': 'Payload contains no sells'};
        }

        final sellData = Map<String, dynamic>.from(sells[0]);

        // Serialize card_details in payments
        if (sellData['payments'] != null && sellData['payments'] is List) {
          List<Map<String, dynamic>> payments = List<Map<String, dynamic>>.from(sellData['payments']);
          for (var payment in payments) {
            if (payment['card_details'] != null && payment['card_details'] is Map) {
              payment['card_details'] = jsonEncode(payment['card_details']);
            }
          }
          sellData['payments'] = payments;
        }

        // If transaction_id exists, use UPDATE instead of CREATE
        if (transactionId != null && transactionId.isNotEmpty) {
          print('createApiSell: Updating existing transaction $transactionId with payload data');

          // Format payload for update (single sell object, not array)
          Map<String, dynamic> updatePayload = Map<String, dynamic>.from(sellData);

          // Ensure string fields are strings (not Maps)
          String _ensureString(dynamic value, {String defaultValue = ''}) {
            if (value == null) return defaultValue;
            if (value is String) return value;
            if (value is Map) return jsonEncode(value);
            return value.toString();
          }

          updatePayload['sale_note'] = _ensureString(sellData['sale_note']);
          updatePayload['staff_note'] = _ensureString(sellData['staff_note']);
          updatePayload['shipping_details'] = _ensureString(sellData['shipping_details']);
          updatePayload['transaction_date'] = _ensureString(sellData['transaction_date']);
          updatePayload['status'] = _ensureString(sellData['status']);
          updatePayload['discount_type'] = _ensureString(sellData['discount_type']);
          updatePayload['tip_type'] = _ensureString(sellData['tip_type'] ?? 'fixed');
          updatePayload['order_note'] = _ensureString(sellData['order_note'] ?? sellData['sale_note']);

          // Ensure tip_amount is a string
          updatePayload['tip_amount'] = sellData['tip_amount']?.toString() ?? '0.00';

          var result = await SellApi().update(transactionId, updatePayload);
          print('createApiSell: Update API call result: $result');

          // Update local database with sync status
          if (sellId != null && result != null && !result.containsKey('error')) {
            await SellDatabase().updateSells(sellId, {
              'is_synced': 1,
              'invoice_url': result['invoice_url'],
              'tip_type': result['tip_type'] ?? 'fixed',
            });
          }

          return result;
        } else {
          // No transaction_id found, create new record
          print('createApiSell: No existing transaction_id found, creating new record');

          for (var sell in sells) {
            final mutableSell = Map<String, dynamic>.from(sell);

            for (var payment in List<Map<String, dynamic>>.from(mutableSell['payments'] ?? [])) {
              if (payment['card_details'] != null) {
                final mutablePayment = Map<String, dynamic>.from(payment);
                mutablePayment['card_details'] = jsonEncode(mutablePayment['card_details']);
                payment = mutablePayment;
              }
            }
            sell = mutableSell;
          }

          print('createApiSell: Using provided payload for CREATE API call: ${jsonEncode(mutablePayload)}');
          var result = await SellApi().create(mutablePayload);
          print('createApiSell: CREATE API call result: $result');

          // Update local database with transaction_id if created successfully
          if (sellId != null && result != null && result['transaction_id'] != null) {
            await SellDatabase().updateSells(sellId, {
              'is_synced': 1,
              'transaction_id': result['transaction_id'].toString(),
              'invoice_url': result['invoice_url'],
              'tip_type': result['tip_type'] ?? 'fixed',
            });
          }

          return result;
        }
      }

      List sales;
      if (syncAll != null && syncAll) {
        sales = await SellDatabase().getNotSyncedSells();
      } else if (sellId != null) {
        sales = await SellDatabase().getSellBySellId(sellId);
      } else if (res_table_id != null) {
        sales = await SellDatabase().getSellsByTableId(res_table_id);
      } else {
        print('Error: Either sellId or syncAll must be provided when payload is null');
        return false;
      }

      // Convert to mutable maps
      final mutableSales = sales.map((s) => Map<String, dynamic>.from(s)).toList();
      print('Sales to sync: ${jsonEncode(mutableSales)}');

      for (var element in mutableSales) {
        // Get mutable copies of products and payments
        List<Map<String, dynamic>> products = (await SellDatabase().getSellLines(element['id'], res_table_id: element['res_table_id']))
            .map((p) => Map<String, dynamic>.from(p)).toList();

        List<Map<String, dynamic>> payments = (await PaymentDatabase().get(element['id'], res_table_id: element['res_table_id']))
            .map((p) => Map<String, dynamic>.from(p)).toList();

        // Process products and payments
        for (var product in products) {
          product['product_order_category'] = product['product_order_category'] ?? 'BAR';
        }

        for (var payment in payments) {
          payment['received_amount'] = payment['received_amount'];
          payment['change_return'] = payment['change_return'];
          if (payment['card_details'] != null) {
            payment['card_details'] = jsonEncode(payment['card_details']);
          }
        }

        Map<String, dynamic> sale = {
          'location_id': element['location_id'],
          'contact_id': element['contact_id'],
          'transaction_date': element['transaction_date'],
          'invoice_no': element['invoice_no'],
          'status': element['status'],
          'sub_status': (element['is_quotation'].toString() == '1') ? 'quotation' : null,
          'tax_rate_id': (element['tax_rate_id'] == 0) ? null : element['tax_rate_id'],
          'discount_amount': element['discount_amount'],
          'discount_type': element['discount_type'],
          'change_return': element['change_return'],
          'products': products,
          'sale_note': element['sale_note'],
          'staff_note': element['staff_note'],
          'shipping_charges': element['shipping_charges'],
          'shipping_details': element['shipping_details'],
          'tip_amount': element['tip_amount']?.toString() ?? '0.00',
          'tip_type': element['tip_type'] ?? 'fixed',
          'is_quotation': element['is_quotation'],
          'payments': payments,
          'res_table_id': element['res_table_id'],
          'is_shipping': element['is_shipping'],
        };

        print('Prepared Sale Data: ${jsonEncode(sale)}');

        // Fetch paymentLine where is_return = 1
        List paymentDetail = await PaymentDatabase().getPaymentLineByReturnValue(element['id'], 1);
        var returnId = paymentDetail.isNotEmpty ? paymentDetail[0]['payment_id'] : null;

        // Model map for updating an existing sell
        Map<String, dynamic> editedSale = {
          'contact_id': element['contact_id'],
          'transaction_date': element['transaction_date'],
          'status': element['status'],
          'tax_rate_id': (element['tax_rate_id'] == 0) ? null : element['tax_rate_id'],
          'discount_amount': element['discount_amount'],
          'discount_type': element['discount_type'],
          'sale_note': element['sale_note'],
          'staff_note': element['staff_note'],
          'shipping_charges': element['shipping_charges'],
          'shipping_details': element['shipping_details'],
          'tip_amount': element['tip_amount']?.toString() ?? '0.00',
          'tip_type': element['tip_type'] ?? 'fixed',
          'is_quotation': element['is_quotation'],
          'change_return': element['change_return'],
          'change_return_id': returnId,
          'products': products,
          'payments': payments,
        };

        if (element['is_synced'] == 0) {
          if (element['transaction_id'] != null) {
            print('Updating existing sell: ${element['transaction_id']}');
            Map<String, dynamic>? updatedResult = await SellApi().update(element['transaction_id'], editedSale);
            if (updatedResult != null) {
              var result = updatedResult['payment_lines'];
              if (result != null) {
                await SellDatabase().updateSells(element['id'], {
                  'is_synced': 1,
                  'invoice_url': updatedResult['invoice_url'],
                  'tip_type': updatedResult['tip_type'] ?? 'fixed',
                });
                // Delete existing payment lines
                await PaymentDatabase().delete(element['id']);
                for (var paymentLine in result) {
                  await PaymentDatabase().store({
                    'sell_id': element['id'],
                    'method': paymentLine['method'],
                    'amount': paymentLine['amount'],
                    'note': paymentLine['note'],
                    'payment_id': paymentLine['id'],
                    'is_return': paymentLine['is_return'],
                    'account_id': paymentLine['account_id'],
                    'received_amount': paymentLine['received_amount'],
                    'change_return': paymentLine['change_return'],
                  });
                }
              }
            } else {
              print('Failed to update sell: ${element['transaction_id']}');
            }
          } else {
            print('Creating new sell: ${element['invoice_no']}');
            var sellPayload = {'sells': [sale]};
            var result = await SellApi().create(sellPayload);
            if (result != null) {
              await SellDatabase().updateSells(element['id'], {
                'is_synced': 1,
                'transaction_id': result['transaction_id'],
                'invoice_url': result['invoice_url'],
                'tip_type': result['tip_type'] ?? 'fixed',
              });
              if (result['payment_lines'] != null) {
                await PaymentDatabase().delete(element['id']);
                for (var paymentLine in result['payment_lines']) {
                  await PaymentDatabase().store({
                    'sell_id': element['id'],
                    'method': paymentLine['method'],
                    'amount': paymentLine['amount'],
                    'note': paymentLine['note'],
                    'payment_id': paymentLine['id'],
                    'is_return': paymentLine['is_return'],
                    'account_id': paymentLine['account_id'],
                    'received_amount': paymentLine['received_amount'],
                    'change_return': paymentLine['change_return'],
                  });
                }
              }
              return result; // Return the result for the new sell
            } else {
              print('Failed to create sell: ${element['invoice_no']}');
            }
          }
        }
      }
      return true;
    } catch (e, stackTrace) {
      debugPrint('Error in createApiSell: $e');
      debugPrint('Stack trace: $stackTrace');
      rethrow;
    }
  }



  Future<void> makePayment(List payments, int sellId, int? res_table_id) async {
    if (sellId == null && res_table_id != null) {
      // Find the most recent sale for res_table_id
      List sales = await SellDatabase().getSellsByTableId(res_table_id);
      if (sales.isEmpty) {
        throw Exception('No sale found for res_table_id: $res_table_id');
      }
      if (sales.length > 1) {
        print('Warning: Multiple sales found for res_table_id: $res_table_id. Using most recent.');
      }
      sellId = sales.first['id']; // Use the most recent sale
    }
    if (sellId == null) {
      throw Exception('sellId or res_table_id must be provided');
    }

    for (var element in payments) {
      Map<String, dynamic> payment = {
        'sell_id': sellId,
        'method': element['method'],
        'amount': element['amount'],
        'note': element['note'],
        'account_id': element['account_id'],
        'received_amount': element['received_amount'],
        'change_return': element['change_return'],
        'card_details': element['card_details'] != null
            ? jsonEncode(element['card_details'])
            : null,
      };
      await PaymentDatabase().store(payment);
    }
  }

  Future<Map<String, dynamic>> createSell({
    String? invoiceNo,
    String? transactionDate,
    int? contactId,
    int? locId,
    int? taxId,
    String? discountType,
    double? discountAmount,
    double? invoiceAmount,
    double? changeReturn,
    double? pending,
    String? saleNote,
    String? staffNote,
    double? shippingCharges,
    String? shippingDetails,
    required double tip_amount,
    String? tip_type,
    String? saleStatus,
    int? isQuotation,
    int? sellId,
    int? is_synced,

    int? res_table_id,
    int? is_shipping,
  }) async {
    Map<String, dynamic> sale;
    if (sellId == null) {
      sale = {
        'transaction_date': transactionDate,
        'invoice_no': invoiceNo,
        'contact_id': contactId,
        'location_id': locId,
        //'status': saleStatus,
        'sale_status': saleStatus,
        'tax_rate_id': taxId,
        'discount_amount': discountAmount ?? 0.00,
        'discount_type': discountType,
        'invoice_amount': invoiceAmount,
        'change_return': changeReturn,
        'sale_note': saleNote,
        'staff_note': staffNote,
        'shipping_charges': shippingCharges,
        'shipping_details': shippingDetails,
        'tip_amount': tip_amount,
        'tip_type': tip_type ?? 'fixed',
        'is_quotation': isQuotation ?? 0,
        'is_synced': is_synced ?? 0,

        'res_table_id': res_table_id,
        'is_shipping': is_shipping ?? 0,
      };
    }
    else {
      sale = {
        'contact_id': contactId,
        'transaction_date': transactionDate,
        'location_id': locId,
        // 'status': saleStatus,
        'sale_status': saleStatus,

        'tax_rate_id': taxId,
        'discount_amount': discountAmount ?? 0.00,
        'discount_type': discountType,
        'invoice_amount': invoiceAmount,
        'change_return': changeReturn,
        'sale_note': saleNote,
        'staff_note': staffNote,
        'shipping_charges': shippingCharges,
        'shipping_details': shippingDetails,
        'tip_amount': tip_amount,
        'tip_type': tip_type ?? 'fixed',
        'pending_amount': pending,
        'is_quotation': isQuotation ?? 0,
        'is_synced': is_synced ?? 0,

        'res_table_id': res_table_id,
        'is_shipping': is_shipping ?? 0,
      };
    }
    print('Created Sell Map: ${jsonEncode(sale)}');
    return sale;
  }

  Future<double> getUnitPrice(double unitPrice, int? taxId) async {
    double price = 0.00;
    await System().get('tax').then((value) {
      for (var element in value) {
        if (element['id'] == taxId) {
          price = (unitPrice * 100) / (double.parse(element['amount'].toString()) + 100);
        }
      }
    });
    return price;
  }

//   Future<void> addToCart(Map product, int? sellId ,  int? res_table_id) async {
//     if (sellId == null) {
//       print('addToCart: sellId is null, cannot add to cart');
//       await Sell().cleanupOldDrafts(keepSellId: sellId);
//       return;
//     }
//     debugPrint('Sell.addToCart: Adding product ${product['display_name']} with sellId $sellId');          // here changes add
//     double price = (product['tax_rate_id'] != 0 && product['tax_rate_id'] != null)
//         ? await getUnitPrice(double.parse(product['unit_price'].toString()), product['tax_rate_id'])
//         : product['unit_price'];
//     var sellLine = {
//       'sell_id': sellId,
//       'product_id': product['product_id'],
//       'variation_id': product['variation_id'],
//       'quantity': 1,
//       'unit_price': price,
//       'tax_rate_id': (product['tax_rate_id'] == 0) ? null : product['tax_rate_id'],
//       'discount_amount': 0.00,
//       'discount_type': 'fixed',
//       'note': '',
//       'is_completed': 0,
//       'product_order_category': product['product_order_category'] ?? 'BAR',
//     };
//
//     List checkSellLine = await SellDatabase().checkSellLine(sellLine['variation_id'], sellId: sellId);
//     if (checkSellLine.isNotEmpty) {
// // Update quantity logic can be added here if needed
//       print('addToCart: Product already in cart for sellId: $sellId, variation_id: ${sellLine['variation_id']}');
//     } else {
//       await SellDatabase().store(sellLine);
//       print('addToCart: Added product to cart for sellId: $sellId, variation_id: ${sellLine['variation_id']}');
//     }
//   }
//   Future<void> addToCart(Map product, int? sellId, int? res_table_id) async {
//     if (sellId == null && res_table_id != null) {
//       // Find or create a sale for res_table_id
//       List sales = await SellDatabase().getSellsByTableId(res_table_id);
//       if (sales.isEmpty) {
//         // Create a new draft sale
//         sellId = await createSellDraft(
//           discountAmount: 0.0,
//           discountType: 'fixed',
//           locId: 0,
//           taxId: null,
//           res_table_id: res_table_id,
//           is_shipping: 0,
//         );
//       } else {
//         if (sales.length > 1) {
//           print('Warning: Multiple sales found for res_table_id: $res_table_id. Using most recent.');
//         }
//         sellId = sales.first['id']; // Use the most recent sale
//       }
//     }
//     if (sellId == null) {
//       print('addToCart: sellId and res_table_id are null, cannot add to cart');
//       await Sell().cleanupOldDrafts(keepSellId: sellId);
//       return;
//     }
//
//     // First check if product already exists in cart    //new added
//     List<Map> existingItems = await SellDatabase().getSellLineBySellId(sellId, res_table_id: res_table_id);
//     bool productExists = existingItems.any((item) =>
//     item['product_id'] == product['product_id'] &&
//         item['variation_id'] == product['variation_id']);
//
//     if (productExists) {
//       throw Exception('Product already added to cart');
//     }
//
//     debugPrint('Sell.addToCart: Adding product ${product['display_name']} with sellId $sellId, res_table_id $res_table_id');
//
//     double price = (product['tax_rate_id'] != 0 && product['tax_rate_id'] != null)
//         ? await getUnitPrice(double.parse(product['unit_price'].toString()), product['tax_rate_id'])
//         : product['unit_price'];
//     var sellLine = {
//       'sell_id': sellId,
//       'product_id': product['product_id'],
//       'variation_id': product['variation_id'],
//       'quantity': 1,
//       'unit_price': price,
//       'tax_rate_id': (product['tax_rate_id'] == 0) ? null : product['tax_rate_id'],
//       'discount_amount': 0.00,
//       'discount_type': 'fixed',
//       'note': '',
//       'is_completed': 0,
//       'product_order_category': product['product_order_category'] ?? 'BAR',
//       'res_table_id': res_table_id, // Added to store res_table_id
//     };
//
//     List checkSellLine = await SellDatabase().checkSellLine(sellLine['variation_id'], sellId: sellId,  res_table_id: res_table_id);
//     if (checkSellLine.isNotEmpty) {
//       print('addToCart: Product already in cart for sellId: $sellId, res_table_id: $res_table_id, variation_id: ${sellLine['variation_id']}');
//     } else {
//       await SellDatabase().store(sellLine);
//       print('addToCart: Added product to cart for sellId: $sellId, res_table_id: $res_table_id, variation_id: ${sellLine['variation_id']}');
//     }
//   }
//   Future<void> addToCart(Map product, int? sellId, int? res_table_id) async {
//     try {
//       if (sellId == null && res_table_id != null) {
//         // Find or create a sale for res_table_id
//         List sales = await SellDatabase().getSellsByTableId(res_table_id);
//         if (sales.isEmpty) {
//           // Create a new draft sale
//           sellId = await createSellDraft(
//             discountAmount: 0.0,
//             discountType: 'fixed',
//             locId: product['location_id'] ?? 0,
//             taxId: null,
//             res_table_id: res_table_id,
//             is_shipping: 0,
//           );
//           debugPrint('addToCart: Created new draft sale with sellId=$sellId for res_table_id=$res_table_id');
//         } else {
//           if (sales.length > 1) {
//             debugPrint('Warning: Multiple sales found for res_table_id=$res_table_id. Using most recent.');
//           }
//           sellId = sales.first['id'];
//           debugPrint('addToCart: Using existing sellId=$sellId for res_table_id=$res_table_id');
//         }
//       }
//       if (sellId == null) {
//         debugPrint('addToCart: sellId and res_table_id are null, cannot add to cart');
//         Fluttertoast.showToast(msg: AppLocalizations.of(context as BuildContext).translate('error_adding_to_cart'));
//         return;
//       }
//
//       // Check for existing product
//       List<Map> existingItems = await SellDatabase().getSellLineBySellId(sellId, res_table_id: res_table_id);
//       bool productExists = existingItems.any((item) =>
//       item['product_id'] == product['product_id'] &&
//           item['variation_id'] == product['variation_id'] &&
//           item['res_table_id'] == (res_table_id ?? 0) &&
//           item['is_completed'] == 0);
//
//       if (productExists) {
//         debugPrint('addToCart: Product already in cart for sellId=$sellId, res_table_id=$res_table_id, variation_id=${product['variation_id']}');
//         Fluttertoast.showToast(msg: AppLocalizations.of(context as BuildContext).translate('product_already_in_cart'));
//         // Optionally update quantity instead of skipping
//         // Example: await SellDatabase().updateSellLine(sellId, product['variation_id'], {'quantity': item['quantity'] + 1});
//         return;
//       }
//
//       debugPrint('addToCart: Adding product ${product['display_name']} with sellId=$sellId, res_table_id=$res_table_id');
//
//       double price = (product['tax_rate_id'] != 0 && product['tax_rate_id'] != null)
//           ? await getUnitPrice(double.parse(product['unit_price'].toString()), product['tax_rate_id'])
//           : product['unit_price'];
//
//       var sellLine = {
//         'sell_id': sellId,
//         'product_id': product['product_id'],
//         'variation_id': product['variation_id'],
//         'quantity': product['quantity'] ?? 1,
//         'unit_price': price,
//         'tax_rate_id': (product['tax_rate_id'] == 0) ? null : product['tax_rate_id'],
//         'discount_amount': product['discount_amount'] ?? 0.0,
//         'discount_type': product['discount_type'] ?? 'fixed',
//         'note': product['note'] ?? '',
//         'is_completed': 0,
//         'product_order_category': product['product_order_category'] ?? 'BAR',
//         'res_table_id': res_table_id ?? 0,
//         'is_shipping': product['is_shipping'] ?? 0,
//       };
//
//       await SellDatabase().store(sellLine);
//       debugPrint('addToCart: Stored sell_line for sellId=$sellId, res_table_id=$res_table_id, variation_id=${sellLine['variation_id']}');
//
//       // Verify storage
//       await SellDatabase().debugSellData(sellId, res_table_id);
//
//       // Update invoice_amount in sells table
//       List<Map> updatedItems = await SellDatabase().getSellLineBySellId(sellId, res_table_id: res_table_id);
//       double total = updatedItems.fold(0.0, (sum, item) => sum + (item['unit_price'] * item['quantity']));
//       await SellDatabase().updateSells(sellId, {'invoice_amount': total, 'pending_amount': total});
//       debugPrint('addToCart: Updated invoice_amount=$total for sellId=$sellId');
//     } catch (e, stackTrace) {
//       debugPrint('Error in addToCart for sellId=$sellId, res_table_id=$res_table_id: $e');
//       debugPrint('Stack trace: $stackTrace');
//       Fluttertoast.showToast(msg: AppLocalizations.of(context as BuildContext).translate('error_adding_to_cart'));
//     }
//   }
// In Sell.dart, modify the addToCart method

  Future<void> addToCart(Map product, int? sellId, int? res_table_id, {int? is_shipping}) async {
    try {
      if (sellId == null && res_table_id != null) {
        // Find or create a sale for res_table_id
        List sales = await SellDatabase().getSellsByTableId(res_table_id);
        if (sales.isEmpty) {
          // Create a new draft sale
          sellId = await createSellDraft(
            discountAmount: 0.0,
            discountType: 'fixed',
            locId: product['location_id'] ?? 0,
            taxId: null,
            res_table_id: res_table_id,
            is_shipping: 0,
          );
          debugPrint('addToCart: Created new draft sale with sellId=$sellId for res_table_id=$res_table_id');
        } else {
          if (sales.length > 1) {
            debugPrint('Warning: Multiple sales found for res_table_id=$res_table_id. Using most recent.');
          }
          sellId = sales.first['id'];
          debugPrint('addToCart: Using existing sellId=$sellId for res_table_id=$res_table_id');
        }
      }
      if (sellId == null) {
        debugPrint('addToCart: sellId and res_table_id are null, cannot add to cart');
        Fluttertoast.showToast(msg: AppLocalizations.of(context as BuildContext).translate('error_adding_to_cart'));
        return;
      }

      // Check for existing product - prevent duplicates
      List<Map> existingItems = await SellDatabase().getSellLineBySellId(sellId, res_table_id: res_table_id);
      bool productExists = existingItems.any((item) =>
      item['product_id'] == product['product_id'] &&
          item['variation_id'] == product['variation_id'] &&
          item['res_table_id'] == (res_table_id ?? 0) &&
          item['is_completed'] == 0);

      if (productExists) {
        debugPrint('addToCart: Product already in cart for sellId=$sellId, res_table_id=$res_table_id, variation_id=${product['variation_id']}');
        Fluttertoast.showToast(msg: AppLocalizations.of(context as BuildContext).translate('product_already_added'));
        // Instead of returning, throw an exception to let the caller know
        throw Exception('product_already_added');
      }

      debugPrint('addToCart: Adding product ${product['display_name']} with sellId=$sellId, res_table_id=$res_table_id');

      double price = (product['tax_rate_id'] != 0 && product['tax_rate_id'] != null)
          ? await getUnitPrice(double.parse(product['unit_price'].toString()), product['tax_rate_id'])
          : product['unit_price'];

      var sellLine = {
        'sell_id': sellId,
        'product_id': product['product_id'],
        'variation_id': product['variation_id'],
        'quantity': product['quantity'] ?? 1,
        'unit_price': price,
        'tax_rate_id': product['tax_rate_id'] ?? 0, // Use 0 instead of null to avoid foreign key issues
        'discount_amount': product['discount_amount'] ?? 0.0,
        'discount_type': product['discount_type'] ?? 'fixed',
        'note': product['note'] ?? '',
        'is_completed': 0,
        'product_order_category': product['product_order_category'] ?? 'BAR',
        'res_table_id': res_table_id ?? 0,
        'is_shipping': is_shipping ?? 0,
      };

      await SellDatabase().store(sellLine);
      debugPrint('addToCart: Stored sell_line for sellId=$sellId, res_table_id=$res_table_id, variation_id=${sellLine['variation_id']}');

      // Verify storage
      await SellDatabase().debugSellData(sellId, res_table_id);

      // Don't update invoice_amount in sells table until the user saves the changes
      // This prevents temporary cart changes from being reflected in the Sales Screen
      // The invoice_amount will only be updated when the user taps "Add Quotation" or "Update Quotation"
      // List<Map> updatedItems = await SellDatabase().getSellLineBySellId(sellId, res_table_id: res_table_id);
      // double total = updatedItems.fold(0.0, (sum, item) => sum + (item['unit_price'] * item['quantity']));
      // await SellDatabase().updateSells(sellId, {'invoice_amount': total, 'pending_amount': total});
      debugPrint('addToCart: Product added to cart - invoice_amount not updated until saved');
    } catch (e, stackTrace) {
      debugPrint('Error in addToCart for sellId=$sellId, res_table_id=$res_table_id: $e');
      debugPrint('Stack trace: $stackTrace');
      Fluttertoast.showToast(msg: AppLocalizations.of(context as BuildContext).translate('error_adding_to_cart'));
    }
  }

  // Future<void> resetCart({int? sellId}) async {
  //   if (sellId != null) {
  //     await SellDatabase().deleteSell(sellId);
  //     print('resetCart: Deleted cart items for sellId: $sellId');
  //   } else {
  //     await SellDatabase().deleteInComplete();
  //     print('resetCart: Deleted all incomplete cart items');
  //   }
  // }
  Future<void> resetCart({int? sellId, int? res_table_id}) async {
    try {
      if (sellId == null && res_table_id != null) {
        List sales = await SellDatabase().getSellsByTableId(res_table_id);
        if (sales.isEmpty) {
          debugPrint('resetCart: No sales found for res_table_id=$res_table_id');
          return;
        }
        debugPrint('resetCart: Sales for res_table_id=$res_table_id: ${jsonEncode(sales)}');
        for (var sale in sales) {
          if (sale['status'] == 'final' || sale['is_synced'] == 1) {
            await SellDatabase().debugSellData(sale['id'], res_table_id);
            await SellDatabase().deleteSell(sale['id']);
            debugPrint('resetCart: Deleted finalized sale for sellId=${sale['id']}, res_table_id=$res_table_id');
          }
        }
      } else if (sellId != null) {
        var sell = await SellDatabase().getSellBySellId(sellId);
        if (sell.isNotEmpty && (sell[0]['status'] == 'final' || sell[0]['is_synced'] == 1)) {
          await SellDatabase().debugSellData(sellId, res_table_id);
          await SellDatabase().deleteSell(sellId);
          debugPrint('resetCart: Deleted finalized sale for sellId=$sellId');
        } else {
          debugPrint('resetCart: Skipped deletion for draft sale sellId=$sellId');
        }
      } else {
        await SellDatabase().deleteInComplete();
        debugPrint('resetCart: Deleted all incomplete cart items');
      }
    } catch (e, stackTrace) {
      debugPrint('Error in resetCart for sellId=$sellId, res_table_id=$res_table_id: $e');
      debugPrint('Stack trace: $stackTrace');
      Fluttertoast.showToast(msg: AppLocalizations.of(context as BuildContext).translate('error_resetting_cart'));
    }
  }
  // Future<String> cartItemCount({int? isCompleted, int? sellId}) async {
  //   String count = await SellDatabase().countSellLines(isCompleted: isCompleted, sellId: sellId);
  //   //print('cartItemCount: sellId = $sellId, isCompleted = $isCompleted, count = $count');
  //   return count;
  // }
  Future<String> cartItemCount({int? isCompleted, int? sellId, int? res_table_id}) async {
    try {
      if (sellId == null && res_table_id != null) {
        List sales = await SellDatabase().getSellsByTableId(res_table_id);
        if (sales.isEmpty) {
          return "0";
        }
        if (sales.length > 1) {
          print('Warning: Multiple sales found for res_table_id: $res_table_id. Using most recent.');
        }
        sellId = sales.first['id'];
      }
      if (sellId == null) {
        return "0";
      }

      // For existing sales (when sellId is provided), include completed items for editing
      // For new sales, only count incomplete items
      bool includeCompleted = sellId != null;

      String count = await SellDatabase().countSellLines(
        isCompleted: isCompleted ?? 0,
        sellId: sellId,
        res_table_id: res_table_id,
        includeCompleted: includeCompleted,
      );

      return (count.isEmpty || count == "null") ? "0" : count;
    } catch (e) {
      print('Error in cartItemCount: $e');
      return "0";
    }
  }
  // Future<String> cartItemCount({int? isCompleted, int? sellId}) async {
  //   try {
  //     if (sellId == null) {
  //       return "0";
  //     }
  //
  //     String count = await SellDatabase().countSellLines(
  //       isCompleted: isCompleted ?? 0,
  //       sellId: sellId,
  //     );
  //
  //     // Ensure we return "0" if count is null or empty
  //     return (count.isEmpty || count == "null") ? "0" : count;
  //   } catch (e) {
  //     print('Error in cartItemCount: $e');
  //     return "0";
  //   }
  // }

  // Future<List<Map>> getCartItems(int? sellId,) async {
  //   if (sellId == null) {
  //     //print('getCartItems: sellId is null, returning empty list');
  //     return [];
  //   }
  //   List<Map> cartItems = await SellDatabase().getSellLineBySellId(sellId);
  //   //print('getCartItems: Retrieved ${cartItems.length} items for sellId: $sellId');
  //   return cartItems.map((item) {
  //     return {
  //       'product_id': item['product_id'],
  //       'variation_id': item['variation_id'],
  //       'quantity': item['quantity'],
  //       'unit_price': item['unit_price'],
  //       'tax_rate_id': item['tax_rate_id'],
  //       'discount_amount': item['discount_amount'] ?? 0.0,
  //       'discount_type': item['discount_type'] ?? 'fixed',
  //       'note': item['note'] ?? '',
  //       'product_order_category': item['product_order_category'] ?? 'BAR',
  //     };
  //   }).toList();
  // }
  Future<List<Map>> getCartItems(int? sellId, int? res_table_id) async {
    if (sellId == null && res_table_id != null) {
      List sales = await SellDatabase().getSellsByTableId(res_table_id);
      if (sales.isEmpty) {
        print('getCartItems: No sales found for res_table_id: $res_table_id');
        return [];
      }
      if (sales.length > 1) {
        print('Warning: Multiple sales found for res_table_id: $res_table_id. Using most recent.');
      }
      sellId = sales.first['id'];
    }
    if (sellId == null) {
      print('getCartItems: sellId and res_table_id are null, returning empty list');
      return [];
    }
    List<Map> cartItems = await SellDatabase().getSellLineBySellId(sellId , res_table_id: res_table_id, includeCompleted: true);
    print('getCartItems: Retrieved ${cartItems.length} items for sellId: $sellId, res_table_id: $res_table_id');
    return cartItems.map((item) {
      return {
        'product_id': item['product_id'],
        'variation_id': item['variation_id'],
        'quantity': item['quantity'],
        'unit_price': item['unit_price'],
        'tax_rate_id': item['tax_rate_id'],
        'discount_amount': item['discount_amount'] ?? 0.0,
        'discount_type': item['discount_type'] ?? 'fixed',
        'note': item['note'] ?? '',
        'product_order_category': item['product_order_category'] ?? 'BAR',
      };
    }).toList();
  }

  Map<String, dynamic> createSellMap(Map sell, double change, double pending) {
    Map<String, dynamic> sale = {
      'transaction_date': sell['transaction_date'],
      // FIXED: Preserve original invoice_no from local database instead of overwriting with API invoice_no
      // This ensures draft invoice numbers like "DRAFT-1759825990955" are preserved after completion
      'invoice_no': sell['invoice_no'], // Keep original local invoice number
      'contact_id': sell['contact_id'],
      'location_id': sell['location_id'],
      // 'status': sell['status'],
      'sale_status': sell['status'],
      'tax_rate_id': (sell['tax_id'] != 0) ? sell['tax_id'] : null,
      'discount_amount': (sell['discount_amount'] != null) ? sell['discount_amount'] : 0.00,
      'discount_type': sell['discount_type'],
      'invoice_amount': sell['final_total'],
      'change_return': change,
      'sale_note': sell['additional_notes'],
      'staff_note': sell['staff_note'],
      'shipping_charges': double.parse(sell['shipping_charges'].toString()),
      'shipping_details': sell['shipping_details'],
      'tip_amount': double.parse(sell['tip_amount'].toString()),
      'tip_type': sell['tip_type'] ?? 'fixed',
      'pending_amount': pending,
      'is_synced': 1,

      'res_table_id': sell['res_table_id'],
      'is_shipping': sell['is_shipping'],
    };
    return sale;
  }

  Future<int?> createSellDraft({
    double? discountAmount,
    required String discountType,
    required locId,
    int? taxId,
    int? res_table_id,
    int? is_shipping}) async {
    try {
      debugPrint('createSellDraft: Called with res_table_id=$res_table_id, is_shipping=$is_shipping');
      final db = await SellDatabase().dbProvider.database;
      final sellData = await createSell(
        transactionDate: DateTime.now().toIso8601String(),
        invoiceNo: 'DRAFT-${DateTime.now().millisecondsSinceEpoch}',
        // locId: 0,
        locId: locId, // Fix: Use the passed locId parameter instead of hardcoded 0

        tip_amount: 0.0,
        saleStatus: 'draft',
        isQuotation: 0,
        is_synced: 0,

        res_table_id: res_table_id,
        is_shipping: is_shipping ?? 0,
      );
      debugPrint('createSellDraft: Created sellData: ${jsonEncode(sellData)}');
      final sellId = await SellDatabase().storeSell(sellData);
      debugPrint('Created draft sale with sellId: $sellId, res_table_id: $res_table_id, is_shipping: $is_shipping');

      // Verify the stored data
      final storedData = await SellDatabase().getSellBySellId(sellId);
      debugPrint('createSellDraft: Verified stored data: ${jsonEncode(storedData)}');

      return sellId;
    } catch (e) {
      print('Error creating draft sale: $e');
      return null;
    }
  }

  // Future<void> deleteSell(int sellId) async {
  //   try {
  //     await SellDatabase().deleteSell(sellId);
  //     print('Called SellDatabase.deleteSell for sellId: $sellId');
  //   } catch (e) {
  //     print('Error calling deleteSell for sellId: $sellId: $e');
  //     rethrow;
  //   }
  // }
  Future<void> deleteSell(int? sellId, int? res_table_id) async {
    if (sellId == null && res_table_id != null) {
      await SellDatabase().resetCartForTable(res_table_id);
    } else if (sellId != null) {
      try {
        await SellDatabase().deleteSell(sellId);
        print('deleteSell: Deleted sale for sellId: $sellId');
      } catch (e) {
        print('Error calling deleteSell for sellId: $sellId: $e');
        rethrow;
      }
    } else {
      print('deleteSell: sellId and res_table_id are null');
    }
  }

  Future<void> cleanupSavedCartData() async {
    try {
      // Get all finalized sales
      List finalizedSales = await SellDatabase().getSells(all: true);

      for (var sale in finalizedSales) {
        // if (sale['status'] == 'final') {
        if (sale['sale_status'] == 'final') {
          // Remove saved cart data for finalized sales
          await Helper.removeCartData(sale['id']);
        }
      }

      debugPrint('cleanupSavedCartData: Removed saved cart data for finalized sales');
    } catch (e) {
      debugPrint('Error in cleanupSavedCartData: $e');
    }
  }

  // Future<void> cleanupOldDrafts({int? keepSellId}) async {
  //   try {
  //     await SellDatabase().deleteOldDrafts(keepSellId: keepSellId);
  //     print('cleanupOldDrafts: Deleted old draft sales, keeping sellId: $keepSellId');
  //   } catch (e) {
  //     print('Error cleaning up old drafts: $e');
  //   }
  // }
  Future<void> cleanupOldDrafts({int? keepSellId , int? keepResTableId}) async {
    try {
      await SellDatabase().deleteOldDrafts(keepSellId: keepSellId);
      print('cleanupOldDrafts: Deleted old draft sales, keeping sellId: $keepSellId res_table_id: $keepResTableId');
    } catch (e) {
      print('Error cleaning up old drafts: $e');
    }
  }

  //new added
  // Future<void> resetCartByTable(int? res_table_id, int? locationId) async {
  //   try {
  //     await SellDatabase().deleteSellLinesByTable(res_table_id, locationId);
  //     debugPrint('resetCartByTable: Cleared cart for res_table_id: $res_table_id, locationId: $locationId');
  //   } catch (e) {
  //     debugPrint('Error in resetCartByTable: $e');
  //     Fluttertoast.showToast(msg: 'Error resetting cart: $e');
  //   }
  // }
  Future<void> resetCartByTable(int? res_table_id, int? locationId) async {
    try {
      if (res_table_id == null) {
        debugPrint('resetCartByTable: res_table_id is null, skipping');
        return;
      }
      // Log sales and sell lines before deletion
      List sales = await SellDatabase().getSellsByTableId(res_table_id);
      debugPrint('resetCartByTable: Sales for res_table_id=$res_table_id: ${jsonEncode(sales)}');
      await SellDatabase().debugSellData(null, res_table_id);

      // Only delete finalized sales or orphaned sell lines
      for (var sale in sales) {
        if (sale['status'] == 'final' || sale['is_synced'] == 1) {
          await SellDatabase().deleteSell(sale['id']);
          debugPrint('resetCartByTable: Deleted finalized sale for sellId=${sale['id']}, res_table_id=$res_table_id');
        }
      }

      await SellDatabase().deleteSellLinesByTable(res_table_id, locationId);
      debugPrint('resetCartByTable: Cleared sell_lines for res_table_id=$res_table_id, locationId=$locationId');

      // Verify deletion
      await SellDatabase().debugSellData(null, res_table_id);
    } catch (e, stackTrace) {
      debugPrint('Error in resetCartByTable for res_table_id=$res_table_id, locationId=$locationId: $e');
      debugPrint('Stack trace: $stackTrace');
      Fluttertoast.showToast(msg: AppLocalizations.of(context as BuildContext).translate('error_resetting_cart'));
    }
  }

  /// Updates the invoice amount in the sells table based on current cart items
  /// This method should be called when the user saves the changes (Add/Update Quotation)
  /// to ensure the Sales Screen shows the correct amount
  Future<void> updateInvoiceAmountFromCart(int? sellId, int? res_table_id) async {
    try {
      debugPrint('updateInvoiceAmountFromCart: Starting calculation for sellId=$sellId, res_table_id=$res_table_id');
      if (sellId == null) {
        debugPrint('updateInvoiceAmountFromCart: sellId is null, returning');
        return;
      }

      // Get sell record to check current state
      List<Map<String, dynamic>> sellRecords = await SellDatabase().getSellBySellId(sellId);
      if (sellRecords.isEmpty) {
        debugPrint('updateInvoiceAmountFromCart: No sell record found for sellId: $sellId');
        return;
      }

      Map<String, dynamic> sellRecord = sellRecords.first;
      double currentInvoiceAmount = sellRecord['invoice_amount']?.toDouble() ?? 0.0;

      // Get all cart items for this sale (include completed items for editing)
      List<Map> cartItems = await SellDatabase().getSellLineBySellId(sellId, res_table_id: res_table_id, includeCompleted: true);

      if (cartItems.isEmpty) {
        debugPrint('updateInvoiceAmountFromCart: No cart items found for sellId: $sellId');
        return;
      }

      // Calculate raw subtotal from cart items
      double rawSubtotal = cartItems.fold(0.0, (sum, item) {
        double unitPrice = item['unit_price']?.toDouble() ?? 0.0;
        double quantity = item['quantity']?.toDouble() ?? 0.0;
        return sum + (unitPrice * quantity);
      });

      // Check if the current invoice_amount is significantly different from raw subtotal
      // This indicates that a discount has already been applied
      double tipAmount = sellRecord['tip_amount']?.toDouble() ?? 0.0;
      double shippingCharges = sellRecord['shipping_charges']?.toDouble() ?? 0.0;
      double expectedRawTotal = rawSubtotal + tipAmount + shippingCharges;

      debugPrint('updateInvoiceAmountFromCart: RawSubtotal=$rawSubtotal, TipAmount=$tipAmount, ShippingCharges=$shippingCharges, ExpectedRawTotal=$expectedRawTotal, CurrentInvoiceAmount=$currentInvoiceAmount');

      // If the current invoice amount is significantly less than the raw total,
      // it means a discount has already been applied, so don't override it
      if (currentInvoiceAmount < (expectedRawTotal - 1.0)) { // 1.0 tolerance for rounding
        debugPrint('updateInvoiceAmountFromCart: Discount already applied (currentInvoiceAmount=$currentInvoiceAmount < expectedRawTotal=$expectedRawTotal), skipping recalculation');
        return;
      }

      double? cartDiscountAmount = sellRecord['discount_amount']?.toDouble();
      String cartDiscountType = sellRecord['discount_type'] ?? 'fixed';
      int? taxId = sellRecord['tax_rate_id'];

      // Calculate subtotal (raw total without discounts)
      double subtotal = cartItems.fold(0.0, (sum, item) {
        double unitPrice = item['unit_price']?.toDouble() ?? 0.0;
        double quantity = item['quantity']?.toDouble() ?? 0.0;
        return sum + (unitPrice * quantity);
      });

      // Calculate total item-level discounts
      double totalItemDiscounts = 0.0;
      for (var item in cartItems) {
        double itemPrice = item['unit_price']?.toDouble() ?? 0.0;
        double quantity = item['quantity']?.toDouble() ?? 0.0;
        double discountAmount = item['discount_amount']?.toDouble() ?? 0.0;
        String discountType = item['discount_type'] ?? 'fixed';

        if (discountType == 'fixed') {
          totalItemDiscounts += discountAmount * quantity;
        } else {
          totalItemDiscounts += (itemPrice * discountAmount / 100) * quantity;
        }
      }

      // Apply item discounts first
      double amountAfterItemDiscounts = subtotal - totalItemDiscounts;

      // Apply cart-level discount
      // This is the key fix: use the cart-level discount from the sell record
      double amountAfterCartDiscount;
      if (cartDiscountType == 'fixed') {
        amountAfterCartDiscount = amountAfterItemDiscounts - (cartDiscountAmount ?? 0.0);
      } else {
        amountAfterCartDiscount = amountAfterItemDiscounts * (1 - (cartDiscountAmount ?? 0.0) / 100);
      }

      debugPrint('updateInvoiceAmountFromCart: Subtotal=$subtotal, ItemDiscounts=$totalItemDiscounts, CartDiscountAmount=${cartDiscountAmount ?? 0.0}, CartDiscountType=$cartDiscountType, AmountAfterItemDiscounts=$amountAfterItemDiscounts, AmountAfterCartDiscount=$amountAfterCartDiscount');

      // Calculate tax amount on the discounted amount (not the original subtotal)
      double taxAmount = 0.0;
      if (taxId != null && taxId != 0) {
        List taxList = await System().get('tax');
        for (var tax in taxList) {
          if (tax['id'] == taxId) {
            // Calculate tax on the amount after applying discounts, not on the original subtotal
            taxAmount = amountAfterCartDiscount * (tax['amount'] / 100);
            break;
          }
        }
      }

      // Calculate final total (base amount after discounts and tax)
      double finalTotal = amountAfterCartDiscount + taxAmount;

      // Calculate total amount including tip and shipping charges
      // This ensures consistency across all sections (Recent Sales, Dashboard, Payment Details)
      double totalAmountWithTipAndShipping = finalTotal + tipAmount + shippingCharges;

      // Calculate total paid amount from existing payments
      double totalPaidAmount = 0.0;
      try {
        List paymentRecords = await PaymentDatabase().get(sellId, allColumns: true, res_table_id: res_table_id);
        for (var payment in paymentRecords) {
          if (payment['is_return'] != 1) {
            double paymentAmount = double.tryParse(payment['amount']?.toString() ?? '0') ?? 0.0;
            totalPaidAmount += paymentAmount;
          }
        }
      } catch (e) {
        debugPrint('updateInvoiceAmountFromCart: Error calculating total paid amount: $e');
      }

      // Calculate pending amount (total amount with tip and shipping - total paid)
      double pendingAmount = (totalAmountWithTipAndShipping - totalPaidAmount).clamp(0.0, totalAmountWithTipAndShipping);

      // Update the sells table with the calculated total and pending amount
      // Store the complete amount (including tip and shipping) in invoice_amount for consistency
      await SellDatabase().updateSells(sellId, {
        'invoice_amount': totalAmountWithTipAndShipping,
        'pending_amount': pendingAmount,
      });

      debugPrint('Sell: Updated invoice amount - sellId=$sellId, BaseAmount=$finalTotal, Tip=$tipAmount, Shipping=$shippingCharges, TotalAmount=$totalAmountWithTipAndShipping, Discount=${cartDiscountAmount ?? 0.0}');
      debugPrint('updateInvoiceAmountFromCart: Successfully completed for sellId=$sellId');
    } catch (e, stackTrace) {
      debugPrint('Error in updateInvoiceAmountFromCart for sellId=$sellId: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }

  /// Recalculates pending amount for a specific sale based on existing payments
  /// This method ensures the pending amount is correctly calculated after payments
  Future<void> recalculatePendingAmount(int sellId, int? res_table_id) async {
    try {
      // Get the current sale record
      List<Map<String, dynamic>> sellRecords = await SellDatabase().getSellBySellId(sellId);
      if (sellRecords.isEmpty) {
        debugPrint('recalculatePendingAmount: No sell record found for sellId: $sellId');
        return;
      }

      Map<String, dynamic> sellRecord = sellRecords.first;
      double invoiceAmount = double.tryParse(sellRecord['invoice_amount']?.toString() ?? '0') ?? 0.0;

      // Calculate total paid amount from existing payments
      double totalPaidAmount = 0.0;
      List paymentRecords = await PaymentDatabase().get(sellId, allColumns: true, res_table_id: res_table_id);
      for (var payment in paymentRecords) {
        if (payment['is_return'] != 1) {
          double paymentAmount = double.tryParse(payment['amount']?.toString() ?? '0') ?? 0.0;
          totalPaidAmount += paymentAmount;
        }
      }

      // Calculate pending amount (invoice amount - total paid)
      double pendingAmount = (invoiceAmount - totalPaidAmount).clamp(0.0, invoiceAmount);

      // Update the pending amount in the database
      await SellDatabase().updateSells(sellId, {
        'pending_amount': pendingAmount,
      });

      debugPrint('recalculatePendingAmount: sellId=$sellId, InvoiceAmount=$invoiceAmount, TotalPaid=$totalPaidAmount, PendingAmount=$pendingAmount');
    } catch (e, stackTrace) {
      debugPrint('Error in recalculatePendingAmount for sellId=$sellId: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }

  /// Finalizes an order and marks the table/shipping as available
  /// This method should be called when an order is completed/finalized
  /// Works from any screen - automatically enables table/shipping
  Future<void> finalizeOrder(int? sellId, int? res_table_id, int? is_shipping) async {
    try {
      debugPrint('finalizeOrder: Called with sellId=$sellId, res_table_id=$res_table_id, is_shipping=$is_shipping');
      if (sellId == null) {
        debugPrint('finalizeOrder: sellId is null, cannot finalize order');
        return;
      }

      // Get locationId from the sale record
      var sellRecord = await SellDatabase().getSellBySellId(sellId);
      int? locationId = sellRecord.isNotEmpty ? sellRecord[0]['location_id'] : null;

      // CRITICAL: Update the order status to 'final' with multiple attempts
      int updateAttempts = 0;
      bool updateSuccessful = false;

      while (updateAttempts < 3 && !updateSuccessful) {
        updateAttempts++;
        debugPrint('finalizeOrder: Attempt $updateAttempts to update sale_status to final for sellId=$sellId');

        await SellDatabase().updateSells(sellId, {
          'sale_status': 'final',
          'is_synced': 1,
        });

        // CRITICAL: Verify the update was successful by reading back from database
        var verifyRecord = await SellDatabase().getSellBySellId(sellId);
        if (verifyRecord.isNotEmpty) {
          String? actualStatus = verifyRecord[0]['sale_status']?.toString();
          debugPrint('finalizeOrder: Verified sale_status update (attempt $updateAttempts) - actual status: $actualStatus');
          if (actualStatus == 'final') {
            updateSuccessful = true;
            debugPrint('finalizeOrder: Successfully updated sale_status to final for sellId=$sellId');
          } else {
            debugPrint('finalizeOrder: WARNING - sale_status is still not final after attempt $updateAttempts! Actual: $actualStatus');
            if (updateAttempts < 3) {
              // Wait a bit before retrying
              await Future.delayed(Duration(milliseconds: 200));
            }
          }
        } else {
          debugPrint('finalizeOrder: ERROR - Could not find sell record with id: $sellId');
        }
      }

      if (!updateSuccessful) {
        debugPrint('finalizeOrder: CRITICAL ERROR - Failed to update sale_status to final after 3 attempts!');
        // Last resort: try direct database access with multiple attempts
        bool directSqlSuccess = false;
        for (int sqlAttempt = 1; sqlAttempt <= 3 && !directSqlSuccess; sqlAttempt++) {
          try {
            final db = await SellDatabase().database;
            int rowsUpdated = await db.rawUpdate(
              'UPDATE sell SET sale_status = ? WHERE id = ?',
              ['final', sellId],
            );
            debugPrint('finalizeOrder: Direct SQL update (attempt $sqlAttempt) affected $rowsUpdated rows');

            if (rowsUpdated == 0) {
              // Try 'sells' table
              rowsUpdated = await db.rawUpdate(
                'UPDATE sells SET sale_status = ? WHERE id = ?',
                ['final', sellId],
              );
              debugPrint('finalizeOrder: Direct SQL update on "sells" table (attempt $sqlAttempt) affected $rowsUpdated rows');
            }

            // Wait a bit for commit
            await Future.delayed(Duration(milliseconds: 100));

            // Verify immediately
            var finalVerify = await SellDatabase().getSellBySellId(sellId);
            if (finalVerify.isNotEmpty) {
              String? finalStatus = finalVerify[0]['sale_status']?.toString();
              debugPrint('finalizeOrder: Verification after direct SQL (attempt $sqlAttempt) - sale_status: $finalStatus');
              if (finalStatus == 'final') {
                directSqlSuccess = true;
                debugPrint('finalizeOrder: Direct SQL update successful on attempt $sqlAttempt');
              } else if (sqlAttempt < 3) {
                debugPrint('finalizeOrder: Direct SQL update did not persist, retrying...');
                await Future.delayed(Duration(milliseconds: 200));
              }
            }
          } catch (e) {
            debugPrint('finalizeOrder: Direct SQL update (attempt $sqlAttempt) failed: $e');
            if (sqlAttempt < 3) {
              await Future.delayed(Duration(milliseconds: 200));
            }
          }
        }

        if (!directSqlSuccess) {
          debugPrint('finalizeOrder: CRITICAL - All direct SQL update attempts failed!');
        }
      }

      // CRITICAL: Small delay to ensure database transaction is committed
      await Future.delayed(Duration(milliseconds: 100));

      // Force enable table/shipping immediately after finalization
      await _forceEnableTableOrShipping(res_table_id, is_shipping, locationId);

      // Unlock table in Firebase if this is a table order
      if (res_table_id != null && res_table_id > 0 && is_shipping != 1 && locationId != null) {
        try {
          await FirebaseTableLockService().unlockTable(
            tableId: res_table_id,
            locationId: locationId,
          );
          debugPrint('finalizeOrder: Unlocked table $res_table_id in Firebase');
        } catch (e) {
          debugPrint('finalizeOrder: Error unlocking table in Firebase: $e');
        }
      }

      // Fire additional events to ensure all screens are notified
      await _notifyAllScreensOfFinalization(res_table_id, is_shipping);

      // CRITICAL: Final verification - check database one more time
      var finalVerify = await SellDatabase().getSellBySellId(sellId);
      if (finalVerify.isNotEmpty) {
        String? finalStatus = finalVerify[0]['sale_status']?.toString();
        debugPrint('finalizeOrder: Final verification - sale_status: $finalStatus');
        if (finalStatus != 'final') {
          debugPrint('finalizeOrder: CRITICAL ERROR - sale_status is still not final after all updates!');
          // Last resort: use raw SQL via updateSells with explicit sale_status
          try {
            await SellDatabase().updateSells(sellId, {'sale_status': 'final'});
            debugPrint('finalizeOrder: Used updateSells as last resort to set sale_status to final');
            // Verify one more time
            var lastVerify = await SellDatabase().getSellBySellId(sellId);
            if (lastVerify.isNotEmpty) {
              String? lastStatus = lastVerify[0]['sale_status']?.toString();
              debugPrint('finalizeOrder: After last resort update - sale_status: $lastStatus');
            }
          } catch (e) {
            debugPrint('finalizeOrder: Last resort update failed: $e');
          }
        }
      }

      debugPrint('finalizeOrder: Order $sellId finalized successfully - table/shipping enabled from any screen');
    } catch (e, stackTrace) {
      debugPrint('Error in finalizeOrder for sellId=$sellId: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }

  /// Notify all screens about order finalization to ensure table/shipping availability
  /// This ensures tables/shipping are enabled regardless of which screen the user is on
  Future<void> _notifyAllScreensOfFinalization(int? res_table_id, int? is_shipping) async {
    try {
      if (is_shipping == 1) {
        // Fire multiple events to ensure all screens receive the notification
        EventBus().fire(TableAvailabilityChangedEvent(
          isShipping: true,
          isAvailable: true,
        ));

        // Also fire a general sale finalized event
        EventBus().fire(SaleFinalizedEvent(0.0));

        debugPrint('_notifyAllScreensOfFinalization: Shipping finalization events fired');
      } else if (res_table_id != null && res_table_id > 0) {
        // Fire multiple events to ensure all screens receive the notification
        EventBus().fire(TableAvailabilityChangedEvent(
          tableId: res_table_id,
          isShipping: false,
          isAvailable: true,
        ));

        // Also fire a general sale finalized event
        EventBus().fire(SaleFinalizedEvent(0.0));

        debugPrint('_notifyAllScreensOfFinalization: Table $res_table_id finalization events fired');
      }
    } catch (e) {
      debugPrint('Error in _notifyAllScreensOfFinalization: $e');
    }
  }

  /// Force enable table or shipping after order finalization
  /// This ensures tables/shipping are always available after orders are completed
  Future<void> _forceEnableTableOrShipping(int? res_table_id, int? is_shipping, int? locationId) async {
    try {
      if (is_shipping == 1) {
        // This is a shipping order - force enable shipping
        await _forceEnableShipping(locationId);
        debugPrint('finalizeOrder: Force enabled shipping after order finalization');
      } else if (res_table_id != null && res_table_id > 0) {
        // This is a table order - force enable table
        await _forceEnableTable(res_table_id, locationId);
        debugPrint('finalizeOrder: Force enabled table $res_table_id after order finalization');
      }
    } catch (e) {
      debugPrint('Error in _forceEnableTableOrShipping: $e');
    }
  }

  /// Force enable shipping - ensures shipping is always available
  Future<void> _forceEnableShipping(int? locationId) async {
    try {
      final availabilityManager = TableAvailabilityManager();

      // Force enable shipping using the new method with locationId
      await availabilityManager.forceEnableTableOrShipping(isShipping: true, locationId: locationId);

      // Fire event to notify Tables screen
      EventBus().fire(TableAvailabilityChangedEvent(
        isShipping: true,
        isAvailable: true,
      ));

      debugPrint('_forceEnableShipping: Shipping force enabled for locationId=$locationId');
    } catch (e) {
      debugPrint('Error in _forceEnableShipping: $e');
    }
  }

  /// Force enable table - ensures table is always available
  Future<void> _forceEnableTable(int tableId, int? locationId) async {
    try {
      final availabilityManager = TableAvailabilityManager();

      // Force enable table using the new method with locationId
      await availabilityManager.forceEnableTableOrShipping(tableId: tableId, locationId: locationId);

      // Unlock table in Firebase
      if (locationId != null) {
        try {
          await FirebaseTableLockService().unlockTable(
            tableId: tableId,
            locationId: locationId,
          );
          debugPrint('_forceEnableTable: Unlocked table $tableId in Firebase');
        } catch (e) {
          debugPrint('_forceEnableTable: Error unlocking table in Firebase: $e');
        }
      }

      // Fire event to notify Tables screen
      EventBus().fire(TableAvailabilityChangedEvent(
        tableId: tableId,
        isShipping: false,
        isAvailable: true,
      ));

      debugPrint('_forceEnableTable: Table $tableId force enabled for locationId=$locationId');
    } catch (e) {
      debugPrint('Error in _forceEnableTable: $e');
    }
  }

  /// Cancels an order and marks the table/shipping as available
  /// This method should be called when an order is cancelled
  /// Works from any screen - automatically enables table/shipping
  Future<void> cancelOrder(int? sellId, int? res_table_id, int? is_shipping) async {
    try {
      if (sellId == null) {
        debugPrint('cancelOrder: sellId is null, cannot cancel order');
        return;
      }

      // Get locationId from the sale record before deleting
      var sellRecord = await SellDatabase().getSellBySellId(sellId);
      int? locationId = sellRecord.isNotEmpty ? sellRecord[0]['location_id'] : null;

      // Delete the order and related data
      await SellDatabase().deleteSell(sellId);

      // Force enable table/shipping immediately after cancellation
      await _forceEnableTableOrShipping(res_table_id, is_shipping, locationId);

      // Fire additional events to ensure all screens are notified
      await _notifyAllScreensOfFinalization(res_table_id, is_shipping);

      debugPrint('cancelOrder: Order $sellId cancelled successfully - table/shipping enabled from any screen');
    } catch (e, stackTrace) {
      debugPrint('Error in cancelOrder for sellId=$sellId: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }

  /// Completes payment for an order and marks the table/shipping as available
  /// This method should be called when an order is fully paid
  /// Works from any screen - automatically enables table/shipping
  Future<void> completePayment(int? sellId, int? res_table_id, int? is_shipping) async {
    try {
      if (sellId == null) {
        debugPrint('completePayment: sellId is null, cannot complete payment');
        return;
      }

      // Get locationId from the sale record
      var sellRecord = await SellDatabase().getSellBySellId(sellId);
      int? locationId = sellRecord.isNotEmpty ? sellRecord[0]['location_id'] : null;

      // Update the order status to 'final' if not already
      await SellDatabase().updateSells(sellId, {
        'sale_status': 'final',
        'is_synced': 1,
      });

      // Force enable table/shipping immediately after payment completion
      await _forceEnableTableOrShipping(res_table_id, is_shipping, locationId);

      // Unlock table in Firebase if this is a table order
      if (res_table_id != null && res_table_id > 0 && is_shipping != 1 && locationId != null) {
        try {
          await FirebaseTableLockService().unlockTable(
            tableId: res_table_id,
            locationId: locationId,
          );
          debugPrint('completePayment: Unlocked table $res_table_id in Firebase');
        } catch (e) {
          debugPrint('completePayment: Error unlocking table in Firebase: $e');
        }
      }

      // Fire additional events to ensure all screens are notified
      await _notifyAllScreensOfFinalization(res_table_id, is_shipping);

      debugPrint('completePayment: Payment completed for order $sellId - table/shipping enabled from any screen');
    } catch (e, stackTrace) {
      debugPrint('Error in completePayment for sellId=$sellId: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }




  /// Ensures cart items are saved to sell_lines when navigating from Sales to Checkout
  /// This method is specifically for Sales → Checkout navigation
  Future<void> ensureCartItemsForSalesToCheckout({
    required int sellId,
    required int? resTableId,
    required int? isShipping,
    required List<Map> products, // Changed from List<Map<String, dynamic>>
  }) async {
    try {
      debugPrint('ensureCartItemsForSalesToCheckout: Starting for sellId=$sellId, resTableId=$resTableId, products=${products.length}');

      // Check if we already have cart items for this sale
      List<Map<String, dynamic>> existingCartItems = await SellDatabase().getSellLineBySellId(
          sellId,
          res_table_id: resTableId,
          includeCompleted: true
      );

      debugPrint('ensureCartItemsForSalesToCheckout: Found ${existingCartItems.length} existing cart items');

      // If no cart items exist, save the products from sales data
      if (existingCartItems.isEmpty && products.isNotEmpty) {
        debugPrint('ensureCartItemsForSalesToCheckout: No existing cart items found, saving ${products.length} products from sales data');

        for (var product in products) {
          try {
            // Safely extract values with null checks and type conversion
            int productId = int.tryParse(product['product_id']?.toString() ?? '0') ?? 0;
            int variationId = int.tryParse(product['variation_id']?.toString() ?? '0') ?? 0;
            double quantity = double.tryParse(product['quantity']?.toString() ?? '1') ?? 1.0;
            double unitPrice = double.tryParse(product['unit_price']?.toString() ?? '0') ?? 0.0;
            int? taxRateId = product['tax_rate_id'] != null ? int.tryParse(product['tax_rate_id'].toString()) : null;
            double discountAmount = double.tryParse(product['discount_amount']?.toString() ?? '0') ?? 0.0;
            String discountType = product['discount_type']?.toString() ?? 'fixed';
            String note = product['note']?.toString() ?? '';
            String productOrderCategory = product['product_order_category']?.toString() ?? 'BAR';

            double price = (taxRateId != 0 && taxRateId != null)
                ? await getUnitPrice(unitPrice, taxRateId)
                : unitPrice;

            var sellLine = {
              'sell_id': sellId,
              'product_id': productId,
              'variation_id': variationId,
              'quantity': quantity,
              'unit_price': price,
              'tax_rate_id': taxRateId ?? 0, // Use 0 instead of null to avoid foreign key issues
              'discount_amount': discountAmount,
              'discount_type': discountType,
              'note': note,
              'is_completed': 1, // Mark as completed since this is from existing sales
              'product_order_category': productOrderCategory,
              'res_table_id': resTableId ?? 0,
              'is_shipping': isShipping ?? 0,
            };

            await SellDatabase().store(sellLine);
            debugPrint('ensureCartItemsForSalesToCheckout: Saved product $productId-$variationId to sell_lines');

          } catch (e) {
            debugPrint('ensureCartItemsForSalesToCheckout: Error saving product ${product['product_id']}: $e');
          }
        }

        debugPrint('ensureCartItemsForSalesToCheckout: Successfully saved ${products.length} products to sell_lines');

      } else if (existingCartItems.isNotEmpty) {
        debugPrint('ensureCartItemsForSalesToCheckout: Cart items already exist, no action needed');
      }

      // Verify the storage
      List<Map<String, dynamic>> finalCartItems = await SellDatabase().getSellLineBySellId(
          sellId,
          res_table_id: resTableId,
          includeCompleted: true
      );

      debugPrint('ensureCartItemsForSalesToCheckout: Final cart items count: ${finalCartItems.length}');

    } catch (e, stackTrace) {
      debugPrint('ensureCartItemsForSalesToCheckout: Error - $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }
}