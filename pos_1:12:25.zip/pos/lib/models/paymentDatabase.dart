// import 'database.dart';
//
// class PaymentDatabase {
//   late DbProvider dbProvider;
//
//   PaymentDatabase() {
//     dbProvider = new DbProvider();
//   }
//
//   //add payment line
//   Future<int> store(value) async {
//     final db = await dbProvider.database;
//     var response = db.insert('sell_payments', value);
//     return response;
//   }
//
//   //delete payment line with its corresponding sellId
//   Future<int> delete(sellId) async {
//     final db = await dbProvider.database;
//     var response = await db
//         .delete('sell_payments', where: 'sell_id = ?', whereArgs: [sellId]);
//     return response;
//   }
//
//   //update payment line
//   Future<int> updateEditedPaymentLine(id, value) async {
//     final db = await dbProvider.database;
//     var response = await db
//         .update('sell_payments', value, where: 'id = ?', whereArgs: [id]);
//     return response;
//   }
//
//   //fetch payment line by sellId
//   Future<List> get(sellId, {bool? allColumns}) async {
//     final db = await dbProvider.database;
//     List<String> columns;
//     if (allColumns == true)
//       columns = [
//         'id',
//         'payment_id',
//         'amount',
//         'method',
//         'note',
//         'is_return',
//         'account_id'
//       ];
//     else
//       columns = ['amount', 'method', 'note', 'account_id'];
//     var response = db.query('sell_payments',
//         columns: columns,
//         where: 'sell_id = ? ORDER BY is_return',
//         whereArgs: [sellId]);
//     return response;
//   }
//
//   //fetch sell_payments according to is_return value
//   Future<List> getPaymentLineByReturnValue(sellId, isReturn) async {
//     final db = await dbProvider.database;
//     var response = db.query('sell_payments',
//         where: 'sell_id = ? AND is_return = ?', whereArgs: [sellId, isReturn]);
//     return response;
//   }
//
//   //fetch payment line by id
//   Future<Map> getPaymentLineById(id) async {
//     final db = await dbProvider.database;
//     List response =
//         await db.query('sell_payments', where: 'id = ?', whereArgs: [id]);
//     return response[0];
//   }
//
//   //delete payment line by List of id
//   deletePaymentLineByIds(List<int> id) async {
//     final db = await dbProvider.database;
//     String ids = id.join(",");
//     var response = await db.rawQuery('DELETE FROM "sell_payments" '
//         'WHERE "id" in ($ids)');
//     return response;
//   }
// }

import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'database.dart';

class PaymentDatabase {
  late DbProvider dbProvider;

  PaymentDatabase() {
    dbProvider = DbProvider();
  }

  Future<Database> get database async => await dbProvider.database;


  Future<int> store(Map<String, dynamic> paymentLine) async {
    try {
      final db = await database;
      // Serialize card_details to JSON string
      if (paymentLine['card_details'] != null) {
        paymentLine['card_details'] = jsonEncode(paymentLine['card_details']);
      }
      var response = await db.insert('sell_payments', paymentLine);
      print('Stored payment for sell_id: ${paymentLine['sell_id']}');
      return response;
    } catch (e) {
      print('Error storing payment: $e');
      rethrow;
    }
  }

  // Future<List<Map<String, dynamic>>> get(int sellId, {bool allColumns = false, required res_table_id}) async {
  Future<List<Map<String, dynamic>>> get(int sellId, {bool allColumns = false, int? res_table_id}) async {
    try {
      final db = await database;
      var response = await db.query(
        'sell_payments',
        // columns: allColumns ? null : ['amount', 'method', 'note', 'account_id', 'received_amount', 'change_return', 'card_details'],   //new added
        columns: allColumns ? null : ['amount', 'method', 'note', 'account_id', 'received_amount', 'change_return', 'card_details'],
        where: 'sell_id = ? AND is_return = ?',
        whereArgs: [sellId, 0],
        // whereArgs: [sellId, 0, res_table_id ?? sellId],           //new added
      );

      // Log query result    //new added
      print('PaymentDatabase.get: Queried sellId: $sellId, res_table_id: $res_table_id, result: $response');

      // Deserialize card_details from JSON string
      return response.map((map) {
        if (map['card_details'] is String &&
            (map['card_details'] as String).isNotEmpty) {
          try {
            map['card_details'] = jsonDecode(map['card_details'] as String);
          } catch (e) {
            print(
                'Error decoding card_details for payment id ${map['id']}: $e');
            map['card_details'] = null;
          }
        } else {
          map['card_details'] = null;
        }
        return map;
      }).toList();
    } catch (e) {
      //print('Error fetching payments for sell_id: $sellId: $e');
      print('Error fetching payments for sell_id: $sellId: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> getPaymentLineByReturnValue(
      int sellId, int isReturn) async {
    try {
      final db = await database;
      var response = await db.query(
        'sell_payments',
        where: 'sell_id = ? AND is_return = ?',
        whereArgs: [sellId, isReturn],
      );

      // Log query result     //new added
      print('PaymentDatabase.getPaymentLineByReturnValue: Queried sellId: $sellId, isReturn: $isReturn, result: $response');


      // Deserialize card_details from JSON string
      return response.map((map) {
        if (map['card_details'] is String &&
            (map['card_details'] as String).isNotEmpty) {
          try {
            map['card_details'] = jsonDecode(map['card_details'] as String);
          } catch (e) {
            print(
                'Error decoding card_details for payment id ${map['id']}: $e');
            map['card_details'] = null;
          }
        } else {
          map['card_details'] = null;
        }
        return map;
      }).toList();
    } catch (e) {
      print(
          'Error fetching payment lines for sell_id: $sellId, is_return: $isReturn: $e');
      return [];
    }
  }

  Future<int> delete(int sellId) async {
    try {
      final db = await database;
      var response = await db.delete(
        'sell_payments',
        where: 'sell_id = ?',
        whereArgs: [sellId],
      );
      print('Deleted payments for sell_id: $sellId');
      return response;
    } catch (e) {
      print('Error deleting payments for sell_id: $sellId: $e');
      return 0;
    }
  }

  Future<int> updateEditedPaymentLine(
      int id, Map<String, dynamic> paymentLine) async {
    try {
      final db = await database;
      // Serialize card_details to JSON string
      if (paymentLine['card_details'] != null) {
        paymentLine['card_details'] = jsonEncode(paymentLine['card_details']);
      }
      var response = await db.update(
        'sell_payments',
        paymentLine,
        where: 'id = ?',
        whereArgs: [id],
      );
      print('Updated payment id: $id');
      return response;
    } catch (e) {
      print('Error updating payment id: $id: $e');
      return 0;
    }
  }

  // New method to delete payment lines by IDs
  Future<int> deletePaymentLineByIds(List<int> paymentIds) async {
    try {
      final db = await database;
      if (paymentIds.isEmpty) {
        print('No payment IDs provided for deletion');
        return 0;
      }
      // Create a WHERE clause with multiple IDs
      String whereClause = 'id IN (${paymentIds.map((_) => '?').join(',')})';
      var response = await db.delete(
        'sell_payments',
        where: whereClause,
        whereArgs: paymentIds,
      );
      print('Deleted ${response} payment lines with IDs: $paymentIds');
      return response;
    } catch (e) {
      print('Error deleting payment lines with IDs: $paymentIds: $e');
      return 0;
    }
  }

  //new added updatePaymentLines
  Future<void> updatePaymentLines(List<dynamic> paymentLines) async {
    try {
    var db = await DbProvider().database;
    for (var line in paymentLines) {

      // Serialize card_details if present //new added
      if (line['card_details'] != null) {
        line['card_details'] = jsonEncode(line['card_details']);
      }


      // await db.update('payment_lines', line,
      //     where: 'id = ?', whereArgs: [line['id']]);
      await db.update(
        'sell_payments', // Fixed table name (was payment_lines)
        line,
        where: 'id = ?',
        whereArgs: [line['id']],
      );
      print('Updated payment line id: ${line['id']}');
    }
  }catch(e){
      print('Error updating payment lines: $e');
      rethrow;
    }
  }
// Add this to your PaymentDatabase class
  Future<List<Map<String, dynamic>>> getAllPayments() async {
    try {
      final db = await database;
      var payments = await db.query(
        'sell_payments',
        where: 'is_return = ?',
        whereArgs: [0], // Only non-return payments
      );
      return List<Map<String, dynamic>>.from(payments);
    } catch (e) {
      print('Error getting all payments: $e');
      return [];
    }
  }
}
