// // import 'dart:async';
// // import 'dart:io';
// //
// // import 'package:path/path.dart';
// // import 'package:path_provider/path_provider.dart';
// // import 'package:sqflite/sqflite.dart';
// //
// // import '../pages/login.dart';
// //
// // class DbProvider {
// //   DbProvider();
// //
// //   DbProvider._createInstance();
// //
// //   static final DbProvider db = DbProvider._createInstance();
// //   static Database? _database;
// //
// //   // Query to create system table (location, brand, category, taxRate)
// //   String createSystemTable =
// //       "CREATE TABLE system (id INTEGER PRIMARY KEY AUTOINCREMENT, keyId INTEGER DEFAULT null,"
// //       " key TEXT, value TEXT)";
// //
// //   // Query to create contact table
// //   String createContactTable =
// //       "CREATE TABLE contact (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, city TEXT, state TEXT,"
// //       " country TEXT, address_line_1 TEXT, address_line_2 TEXT, zip_code TEXT, mobile TEXT)";
// //
// //   // Query to create variation table
// //   String createVariationTable =
// //       "CREATE TABLE variations (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER,"
// //       " variation_id INTEGER, product_name TEXT, product_variation_name TEXT, variation_name TEXT,"
// //       " display_name TEXT, sku TEXT, sub_sku TEXT, type TEXT, enable_stock INTEGER,"
// //       " brand_id INTEGER, unit_id INTEGER, category_id INTEGER, sub_category_id INTEGER,"
// //       " tax_id INTEGER, default_sell_price REAL, sell_price_inc_tax REAL, product_image_url TEXT,"
// //       " selling_price_group BLOB DEFAULT null, product_description TEXT)";
// //
// //   // Query to create variation by location table
// //   String createVariationByLocationTable =
// //       "CREATE TABLE variations_location_details (id INTEGER PRIMARY KEY AUTOINCREMENT,"
// //       " product_id INTEGER, variation_id INTEGER, location_id INTEGER, qty_available REAL)";
// //
// //   // Query to create product available in location table
// //   String createProductAvailableInLocationTable =
// //       "CREATE TABLE product_locations (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER,"
// //       " location_id INTEGER)";
// //
// //   // Query to create sell table in database
// //   String createSellTable =
// //       "CREATE TABLE sell (id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_date TEXT, invoice_no TEXT,"
// //       " contact_id INTEGER, location_id INTEGER, status TEXT, tax_rate_id INTEGER, discount_amount REAL,"
// //       " discount_type TEXT, sale_note TEXT, staff_note TEXT, shipping_details TEXT, is_quotation INTEGER DEFAULT 0,"
// //       " shipping_charges REAL DEFAULT 0.00, tip_amount REAL, tip_type TEXT, invoice_amount REAL, change_return REAL DEFAULT 0.00,"
// //       " pending_amount REAL DEFAULT 0.00, is_synced INTEGER, transaction_id INTEGER DEFAULT null, invoice_url TEXT DEFAULT null)";
// //
// //   // Query to create sell line table in database
// //   String createSellLineTable =
// //       "CREATE TABLE sell_lines (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
// //       " product_id INTEGER, variation_id INTEGER, quantity REAL, unit_price REAL,"
// //       " tax_rate_id INTEGER, discount_amount REAL, discount_type TEXT, note TEXT,"
// //       " is_completed INTEGER, product_order_category TEXT DEFAULT 'BAR')";
// //
// //   // Query to create payment line table in database
// //   String createSellPaymentsTable =
// //       "CREATE TABLE sell_payments (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
// //       " payment_id INTEGER DEFAULT null, method TEXT, amount REAL, note TEXT,"
// //       " account_id INTEGER DEFAULT null, is_return INTEGER DEFAULT 0, received_amount REAL, change_return REAL)";
// //
// //   // Get database of type Future<Database>
// //   Future<Database> get database async {
// //     // If database doesn't exist, create one
// //     if (_database == null) {
// //       _database = await initializeDatabase(USERID);
// //     }
// //     // If database exists, return database
// //     return _database!;
// //   }
// //
// //   int currVersion = 8; // Incremented version to trigger migration
// //
// //   // Create tables during the creation of the database itself
// //   Future<Database> initializeDatabase(loginUserId) async {
// //     Directory posDirectory = await getApplicationDocumentsDirectory();
// //     String path = join(posDirectory.path, 'PosDemo$loginUserId.db');
// //     return await openDatabase(
// //       path,
// //       version: currVersion,
// //       onCreate: (Database db, int version) async {
// //         await db.execute(createSystemTable);
// //         await db.execute(createContactTable);
// //         await db.execute(createVariationTable);
// //         await db.execute(createVariationByLocationTable);
// //         await db.execute(createProductAvailableInLocationTable);
// //         await db.execute(createSellTable);
// //         await db.execute(createSellLineTable);
// //         await db.execute(createSellPaymentsTable);
// //       },
// //       onUpgrade: (db, oldVersion, newVersion) async {
// //         if (oldVersion < 2) {
// //           await db.execute("ALTER TABLE sell_lines RENAME TO prev_sell_line;");
// //           await db.execute(createSellLineTable);
// //           await db.execute("INSERT INTO sell_lines SELECT *, 'BAR' AS product_order_category FROM prev_sell_line;");
// //         }
// //
// //         if (oldVersion < 3) {
// //           await db.execute("ALTER TABLE variations RENAME TO prev_variations;");
// //           await db.execute(createVariationTable);
// //           await db.execute("INSERT INTO variations SELECT * FROM prev_variations;");
// //         }
// //
// //         if (oldVersion < 4) {
// //           await db.execute(createContactTable);
// //         }
// //
// //         if (oldVersion < 5) {
// //           await db.execute("ALTER TABLE sell ADD COLUMN invoice_url TEXT DEFAULT null;");
// //         }
// //
// //         if (oldVersion < 6) {
// //           await db.execute(
// //               "ALTER TABLE sell_payments ADD COLUMN account_id INTEGER DEFAULT null;");
// //         }
// //
// //         if (oldVersion < 7) {
// //           await db.execute("ALTER TABLE sell ADD COLUMN tip_amount REAL;");
// //           await db.execute("ALTER TABLE sell ADD COLUMN tip_type TEXT DEFAULT 'fixed';");
// //         }
// //
// //         if (oldVersion < 8) {
// //           await db.execute("ALTER TABLE sell_lines ADD COLUMN product_order_category TEXT DEFAULT 'BAR';");
// //           await db.execute("ALTER TABLE sell_payments ADD COLUMN received_amount REAL;");
// //           await db.execute("ALTER TABLE sell_payments ADD COLUMN change_return REAL;");
// //         }
// //
// //         await db.setVersion(currVersion);
// //       },
// //     );
// //   }
// //
// //   Future<bool> checkSchema() async {
// //     try {
// //       final db = await database;
// //       var columns = await db.rawQuery('PRAGMA table_info(sell);');
// //       bool hasTipType = columns.any((column) => column['name'] == 'tip_type');
// //       print('Schema check: tip_type column exists = $hasTipType');
// //       return hasTipType;
// //     } catch (e) {
// //       print('Error checking schema: $e');
// //       return false;
// //     }
// //   }
// // }
//
// import 'dart:async';
// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:path/path.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:sqflite/sqflite.dart';
//
// import '../pages/login.dart';
//
// class DbProvider {
//   DbProvider();
//
//   DbProvider._createInstance();
//
//   static final DbProvider db = DbProvider._createInstance();
//
//   static Database? _database;
//
//   // Query to create system table (location, brand, category, taxRate)
//   String createSystemTable =
//       "CREATE TABLE system (id INTEGER PRIMARY KEY AUTOINCREMENT, keyId INTEGER DEFAULT null,"
//       " key TEXT, value TEXT)";
//
//   // Query to create contact table
//   String createContactTable =
//       "CREATE TABLE contact (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, city TEXT, state TEXT,"
//       " country TEXT, address_line_1 TEXT, address_line_2 TEXT, zip_code TEXT, mobile TEXT)";
//
//   // Query to create variation table
//   String createVariationTable =
//       "CREATE TABLE variations (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER,"
//       " variation_id INTEGER, product_name TEXT, product_variation_name TEXT, variation_name TEXT,"
//       " display_name TEXT, sku TEXT, sub_sku TEXT, type TEXT, enable_stock INTEGER,"
//       " brand_id INTEGER, unit_id INTEGER, category_id INTEGER, sub_category_id INTEGER,"
//       " tax_id INTEGER, default_sell_price REAL, sell_price_inc_tax REAL, product_image_url TEXT,"
//       " selling_price_group BLOB DEFAULT null, product_description TEXT)";
//
//   // Query to create variation by location table
//   String createVariationByLocationTable =
//       "CREATE TABLE variations_location_details (id INTEGER PRIMARY KEY AUTOINCREMENT,"
//       " product_id INTEGER, variation_id INTEGER, location_id INTEGER, qty_available REAL)";
//
//   // Query to create product available in location table
//   String createProductAvailableInLocationTable =
//       "CREATE TABLE product_locations (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER,"
//       " location_id INTEGER)";
//
//   // Query to create sell table in database
//   String createSellTable =
//       "CREATE TABLE sell (id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_date TEXT, invoice_no TEXT,"
//       " contact_id INTEGER, location_id INTEGER, status TEXT, tax_rate_id INTEGER, discount_amount REAL,"
//       " discount_type TEXT, sale_note TEXT, staff_note TEXT, shipping_details TEXT, is_quotation INTEGER DEFAULT 0,"
//       " shipping_charges REAL DEFAULT 0.00, tip_amount REAL, tip_type TEXT, invoice_amount REAL, change_return REAL DEFAULT 0.00,"
//       " pending_amount REAL DEFAULT 0.00, is_synced INTEGER, transaction_id INTEGER DEFAULT null, invoice_url TEXT DEFAULT null,"
//       // " res_table_id INTEGER, is_shipping INTEGER DEFAULT 0)";   //here added res_table_id and is_shipping
//       " res_table_id INTEGER, is_shipping INTEGER DEFAULT 0, sale_status TEXT DEFAULT 'final')";   //here added res_table_id, is_shipping, and sale_status
//
//   // Query to create sell line table in database
//   String createSellLineTable =
//       // "CREATE TABLE sell_lines (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
//       // " product_id INTEGER, variation_id INTEGER, quantity REAL, unit_price REAL,"
//       // " tax_rate_id INTEGER, discount_amount REAL, discount_type TEXT, note TEXT,"
//       // " is_completed INTEGER, product_order_category TEXT DEFAULT 'BAR')";
//       "CREATE TABLE sell_lines (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
//       " product_id INTEGER, variation_id INTEGER, quantity REAL, unit_price REAL,"
//       " tax_rate_id INTEGER, discount_amount REAL, discount_type TEXT, note TEXT,"
//       " is_completed INTEGER, product_order_category TEXT DEFAULT 'BAR', res_table_id INTEGER,"
//       " is_shipping INTEGER DEFAULT 0, FOREIGN KEY (sell_id) REFERENCES sell(id))";
//
//   // Query to create payment line table in database
//   String createSellPaymentsTable =
//       "CREATE TABLE sell_payments (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
//       " payment_id INTEGER DEFAULT null, method TEXT, amount REAL, note TEXT,"
//       " account_id INTEGER DEFAULT null, is_return INTEGER DEFAULT 0, received_amount REAL, change_return REAL,"
//       " card_details TEXT)"; // Added card_details TEXT column
//
//   // Get database of type Future<Database>
//   Future<Database> get database async {
//     // If database doesn't exist, create one
//     if (_database == null) {
//       _database = await initializeDatabase(USERID);
//     }
//     // If database exists, return database
//     return _database!;
//   }
//
//   // int currVersion = 11; // Incremented version to trigger migration
//   int currVersion = 12; // Incremented version to trigger migration
//
//   // Create tables during the creation of the database itself
//   Future<Database> initializeDatabase(loginUserId) async {
//     Directory posDirectory = await getApplicationDocumentsDirectory();
//     String path = join(posDirectory.path, 'PosDemo$loginUserId.db');
//     // String path = join(posDirectory.path, 'PosDemo.db');
//     return await openDatabase(
//       path,
//       version: currVersion,
//       onCreate: (Database db, int version) async {
//         await db.execute(createSystemTable);
//         await db.execute(createContactTable);
//         await db.execute(createVariationTable);
//         await db.execute(createVariationByLocationTable);
//         await db.execute(createProductAvailableInLocationTable);
//         await db.execute(createSellTable);
//         await db.execute(createSellLineTable);
//         await db.execute(createSellPaymentsTable);
//       },
//       onUpgrade: (db, oldVersion, newVersion) async {
//         if (oldVersion < 2) {
//           await db.execute("ALTER TABLE sell_lines RENAME TO prev_sell_line;");
//           await db.execute(createSellLineTable);
//           await db.execute("INSERT INTO sell_lines SELECT *, 'BAR' AS product_order_category FROM prev_sell_line;");
//         }
//
//         if (oldVersion < 3) {
//           await db.execute("ALTER TABLE variations RENAME TO prev_variations;");
//           await db.execute(createVariationTable);
//           await db.execute("INSERT INTO variations SELECT * FROM prev_variations;");
//         }
//
//         if (oldVersion < 4) {
//           await db.execute(createContactTable);
//         }
//
//         if (oldVersion < 5) {
//           await db.execute("ALTER TABLE sell ADD COLUMN invoice_url TEXT DEFAULT null;");
//         }
//
//         if (oldVersion < 6) {
//           await db.execute(
//               "ALTER TABLE sell_payments ADD COLUMN account_id INTEGER DEFAULT null;");
//         }
//
//         if (oldVersion < 7) {
//           await db.execute("ALTER TABLE sell ADD COLUMN tip_amount REAL;");
//           await db.execute("ALTER TABLE sell ADD COLUMN tip_type TEXT DEFAULT 'fixed';");
//         }
//
//         if (oldVersion < 8) {
//           await db.execute("ALTER TABLE sell_lines ADD COLUMN product_order_category TEXT DEFAULT 'BAR';");
//           await db.execute("ALTER TABLE sell_payments ADD COLUMN received_amount REAL;");
//           await db.execute("ALTER TABLE sell_payments ADD COLUMN change_return REAL;");
//         }
//
//         if (oldVersion < 9) {
//           await db.execute("ALTER TABLE sell_payments ADD COLUMN card_details TEXT;");
//         }
//
//         if (oldVersion < 10) {
//           // Add res_table_id and is_shipping columns to sell table
//           await db.execute("ALTER TABLE sell ADD COLUMN res_table_id INTEGER DEFAULT null;");
//           await db.execute("ALTER TABLE sell ADD COLUMN is_shipping INTEGER DEFAULT 0;");
//         }
//
//       if (oldVersion < 11) {
//         await db.execute("ALTER TABLE sell_lines ADD COLUMN res_table_id INTEGER DEFAULT null;");
//         await db.execute("ALTER TABLE sell_lines ADD COLUMN is_shipping INTEGER DEFAULT 0;");
//         // Update existing shipping sales to set res_table_id = 0 and is_shipping = 1
//         await db.execute("UPDATE sell SET res_table_id = 0, is_shipping = 1 WHERE res_table_id IS NULL;");
//         await db.execute("UPDATE sell_lines SET res_table_id = 0, is_shipping = 1 WHERE res_table_id IS NULL;");
//       }
//
//         if (oldVersion < 12) {
//           // Add sale_status field to sell table for draft functionality
//           await db.execute("ALTER TABLE sell ADD COLUMN sale_status TEXT DEFAULT 'final';");
//         }
//
//         // Version 12 - 15: only update DB version without new columns/tables
//         // v12 to v15: No new columns/tables, just set version
//         if (oldVersion < 15) {
//           print("Database upgraded to version 15 without schema changes.");
//         }
//
//         await db.setVersion(currVersion);
//       },
//     );
//   }
//
//   Future<bool> checkSchema() async {
//     try {
//       final db = await database;
//
//       var columns = await db.rawQuery('PRAGMA table_info(sell);');
//       bool hasTipType = columns.any((column) => column['name'] == 'tip_type');
//       var paymentColumns = await db.rawQuery('PRAGMA table_info(sell_payments);');
//       bool hasCardDetails = paymentColumns.any((column) => column['name'] == 'card_details');
//       bool hasResTableId = columns.any((column) => column['name'] == 'res_table_id');   //new add
//       bool hasIsShipping = columns.any((column) => column['name'] == 'is_shipping');//new add
//       // print('Schema check: tip_type=$hasTipType, card_details=$hasCardDetails, res_table_id=$hasResTableId, is_shipping=$hasIsShipping'); //new add
//       bool hasSaleStatus = columns.any((column) => column['name'] == 'sale_status'); //new add
//       print('Schema check: tip_type=$hasTipType, card_details=$hasCardDetails, res_table_id=$hasResTableId, is_shipping=$hasIsShipping, sale_status=$hasSaleStatus'); //new add
//       print('Schema check: tip_type column exists = $hasTipType, card_details column exists = $hasCardDetails');
//       // return hasTipType && hasCardDetails;
//       return hasTipType && hasCardDetails && hasSaleStatus;
//     } catch (e) {
//       print('Error checking schema: $e');
//       return false;
//     }
//   }
//   // Add these methods to your DbProvider class
//   Future<void> clearUserData(int userId) async {
//     final db = await database;
//
//     // Start a transaction
//     await db.transaction((txn) async {
//       // Delete all user-specific data
//       await txn.delete('sell', where: 'user_id = ?', whereArgs: [userId]);
//       await txn.delete('sell_lines');
//       await txn.delete('sell_payments');
//
//       // Keep system, contact, and product data as they're shared
//     });
//   }
//
//   Future<void> deleteUserDatabase(int userId) async {
//     // Close the existing database connection if open
//     if (_database != null) {
//       await _database!.close();
//       _database = null;
//     }
//
//     // Delete the physical database file
//     Directory posDirectory = await getApplicationDocumentsDirectory();
//     String path = join(posDirectory.path, 'PosDemo$userId.db');
//     if (await File(path).exists()) {
//       await File(path).delete();
//     }
//   }
//
//   //new added
//   Future<void> resetProblematicData() async {
//     try {
//       final db = await database;
//
//       // Delete any sell_lines that reference non-existent sells
//       await db.rawDelete('''
//       DELETE FROM sell_lines
//       WHERE sell_id NOT IN (SELECT id FROM sells)
//     ''');
//
//       debugPrint('Cleaned up orphaned sell_lines');
//
//     } catch (e) {
//       debugPrint('Error resetting problematic data: $e');
//     }
//   }
// }

// import 'dart:async';
// import 'dart:io';
//
// import 'package:path/path.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:sqflite/sqflite.dart';
//
// import '../pages/login.dart';
//
// class DbProvider {
//   DbProvider();
//
//   DbProvider._createInstance();
//
//   static final DbProvider db = DbProvider._createInstance();
//   static Database? _database;
//
//   // Query to create system table (location, brand, category, taxRate)
//   String createSystemTable =
//       "CREATE TABLE system (id INTEGER PRIMARY KEY AUTOINCREMENT, keyId INTEGER DEFAULT null,"
//       " key TEXT, value TEXT)";
//
//   // Query to create contact table
//   String createContactTable =
//       "CREATE TABLE contact (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, city TEXT, state TEXT,"
//       " country TEXT, address_line_1 TEXT, address_line_2 TEXT, zip_code TEXT, mobile TEXT)";
//
//   // Query to create variation table
//   String createVariationTable =
//       "CREATE TABLE variations (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER,"
//       " variation_id INTEGER, product_name TEXT, product_variation_name TEXT, variation_name TEXT,"
//       " display_name TEXT, sku TEXT, sub_sku TEXT, type TEXT, enable_stock INTEGER,"
//       " brand_id INTEGER, unit_id INTEGER, category_id INTEGER, sub_category_id INTEGER,"
//       " tax_id INTEGER, default_sell_price REAL, sell_price_inc_tax REAL, product_image_url TEXT,"
//       " selling_price_group BLOB DEFAULT null, product_description TEXT)";
//
//   // Query to create variation by location table
//   String createVariationByLocationTable =
//       "CREATE TABLE variations_location_details (id INTEGER PRIMARY KEY AUTOINCREMENT,"
//       " product_id INTEGER, variation_id INTEGER, location_id INTEGER, qty_available REAL)";
//
//   // Query to create product available in location table
//   String createProductAvailableInLocationTable =
//       "CREATE TABLE product_locations (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER,"
//       " location_id INTEGER)";
//
//   // Query to create sell table in database
//   String createSellTable =
//       "CREATE TABLE sell (id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_date TEXT, invoice_no TEXT,"
//       " contact_id INTEGER, location_id INTEGER, status TEXT, tax_rate_id INTEGER, discount_amount REAL,"
//       " discount_type TEXT, sale_note TEXT, staff_note TEXT, shipping_details TEXT, is_quotation INTEGER DEFAULT 0,"
//       " shipping_charges REAL DEFAULT 0.00, tip_amount REAL, tip_type TEXT, invoice_amount REAL, change_return REAL DEFAULT 0.00,"
//       " pending_amount REAL DEFAULT 0.00, is_synced INTEGER, transaction_id INTEGER DEFAULT null, invoice_url TEXT DEFAULT null)";
//
//   // Query to create sell line table in database
//   String createSellLineTable =
//       "CREATE TABLE sell_lines (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
//       " product_id INTEGER, variation_id INTEGER, quantity REAL, unit_price REAL,"
//       " tax_rate_id INTEGER, discount_amount REAL, discount_type TEXT, note TEXT,"
//       " is_completed INTEGER, product_order_category TEXT DEFAULT 'BAR')";
//
//   // Query to create payment line table in database
//   String createSellPaymentsTable =
//       "CREATE TABLE sell_payments (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
//       " payment_id INTEGER DEFAULT null, method TEXT, amount REAL, note TEXT,"
//       " account_id INTEGER DEFAULT null, is_return INTEGER DEFAULT 0, received_amount REAL, change_return REAL)";
//
//   // Get database of type Future<Database>
//   Future<Database> get database async {
//     // If database doesn't exist, create one
//     if (_database == null) {
//       _database = await initializeDatabase(USERID);
//     }
//     // If database exists, return database
//     return _database!;
//   }
//
//   int currVersion = 8; // Incremented version to trigger migration
//
//   // Create tables during the creation of the database itself
//   Future<Database> initializeDatabase(loginUserId) async {
//     Directory posDirectory = await getApplicationDocumentsDirectory();
//     String path = join(posDirectory.path, 'PosDemo$loginUserId.db');
//     return await openDatabase(
//       path,
//       version: currVersion,
//       onCreate: (Database db, int version) async {
//         await db.execute(createSystemTable);
//         await db.execute(createContactTable);
//         await db.execute(createVariationTable);
//         await db.execute(createVariationByLocationTable);
//         await db.execute(createProductAvailableInLocationTable);
//         await db.execute(createSellTable);
//         await db.execute(createSellLineTable);
//         await db.execute(createSellPaymentsTable);
//       },
//       onUpgrade: (db, oldVersion, newVersion) async {
//         if (oldVersion < 2) {
//           await db.execute("ALTER TABLE sell_lines RENAME TO prev_sell_line;");
//           await db.execute(createSellLineTable);
//           await db.execute("INSERT INTO sell_lines SELECT *, 'BAR' AS product_order_category FROM prev_sell_line;");
//         }
//
//         if (oldVersion < 3) {
//           await db.execute("ALTER TABLE variations RENAME TO prev_variations;");
//           await db.execute(createVariationTable);
//           await db.execute("INSERT INTO variations SELECT * FROM prev_variations;");
//         }
//
//         if (oldVersion < 4) {
//           await db.execute(createContactTable);
//         }
//
//         if (oldVersion < 5) {
//           await db.execute("ALTER TABLE sell ADD COLUMN invoice_url TEXT DEFAULT null;");
//         }
//
//         if (oldVersion < 6) {
//           await db.execute(
//               "ALTER TABLE sell_payments ADD COLUMN account_id INTEGER DEFAULT null;");
//         }
//
//         if (oldVersion < 7) {
//           await db.execute("ALTER TABLE sell ADD COLUMN tip_amount REAL;");
//           await db.execute("ALTER TABLE sell ADD COLUMN tip_type TEXT DEFAULT 'fixed';");
//         }
//
//         if (oldVersion < 8) {
//           await db.execute("ALTER TABLE sell_lines ADD COLUMN product_order_category TEXT DEFAULT 'BAR';");
//           await db.execute("ALTER TABLE sell_payments ADD COLUMN received_amount REAL;");
//           await db.execute("ALTER TABLE sell_payments ADD COLUMN change_return REAL;");
//         }
//
//         await db.setVersion(currVersion);
//       },
//     );
//   }
//
//   Future<bool> checkSchema() async {
//     try {
//       final db = await database;
//       var columns = await db.rawQuery('PRAGMA table_info(sell);');
//       bool hasTipType = columns.any((column) => column['name'] == 'tip_type');
//       print('Schema check: tip_type column exists = $hasTipType');
//       return hasTipType;
//     } catch (e) {
//       print('Error checking schema: $e');
//       return false;
//     }
//   }
// }

import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../pages/login.dart';

class DbProvider {
  DbProvider();

  DbProvider._createInstance();

  static final DbProvider db = DbProvider._createInstance();

  static Database? _database;

  // Query to create system table (location, brand, category, taxRate)
  String createSystemTable =
      "CREATE TABLE system (id INTEGER PRIMARY KEY AUTOINCREMENT, keyId INTEGER DEFAULT null,"
      " key TEXT, value TEXT)";

  // Query to create contact table
  String createContactTable =
      "CREATE TABLE contact (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, city TEXT, state TEXT,"
      " country TEXT, address_line_1 TEXT, address_line_2 TEXT, zip_code TEXT, mobile TEXT)";

  // Query to create variation table
  String createVariationTable =
      "CREATE TABLE variations (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER,"
      " variation_id INTEGER, product_name TEXT, product_variation_name TEXT, variation_name TEXT,"
      " display_name TEXT, sku TEXT, sub_sku TEXT, type TEXT, enable_stock INTEGER,"
      " brand_id INTEGER, unit_id INTEGER, category_id INTEGER, sub_category_id INTEGER,"
      " tax_id INTEGER, default_sell_price REAL, sell_price_inc_tax REAL, product_image_url TEXT,"
      " selling_price_group BLOB DEFAULT null, product_description TEXT)";

  // Query to create variation by location table
  String createVariationByLocationTable =
      "CREATE TABLE variations_location_details (id INTEGER PRIMARY KEY AUTOINCREMENT,"
      " product_id INTEGER, variation_id INTEGER, location_id INTEGER, qty_available REAL)";

  // Query to create product available in location table
  String createProductAvailableInLocationTable =
      "CREATE TABLE product_locations (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER,"
      " location_id INTEGER)";

  // Query to create sell table in database
  String createSellTable =
      "CREATE TABLE sell (id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_date TEXT, invoice_no TEXT,"
      " contact_id INTEGER, location_id INTEGER, status TEXT, tax_rate_id INTEGER, discount_amount REAL,"
      " discount_type TEXT, sale_note TEXT, staff_note TEXT, shipping_details TEXT, is_quotation INTEGER DEFAULT 0,"
      " shipping_charges REAL DEFAULT 0.00, tip_amount REAL, tip_type TEXT, invoice_amount REAL, change_return REAL DEFAULT 0.00,"
      " pending_amount REAL DEFAULT 0.00, is_synced INTEGER, transaction_id INTEGER DEFAULT null, invoice_url TEXT DEFAULT null,"
  // " res_table_id INTEGER, is_shipping INTEGER DEFAULT 0)";   //here added res_table_id and is_shipping
      " res_table_id INTEGER, is_shipping INTEGER DEFAULT 0, sale_status TEXT DEFAULT 'final')";   //here added res_table_id, is_shipping, and sale_status

  // Query to create sell line table in database
  String createSellLineTable =
  // "CREATE TABLE sell_lines (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
  // " product_id INTEGER, variation_id INTEGER, quantity REAL, unit_price REAL,"
  // " tax_rate_id INTEGER, discount_amount REAL, discount_type TEXT, note TEXT,"
  // " is_completed INTEGER, product_order_category TEXT DEFAULT 'BAR')";
      "CREATE TABLE sell_lines (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
      " product_id INTEGER, variation_id INTEGER, quantity REAL, unit_price REAL,"
      " tax_rate_id INTEGER, discount_amount REAL, discount_type TEXT, note TEXT,"
      " is_completed INTEGER, product_order_category TEXT DEFAULT 'BAR', res_table_id INTEGER,"
      " is_shipping INTEGER DEFAULT 0, FOREIGN KEY (sell_id) REFERENCES sell(id))";

  // Query to create payment line table in database
  String createSellPaymentsTable =
      "CREATE TABLE sell_payments (id INTEGER PRIMARY KEY AUTOINCREMENT, sell_id INTEGER,"
      " payment_id INTEGER DEFAULT null, method TEXT, amount REAL, note TEXT,"
      " account_id INTEGER DEFAULT null, is_return INTEGER DEFAULT 0, received_amount REAL, change_return REAL,"
      " card_details TEXT)"; // Added card_details TEXT column

  // Get database of type Future<Database>
  Future<Database> get database async {
    // If database doesn't exist, create one
    if (_database == null) {
      _database = await initializeDatabase(USERID);
    }
    // If database exists, return database
    return _database!;
  }

  // Optimized database access with connection pooling
  static final Map<String, Database> _databasePool = {};

  Future<Database> getOptimizedDatabase() async {
    String dbKey = 'PosDemo$USERID';

    if (_databasePool.containsKey(dbKey)) {
      return _databasePool[dbKey]!;
    }

    Database db = await initializeDatabase(USERID);
    _databasePool[dbKey] = db;
    return db;
  }

  // int currVersion = 11; // Incremented version to trigger migration
  int currVersion = 12; // Incremented version to trigger migration

  // Create tables during the creation of the database itself
  Future<Database> initializeDatabase(loginUserId) async {
    Directory posDirectory = await getApplicationDocumentsDirectory();
    String path = join(posDirectory.path, 'PosDemo$loginUserId.db');
    // String path = join(posDirectory.path, 'PosDemo.db');
    return await openDatabase(
      path,
      version: currVersion,
      onCreate: (Database db, int version) async {
        // Execute all table creation in a single transaction for better performance
        await db.transaction((txn) async {
          // Create tables in optimized order (most used first)
          await txn.execute(createSystemTable);
          await txn.execute(createSellTable);
          await txn.execute(createSellLineTable);
          await txn.execute(createSellPaymentsTable);
          await txn.execute(createContactTable);
          await txn.execute(createVariationTable);
          await txn.execute(createVariationByLocationTable);
          await txn.execute(createProductAvailableInLocationTable);
        });
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute("ALTER TABLE sell_lines RENAME TO prev_sell_line;");
          await db.execute(createSellLineTable);
          await db.execute("INSERT INTO sell_lines SELECT *, 'BAR' AS product_order_category FROM prev_sell_line;");
        }

        if (oldVersion < 3) {
          await db.execute("ALTER TABLE variations RENAME TO prev_variations;");
          await db.execute(createVariationTable);
          await db.execute("INSERT INTO variations SELECT * FROM prev_variations;");
        }

        if (oldVersion < 4) {
          await db.execute(createContactTable);
        }

        if (oldVersion < 5) {
          await db.execute("ALTER TABLE sell ADD COLUMN invoice_url TEXT DEFAULT null;");
        }

        if (oldVersion < 6) {
          await db.execute(
              "ALTER TABLE sell_payments ADD COLUMN account_id INTEGER DEFAULT null;");
        }

        if (oldVersion < 7) {
          await db.execute("ALTER TABLE sell ADD COLUMN tip_amount REAL;");
          await db.execute("ALTER TABLE sell ADD COLUMN tip_type TEXT DEFAULT 'fixed';");
        }

        if (oldVersion < 8) {
          await db.execute("ALTER TABLE sell_lines ADD COLUMN product_order_category TEXT DEFAULT 'BAR';");
          await db.execute("ALTER TABLE sell_payments ADD COLUMN received_amount REAL;");
          await db.execute("ALTER TABLE sell_payments ADD COLUMN change_return REAL;");
        }

        if (oldVersion < 9) {
          await db.execute("ALTER TABLE sell_payments ADD COLUMN card_details TEXT;");
        }

        if (oldVersion < 10) {
          // Add res_table_id and is_shipping columns to sell table
          await db.execute("ALTER TABLE sell ADD COLUMN res_table_id INTEGER DEFAULT null;");
          await db.execute("ALTER TABLE sell ADD COLUMN is_shipping INTEGER DEFAULT 0;");
        }

        if (oldVersion < 11) {
          await db.execute("ALTER TABLE sell_lines ADD COLUMN res_table_id INTEGER DEFAULT null;");
          await db.execute("ALTER TABLE sell_lines ADD COLUMN is_shipping INTEGER DEFAULT 0;");
          // Update existing shipping sales to set res_table_id = 0 and is_shipping = 1
          await db.execute("UPDATE sell SET res_table_id = 0, is_shipping = 1 WHERE res_table_id IS NULL;");
          await db.execute("UPDATE sell_lines SET res_table_id = 0, is_shipping = 1 WHERE res_table_id IS NULL;");
        }

        if (oldVersion < 12) {
          // Add sale_status field to sell table for draft functionality
          await db.execute("ALTER TABLE sell ADD COLUMN sale_status TEXT DEFAULT 'final';");
        }

        // Version 12 - 15: only update DB version without new columns/tables
        // v12 to v15: No new columns/tables, just set version
        if (oldVersion < 15) {
          print("Database upgraded to version 15 without schema changes.");
        }

        await db.setVersion(currVersion);
      },
    );
  }

  Future<bool> checkSchema() async {
    try {
      final db = await database;

      var columns = await db.rawQuery('PRAGMA table_info(sell);');
      bool hasTipType = columns.any((column) => column['name'] == 'tip_type');
      var paymentColumns = await db.rawQuery('PRAGMA table_info(sell_payments);');
      bool hasCardDetails = paymentColumns.any((column) => column['name'] == 'card_details');
      bool hasResTableId = columns.any((column) => column['name'] == 'res_table_id');   //new add
      bool hasIsShipping = columns.any((column) => column['name'] == 'is_shipping');//new add
      // print('Schema check: tip_type=$hasTipType, card_details=$hasCardDetails, res_table_id=$hasResTableId, is_shipping=$hasIsShipping'); //new add
      bool hasSaleStatus = columns.any((column) => column['name'] == 'sale_status'); //new add
      print('Schema check: tip_type=$hasTipType, card_details=$hasCardDetails, res_table_id=$hasResTableId, is_shipping=$hasIsShipping, sale_status=$hasSaleStatus'); //new add
      print('Schema check: tip_type column exists = $hasTipType, card_details column exists = $hasCardDetails');
      // return hasTipType && hasCardDetails;
      return hasTipType && hasCardDetails && hasSaleStatus;
    } catch (e) {
      print('Error checking schema: $e');
      return false;
    }
  }
  // Add these methods to your DbProvider class
  Future<void> clearUserData(int userId) async {
    final db = await database;

    // Start a transaction
    await db.transaction((txn) async {
      // Delete all user-specific data
      await txn.delete('sell', where: 'user_id = ?', whereArgs: [userId]);
      await txn.delete('sell_lines');
      await txn.delete('sell_payments');

      // Keep system, contact, and product data as they're shared
    });
  }

  Future<void> deleteUserDatabase(int userId) async {
    // Close the existing database connection if open
    if (_database != null) {
      await _database!.close();
      _database = null;
    }

    // Delete the physical database file
    Directory posDirectory = await getApplicationDocumentsDirectory();
    String path = join(posDirectory.path, 'PosDemo$userId.db');
    if (await File(path).exists()) {
      await File(path).delete();
    }
  }

  //new added
  Future<void> resetProblematicData() async {
    try {
      final db = await database;

      // Delete any sell_lines that reference non-existent sells
      await db.rawDelete('''
      DELETE FROM sell_lines 
      WHERE sell_id NOT IN (SELECT id FROM sells)
    ''');

      debugPrint('Cleaned up orphaned sell_lines');

    } catch (e) {
      debugPrint('Error resetting problematic data: $e');
    }
  }

  /// Reset the database instance to force recreation
  static void resetDatabase() {
    if (_database != null) {
      _database!.close();
      _database = null;
    }
    debugPrint('Database instance reset - will be recreated on next access');
  }

  /// Complete database cleanup for session reset
  Future<void> clearAllTables() async {
    try {
      final db = await database;

      // Disable foreign key constraints temporarily
      await db.execute('PRAGMA foreign_keys = OFF');

      // Clear all tables in proper order
      await db.delete('sell_payments');
      await db.delete('sell_lines');
      await db.delete('sells');
      await db.delete('sell'); // Legacy table name
      await db.delete('contact');
      await db.delete('variations_location_details');
      await db.delete('variations');
      await db.delete('product_locations');
      await db.delete('system');

      // Re-enable foreign key constraints
      await db.execute('PRAGMA foreign_keys = ON');

      debugPrint('✅ All database tables cleared successfully');
    } catch (e) {
      debugPrint('❌ Error clearing database tables: $e');
      rethrow;
    }
  }
}