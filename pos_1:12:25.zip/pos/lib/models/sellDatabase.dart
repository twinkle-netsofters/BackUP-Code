// import 'database.dart';
// import 'system.dart';
//
// class SellDatabase {
//   late DbProvider dbProvider;
//
//   SellDatabase() {
//     dbProvider = DbProvider(); // Initialize DbProvider for database access
//   }
//
//   // Add item to cart (insert into sell_lines table)
//   Future<int> store(Map<String, dynamic> value) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.insert('sell_lines', value);
//       print('Stored sell_line: ${value['variation_id']} for sell_id: ${value['sell_id']}');
//       return response;
//     } catch (e) {
//       print('Error storing sell_line: $e');
//       rethrow; // Rethrow to allow caller to handle the error
//     }
//   }
//
//   // Check presence of incomplete sellLine by variationId
//   Future<List> checkSellLine(int varId, {int? sellId}) async {
//     try {
//       var where;
//       var arg = sellId ?? 0;
//       where = sellId == null ? 'is_completed = ?' : 'sell_id = ?';
//       final db = await dbProvider.database;
//       var response = await db.query(
//         'sell_lines',
//         where: '$where and variation_id = ?',
//         whereArgs: [arg, varId],
//       );
//       return response;
//     } catch (e) {
//       print('Error checking sell_line for variation_id: $varId, sellId: $sellId: $e');
//       return [];
//     }
//   }
//
//   // Fetch sell_lines by sell_id
//   Future<List> getSellLines(int sellId) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.query(
//         'sell_lines',
//         columns: [
//           'product_id',
//           'variation_id',
//           'quantity',
//           'unit_price',
//           'tax_rate_id',
//           'discount_amount',
//           'discount_type',
//           'note',
//           'product_order_category',
//         ],
//         where: 'sell_id = ?',
//         whereArgs: [sellId],
//       );
//       return response;
//     } catch (e) {
//       print('Error fetching sell_lines for sell_id: $sellId: $e');
//       return [];
//     }
//   }
//
//   // Fetch incomplete sell_lines for a location or specific sell_id
//   Future<List> getInCompleteLines(int locationId, {int? sellId}) async {
//     try {
//       String where = 'is_completed = 0';
//       if (sellId != null) where = 'sell_id = $sellId';
//
//       // Get product last sync datetime
//       String productLastSync = await System().getProductLastSync();
//
//       final db = await dbProvider.database;
//       List res = await db.rawQuery(
//         'SELECT DISTINCT SL.*, V.display_name AS name, V.sell_price_inc_tax,'
//             ' CASE WHEN (qty_available IS NULL AND enable_stock = 0) THEN 9999 '
//             ' WHEN (qty_available IS NULL AND enable_stock = 1) THEN 0 '
//             ' ELSE (qty_available - COALESCE('
//             ' (SELECT SUM(SL2.quantity) FROM sell_lines AS SL2 JOIN sell AS S on SL2.sell_id = S.id'
//             ' WHERE (SL2.is_completed = 0 OR S.transaction_date > "$productLastSync") AND S.location_id = $locationId AND SL2.variation_id=V.variation_id)'
//             ', 0))'
//             ' END as "stock_available" '
//             ' FROM "sell_lines" AS SL JOIN "variations" AS V on (SL.variation_id = V.variation_id) '
//             ' LEFT JOIN "variations_location_details" as VLD '
//             ' ON SL.variation_id = VLD.variation_id AND SL.product_id = VLD.product_id AND VLD.location_id = $locationId '
//             ' WHERE $where',
//       );
//       return res;
//     } catch (e) {
//       print('Error fetching incomplete sell_lines for location_id: $locationId, sellId: $sellId: $e');
//       return [];
//     }
//   }
//
//   // Fetch sell_lines (completed or incomplete) by sell_id or completion status
//   Future<List> get({int? isCompleted, int? sellId}) async {
//     try {
//       String where;
//       if (sellId != null) {
//         where = 'sell_id = $sellId';
//       } else {
//         where = 'is_completed = $isCompleted';
//       }
//       final db = await dbProvider.database;
//       List res = await db.rawQuery(
//         'SELECT DISTINCT SL.*,V.display_name as name,V.sell_price_inc_tax,V.sub_sku,'
//             'V.default_sell_price FROM "sell_lines" as SL JOIN "variations" as V '
//             'on (SL.variation_id = V.variation_id) '
//             'where $where',
//       );
//       return res;
//     } catch (e) {
//       print('Error fetching sell_lines for sellId: $sellId, isCompleted: $isCompleted: $e');
//       return [];
//     }
//   }
//
//   // Update sell_lines by variationId
//   Future<int> update(int sellLineId, Map<String, dynamic> value) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.update(
//         'sell_lines',
//         value,
//         where: 'id = ?',
//         whereArgs: [sellLineId],
//       );
//       return response;
//     } catch (e) {
//       print('Error updating sell_line id: $sellLineId: $e');
//       return 0;
//     }
//   }
//
//   // Update sell_lines after creating a sell
//   Future<int> updateSellLine(Map<String, dynamic> value) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.update(
//         'sell_lines',
//         value,
//         where: 'is_completed = ?',
//         whereArgs: [0],
//       );
//       return response;
//     } catch (e) {
//       print('Error updating sell_lines for incomplete sales: $e');
//       return 0;
//     }
//   }
//
//   // Delete sell_line by variation_id and product_id
//   Future<int> delete(int varId, int prodId, {int? sellId}) async {
//     try {
//       String where;
//       var args;
//       if (sellId == null) {
//         where = 'is_completed = ? and variation_id = ? and product_id = ?';
//         args = [0, varId, prodId];
//       } else {
//         where = 'sell_id = ? and variation_id = ? and product_id = ?';
//         args = [sellId, varId, prodId];
//       }
//       final db = await dbProvider.database;
//       var response = await db.delete('sell_lines', where: where, whereArgs: args);
//       return response;
//     } catch (e) {
//       print('Error deleting sell_line for variation_id: $varId, product_id: $prodId, sellId: $sellId: $e');
//       return 0;
//     }
//   }
//
//   // Delete sell_line by sell_id
//   Future<int> deleteSellLineBySellId(int sellId) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.delete(
//         'sell_lines',
//         where: 'sell_id = ?',
//         whereArgs: [sellId],
//       );
//       return response;
//     } catch (e) {
//       print('Error deleting sell_lines for sell_id: $sellId: $e');
//       return 0;
//     }
//   }
//
//   // Create sell (insert into sell table)
//   Future<int> storeSell(Map<String, dynamic> value) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.insert('sell', value);
//       print('Stored sell with id: $response');
//       return response;
//     } catch (e) {
//       print('Error storing sell: $e');
//       rethrow; // Rethrow to allow caller (e.g., createSellDraft) to handle
//     }
//   }
//
//   // Empty sells and sell details
//   Future<void> deleteSellTables() async {
//     try {
//       final db = await dbProvider.database;
//       await db.delete('sell');
//       await db.delete('sell_lines');
//       await db.delete('sell_payments');
//       print('Deleted all sell, sell_lines, and sell_payments');
//     } catch (e) {
//       print('Error deleting sell tables: $e');
//     }
//   }
//
//   // Fetch current sales from database
//   Future<List> getSells({bool? all}) async {
//     try {
//       final db = await dbProvider.database;
//       var response = all == true
//           ? await db.query('sell', orderBy: 'id DESC')
//           : await db.query(
//         'sell',
//         orderBy: 'id DESC',
//         where: 'is_quotation = ?',
//         whereArgs: [0],
//       );
//       return response;
//     } catch (e) {
//       print('Error fetching sells, all: $all: $e');
//       return [];
//     }
//   }
//
//   // Fetch transactionIds of synced sales from sell table
//   Future<List> getTransactionIds() async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.query(
//         'sell',
//         columns: ['transaction_id'],
//         where: 'transaction_id != ?',
//         whereArgs: ['null'],
//       );
//       var ids = response.map((element) => element['transaction_id']).toList();
//       return ids;
//     } catch (e) {
//       print('Error fetching transaction IDs: $e');
//       return [];
//     }
//   }
//
//   // Fetch sales by sellId
//   Future<List> getSellBySellId(int sellId) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.query(
//         'sell',
//         where: 'id = ?',
//         whereArgs: [sellId],
//       );
//       return response;
//     } catch (e) {
//       print('Error fetching sell by sellId: $sellId: $e');
//       return [];
//     }
//   }
//
//   // Fetch sales by TransactionId
//   Future<List> getSellByTransactionId(String transactionId) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.query(
//         'sell',
//         where: 'transaction_id = ?',
//         whereArgs: [transactionId],
//       );
//       return response;
//     } catch (e) {
//       print('Error fetching sell by transactionId: $transactionId: $e');
//       return [];
//     }
//   }
//
//   // Fetch not synced sales
//   Future<List> getNotSyncedSells() async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.query('sell', where: 'is_synced = 0');
//       return response;
//     } catch (e) {
//       print('Error fetching not synced sells: $e');
//       return [];
//     }
//   }
//
//   // Update sale
//   Future<int> updateSells(int sellId, Map<String, dynamic> value) async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.update(
//         'sell',
//         value,
//         where: 'id = ?',
//         whereArgs: [sellId],
//       );
//       return response;
//     } catch (e) {
//       print('Error updating sell id: $sellId: $e');
//       return 0;
//     }
//   }
//
//   // Delete all lines where is_completed = 0
//   Future<int> deleteInComplete() async {
//     try {
//       final db = await dbProvider.database;
//       var response = await db.delete(
//         'sell_lines',
//         where: 'is_completed = ?',
//         whereArgs: [0],
//       );
//       return response;
//     } catch (e) {
//       print('Error deleting incomplete sell_lines: $e');
//       return 0;
//     }
//   }
//
//   // Count sell_lines (for cart item count)
//   Future<String> countSellLines({int? isCompleted, int? sellId}) async {
//     try {
//       String where = sellId != null ? 'sell_id = $sellId' : 'is_completed = 0';
//       final db = await dbProvider.database;
//       var response = await db.rawQuery(
//         'SELECT COUNT(*) AS counts FROM sell_lines WHERE $where',
//       );
//       return response[0]['counts'].toString();
//     } catch (e) {
//       print('Error counting sell_lines for sellId: $sellId, isCompleted: $isCompleted: $e');
//       return '0';
//     }
//   }
//
//   // Fetch sell_lines by sell_id for cart
//   Future<List<Map>> getSellLineBySellId(int sellId) async {
//     try {
//       final db = await dbProvider.database;
//       return await db.query(
//         'sell_lines',
//         where: 'sell_id = ? AND is_completed = ?',
//         whereArgs: [sellId, 0],
//       );
//     } catch (e) {
//       print('Error fetching sell_lines by sellId: $sellId: $e');
//       return [];
//     }
//   }
// }


import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../apis/sell.dart';
import '../locale/MyLocalizations.dart';
import 'database.dart';
import 'system.dart';

class SellDatabase {
  late DbProvider dbProvider;

  SellDatabase() {
    dbProvider = DbProvider();
  }

  Future<Database> get database async => await dbProvider.database;

  Future<int> store(Map<String, dynamic> value) async {
    await initDatabase(); // Ensure tables exist

    try {
      final db = await database;
      var response = await db.insert('sell_lines', value);
      print('Stored sell_line: ${value['variation_id']} for sell_id: ${value['sell_id']},res_table_id=${value['res_table_id']}');
      return response;
    } catch (e, stackTrace) {
      print('Error storing sell_line: $e');
      debugPrint('Stack trace: $stackTrace');
      rethrow;
    }
  }

  Future<List> checkSellLine(int varId, {int? sellId, int? res_table_id}) async {
    try {
      if (sellId == null && res_table_id != null) {
        List sales = await getSellsByTableId(res_table_id);
        if (sales.isEmpty) {
          print('checkSellLine: No sales found for res_table_id: $res_table_id');
          return [];
        }
        if (sales.length > 1) {
          print('Warning: Multiple sales found for res_table_id: $res_table_id. Using most recent.');
        }
        sellId = sales.first['id'];
      }
      if (sellId == null) {
        print('Error: sellId is null in checkSellLine');
        return [];
      }
      final db = await database;
      var response = await db.query(
        'sell_lines',
        where: 'sell_id = ? AND variation_id = ? AND is_completed = ?',
        whereArgs: [sellId, varId, 0],
      );
      return response;
    } catch (e) {
      print('Error checking sell_line for variation_id: $varId, sellId: $sellId, res_table_id: $res_table_id: $e');
      return [];
    }
  }

  Future<List> getSellLines(int sellId, {int? res_table_id}) async {
    try {
      final db = await database;
      var response = await db.query(
        'sell_lines',
        columns: [
          'product_id',
          'variation_id',
          'quantity',
          'unit_price',
          'tax_rate_id',
          'discount_amount',
          'discount_type',
          'note',
          'product_order_category',
        ],
        where: 'sell_id = ?',
        whereArgs: [sellId],
      );
      return response;
    } catch (e) {
      print('Error fetching sell_lines for sell_id: $sellId: $e res_table_id: $res_table_id: $e');
      return [];
    }
  }

  // Future<List> getInCompleteLines(int locationId, {int? sellId, int? resTableId}) async {
  //   try {
  //     String where = 'is_completed = 0';
  //     if (sellId != null) where = 'sell_id = $sellId';
  //     String productLastSync = await System().getProductLastSync();
  //     final db = await database;
  //     List res = await db.rawQuery(
  //       'SELECT DISTINCT SL.*, V.display_name AS name, V.sell_price_inc_tax,'
  //           ' CASE WHEN (qty_available IS NULL AND enable_stock = 0) THEN 9999 '
  //           ' WHEN (qty_available IS NULL AND enable_stock = 1) THEN 0 '
  //           ' ELSE (qty_available - COALESCE('
  //           ' (SELECT SUM(SL2.quantity) FROM sell_lines AS SL2 JOIN sell AS S on SL2.sell_id = S.id'
  //           ' WHERE (SL2.is_completed = 0 OR S.transaction_date > "$productLastSync") AND S.location_id = $locationId AND SL2.variation_id=V.variation_id)'
  //           ', 0))'
  //           ' END as "stock_available" '
  //           ' FROM "sell_lines" AS SL JOIN "variations" AS V on (SL.variation_id = V.variation_id) '
  //           ' LEFT JOIN "variations_location_details" as VLD '
  //           ' ON SL.variation_id = VLD.variation_id AND SL.product_id = VLD.product_id AND VLD.location_id = $locationId '
  //           ' WHERE $where',
  //     );
  //     return res;
  //   } catch (e) {
  //     print('Error fetching incomplete sell_lines for location_id: $locationId, sellId: $sellId: $e');
  //     return [];
  //   }
  // }
  // Modified to properly handle resTableId filtering and optimize query
  Future<List> getInCompleteLines(int locationId, {int? sellId, int? resTableId}) async {
    try {
      final db = await database;
      String query = '''
        SELECT DISTINCT SL.*, V.display_name AS name, V.sell_price_inc_tax,
        CASE WHEN (VLD.qty_available IS NULL AND V.enable_stock = 0) THEN 9999
             WHEN (VLD.qty_available IS NULL AND V.enable_stock = 1) THEN 0
             ELSE (VLD.qty_available - COALESCE(
               (SELECT SUM(SL2.quantity) 
                FROM sell_lines AS SL2 
                JOIN sells AS S ON SL2.sell_id = S.id
                WHERE (SL2.is_completed = 0 OR S.transaction_date > ?) 
                  AND S.location_id = ? 
                  AND SL2.variation_id = V.variation_id), 0))
        END as "stock_available"
        FROM sell_lines AS SL
        JOIN variations AS V ON SL.variation_id = V.variation_id
        LEFT JOIN variations_location_details AS VLD 
          ON SL.variation_id = VLD.variation_id 
          AND SL.product_id = VLD.product_id 
          AND VLD.location_id = ?
        WHERE SL.is_completed = 0
      ''';
      List<dynamic> args = [await System().getProductLastSync(), locationId, locationId];

      if (sellId != null) {
        query += ' AND SL.sell_id = ?';
        args.add(sellId);
      }

      if (resTableId != null) {
        query += ' AND SL.res_table_id = ?';
        args.add(resTableId);
      }

      List res = await db.rawQuery(query, args);
      debugPrint('getInCompleteLines:  Args=$args, Result=$res');
      return res;
    } catch (e) {
      debugPrint('Error fetching incomplete sell_lines for location_id=$locationId, sellId=$sellId, resTableId=$resTableId: $e');
      return [];
    }
  }

  // Future<List> get({int? isCompleted, int? sellId}) async {
  //   try {
  //     String where = sellId != null ? 'sell_id = $sellId' : 'is_completed = $isCompleted';
  //     final db = await database;
  //     List res = await db.rawQuery(
  //       'SELECT DISTINCT SL.*,V.display_name as name,V.sell_price_inc_tax,V.sub_sku,'
  //           'V.default_sell_price FROM "sell_lines" as SL JOIN "variations" as V '
  //           'on (SL.variation_id = V.variation_id) '
  //           'where $where',
  //     );
  //     return res;
  //   } catch (e) {
  //     print('Error fetching sell_lines for sellId: $sellId, isCompleted: $isCompleted: $e');
  //     return [];
  //   }
  // }
  Future<List> get({int? isCompleted, int? sellId, int? res_table_id}) async {
    try {
      if (sellId == null && res_table_id != null) {
        List sales = await getSellsByTableId(res_table_id);
        if (sales.isEmpty) {
          print('get: No sales found for res_table_id: $res_table_id');
          return [];
        }
        if (sales.length > 1) {
          print('Warning: Multiple sales found for res_table_id: $res_table_id. Using most recent.');
        }
        sellId = sales.first['id'];
      }
      String where = sellId != null ? 'sell_id = $sellId' : 'is_completed = $isCompleted';
      final db = await database;
      List res = await db.rawQuery(
        'SELECT DISTINCT SL.*,V.display_name as name,V.sell_price_inc_tax,V.sub_sku,'
            'V.default_sell_price FROM "sell_lines" as SL JOIN "variations" as V '
            'on (SL.variation_id = V.variation_id) '
            'where $where',
      );
      return res;
    } catch (e) {
      print('Error fetching sell_lines for sellId: $sellId, res_table_id: $res_table_id, isCompleted: $isCompleted: $e');
      return [];
    }
  }

  Future<int> update(int sellLineId, Map<String, dynamic> value) async {
    try {
      final db = await database;
      var response = await db.update(
        'sell_lines',
        value,
        where: 'id = ?',
        whereArgs: [sellLineId],
      );
      print('Updated sell_line id: $sellLineId with values: ${jsonEncode(value)}');
      return response;
    } catch (e) {
      print('Error updating sell_line id: $sellLineId: $e');
      return 0;
    }
  }

  // Future<int> updateSellLine(Map<String, dynamic> value, {required int resTableId}) async {
  //   await initDatabase(); // Ensure tables exist
  //
  //   try {
  //     final db = await database;
  //     var response = await db.update(
  //       'sell_lines',
  //       value,
  //       where: 'is_completed = ?',
  //       whereArgs: [0],
  //     );
  //     debugPrint('updateSellLine: Updated incomplete sell_lines with values=${jsonEncode(value)}, resTableId=$resTableId, count=$response');
  //     return response;
  //   } catch (e) {
  //     print('Error updating sell_lines for incomplete sales: $e');
  //     return 0;
  //   }
  // }
  Future<int> updateSellLine(Map<String, dynamic> value, {int? sellId, int? resTableId}) async {
    await initDatabase();
    try {
      final db =    await database;
      String where = 'is_completed = ?';
      List<dynamic> whereArgs = [0];
      if (sellId != null) {
        where += ' AND sell_id = ?';
        whereArgs.add(sellId);
      }
      if (resTableId != null) {
        where += ' AND res_table_id = ?';
        whereArgs.add(resTableId);
      }
      var response = await db.update(
        'sell_lines',
        value,
        where: where,
        whereArgs: whereArgs,
      );
      debugPrint('updateSellLine: Updated sell_lines with values=${jsonEncode(value)}, sellId=$sellId, resTableId=$resTableId, count=$response');
      return response;
    } catch (e) {
      print('Error updating sell_lines: $e');
      return 0;
    }
  }

  // Future<int> delete(int varId, int prodId, {int? sellId}) async {
  //   try {
  //     String where;
  //     var args;
  //     if (sellId == null) {
  //       where = 'is_completed = ? and variation_id = ? and product_id = ?';
  //       args = [0, varId, prodId];
  //     } else {
  //       where = 'sell_id = ? and variation_id = ? and product_id = ?';
  //       args = [sellId, varId, prodId];
  //     }
  //     final db = await database;
  //     var response = await db.delete('sell_lines', where: where, whereArgs: args);
  //     return response;
  //   } catch (e) {
  //     print('Error deleting sell_line for variation_id: $varId, product_id: $prodId, sellId: $sellId: $e');
  //     return 0;
  //   }
  // }
  Future<int> delete(int varId, int prodId, {int? sellId, int? res_table_id}) async {
    try {
      if (sellId == null && res_table_id != null) {
        List sales = await getSellsByTableId(res_table_id);
        if (sales.isEmpty) {
          print('delete: No sales found for res_table_id: $res_table_id');
          return 0;
        }
        if (sales.length > 1) {
          print('Warning: Multiple sales found for res_table_id: $res_table_id. Using most recent.');
        }
        sellId = sales.first['id'];
      }
      String where;
      var args;
      if (sellId == null) {
        where = 'is_completed = ? and variation_id = ? and product_id = ?';
        args = [0, varId, prodId];
      } else {
        where = 'sell_id = ? and variation_id = ? and product_id = ?';
        args = [sellId, varId, prodId];
      }
      final db = await database;
      var response = await db.delete('sell_lines', where: where, whereArgs: args);
      return response;
    } catch (e) {
      print('Error deleting sell_line for variation_id: $varId, product_id: $prodId, sellId: $sellId, res_table_id: $res_table_id: $e');
      return 0;
    }
  }

  // Future<int> deleteSellLineBySellId(int sellId) async {
  //   try {
  //     final db = await database;
  //     var response = await db.delete(
  //       'sell_lines',
  //       where: 'sell_id = ?',
  //       whereArgs: [sellId],
  //     );
  //     print('Deleted sell_lines for sell_id: $sellId, count: $response');
  //     return response;
  //   } catch (e) {
  //     print('Error deleting sell_lines for sell_id: $sellId: $e');
  //     return 0;
  //   }
  // }
  Future<int> deleteSellLineBySellId(int sellId) async {
    try {
      final db = await database;
      var sellLines = await db.query('sell_lines', where: 'sell_id = ?', whereArgs: [sellId]);
      debugPrint('deleteSellLineBySellId: Deleting sell_lines for sellId=$sellId: ${jsonEncode(sellLines)}');
      var response = await db.delete(
        'sell_lines',
        where: 'sell_id = ?',
        whereArgs: [sellId],
      );
      debugPrint('deleteSellLineBySellId: Deleted $response sell_lines for sellId=$sellId');
      return response;
    } catch (e) {
      debugPrint('Error deleting sell_lines for sellId=$sellId: $e');
      return 0;
    }
  }

  Future<int> storeSell(Map<String, dynamic> value) async {
    await initDatabase(); // Ensure tables exist
    try {
      debugPrint('storeSell: Storing sell data: ${jsonEncode(value)}');
      final db = await database;
      var response = await db.insert('sell', value);
      debugPrint('Stored sell with id: $response');

      // Verify the stored data
      final storedData = await db.query('sell', where: 'id = ?', whereArgs: [response]);
      debugPrint('storeSell: Verified stored data: ${jsonEncode(storedData)}');

      return response;
    } catch (e) {
      print('Error storing sell: $e');
      rethrow;
    }
  }

  Future<void> verifySellData(int sellId) async {
    try {
      final db = await database;
      final result = await db.query(
        'sell',
        where: 'id = ?',
        whereArgs: [sellId],
      );
      debugPrint('verifySellData: Sell data for ID $sellId: $result');
      if (result.isEmpty) {
        debugPrint('verifySellData: No sell data found for ID $sellId');
      } else {
        debugPrint('verifySellData: Found sell data: ${jsonEncode(result[0])}');
      }
    } catch (e) {
      debugPrint('Error in verifySellData for sellId $sellId: $e');
    }
  }

  Future<void> deleteSellTables() async {
    try {
      final db = await database;
      await db.delete('sell');
      await db.delete('sell_lines');
      await db.delete('sell_payments');
      print('Deleted all sell, sell_lines, and sell_payments');
    } catch (e) {
      print('Error deleting sell tables: $e');
    }
  }

  // Future<List> getSells({bool? all}) async {
  //   try {
  //     final db = await database;
  //     var response = all == true
  //         ? await db.query('sell', orderBy: 'id DESC')
  //         : await db.query(
  //       'sell',
  //       orderBy: 'id DESC',
  //       where: 'is_quotation = ?',
  //       whereArgs: [0],
  //     );
  //     return response;
  //   } catch (e) {
  //     print('Error fetching sells, all: $all: $e');
  //     return [];
  //   }
  // }
  Future<List> getSells({bool? all, String? status}) async {
    try {
      final db = await database;

      if (status != null) {
        // Get sells with specific status
        return await db.query(
            'sell',
            where: 'sale_status = ?',
            whereArgs: [status],
            orderBy: 'id DESC'
        );
      } else if (all == true) {
        // Get all sells
        return await db.query('sell', orderBy: 'id DESC');
      } else {
        // Get non-quotation sells
        return await db.query(
          'sell',
          orderBy: 'id DESC',
          where: 'is_quotation = ?',
          whereArgs: [0],
        );
      }
    } catch (e) {
      print('Error fetching sells, all: $all: $e');
      return [];
    }
  }

  Future<List> getTransactionIds() async {
    try {
      final db = await database;
      var response = await db.query(
        'sell',
        columns: ['transaction_id'],
        where: 'transaction_id IS NOT NULL',
      );
      var ids = response.map((element) => element['transaction_id']).toList();
      return ids;
    } catch (e) {
      print('Error fetching transaction IDs: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> getSellBySellId(int sellId) async {
    await initDatabase(); // Ensure tables exist

    try {
      final db = await database;
      final result = await db.query(
        'sell',
        where: 'id = ?',
        whereArgs: [sellId],
      );
      debugPrint('getSellBySellId: Queried sellId: $sellId, result: $result');
      if (result.isEmpty) {
        debugPrint('getSellBySellId: No data found for sellId: $sellId');
      } else {
        debugPrint('getSellBySellId: Found data: ${jsonEncode(result)}');
      }
      return result;
    } catch (e) {
      debugPrint('Error in getSellBySellId for sellId: $sellId, error: $e');
      return [];
    }
  }

  Future<List> getSellByTransactionId(String transactionId) async {
    try {
      final db = await database;
      var response = await db.query(
        'sell',
        where: 'transaction_id = ?',
        whereArgs: [transactionId],
      );
      return response;
    } catch (e) {
      print('Error fetching sell by transactionId: $transactionId: $e');
      return [];
    }
  }

  Future<List> getNotSyncedSells() async {
    try {
      final db = await database;
      var response = await db.query('sell', where: 'is_synced = 0');
      return response;
    } catch (e) {
      print('Error fetching not synced sells: $e');
      return [];
    }
  }

  Future<int> updateSells(int sellId, Map<String, dynamic> value) async {
    await initDatabase(); // Ensure tables exist
    try {
      final db = await database;
      
      // CRITICAL: If updating sale_status, use direct SQL FIRST to ensure it works
      if (value.containsKey('sale_status') && value['sale_status'] == 'final') {
        try {
          int directRows = await db.rawUpdate(
            'UPDATE sell SET sale_status = ? WHERE id = ?',
            ['final', sellId],
          );
          debugPrint('updateSells: Direct SQL update for sale_status=final affected $directRows rows for sellId=$sellId');
          
          if (directRows == 0) {
            // Try 'sells' table
            directRows = await db.rawUpdate(
              'UPDATE sells SET sale_status = ? WHERE id = ?',
              ['final', sellId],
            );
            debugPrint('updateSells: Direct SQL update on "sells" table affected $directRows rows');
          }
          
          // Verify immediately
          var verifyDirect = await db.query('sell', where: 'id = ?', whereArgs: [sellId]);
          if (verifyDirect.isEmpty) {
            verifyDirect = await db.query('sells', where: 'id = ?', whereArgs: [sellId]);
          }
          if (verifyDirect.isNotEmpty) {
            String? statusAfterDirect = verifyDirect[0]['sale_status']?.toString();
            debugPrint('updateSells: sale_status after direct SQL: $statusAfterDirect');
          }
        } catch (e) {
          debugPrint('updateSells: Direct SQL update for sale_status failed: $e');
        }
      }
      
      // CRITICAL: Try both table names to ensure update works
      // The actual table might be 'sell' or 'sells' depending on database state
      int response = 0;
      String actualTableName = 'sell'; // Default to 'sell' as that's what most queries use
      
      try {
        // Try 'sell' first as that's what most queries use
        response = await db.update(
          'sell',
          value,
          where: 'id = ?',
          whereArgs: [sellId],
        );
        actualTableName = 'sell';
        debugPrint('updateSells: Updated sell id: $sellId with values: ${jsonEncode(value)}, rows affected: $response');
      } catch (e) {
        debugPrint('updateSells: Failed to update table "sell", trying "sells": $e');
        try {
          response = await db.update(
            'sells',
            value,
            where: 'id = ?',
            whereArgs: [sellId],
          );
          actualTableName = 'sells';
          debugPrint('updateSells: Updated sells id: $sellId with values: ${jsonEncode(value)}, rows affected: $response');
        } catch (e2) {
          debugPrint('updateSells: Failed to update both table names: $e2');
          rethrow;
        }
      }
      
      // CRITICAL: Verify update was successful by reading back from database
      var updatedSell = await db.query(
        actualTableName,
        where: 'id = ?',
        whereArgs: [sellId],
      );
      if (updatedSell.isEmpty && actualTableName == 'sell') {
        // Try 'sells' table as fallback
        updatedSell = await db.query(
          'sells',
          where: 'id = ?',
          whereArgs: [sellId],
        );
      } else if (updatedSell.isEmpty && actualTableName == 'sells') {
        // Try 'sell' table as fallback
        updatedSell = await db.query(
          'sell',
          where: 'id = ?',
          whereArgs: [sellId],
        );
      }
      
      debugPrint('updateSells: Verified sell id: $sellId, result: ${jsonEncode(updatedSell)}');
      if (updatedSell.isNotEmpty && value.containsKey('sale_status')) {
        String? actualStatus = updatedSell[0]['sale_status']?.toString();
        String? expectedStatus = value['sale_status']?.toString();
        if (actualStatus != expectedStatus) {
          debugPrint('updateSells: WARNING - sale_status mismatch! Expected: $expectedStatus, Actual: $actualStatus');
          // CRITICAL: Try direct SQL update as fallback - try both table names
          bool rawUpdateSuccess = false;
          
          // Try 'sell' table first
          try {
            int rowsAffected = await db.rawUpdate(
              'UPDATE sell SET sale_status = ? WHERE id = ?',
              [expectedStatus, sellId],
            );
            debugPrint('updateSells: Raw SQL update on "sell" table affected $rowsAffected rows');
            
            // Verify immediately
            var verifyAfterRaw = await db.query('sell', where: 'id = ?', whereArgs: [sellId]);
            if (verifyAfterRaw.isNotEmpty) {
              String? statusAfterRaw = verifyAfterRaw[0]['sale_status']?.toString();
              debugPrint('updateSells: After raw SQL update on "sell" - sale_status: $statusAfterRaw');
              if (statusAfterRaw == expectedStatus) {
                rawUpdateSuccess = true;
              }
            }
            
            if (!rawUpdateSuccess && rowsAffected == 0) {
              // Try 'sells' table
              try {
                int rowsAffected2 = await db.rawUpdate(
                  'UPDATE sells SET sale_status = ? WHERE id = ?',
                  [expectedStatus, sellId],
                );
                debugPrint('updateSells: Raw SQL update on "sells" table affected $rowsAffected2 rows');
                
                // Verify immediately
                var verifyAfterRaw2 = await db.query('sells', where: 'id = ?', whereArgs: [sellId]);
                if (verifyAfterRaw2.isNotEmpty) {
                  String? statusAfterRaw2 = verifyAfterRaw2[0]['sale_status']?.toString();
                  debugPrint('updateSells: After raw SQL update on "sells" - sale_status: $statusAfterRaw2');
                  if (statusAfterRaw2 == expectedStatus) {
                    rawUpdateSuccess = true;
                  }
                }
              } catch (e4) {
                debugPrint('updateSells: Raw SQL update for "sells" table failed: $e4');
              }
            }
          } catch (e3) {
            debugPrint('updateSells: Raw SQL update for "sell" table failed: $e3, trying "sells" table');
            try {
              int rowsAffected = await db.rawUpdate(
                'UPDATE sells SET sale_status = ? WHERE id = ?',
                [expectedStatus, sellId],
              );
              debugPrint('updateSells: Raw SQL update on "sells" table affected $rowsAffected rows');
              
              // Verify immediately
              var verifyAfterRaw = await db.query('sells', where: 'id = ?', whereArgs: [sellId]);
              if (verifyAfterRaw.isNotEmpty) {
                String? statusAfterRaw = verifyAfterRaw[0]['sale_status']?.toString();
                debugPrint('updateSells: After raw SQL update on "sells" - sale_status: $statusAfterRaw');
                if (statusAfterRaw == expectedStatus) {
                  rawUpdateSuccess = true;
                }
              }
            } catch (e4) {
              debugPrint('updateSells: Raw SQL update for "sells" table also failed: $e4');
            }
          }
          
          if (!rawUpdateSuccess) {
            debugPrint('updateSells: CRITICAL - All attempts to update sale_status failed!');
          }
        } else {
          debugPrint('updateSells: sale_status correctly updated to $actualStatus');
        }
      }
      
      return response;
    } catch (e) {
      debugPrint('Error updating sell id: $sellId: $e');
      return 0;
    }
  }

  Future<int> deleteInComplete() async {
    try {
      final db = await database;
      var response = await db.delete(
        'sell_lines',
        where: 'is_completed = ?',
        whereArgs: [0],
      );
      print('Deleted incomplete sell_lines, count: $response');
      return response;
    } catch (e) {
      print('Error deleting incomplete sell_lines: $e');
      return 0;
    }
  }

  // Future<String> countSellLines({int? isCompleted, int? sellId}) async {
  //   try {
  //     String where = 'is_completed = ?';
  //     List<dynamic> whereArgs = [isCompleted ?? 0];
  //     if (sellId != null) {
  //       where += ' AND sell_id = ?';
  //       whereArgs.add(sellId);
  //     }
  //     final db = await database;
  //     var response = await db.rawQuery(
  //       'SELECT COUNT(*) AS counts FROM sell_lines WHERE $where',
  //       whereArgs,
  //     );
  //     String count = response[0]['counts'].toString();
  //     return count;
  //   } catch (e) {
  //     print('Error counting sell_lines for sellId: $sellId, isCompleted: $isCompleted: $e');
  //     return '0';
  //   }
  // }
  Future<String> countSellLines({int? isCompleted, int? sellId, int? res_table_id, bool includeCompleted = false}) async {
    try {
      if (sellId == null && res_table_id != null) {
        List sales = await getSellsByTableId(res_table_id);
        if (sales.isEmpty) {
          print('countSellLines: No sales found for res_table_id: $res_table_id');
          return '0';
        }
        if (sales.length > 1) {
          print('Warning: Multiple sales found for res_table_id: $res_table_id. Using most recent.');
        }
        sellId = sales.first['id'];
      }
      String where = '';
      List<dynamic> whereArgs = [];

      // Only filter by is_completed if we don't want to include completed items
      if (!includeCompleted) {
        where = 'is_completed = ?';
        whereArgs.add(isCompleted ?? 0);
      }

      if (sellId != null) {
        if (where.isNotEmpty) where += ' AND ';
        where += 'sell_id = ?';
        whereArgs.add(sellId);
      }

      if (res_table_id != null && res_table_id != 0) {
        if (where.isNotEmpty) where += ' AND ';
        where += 'res_table_id = ?';
        whereArgs.add(res_table_id);
      } else if (res_table_id == 0) {
        if (where.isNotEmpty) where += ' AND ';
        where += '(res_table_id IS NULL OR res_table_id = 0)';
      }

      final db = await database;
      var response = await db.rawQuery(
        'SELECT COUNT(*) AS counts FROM sell_lines WHERE $where',
        whereArgs,
      );
      String count = response[0]['counts'].toString();
      debugPrint('countSellLines: sellId=$sellId, res_table_id=$res_table_id, includeCompleted=$includeCompleted, count=$count');
      return count;
    } catch (e) {
      print('Error counting sell_lines for sellId: $sellId, res_table_id: $res_table_id, isCompleted: $isCompleted: $e');
      return '0';
    }
  }

  // Future<List<Map>> getSellLineBySellId(int sellId, {int? res_table_id}) async {
  //   await initDatabase(); // Ensure tables exist
  //
  //   try {
  //     final db = await database;
  //     var response = await db.query(
  //       'sell_lines',
  //       where: 'sell_id = ? AND is_completed = ?',
  //       whereArgs: [sellId, 0],
  //     );
  //     print('Fetched ${response.length} sell_lines for sellId: $sellId , res_table_id: $res_table_id');
  //     return response;
  //   } catch (e) {
  //     print('Error fetching sell_lines by sellId: $sellId: $e , res_table_id: $res_table_id');
  //     return [];
  //   }
  // }
  Future<List<Map<String, dynamic>>> getSellLineBySellId(int sellId, {int? res_table_id, bool includeCompleted = false}) async {
    await initDatabase(); // Ensure tables exist

    try {
      final db = await database;
      String where = 'sell_id = ?';
      List<dynamic> whereArgs = [sellId];

      if (res_table_id != null && res_table_id != 0) {
        where += ' AND res_table_id = ?';
        whereArgs.add(res_table_id);
      } else {
        where += ' AND (res_table_id IS NULL OR res_table_id = 0)';
      }

      // Only filter by is_completed if we don't want to include completed items
      if (!includeCompleted) {
        where += ' AND is_completed = ?';
        whereArgs.add(0);
      }

      var response = await db.query(
        'sell_lines',
        where: where,
        whereArgs: whereArgs,
      );
      // debugPrint('getSellLineBySellId: Queried sellId=$sellId, res_table_id=$res_table_id, includeCompleted=$includeCompleted, found ${response.length} sell_lines: ${jsonEncode(response)}');

      return response;
    } catch (e) {
      debugPrint('Error fetching sell_lines for sellId=$sellId, res_table_id=$res_table_id: $e');
      return [];
    }
  }
  Future<void> deleteSell(int sellId,{bool deleteSellPayment=false}) async {
    try {
      final db = await database;
      if(deleteSellPayment){

        await db.delete('sell_payments',
            where: 'sell_id = ?',
            whereArgs: [sellId]);
      }

      await db.delete(
          'sell_lines',
          where: 'sell_id = ?',
          whereArgs: [sellId]);

      await db.delete(
          'sell',
          where: 'id = ?',
          whereArgs: [sellId]);

      print('Deleted sell and related data for sellId: $sellId');
    } catch (e) {
      print('Error deleting sell for sellId: $sellId: $e');
      rethrow;
    }
  }


  ///>>>>>>>>this is right final
  // Future<void> deleteOldDrafts({int? keepSellId}) async {
  //   final db = await database;
  //   if (keepSellId != null) {
  //     await db.delete(
  //       'sells',
  //       where: 'is_synced = 0 AND id != ?',
  //       whereArgs: [keepSellId],
  //     );
  //   } else {
  //     await db.delete(
  //       'sells',
  //       where: 'is_synced = 0',
  //     );
  //   }
  // }
  // Modified to fix table name and improve efficiency
  Future<void> deleteOldDrafts({int? keepSellId, int? keepResTableId}) async {
    try {
      final db = await database;
      String query = 'DELETE FROM sells WHERE is_synced = 0 AND status = ?';
      List<dynamic> args = ['draft'];
      if (keepSellId != null) {
        query += ' AND id != ?';
        args.add(keepSellId);
      }
      if (keepResTableId != null) {
        query += ' AND res_table_id != ?';
        args.add(keepResTableId);
      }
      // Debug: Log sells to be deleted
      var sellsToDelete = await db.query(
        'sells',
        where: keepSellId != null
            ? 'is_synced = ? AND sale_status = ? AND id != ? AND res_table_id != ?'
            : keepSellId != null
            ? 'is_synced = ? AND sale_status = ? AND id != ?'
            : keepResTableId != null
            ? 'is_synced = ? AND sale_status = ? AND res_table_id != ?'
            : 'is_synced = ? AND sale_status = ?',
        whereArgs: keepSellId != null && keepResTableId != null
            ? [0, 'draft', keepSellId, keepResTableId]
            : keepSellId != null
            ? [0, 'draft', keepSellId]
            : keepResTableId != null
            ? [0, 'draft', keepResTableId]
            : [0, 'draft'],
      );
      debugPrint('deleteOldDrafts: Sells to be deleted: ${jsonEncode(sellsToDelete)}');

      await db.rawDelete(query, args);
      // Clean up orphaned sell_lines
      await db.delete(
        'sell_lines',
        where: 'sell_id NOT IN (SELECT id FROM sells)',
      );
      // Clean up orphaned sell_payments
      await db.delete(
        'sell_payments',
        where: 'sell_id NOT IN (SELECT id FROM sells)',
      );
      debugPrint('deleteOldDrafts: Deleted draft sells, sell_lines, and sell_payments for keepSellId=$keepSellId keepResTableId=$keepResTableId');
    } catch (e) {
      debugPrint('Error deleting old drafts: $e');
      rethrow;
    }
  }

  Future<int> deleteSellLineById(int sellLineId) async {
    try {
      final db = await database;
      var response = await db.delete(
        'sell_lines',
        where: 'id = ?',
        whereArgs: [sellLineId],
      );
      print('Deleted sell_line with id: $sellLineId, count: $response');
      return response;
    } catch (e) {
      print('Error deleting sell_line with id: $sellLineId: $e');
      return 0;
    }
  }
  //
  // Future<void> previosSellRowDelete()async{
  //   final db = await database;
  //   final List<Map<String, dynamic>> result =await db.rawQuery("SELECT DISTINCT sell_id FROM sell_lines");
  //   List allsellId= result.map((e) => e['sell_id']).toList();
  //   if(allsellId.length>1){
  //     await db.delete(
  //       'sell_lines',
  //       where: 'sell_id = ?',
  //       whereArgs: [allsellId.first],
  //     );
  //   }
  //
  //   print("Result::$result");
  //
  // }
  Future<void> previosSellRowDelete() async {
    final db = await database;

    // Get distinct sell_ids
    final List<Map<String, dynamic>> sellResult =
    await db.rawQuery("SELECT DISTINCT sell_id FROM sell_lines");
    List allSellId = sellResult.map((e) => e['sell_id']).toList();

    // Delete first sell_id if more than one exists
    if (allSellId.length > 1) {
      await db.delete(
        'sell_lines',
        where: 'sell_id = ?',
        whereArgs: [allSellId.first],
      );
    }

    // Get distinct res_table_ids
    final List<Map<String, dynamic>> tableResult =
    await db.rawQuery("SELECT DISTINCT res_table_id FROM sell_lines");
    List allTableId = tableResult.map((e) => e['res_table_id']).toList();

    // Delete first res_table_id if more than one exists
    if (allTableId.length > 1) {
      await db.delete(
        'sell_lines',
        where: 'res_table_id = ?',
        whereArgs: [allTableId.first],
      );
    }

    print("Sell Result :: $sellResult");
    print("Table Result :: $tableResult");
  }



  /// Deletes incomplete sell lines (temporary cart items) for a specific sale
  /// This is used when the user navigates back from the cart without saving changes
  Future<int> deleteIncompleteSellLines(int sellId, int? res_table_id) async {
    try {
      final db = await database;
      String whereClause = 'sell_id = ? AND is_completed = 0';
      List<dynamic> whereArgs = [sellId];

      if (res_table_id != null) {
        whereClause += ' AND res_table_id = ?';
        whereArgs.add(res_table_id);
      }

      var response = await db.delete(
        'sell_lines',
        where: whereClause,
        whereArgs: whereArgs,
      );

      debugPrint('deleteIncompleteSellLines: Deleted $response incomplete sell_lines for sellId=$sellId, res_table_id=$res_table_id');
      return response;
    } catch (e) {
      debugPrint('Error deleting incomplete sell_lines for sellId=$sellId, res_table_id=$res_table_id: $e');
      return 0;
    }
  }

  // Future<void> resetCartForTable(int? resTableId) async {
  //   await initDatabase(); // Ensure tables exist
  //   try {
  //     final db = await database;
  //
  //     // Check if is_shipping column exists in sell and sell_lines
  //     var sellColumns = await db.rawQuery('PRAGMA table_info(sell)');
  //     var sellLineColumns = await db.rawQuery('PRAGMA table_info(sell_lines)');
  //     bool hasIsShippingSell = sellColumns.any((column) => column['name'] == 'is_shipping');
  //     bool hasIsShippingSellLines = sellLineColumns.any((column) => column['name'] == 'is_shipping');
  //     debugPrint('resetCartForTable: is_shipping column exists: sell=$hasIsShippingSell, sell_lines=$hasIsShippingSellLines');
  //
  //     if (resTableId != null && resTableId != 0) {
  //       // Handle table-based cart reset (non-shipping, res_table_id > 0)
  //       var sellsToDelete = await db.query(
  //         'sells',
  //         where: hasIsShippingSell
  //             ? 'res_table_id = ? AND sale_status = ? AND is_synced = ? AND is_shipping = ?'
  //             : 'res_table_id = ? AND sale_status = ? AND is_synced = ?',
  //         whereArgs: hasIsShippingSell ? [resTableId, 'draft', 0, 0] : [resTableId, 'draft', 0],
  //       );
  //       debugPrint('resetCartForTable: Sells to be deleted for res_table_id=$resTableId: ${jsonEncode(sellsToDelete)}');
  //
  //       await db.delete(
  //         'sells',
  //         where: hasIsShippingSell
  //             ? 'res_table_id = ? AND sale_status = ? AND is_synced = ? AND is_shipping = ?'
  //             : 'res_table_id = ? AND sale_status = ? AND is_synced = ?',
  //         whereArgs: hasIsShippingSell ? [resTableId, 'draft', 0, 0] : [resTableId, 'draft', 0],
  //       );
  //
  //       await db.delete(
  //         'sell_lines',
  //         where: hasIsShippingSellLines ? 'res_table_id = ? AND is_shipping = ?' : 'res_table_id = ?',
  //         whereArgs: hasIsShippingSellLines ? [resTableId, 0] : [resTableId],
  //       );
  //     } else {
  //       // Handle shipping cart reset (res_table_id = 0)
  //       var sellsToDelete = await db.query(
  //         'sells',
  //         where: hasIsShippingSell
  //             ? 'res_table_id = ? AND is_shipping = ? AND sale_status = ? AND is_synced = ?'
  //             : 'res_table_id = ? AND sale_status = ? AND is_synced = ?',
  //         whereArgs: hasIsShippingSell ? [0, 1, 'draft', 0] : [0, 'draft', 0],
  //       );
  //       debugPrint('resetCartForTable: Sells to be deleted for shipping (res_table_id=0): ${jsonEncode(sellsToDelete)}');
  //
  //       await db.delete(
  //         'sells',
  //         where: hasIsShippingSell
  //             ? 'res_table_id = ? AND is_shipping = ? AND sale_status = ? AND is_synced = ?'
  //             : 'res_table_id = ? AND sale_status = ? AND is_synced = ?',
  //         whereArgs: hasIsShippingSell ? [0, 1, 'draft', 0] : [0, 'draft', 0],
  //       );
  //
  //       await db.delete(
  //         'sell_lines',
  //         where: hasIsShippingSellLines ? 'res_table_id = ? AND is_shipping = ?' : 'res_table_id = ?',
  //         whereArgs: hasIsShippingSellLines ? [0, 1] : [0],
  //       );
  //     }
  //
  //     // Clean up orphaned sell_lines
  //     await db.delete(
  //       'sell_lines',
  //       where: 'sell_id NOT IN (SELECT id FROM sell)',
  //     );
  //
  //     // Clean up orphaned sell_payments
  //     await db.delete(
  //       'sell_payments',
  //       where: 'sell_id NOT IN (SELECT id FROM sell)',
  //     );
  //
  //     debugPrint('resetCartForTable: Deleted draft sells, sell_lines, and sell_payments for ${resTableId != null && resTableId != 0 ? 'res_table_id=$resTableId' : 'shipping (res_table_id=0)'}');
  //   } catch (e) {
  //     debugPrint('Error resetting cart for ${resTableId != null && resTableId != 0 ? 'res_table_id=$resTableId' : 'shipping (res_table_id=0)'}: $e');
  //     rethrow;
  //   }
  // }
  Future<void> resetCartForTable(int? resTableId) async {
    await initDatabase();
    try {
      final db = await database;
      // Log sells to be deleted
      var sellsToDelete = await db.query(
        'sells',
        where: resTableId != null && resTableId != 0
            ? 'res_table_id = ? AND sale_status = ? AND is_synced = ? AND is_shipping = ?'
            : 'res_table_id = ? AND sale_status = ? AND is_synced = ? AND is_shipping = ?',
        whereArgs: resTableId != null && resTableId != 0
            ? [resTableId, 'draft', 0, 0]
            : [0, 'draft', 0, 1],
      );
      debugPrint('resetCartForTable: Sells to delete for res_table_id=$resTableId: ${jsonEncode(sellsToDelete)}');

      // Delete sells
      await db.delete(
        'sells',
        where: resTableId != null && resTableId != 0
            ? 'res_table_id = ? AND sale_status = ? AND is_synced = ? AND is_shipping = ?'
            : 'res_table_id = ? AND sale_status = ? AND is_synced = ? AND is_shipping = ?',
        whereArgs: resTableId != null && resTableId != 0
            ? [resTableId, 'draft', 0, 0]
            : [0, 'draft', 0, 1],
      );

      // Delete sell_lines
      var sellLinesToDelete = await db.query(
        'sell_lines',
        where: resTableId != null && resTableId != 0 ? 'res_table_id = ? AND is_shipping = ?' : 'res_table_id = ? AND is_shipping = ?',
        whereArgs: resTableId != null && resTableId != 0 ? [resTableId, 0] : [0, 1],
      );
      debugPrint('resetCartForTable: Sell_lines to delete for res_table_id=$resTableId: ${jsonEncode(sellLinesToDelete)}');

      await db.delete(
        'sell_lines',
        where: resTableId != null && resTableId != 0 ? 'res_table_id = ? AND is_shipping = ?' : 'res_table_id = ? AND is_shipping = ?',
        whereArgs: resTableId != null && resTableId != 0 ? [resTableId, 0] : [0, 1],
      );

      // Clean up orphaned data
      await db.delete('sell_lines', where: 'sell_id NOT IN (SELECT id FROM sells)');
      // await db.delete('sell_payments', where: 'sell_id NOT IN (SELECT id FROM sells)');
      debugPrint('resetCartForTable: Completed for res_table_id=$resTableId');
    } catch (e) {
      debugPrint('Error resetting cart for res_table_id=$resTableId: $e');
      rethrow;
    }
  }

  Future<void> initDatabase() async {
    final db = await database;
    try {
      // Check if sells table exists
      var result = await db.rawQuery(
          "SELECT name FROM sqlite_master WHERE type='table' AND name='sells'");
      if (result.isEmpty) {
        // Create sells table
        await db.execute('''
          CREATE TABLE sells (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_no TEXT,
            transaction_date TEXT,
            change_return REAL,
            contact_id INTEGER,
            invoice_amount REAL,
            location_id INTEGER,
            pending_amount REAL,
            sale_note TEXT,
            sale_status TEXT,
            shipping_charges REAL,
            shipping_details TEXT,
            staff_note TEXT,
            tax_id INTEGER,
            is_quotation INTEGER,
            tip_amount REAL,
            tip_type TEXT,
            discount_amount REAL,
            discount_type TEXT,
            res_table_id INTEGER,
            is_shipping INTEGER DEFAULT 0,
            is_synced INTEGER DEFAULT 0,
            transaction_id TEXT,
            invoice_url TEXT
          )
        ''');
        // Create sell_lines table
        await db.execute('''
          CREATE TABLE sell_lines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sell_id INTEGER,
            product_id INTEGER,
            variation_id INTEGER,
            quantity REAL,
            unit_price REAL,
            tax_rate_id INTEGER,
            discount_amount REAL,
            discount_type TEXT,
            note TEXT,
            product_order_category TEXT,
            is_completed INTEGER,
            res_table_id INTEGER, 
            FOREIGN KEY (sell_id) REFERENCES sells (id) ON DELETE CASCADE
          )
        ''');
        // Create sell_payments table
        await db.execute('''
          CREATE TABLE sell_payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sell_id INTEGER,
            amount REAL,
            method TEXT,
            note TEXT,
            account_id INTEGER,
            received_amount REAL,
            change_return REAL,
            card_details TEXT,
            FOREIGN KEY (sell_id) REFERENCES sells (id) ON DELETE CASCADE
          )
        ''');
        debugPrint('initDatabase: Created sells, sell_lines, and sell_payments tables');
      } else {
        // Check if res_table_id column exists in sell_lines
        var columns = await db.rawQuery('PRAGMA table_info(sell_lines)');
        bool hasResTableId = columns.any((col) => col['name'] == 'res_table_id');
        if (!hasResTableId) {
          await db.execute('ALTER TABLE sell_lines ADD COLUMN res_table_id INTEGER');
          debugPrint('initDatabase: Added res_table_id column to sell_lines');
        }
        // Ensure foreign key constraints are enabled
        await db.execute('PRAGMA foreign_keys = ON');
        // debugPrint('initDatabase: Ensured foreign key constraints are enabled');
      }
    } catch (e) {
      debugPrint('Error initializing database: $e');
      //Fluttertoast.showToast(msg: 'Error initializing database');
    }
  }

//new added
  Future<List<Map<String, dynamic>>> getSellsByTableId(int res_table_id) async {
    await initDatabase();
    try {
      final db = await database;
      final result = await db.query(
        'sells',
        where: 'res_table_id = ? AND sale_status != ?',
        whereArgs: [res_table_id, 'draft'],
        orderBy: 'transaction_date DESC',
      );
      debugPrint('getSellsByTableId: Queried res_table_id: $res_table_id, result: $result');
      if (result.isEmpty) {
        debugPrint('getSellsByTableId: No data found for res_table_id: $res_table_id');
      } else {
        debugPrint('getSellsByTableId: Found data: ${jsonEncode(result)}');
      }
      return result;
    } catch (e) {
      debugPrint('Error in getSellsByTableId for res_table_id: $res_table_id, error: $e');
      return [];
    }
  }

  //new added
  // Future<void> deleteSellLinesByTable(int? res_table_id, int? locationId) async {
  //   final db = await database;
  //   String whereClause = '';
  //   List<dynamic> whereArgs = [];
  //
  //   if (res_table_id != null) {
  //     whereClause = 'res_table_id = ?';
  //     whereArgs.add(res_table_id);
  //   } else {
  //     whereClause = 'res_table_id IS NULL';
  //   }
  //
  //   if (locationId != null) {
  //     whereClause += (whereClause.isNotEmpty ? ' AND ' : '') + 'location_id = ?';
  //     whereArgs.add(locationId);
  //   }
  //
  //   await db.delete('sell_lines', where: whereClause, whereArgs: whereArgs);
  // }
  Future<void> deleteSellLinesByTable(int? resTableId, int? locationId) async {
    try {
      final db = await database;
      var sellLines = await db.query(
        'sell_lines',
        where: 'res_table_id = ? AND is_shipping = ?',
        whereArgs: [resTableId, 0],
      );
      debugPrint('deleteSellLinesByTable: Sell_lines to delete for res_table_id=$resTableId: ${jsonEncode(sellLines)}');
      await db.delete(
        'sell_lines',
        where: 'res_table_id = ? AND is_shipping = ?',
        whereArgs: [resTableId, 0],
      );
      debugPrint('deleteSellLinesByTable: Deleted sell_lines for res_table_id=$resTableId');
    } catch (e, stackTrace) {
      debugPrint('Error in deleteSellLinesByTable for res_table_id=$resTableId: $e');
      debugPrint('Stack trace: $stackTrace');
      rethrow;
    }
  }

  Future<void> debugSellData(int? sellId, int? resTableId) async {
    try {
      final db = await database;
      // Query sells table
      List<Map<String, dynamic>> sells = [];
      if (sellId != null) {
        sells = await db.query(
          'sells',
          where: 'id = ?',
          whereArgs: [sellId],
        );
      }
      debugPrint('debugSellData: sells for sellId=$sellId: ${jsonEncode(sells)}');

      // Query all sell_lines for sell_id
      List<Map<String, dynamic>> allSellLines = [];
      if (sellId != null) {
        allSellLines = await db.query(
          'sell_lines',
          where: 'sell_id = ?',
          whereArgs: [sellId],
        );
      }
      debugPrint('debugSellData: all sell_lines for sellId=$sellId: ${jsonEncode(allSellLines)}');

      // Query sell_lines with res_table_id
      if (resTableId != null) {
        var tableSellLines = await db.query(
          'sell_lines',
          where: 'sell_id = ? AND res_table_id = ?',
          whereArgs: [sellId, resTableId],
        );
        debugPrint('debugSellData: sell_lines for sellId=$sellId, res_table_id=$resTableId: ${jsonEncode(tableSellLines)}');
      }

      // Query all sell_lines for the res_table_id
      if (resTableId != null) {
        var tableAllSellLines = await db.query(
          'sell_lines',
          where: 'res_table_id = ?',
          whereArgs: [resTableId],
        );
        debugPrint('debugSellData: all sell_lines for res_table_id=$resTableId: ${jsonEncode(tableAllSellLines)}');
      }
    } catch (e, stackTrace) {
      debugPrint('Error in debugSellData for sellId=$sellId, res_table_id=$resTableId: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }

  // In SellDatabase.dart, add this method

  Future<void> ensureNoDuplicateCartItems(int sellId, int? resTableId) async {
    try {
      final db = await database;

      // Get all cart items for this sale
      List<Map<String, dynamic>> cartItems = await db.query(
        'sell_lines',
        where: 'sell_id = ? AND is_completed = 0',
        whereArgs: [sellId],
      );

      // Create a map to track unique items by product_id + variation_id
      Map<String, Map<String, dynamic>> uniqueItems = {};

      for (var item in cartItems) {
        String key = '${item['product_id']}_${item['variation_id']}';

        if (uniqueItems.containsKey(key)) {
          // If duplicate found, delete it
          await db.delete(
            'sell_lines',
            where: 'id = ?',
            whereArgs: [item['id']],
          );
          debugPrint('ensureNoDuplicateCartItems: Removed duplicate item with id: ${item['id']}');
        } else {
          // Add to unique items map
          uniqueItems[key] = item;
        }
      }

      debugPrint('ensureNoDuplicateCartItems: Verified ${uniqueItems.length} unique items for sellId: $sellId');
    } catch (e) {
      debugPrint('Error in ensureNoDuplicateCartItems: $e');
    }
  }

  /// Clean up duplicate sales for the same table and invoice pattern
  /// This method removes older duplicate entries, keeping only the most recent one
  Future<void> cleanupDuplicateSales(int resTableId, String invoicePattern) async {
    try {
      final db = await database;

      // Find all sales for this table with similar invoice pattern
      List<Map<String, dynamic>> duplicateSales = await db.query(
        'sell',
        where: 'res_table_id = ? AND invoice_no LIKE ? AND is_quotation = 0',
        whereArgs: [resTableId, '$invoicePattern%'],
        orderBy: 'id DESC', // Most recent first
      );

      if (duplicateSales.length > 1) {
        debugPrint('cleanupDuplicateSales: Found ${duplicateSales.length} duplicate sales for table $resTableId, pattern: $invoicePattern');

        // Keep the most recent sale (first in the list due to DESC order)
        Map<String, dynamic> keepSale = duplicateSales.first;
        List<int> deleteIds = duplicateSales.skip(1).map((sale) => sale['id'] as int).toList();

        debugPrint('cleanupDuplicateSales: Keeping sale ID ${keepSale['id']}, deleting IDs: $deleteIds');

        // Delete duplicate sales and their associated data
        for (int deleteId in deleteIds) {
          // Delete payment lines
          await db.delete('sell_payments', where: 'sell_id = ?', whereArgs: [deleteId]);

          // Delete sell lines
          await db.delete('sell_lines', where: 'sell_id = ?', whereArgs: [deleteId]);

          // Delete the sale itself
          await db.delete('sell', where: 'id = ?', whereArgs: [deleteId]);

          debugPrint('cleanupDuplicateSales: Deleted duplicate sale ID: $deleteId');
        }

        debugPrint('cleanupDuplicateSales: Cleanup completed for table $resTableId');
      }
    } catch (e) {
      debugPrint('Error in cleanupDuplicateSales: $e');
    }
  }

  /// Ensure proper data isolation for sales record editing
  /// This method validates that the selected sales record is properly isolated
  Future<Map<String, dynamic>> validateSalesRecordIsolation(int sellId, int? resTableId) async {
    try {
      final db = await database;

      // Get the specific sales record
      List<Map<String, dynamic>> sellRecord = await db.query(
        'sells',
        where: 'id = ?',
        whereArgs: [sellId],
      );

      if (sellRecord.isEmpty) {
        debugPrint('validateSalesRecordIsolation: Sales record not found for sellId: $sellId');
        return {
          'sellRecord': null,
          'cartItems': [],
          'isValid': false,
          'error': 'Sales record not found for sellId: $sellId',
        };
      }

      // Validate that the res_table_id matches if provided
      if (resTableId != null && sellRecord.first['res_table_id'] != resTableId) {
        debugPrint('validateSalesRecordIsolation: Sales record res_table_id mismatch. Expected: $resTableId, Found: ${sellRecord.first['res_table_id']}');
        return {
          'sellRecord': null,
          'cartItems': [],
          'isValid': false,
          'error': 'Sales record res_table_id mismatch. Expected: $resTableId, Found: ${sellRecord.first['res_table_id']}',
        };
      }

      // Get cart items for this specific sales record
      List<Map<String, dynamic>> cartItems = await getSellLineBySellId(
        sellId,
        res_table_id: resTableId,
        includeCompleted: true,
      );

      debugPrint('validateSalesRecordIsolation: Validated sellId: $sellId, res_table_id: $resTableId, cartItems: ${cartItems.length}');

      return {
        'sellRecord': sellRecord.first,
        'cartItems': cartItems,
        'isValid': true,
      };
    } catch (e) {
      debugPrint('Error in validateSalesRecordIsolation: $e');
      return {
        'sellRecord': null,
        'cartItems': [],
        'isValid': false,
        'error': e.toString(),
      };
    }
  }

  /// Strict filtering method to ensure data isolation by sell_id and res_table_id
  /// This prevents data mixing between different tables/sales
  Future<List<Map<String, dynamic>>> getStrictSellData({
    required int sellId,
    int? resTableId,
    bool includeCompleted = false,
  }) async {
    try {
      final db = await database;

      String whereClause = 'sell_id = ?';
      List<dynamic> whereArgs = [sellId];

      // Always filter by res_table_id if provided to ensure strict isolation
      if (resTableId != null) {
        whereClause += ' AND res_table_id = ?';
        whereArgs.add(resTableId);
      }

      // Only filter by is_completed if we don't want to include completed items
      if (!includeCompleted) {
        whereClause += ' AND is_completed = ?';
        whereArgs.add(0);
      }

      List<Map<String, dynamic>> result = await db.query(
        'sell_lines',
        where: whereClause,
        whereArgs: whereArgs,
      );

      debugPrint('getStrictSellData: sellId=$sellId, resTableId=$resTableId, includeCompleted=$includeCompleted, found ${result.length} items');

      return result;
    } catch (e) {
      debugPrint('Error in getStrictSellData: $e');
      return [];
    }
  }

  /// Clean up any orphaned or mixed data that might cause table data confusion
  Future<void> ensureDataIsolation() async {
    try {
      final db = await database;

      // Find and log any potential data mixing issues
      final mixedData = await db.rawQuery('''
        SELECT s.id as sell_id, s.res_table_id, COUNT(sl.id) as line_count
        FROM sells s
        LEFT JOIN sell_lines sl ON s.id = sl.sell_id
        WHERE s.sale_status = 'draft' AND s.is_synced = 0
        GROUP BY s.id, s.res_table_id
        HAVING line_count = 0
      ''');

      if (mixedData.isNotEmpty) {
        debugPrint('ensureDataIsolation: Found ${mixedData.length} blank draft orders that will be cleaned up');

        // Clean up blank draft orders
        for (var order in mixedData) {
          final sellId = order['sell_id'] as int;
          await deleteSell(sellId);
          debugPrint('ensureDataIsolation: Cleaned up blank order $sellId');
        }
      }

      debugPrint('ensureDataIsolation: Data isolation check completed');
    } catch (e) {
      debugPrint('Error in ensureDataIsolation: $e');
    }
  }
}