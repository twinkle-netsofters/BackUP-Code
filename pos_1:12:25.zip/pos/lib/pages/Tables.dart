// // import 'package:dio/dio.dart';
// // import 'package:flutter/material.dart';
// // import '../config.dart';
// // import '../helpers/AppTheme.dart';
// // import '../helpers/SizeConfig.dart';
// // import '../locale/MyLocalizations.dart';
// // import '../models/system.dart';
// // import 'package:fluttertoast/fluttertoast.dart';
// // import 'package:cached_network_image/cached_network_image.dart';
// // import '../models/sell.dart';
// // import 'elements.dart';
// //
// // class Tables extends StatefulWidget {
// //   @override
// //   _TablesState createState() => _TablesState();
// // }
// //
// // class _TablesState extends State<Tables> {
// //   List tables = [];
// //   static int themeType = 1;
// //   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
// //   CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);
// //   String businessLogo = Config().defaultBusinessImage;
// //   int selectedLocationId = 0;
// //   List<Map<String, dynamic>> locationListMap = [];
// //   bool canChangeLocation = true;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     setLocationMap();
// //     fetchTables();
// //   }
// //
// //   // Fetch tables from API
// //   fetchTables() async {
// //     if (selectedLocationId == 0) {
// //       setState(() {
// //         tables = [];
// //       });
// //       return;
// //     }
// //     try {
// //       final dio = Dio();
// //       var token = await System().getToken();
// //       dio.options.headers['Authorization'] = "Bearer $token";
// //       final response = await dio.get(Config.baseUrl + 'connector/api/table');
// //
// //       if (response.statusCode == 200) {
// //         setState(() {
// //           tables = response.data['data']
// //               .where((table) => table['deleted_at'] == null && table['location_id'] == selectedLocationId)
// //               .toList();
// //         });
// //       } else {
// //         Fluttertoast.showToast(
// //             msg: AppLocalizations.of(context).translate('failed_to_load_tables'));
// //       }
// //     } catch (e) {
// //       Fluttertoast.showToast(
// //           msg: AppLocalizations.of(context).translate('error') + ': $e');
// //     }
// //   }
// //
// //   // Set location map
// //   setLocationMap() async {
// //     // Clear existing locations to prevent duplicates
// //     locationListMap.clear();
// //     // Add default location
// //     locationListMap.add({'id': 0, 'name': 'set location', 'selling_price_group_id': 0});
// //
// //     await System().get('location').then((value) async {
// //       // Use a Set to track unique IDs
// //       Set<int> existingIds = {0}; // 0 is for default location
// //       for (var element in value) {
// //         if (element['is_active'].toString() == '1') {
// //           int id = element['id'];
// //           // Only add if ID is not already present
// //           if (!existingIds.contains(id)) {
// //             setState(() {
// //               locationListMap.add({
// //                 'id': id,
// //                 'name': element['name'],
// //                 'selling_price_group_id': element['selling_price_group_id']
// //               });
// //               existingIds.add(id);
// //             });
// //           }
// //         }
// //       }
// //       setDefaultLocation();
// //     });
// //   }
// //
// //   // Set default location
// //   setDefaultLocation() {
// //     if (locationListMap.length == 2) {
// //       setState(() {
// //         selectedLocationId = locationListMap[1]['id'] as int;
// //         fetchTables(); // Fetch tables after setting default location
// //       });
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     themeData = Theme.of(context);
// //     return Scaffold(
// //       appBar: AppBar(
// //         elevation: 0,
// //         title: Text(
// //           AppLocalizations.of(context).translate('tables'),
// //           style: AppTheme.getTextStyle(themeData.textTheme.headline6,
// //               fontWeight: 600),
// //         ),
// //         actions: [
// //           locations(),
// //         ],
// //       ),
// //       body: Column(
// //         children: [
// //           Visibility(
// //             visible: Config().showFieldForce,
// //             child: ListTile(
// //               leading: Icon(
// //                 Icons.local_shipping_outlined,
// //                 color: themeData.colorScheme.onBackground,
// //               ),
// //               title: Text(
// //                 AppLocalizations.of(context).translate('shipment'),
// //                 style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
// //                     fontWeight: 600),
// //               ),
// //               onTap: () {
// //                 Navigator.pushNamed(context, '/shipment');
// //               },
// //             ),
// //           ),
// //           Expanded(
// //             child: tables.isEmpty
// //                 ? Center(
// //               child: Column(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: [
// //                   Icon(Icons.table_chart),
// //                   Text(AppLocalizations.of(context)
// //                       .translate('no_tables_found')),
// //                 ],
// //               ),
// //             )
// //                 : GridView.builder(
// //               padding: EdgeInsets.all(MySize.size16!),
// //               gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
// //                 crossAxisCount: 2,
// //                 mainAxisSpacing: MySize.size16!,
// //                 crossAxisSpacing: MySize.size16!,
// //                 childAspectRatio: 1.0,
// //               ),
// //               itemCount: tables.length,
// //               itemBuilder: (context, index) {
// //                 return InkWell(
// //                   onTap: () async {
// //                     if (selectedLocationId != 0) {
// //                       int? sellId = await Sell().createSellDraft(
// //                           locId: selectedLocationId, discountType: '');
// //                       Navigator.pushNamed(context, '/products',
// //                           arguments: {
// //                             'locationId': selectedLocationId,
// //                             'sellId': sellId
// //                           });
// //                     } else {
// //                       Fluttertoast.showToast(
// //                           msg: AppLocalizations.of(context)
// //                               .translate('please_set_a_location'));
// //                     }
// //                   },
// //                   child: Card(
// //                     color: Colors.blue, // Blue background for table cards
// //                     elevation: 2,
// //                     child: Column(
// //                       mainAxisAlignment: MainAxisAlignment.center,
// //                       children: [
// //                         Icon(
// //                           Icons.table_restaurant,
// //                           size: MySize.size48,
// //                           color: Colors.white, // White icon for contrast
// //                         ),
// //                         SizedBox(height: MySize.size8),
// //                         Text(
// //                           tables[index]['name'],
// //                           style: AppTheme.getTextStyle(
// //                               themeData.textTheme.subtitle1,
// //                               fontWeight: 600,
// //                               color: Colors.white), // White text
// //                         ),
// //                         if (tables[index]['description'] != null)
// //                           Text(
// //                             tables[index]['description'],
// //
// //                             style: AppTheme.getTextStyle(
// //                                 themeData.textTheme.bodyText2,
// //                                 fontWeight: 400,
// //                                 color: Colors.white), // White text
// //                           ),
// //                       ],
// //                     ),
// //                   ),
// //                 );
// //               },
// //             ),
// //           ),
// //         ],
// //       ),
// //       bottomNavigationBar: posBottomBar('tables', context),
// //     );
// //   }
// //
// //   // Location dropdown
// //   Widget locations() {
// //     return DropdownButtonHideUnderline(
// //       child: DropdownButton<int>(
// //         dropdownColor: themeData.backgroundColor,
// //         icon: Icon(Icons.arrow_drop_down),
// //         value: selectedLocationId,
// //         items: locationListMap.map<DropdownMenuItem<int>>((Map value) {
// //           return DropdownMenuItem<int>(
// //             value: value['id'],
// //             child: SizedBox(
// //               width: MySize.screenWidth! * 0.4,
// //               child: Text(
// //                 '${value['name']}',
// //                 softWrap: true,
// //                 overflow: TextOverflow.ellipsis,
// //                 maxLines: 2,
// //                 style: TextStyle(fontSize: 15),
// //               ),
// //             ),
// //           );
// //         }).toList(),
// //         onChanged: (int? newValue) {
// //           setState(() {
// //             selectedLocationId = newValue!;
// //             tables = [];
// //             fetchTables();
// //           });
// //         },
// //       ),
// //     );
// //   }
// // }
//
// import 'dart:async';
// import 'dart:convert';
// import 'package:dio/dio.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import '../config.dart';
// import '../helpers/AppTheme.dart';
// import '../helpers/SizeConfig.dart';
// import '../helpers/TableAvailabilityManager.dart';
// import '../locale/MyLocalizations.dart';
// import 'event_bus.dart';
// import '../models/sellDatabase.dart';
// import '../models/system.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:cached_network_image/cached_network_image.dart';
// import '../models/sell.dart';
// import 'elements.dart';
//
// class Tables extends StatefulWidget {
//   @override
//   _TablesState createState() => _TablesState();
// }
//
// class _TablesState extends State<Tables> {
//   List tables = [];
//   static int themeType = 1;
//   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
//   CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);
//   String businessLogo = Config().defaultBusinessImage;
//   int selectedLocationId = 0;
//   List<Map<String, dynamic>> locationListMap = [];
//   bool isLoading = true;
//   bool hasError = false;
//
//   // Table availability management
//   final TableAvailabilityManager _availabilityManager = TableAvailabilityManager();
//   Map<int, bool> _tableAvailability = {};
//   bool _shippingAvailable = true;
//
//   // Event subscription for availability changes
//   StreamSubscription? _eventSubscription;
//
//   @override
//   void initState() {
//     super.initState();
//     _loadInitialData();
//     _setupEventListeners();
//   }
//
//   @override
//   void didChangeDependencies() {
//     super.didChangeDependencies();
//     // Refresh availability when returning to this page
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (mounted && selectedLocationId != 0) {
//         _checkAvailability();
//       }
//     });
//   }
//
//   @override
//   void dispose() {
//     _eventSubscription?.cancel();
//     super.dispose();
//   }
//
//   /// Setup event listeners for table/shipping availability changes
//   void _setupEventListeners() {
//     _eventSubscription = EventBus().stream.listen((event) {
//       if (event is TableAvailabilityChangedEvent) {
//         _handleAvailabilityChange(event);
//       }
//     });
//   }
//
//   /// Handle table/shipping availability change events
//   void _handleAvailabilityChange(TableAvailabilityChangedEvent event) {
//     if (!mounted) return;
//
//     setState(() {
//       if (event.isShipping) {
//         _shippingAvailable = event.isAvailable;
//         debugPrint('Tables screen: Shipping availability updated to ${event.isAvailable}');
//       } else if (event.tableId != null) {
//         _tableAvailability[event.tableId!] = event.isAvailable;
//         debugPrint('Tables screen: Table ${event.tableId} availability updated to ${event.isAvailable}');
//       }
//     });
//   }
//
//   Future<void> _loadInitialData() async {
//     try {
//       // Load all initial data in parallel where possible
//       await Future.wait([
//         AppConstants.getData(),
//         _loadLocations(),
//       ]);
//
//       // Set default location if only one exists
//       if (locationListMap.length == 2) {
//         selectedLocationId = locationListMap[1]['id'] as int;
//       }
//
//       // Fetch tables for the selected location
//       if (selectedLocationId != 0) {
//         await _fetchTables();
//         await _checkAvailability();
//       }
//     } catch (e) {
//       setState(() {
//         hasError = true;
//       });
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('error_loading_data'),
//       );
//     } finally {
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   Future<void> _loadLocations() async {
//     locationListMap.clear();
//     locationListMap.add({'id': 0, 'name': 'set location', 'selling_price_group_id': 0});
//
//     try {
//       final locations = await System().get('location');
//       final existingIds = <int>{0};
//
//       for (var element in locations) {
//         if (element['is_active'].toString() == '1') {
//           final id = element['id'];
//           if (!existingIds.contains(id)) {
//             locationListMap.add({
//               'id': id,
//               'name': element['name'],
//               'selling_price_group_id': element['selling_price_group_id']
//             });
//             existingIds.add(id);
//           }
//         }
//       }
//     } catch (e) {
//       throw Exception('Failed to load locations');
//     }
//   }
//
//   Future<void> _fetchTables() async {
//     if (selectedLocationId == 0) {
//       setState(() {
//         tables = [];
//       });
//       return;
//     }
//
//     try {
//       setState(() {
//         isLoading = true;
//       });
//
//       final dio = Dio();
//       final token = await System().getToken();
//       dio.options.headers['Authorization'] = "Bearer $token";
//
//       final response = await dio.get(
//         Config.baseUrl + 'connector/api/table',
//         options: Options(receiveTimeout: Duration(seconds: 10)),
//       );
//
//       if (response.statusCode == 200) {
//         final filteredTables = response.data['data']
//             .where((table) => table['deleted_at'] == null &&
//             table['location_id'] == selectedLocationId)
//             .toList();
//
//         setState(() {
//           tables = filteredTables;
//         });
//       } else {
//         throw Exception('Failed to load tables');
//       }
//     } catch (e) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('error_loading_tables'),
//       );
//       throw Exception('Failed to fetch tables');
//     } finally {
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   Future<void> _checkAvailability() async {
//     try {
//       // Clear shipping cache to force fresh database query
//       _availabilityManager.clearShippingCache();
//
//       // Check table availability
//       final tableIds = tables.map<int>((table) => table['id'] as int).toList();
//       _tableAvailability = await _availabilityManager.getTablesAvailability(tableIds);
//
//       // Check shipping availability
//       _shippingAvailable = await _availabilityManager.isShippingAvailable();
//       debugPrint('Tables screen: Shipping availability set to $_shippingAvailable');
//
//       if (mounted) {
//         setState(() {});
//         debugPrint('Tables screen: setState called, shipping available: $_shippingAvailable');
//       }
//     } catch (e) {
//       debugPrint('Error checking availability: $e');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       bottom: true,
//       top: false,
//       child: Scaffold(
//         appBar: AppBar(
//           elevation: 0,
//           title: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text(
//                 AppLocalizations.of(context).translate('tables'),
//                 style: AppTheme.getTextStyle(
//                   themeData.textTheme.headline6,
//                   fontWeight: 600,
//                 ),
//               ),
//               Card(
//                 //color: Colors.grey,
//                   child: _buildLocationDropdown()),
//             ],
//           ),
//           bottom: isLoading
//               ? PreferredSize(
//             preferredSize: Size.fromHeight(4.0),
//             child: LinearProgressIndicator(),
//           )
//               : null,
//         ),
//         body: _buildBody(),
//         bottomNavigationBar: posBottomBar('tables', context),
//       ),
//     );
//   }
//
//   Widget _buildBody() {
//     if (hasError) {
//       return Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(Icons.error_outline, size: 48),
//             SizedBox(height: 16),
//             Text(AppLocalizations.of(context).translate('error_loading_data')),
//             ElevatedButton(
//               onPressed: _loadInitialData,
//               child: Text(AppLocalizations.of(context).translate('retry')),
//             ),
//           ],
//         ),
//       );
//     }
//
//     if (isLoading) {
//       return Center(child: Text(AppLocalizations.of(context).translate('table_loading')));
//     }
//
//     if (tables.isEmpty && selectedLocationId == 0) {
//       return Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(Icons.table_chart),
//             Text(AppLocalizations.of(context).translate('no_tables_found')),
//           ],
//         ),
//       );
//     }
//
//     return _buildTableGrid();
//   }
//
//   Widget _buildTableGrid() {
//     return GridView.builder(
//       padding: EdgeInsets.all(MySize.size16 ?? 16.0),
//       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: 2,
//         mainAxisSpacing: MySize.size16 ?? 16.0,
//         crossAxisSpacing: MySize.size16 ?? 16.0,
//         childAspectRatio: 1.0,
//       ),
//       itemCount: tables.length + 1, // +1 for shipping card
//       itemBuilder: (context, index) {
//         if (index == 0) {
//           return _buildShippingCard();
//         }
//         return _buildTableCard(index - 1);
//       },
//     );
//   }
//
//   Widget _buildShippingCard() {
//     final isAvailable = _shippingAvailable;
//
//     return GestureDetector(
//       onTap: isAvailable ? () => _handleShippingTap() : null,
//       onLongPress: !isAvailable ? () => _showEnableDialog(isShipping: true) : null,
//       child: Card(
//         color: isAvailable ? Colors.green : Colors.grey,
//         elevation: 2,
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(
//               Icons.local_shipping,
//               color: isAvailable ? Colors.white : Colors.grey[300],
//               size: MySize.size48 ?? 48.0,
//             ),
//             SizedBox(height: MySize.size8 ?? 8.0),
//             Text(
//               AppLocalizations.of(context).translate('shipping'),
//               style: AppTheme.getTextStyle(
//                 themeData.textTheme.subtitle1,
//                 fontWeight: 600,
//                 color: isAvailable ? Colors.white : Colors.grey[300],
//               ),
//             ),
//             if (!isAvailable) ...[
//               SizedBox(height: MySize.size4 ?? 4.0),
//               Text(
//                 AppLocalizations.of(context).translate('in_use'),
//                 style: AppTheme.getTextStyle(
//                   themeData.textTheme.caption,
//                   color: Colors.grey[300],
//                 ),
//               ),
//             ],
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildTableCard(int tableIndex) {
//     final table = tables[tableIndex];
//     final cartKey = table['id'].toString();
//     final tableId = table['id'] as int;
//     final isAvailable = _tableAvailability[tableId] ?? true;
//
//     return GestureDetector(
//       onTap: isAvailable ? () => _handleTableTap(table, cartKey) : null,
//       onLongPress: !isAvailable ? () => _showEnableDialog(isShipping: false, tableId: tableId) : null,
//       child: Card(
//         color: isAvailable ? Colors.blue : Colors.grey,
//         elevation: 2,
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(
//               Icons.table_restaurant,
//               size: MySize.size48 ?? 48.0,
//               color: isAvailable ? Colors.white : Colors.grey[300],
//             ),
//             SizedBox(height: MySize.size8 ?? 8.0),
//             if (table['name'] != null)
//               Text(
//                 table['name'],
//                 style: AppTheme.getTextStyle(
//                   themeData.textTheme.subtitle1,
//                   fontWeight: 600,
//                   color: isAvailable ? Colors.white : Colors.grey[300],
//                 ),
//               ),
//             if (table['description'] != null)
//               Text(
//                 table['description'],
//                 style: AppTheme.getTextStyle(
//                   themeData.textTheme.bodyText2,
//                   fontWeight: 400,
//                   color: isAvailable ? Colors.white : Colors.grey[300],
//                 ),
//               ),
//             if (!isAvailable) ...[
//               SizedBox(height: MySize.size4 ?? 4.0),
//               Text(
//                 AppLocalizations.of(context).translate('in_use'),
//                 style: AppTheme.getTextStyle(
//                   themeData.textTheme.caption,
//                   color: Colors.grey[300],
//                 ),
//               ),
//             ],
//           ],
//         ),
//       ),
//     );
//   }
//
//   Future<void> _handleShippingTap() async {
//     if (selectedLocationId == 0) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('please_set_a_location'),
//       );
//       return;
//     }
//
//     // Check if shipping is available
//     if (!_shippingAvailable) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('shipping_in_use'),
//       );
//       return;
//     }
//
//     try {
//       const cartKey = 'shipping';
//       int? sellId = AppConstants.cartData[cartKey];
//
//       if (sellId == null) {
//         sellId = await Sell().createSellDraft(
//           locId: selectedLocationId,
//           discountType: '',
//           res_table_id: 0,
//           is_shipping: 1,
//         );
//         setState(() {
//           AppConstants.cartData[cartKey] = sellId ?? 0;
//         });
//         // Add this line to persist cartData
//         await ShareInt().setMap(jsonEncode(AppConstants.cartData));
//       }
//
//       // Don't mark shipping as unavailable yet - wait until customer screen
//
//       Navigator.pushNamed(
//         context,
//         '/products',
//         arguments: {
//           'locationId': selectedLocationId,
//           'sellId': sellId,
//           'cartKey': cartKey,
//           'res_table_id': 0,
//           'is_shipping': 1,
//           'products': [],
//           'isShipping': true, // Add this flag
//         },
//       );
//     } catch (e) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('error_creating_sale'),
//       );
//     }
//   }
//
//   Future<void> _handleTableTap(Map table, String cartKey) async {
//     if (selectedLocationId == 0) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('please_set_a_location'),
//       );
//       return;
//     }
//
//     final tableId = table['id'] as int;
//     final isAvailable = _tableAvailability[tableId] ?? true;
//
//     // Check if table is available
//     if (!isAvailable) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('table_in_use'),
//       );
//       return;
//     }
//
//     try {
//       int? sellId = AppConstants.cartData[cartKey];
//
//       if (sellId == null) {
//         sellId = await Sell().createSellDraft(
//           locId: selectedLocationId,
//           discountType: '',
//           res_table_id: table['id'],
//           is_shipping: 0,
//         );
//         setState(() {
//           AppConstants.cartData[cartKey] = sellId ?? 0;
//         });
//         // Add this line to persist cartData
//         await ShareInt().setMap(jsonEncode(AppConstants.cartData));
//       }
//
//       // Don't mark table as unavailable yet - wait until customer screen
//
//       Navigator.pushNamed(
//         context,
//         '/products',
//         arguments: {
//           'locationId': selectedLocationId,
//           'sellId': sellId,
//           'cartKey': cartKey,
//           'res_table_id': table['id'],
//           'is_shipping': 0,
//           'products': [],
//           'tableName': table['name'], // Add this line to pass table name
//         },
//       );
//     } catch (e) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('error_creating_sale'),
//       );
//     }
//   }
//
//   Widget _buildLocationDropdown() {
//     return DropdownButtonHideUnderline(
//       child: DropdownButton<int>(
//         dropdownColor: themeData.cardColor,
//         icon: Icon(Icons.arrow_drop_down),
//         value: selectedLocationId,
//         items: locationListMap.map<DropdownMenuItem<int>>((Map value) {
//           return DropdownMenuItem<int>(
//             value: value['id'],
//             child: SizedBox(
//               width: MySize.screenWidth! * 0.4,
//               child: Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Text(
//                   '${value['name']}',
//                   softWrap: true,
//                   overflow: TextOverflow.ellipsis,
//                   maxLines: 2,
//                   style: TextStyle(fontSize: 15),
//                 ),
//               ),
//             ),
//           );
//         }).toList(),
//         onChanged: (int? newValue) async {
//           if (newValue != null && newValue != selectedLocationId) {
//             setState(() {
//               isLoading = true;
//               selectedLocationId = newValue;
//               tables = [];
//             });
//             await _fetchTables();
//           }
//         },
//       ),
//     );
//   }
//
//   /// Show enable dialog for disabled tables or shipping
//   void _showEnableDialog({required bool isShipping, int? tableId}) {
//     final title = isShipping
//         ? AppLocalizations.of(context).translate('enable_shipping')
//         : AppLocalizations.of(context).translate('enable_table');
//
//     final message = isShipping
//         ? AppLocalizations.of(context).translate('enable_shipping_message')
//         : AppLocalizations.of(context).translate('enable_table_message');
//
//     showDialog(
//       barrierDismissible: true,
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           backgroundColor: customAppTheme.bgLayer1,
//           title: Text(
//             title,
//             style: AppTheme.getTextStyle(
//               themeData.textTheme.headline6,
//               color: Colors.black,
//               fontWeight: 700,
//             ),
//           ),
//           content: Text(
//             message,
//             style: AppTheme.getTextStyle(
//               themeData.textTheme.subtitle1,
//               color: Colors.black,
//             ),
//           ),
//           actions: [
//             ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                 primary: themeData.colorScheme.primary,
//               ),
//               onPressed: () {
//                 Navigator.of(context).pop(); // Close the dialog
//                 _enableTableOrShipping(isShipping: isShipping, tableId: tableId);
//               },
//               child: Text(AppLocalizations.of(context).translate('enable')),
//             ),
//             ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                 primary: themeData.colorScheme.primary,
//               ),
//               onPressed: () {
//                 Navigator.of(context).pop(); // Close the dialog
//               },
//               child: Text(AppLocalizations.of(context).translate('cancel')),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   /// Enable table or shipping and update availability status
//   void _enableTableOrShipping({required bool isShipping, int? tableId}) async {
//     try {
//       if (isShipping) {
//         // Enable shipping by marking it as available
//         _availabilityManager.markShippingAvailable();
//         setState(() {
//           _shippingAvailable = true;
//         });
//         Fluttertoast.showToast(
//           msg: AppLocalizations.of(context).translate('shipping') + ' ' + AppLocalizations.of(context).translate('enabled'),
//         );
//       } else if (tableId != null) {
//         // Enable table by marking it as available
//         _availabilityManager.markTableAvailable(tableId);
//         setState(() {
//           _tableAvailability[tableId] = true;
//         });
//         Fluttertoast.showToast(
//           msg: AppLocalizations.of(context).translate('tables') + ' ' + AppLocalizations.of(context).translate('enabled'),
//         );
//       }
//     } catch (e) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('error_enabling'),
//       );
//       debugPrint('Error enabling table/shipping: $e');
//     }
//   }
// }
//
// class AppConstants {
//   static Map<String, int?> cartData = {};
//
//   static Future<void> getData() async {
//     try {
//       final data = await ShareInt().getMap();
//       if (data.isNotEmpty) {
//         final decoded = jsonDecode(data);
//         if (decoded is Map) {
//           cartData = Map<String, int?>.from(decoded);
//         }
//       }
//     } catch (e) {
//       print("Error loading cart data: $e");
//       cartData = {};
//     }
//   }
//
//   static Future<void> setData(int id) async {
//     cartData.remove(id.toString());
//     await ShareInt().setMap(jsonEncode(cartData));
//   }
// }
//
// class ShareInt {
//   static final ShareInt _instance = ShareInt._();
//   factory ShareInt() => _instance;
//   ShareInt._();
//
//   late SharedPreferences _preferences;
//   bool _isInitialized = false;
//
//   Future<void> init() async {
//     if (!_isInitialized) {
//       _preferences = await SharedPreferences.getInstance();
//       _isInitialized = true;
//     }
//   }
//
//   Future<void> setMap(String value) async {
//     await init();
//     await _preferences.setString("HEYDATA", value);
//   }
//
//   Future<String> getMap() async {
//     await init();
//     return _preferences.getString("HEYDATA") ?? "";
//   }
// }

import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../config.dart';
import '../helpers/AppTheme.dart';
import '../helpers/Responsive_helper.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/TableAvailabilityManager.dart';
import '../helpers/TableStatePersistence.dart';
import '../helpers/FirebaseTableLockService.dart';
import '../locale/MyLocalizations.dart';
import 'event_bus.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import '../apis/sell.dart';
import '../helpers/otherHelpers.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/sell.dart';
import 'elements.dart';

class Tables extends StatefulWidget {
  @override
  _TablesState createState() => _TablesState();
}

class _TablesState extends State<Tables> with WidgetsBindingObserver {
  List tables = [];
  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
  CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);
  String businessLogo = Config().defaultBusinessImage;
  int selectedLocationId = 0;
  List<Map<String, dynamic>> locationListMap = [];
  bool isLoading = true;
  bool hasError = false;

  // Table availability management
  final TableAvailabilityManager _availabilityManager = TableAvailabilityManager();
  static Map<int, bool> _tableAvailability = {};
  static bool _shippingAvailable = true;
  static bool _shippingAvailabilityInitialized = false;

  // Firebase table lock management
  final FirebaseTableLockService _firebaseLockService = FirebaseTableLockService();
  Map<int, bool> _firebaseTableLocks = {}; // Track Firebase locks separately
  Map<int, String?> _firebaseLockedByUser = {}; // Track who locked each table
  StreamSubscription? _firebaseLocationSubscription;

  // Event subscription for availability changes
  StreamSubscription? _eventSubscription;

  // Timer for periodic validation to prevent stuck tables
  Timer? _validationTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _restoreSavedStates();
    _loadInitialData();
    _setupEventListeners();
    _startPeriodicValidation();
    // Clean up any blank orders when the screen initializes
    _cleanupBlankOrders();
    // Ensure data isolation to prevent table data mixing
    SellDatabase().ensureDataIsolation();
    // FIXED: Validate table states when returning from Products screen
    _validateTableStatesOnReturn();
  }

  /// Save current table and shipping states to persistent storage
  Future<void> _saveCurrentStates() async {
    try {
      await TableStatePersistence.saveAllStates(_tableAvailability, _shippingAvailable);
      debugPrint('TableStatePersistence: Saved current states - ${_tableAvailability.length} tables, shipping: $_shippingAvailable');
    } catch (e) {
      debugPrint('Error saving current states: $e');
    }
  }

  /// Restore saved table and shipping states from persistent storage
  Future<void> _restoreSavedStates() async {
    try {
      // Check if saved states are recent (within 24 hours)
      final areStatesRecent = await TableStatePersistence.areStatesRecent();

      if (areStatesRecent) {
        final savedStates = await TableStatePersistence.loadAllStates();
        final savedTableStates = savedStates['tableStates'] as Map<int, bool>?;
        final savedShippingState = savedStates['shippingAvailable'] as bool?;

        if (savedTableStates != null && savedTableStates.isNotEmpty) {
          setState(() {
            _tableAvailability = Map.from(savedTableStates);
            debugPrint('TableStatePersistence: Restored ${savedTableStates.length} table states');
          });
        }

        if (savedShippingState != null) {
          setState(() {
            _shippingAvailable = savedShippingState;
            _shippingAvailabilityInitialized = true;
            debugPrint('TableStatePersistence: Restored shipping state: $savedShippingState');
          });
        }
      } else {
        debugPrint('TableStatePersistence: Saved states are not recent, will use database validation');
      }
    } catch (e) {
      debugPrint('Error restoring saved states: $e');
    }
  }

  /// Initialize table states on first load
  /// Conservative approach: only initializes unset states, preserves existing ones
  Future<void> _initializeTableStates() async {
    if (selectedLocationId != 0 && tables.isNotEmpty) {
      final tableIds = tables.map<int>((table) => table['id'] as int).toList();

      // Initialize Firebase locks for all tables in this location
      await _initializeFirebaseLocks(tableIds);

      // Initialize table states if not already set (preserve existing states)
      for (int tableId in tableIds) {
        if (!_tableAvailability.containsKey(tableId)) {
          // Only initialize if not already set - this preserves user navigation state
          _tableAvailability[tableId] = await _availabilityManager.isTableAvailable(tableId, locationId: selectedLocationId != 0 ? selectedLocationId : null);
          debugPrint('_initializeTableStates: Initialized table $tableId to ${_tableAvailability[tableId]}');
        } else {
          debugPrint('_initializeTableStates: Preserved existing state for table $tableId: ${_tableAvailability[tableId]}');
        }
      }

      // Initialize shipping state if not already set
      if (!_shippingAvailabilityInitialized) {
        _shippingAvailable = await _availabilityManager.isShippingAvailable(locationId: selectedLocationId != 0 ? selectedLocationId : null);
        _shippingAvailabilityInitialized = true;
        debugPrint('_initializeTableStates: Initialized shipping to $_shippingAvailable');
      } else {
        debugPrint('_initializeTableStates: Preserved existing shipping state: $_shippingAvailable');
      }

      // Save states after initialization
      _saveCurrentStates();

      if (mounted) {
        setState(() {});
      }
    }
  }

  /// Initialize Firebase locks and set up real-time listeners
  Future<void> _initializeFirebaseLocks(List<int> tableIds) async {
    try {
      // Cancel existing subscription if any
      _firebaseLocationSubscription?.cancel();

      // Check initial lock status for all tables
      for (int tableId in tableIds) {
        final isLocked = await _firebaseLockService.isTableLocked(
          tableId: tableId,
          locationId: selectedLocationId,
        );
        _firebaseTableLocks[tableId] = isLocked;

        if (isLocked) {
          final lockInfo = await _firebaseLockService.getTableLockInfo(
            tableId: tableId,
            locationId: selectedLocationId,
          );
          _firebaseLockedByUser[tableId] = lockInfo?['lockedByUserName'] as String?;
        }
      }

      // Set up real-time listener for all tables in this location
      _firebaseLocationSubscription = _firebaseLockService.listenToAllTablesInLocation(
        locationId: selectedLocationId,
        onTableStatusChanged: (tableId, isLocked, lockedByUserId, lockedByUserName) {
          if (mounted) {
            // Track previous lock state to detect unlock events
            bool wasPreviouslyLocked = _firebaseTableLocks[tableId] ?? false;

            debugPrint('Tables: Firebase table status changed - tableId: $tableId, isLocked: $isLocked, wasPreviouslyLocked: $wasPreviouslyLocked, lockedByUserId: $lockedByUserId');

            // Check if locked by current user (Device A scenario)
            final isLockedByCurrentUser = isLocked && lockedByUserId != null && lockedByUserId == Config.userId;
            // Check if locked by another user (Device B scenario)
            final isLockedByOther = isLocked && lockedByUserId != null && lockedByUserId != Config.userId;

            setState(() {
              _firebaseTableLocks[tableId] = isLockedByOther; // Track locks by other users
              _firebaseLockedByUser[tableId] = lockedByUserName;

              // CRITICAL FIX: If table is locked (by current user or another user), disable it
              if (isLocked) {
                _tableAvailability[tableId] = false;
                if (isLockedByCurrentUser) {
                  debugPrint('Tables: Table $tableId locked by current user - disabling locally on Device A');
                } else if (isLockedByOther) {
                  debugPrint('Tables: Table $tableId locked by another user - disabling locally');
                }
              }

              // Show notification if table was just locked by another user
              // if (isLockedByOther && lockedByUserName != null) {
              //   Fluttertoast.showToast(
              //     msg: AppLocalizations.of(context).translate('table_already_in_use') ??
              //         'Table already in use.',
              //     toastLength: Toast.LENGTH_SHORT,
              //   );
              // }
            });

            // CRITICAL: When a table is unlocked (was locked but now unlocked),
            // it means an order was completed on another device. We need to sync
            // the order status and enable the table on this device.
            if (wasPreviouslyLocked && !isLocked) {
              debugPrint('Tables: Table $tableId unlocked in Firebase (transition from locked to unlocked) - syncing order status and enabling table');
              _handleTableUnlockedFromAnotherDevice(tableId);
            } else if (!wasPreviouslyLocked && !isLocked) {
              // Table was already unlocked - check if we have stale draft orders
              debugPrint('Tables: Table $tableId is already unlocked in Firebase - checking for stale draft orders');
              _handleTableUnlockedFromAnotherDevice(tableId);
            }
          }
        },
      );

      debugPrint('FirebaseTableLockService: Initialized locks for ${tableIds.length} tables in location $selectedLocationId');
    } catch (e) {
      debugPrint('Error initializing Firebase locks: $e');
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Only refresh availability when returning to this page if we don't have cached states
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && selectedLocationId != 0) {
        // Only initialize table states if we don't have any cached states
        // This prevents unnecessary resets when navigating between screens
        if (_tableAvailability.isEmpty && !_shippingAvailabilityInitialized) {
          _initializeTableStates();
        } else {
          // Just update the UI with existing states
          setState(() {});
        }
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed && mounted) {
      // Trigger immediate refresh when app becomes active
      debugPrint('Tables screen: App resumed, triggering immediate auto-refresh');
      if (selectedLocationId != 0 && tables.isNotEmpty) {
        _performAutoRefresh();
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _eventSubscription?.cancel();
    _validationTimer?.cancel();
    _firebaseLocationSubscription?.cancel();
    _firebaseLockService.cancelLocationSubscription(selectedLocationId);
    super.dispose();
  }

  /// Setup event listeners for table/shipping availability changes
  void _setupEventListeners() {
    _eventSubscription = EventBus().stream.listen((event) {
      if (event is TableAvailabilityChangedEvent) {
        _handleAvailabilityChange(event);
      } else if (event is SaleFinalizedEvent || event is DraftFinalizedEvent || event is QuotationFinalizedEvent) {
        // When an order is finalized, refresh table states to ensure consistency
        _handleOrderFinalized();
      }
    });
  }

  /// Handle table/shipping availability change events
  void _handleAvailabilityChange(TableAvailabilityChangedEvent event) {
    if (!mounted) return;

    setState(() {
      if (event.isShipping) {
        _shippingAvailable = event.isAvailable;
        _shippingAvailabilityInitialized = true;
        debugPrint('Tables screen: Shipping availability updated to ${event.isAvailable}');
        // Save state when shipping availability changes
        _saveCurrentStates();
      } else if (event.tableId != null) {
        // Update local availability, but also check Firebase lock status
        final tableId = event.tableId!;

        // CRITICAL: Check Firebase lock status BEFORE setting availability
        if (event.isAvailable && selectedLocationId > 0) {
          _firebaseLockService.getTableLockInfo(
            tableId: tableId,
            locationId: selectedLocationId,
          ).then((lockInfo) {
            final isLockedInFirebase = lockInfo != null;
            final lockedByUserId = lockInfo?['lockedByUserId'] as int?;
            final isLockedByCurrentUser = isLockedInFirebase && lockedByUserId == Config.userId;

            if (mounted) {
              setState(() {
                if (isLockedInFirebase) {
                  // Table is locked in Firebase (by current user or another user) - disable it
                  _tableAvailability[tableId] = false;
                  _firebaseTableLocks[tableId] = isLockedByCurrentUser ? false : true; // Track locks by other users
                  _firebaseLockedByUser[tableId] = lockInfo?['lockedByUserName'] as String?;
                  debugPrint('Tables screen: Table $tableId is locked in Firebase (by ${isLockedByCurrentUser ? "current user" : "another user"}), overriding local availability');
                } else {
                  // Table is not locked - allow the availability update
                  _tableAvailability[tableId] = event.isAvailable;
                  debugPrint('Tables screen: Table ${event.tableId} availability updated to ${event.isAvailable}');
                }
                // Save state when table availability changes
                _saveCurrentStates();
              });
            }
          });
        } else {
          // If event says table is not available, just update it
          _tableAvailability[tableId] = event.isAvailable;
          debugPrint('Tables screen: Table ${event.tableId} availability updated to ${event.isAvailable}');
          // Save state when table availability changes
          _saveCurrentStates();
        }
      }
    });
  }

  /// Handle order finalization events - trigger immediate auto-refresh
  void _handleOrderFinalized() {
    if (!mounted) return;

    debugPrint('Tables screen: Order finalized event received, triggering immediate auto-refresh');
    // Trigger immediate auto-refresh when an order is finalized for instant updates
    // This ensures that tables are immediately enabled after order completion
    if (selectedLocationId != 0 && tables.isNotEmpty) {
      _performAutoRefresh();
    }
  }

  /// Handle table unlock from another device - sync order status and enable table
  /// This is called when a table is unlocked in Firebase, indicating an order
  /// was completed on another device (Device B). We need to sync the order status
  /// and enable the table on this device (Device A).
  Future<void> _handleTableUnlockedFromAnotherDevice(int tableId) async {
    if (!mounted || selectedLocationId == 0) return;

    try {
      debugPrint('_handleTableUnlockedFromAnotherDevice: Processing unlock for table $tableId');

      // Get all draft and quotation orders for this table from local database
      final allOrders = await SellDatabase().getSells(all: true);
      final draftOrders = allOrders.where((order) =>
      order['res_table_id'] == tableId &&
          (order['is_shipping'] ?? 0) == 0 &&
          (order['sale_status'] == 'draft' || order['sale_status'] == 'quotation') &&
          (order['is_synced'] != 1) &&
          (order['location_id'] == selectedLocationId)
      ).toList();

      if (draftOrders.isEmpty) {
        debugPrint('_handleTableUnlockedFromAnotherDevice: No draft/quotation orders found for table $tableId - table is already available');
        // No active orders, re-validate and enable the table
        await _syncAndRevalidateTable(tableId);
        return;
      }

      debugPrint('_handleTableUnlockedFromAnotherDevice: Found ${draftOrders.length} draft/quotation orders for table $tableId');

      // For each draft/quotation order, sync from API if it has transaction_id
      // Otherwise, mark as final since the table is unlocked (order was completed on another device)
      for (var order in draftOrders) {
        int sellId = order['id'];
        String? transactionId = order['transaction_id']?.toString();

        if (transactionId != null && transactionId.isNotEmpty) {
          // Order has transaction_id - sync from API to get latest status
          debugPrint('_handleTableUnlockedFromAnotherDevice: Syncing order $sellId (transaction_id: $transactionId) from API');

          try {
            // Check connectivity before syncing
            if (await Helper().checkConnectivity()) {
              List specificSales = await SellApi().getSpecifiedSells([transactionId]);

              if (specificSales.isNotEmpty) {
                var saleData = specificSales[0];
                String apiStatus = saleData['status']?.toString() ?? '';

                // Update local database with API status
                // Since table is unlocked, order was completed on another device, so set to 'final'
                await SellDatabase().updateSells(sellId, {
                  'sale_status': 'final', // Always 'final' since table is unlocked
                  'is_synced': 1,
                  'transaction_id': saleData['id']?.toString() ?? transactionId,
                });

                debugPrint('_handleTableUnlockedFromAnotherDevice: Updated order $sellId status to final (API status was: $apiStatus, but table unlock indicates completion)');
              } else {
                // Order not found in API - mark as final since table is unlocked
                debugPrint('_handleTableUnlockedFromAnotherDevice: Order $sellId not found in API - marking as final since table is unlocked');

                // Use multiple attempts to ensure the update persists
                int updateAttempts = 0;
                bool updateSuccessful = false;

                while (updateAttempts < 3 && !updateSuccessful) {
                  updateAttempts++;
                  await SellDatabase().updateSells(sellId, {
                    'sale_status': 'final',
                    'is_synced': 1,
                  });

                  // Verify the update
                  var verifyRecord = await SellDatabase().getSellBySellId(sellId);
                  if (verifyRecord.isNotEmpty) {
                    String? actualStatus = verifyRecord[0]['sale_status']?.toString();
                    int? isSynced = verifyRecord[0]['is_synced'];
                    if (actualStatus == 'final' && isSynced == 1) {
                      updateSuccessful = true;
                    } else if (updateAttempts < 3) {
                      await Future.delayed(Duration(milliseconds: 200));
                    }
                  }
                }
              }
            } else {
              // No connectivity - mark as final since table is unlocked
              debugPrint('_handleTableUnlockedFromAnotherDevice: No connectivity - marking order $sellId as final since table is unlocked');

              // Use multiple attempts to ensure the update persists
              int updateAttempts = 0;
              bool updateSuccessful = false;

              while (updateAttempts < 3 && !updateSuccessful) {
                updateAttempts++;
                await SellDatabase().updateSells(sellId, {
                  'sale_status': 'final',
                  'is_synced': 1,
                });

                // Verify the update
                var verifyRecord = await SellDatabase().getSellBySellId(sellId);
                if (verifyRecord.isNotEmpty) {
                  String? actualStatus = verifyRecord[0]['sale_status']?.toString();
                  int? isSynced = verifyRecord[0]['is_synced'];
                  if (actualStatus == 'final' && isSynced == 1) {
                    updateSuccessful = true;
                  } else if (updateAttempts < 3) {
                    await Future.delayed(Duration(milliseconds: 200));
                  }
                }
              }
            }
          } catch (e) {
            debugPrint('_handleTableUnlockedFromAnotherDevice: Error syncing order $sellId from API: $e');
            // On error, mark as final since table is unlocked
            // Use multiple attempts to ensure the update persists
            int updateAttempts = 0;
            bool updateSuccessful = false;

            while (updateAttempts < 3 && !updateSuccessful) {
              updateAttempts++;
              await SellDatabase().updateSells(sellId, {
                'sale_status': 'final',
                'is_synced': 1,
              });

              // Verify the update
              var verifyRecord = await SellDatabase().getSellBySellId(sellId);
              if (verifyRecord.isNotEmpty) {
                String? actualStatus = verifyRecord[0]['sale_status']?.toString();
                int? isSynced = verifyRecord[0]['is_synced'];
                if (actualStatus == 'final' && isSynced == 1) {
                  updateSuccessful = true;
                } else if (updateAttempts < 3) {
                  await Future.delayed(Duration(milliseconds: 200));
                }
              }
            }
          }
        } else {
          // Order doesn't have transaction_id - mark as final since table is unlocked
          debugPrint('_handleTableUnlockedFromAnotherDevice: Order $sellId has no transaction_id - marking as final since table is unlocked');

          // Use multiple attempts to ensure the update persists, similar to finalizeOrder
          int updateAttempts = 0;
          bool updateSuccessful = false;

          while (updateAttempts < 3 && !updateSuccessful) {
            updateAttempts++;
            await SellDatabase().updateSells(sellId, {
              'sale_status': 'final',
              'is_synced': 1,
            });

            // Verify the update
            var verifyRecord = await SellDatabase().getSellBySellId(sellId);
            if (verifyRecord.isNotEmpty) {
              String? actualStatus = verifyRecord[0]['sale_status']?.toString();
              int? isSynced = verifyRecord[0]['is_synced'];
              if (actualStatus == 'final' && isSynced == 1) {
                updateSuccessful = true;
                debugPrint('_handleTableUnlockedFromAnotherDevice: Successfully updated order $sellId to final (attempt $updateAttempts)');
              } else {
                debugPrint('_handleTableUnlockedFromAnotherDevice: Update not verified for order $sellId (attempt $updateAttempts) - status: $actualStatus, is_synced: $isSynced');
                if (updateAttempts < 3) {
                  await Future.delayed(Duration(milliseconds: 200));
                }
              }
            }
          }

          if (!updateSuccessful) {
            debugPrint('_handleTableUnlockedFromAnotherDevice: WARNING - Failed to update order $sellId after 3 attempts');
          }
        }
      }

      // Re-validate and enable the table after updating order statuses
      await _syncAndRevalidateTable(tableId);

      debugPrint('_handleTableUnlockedFromAnotherDevice: Completed processing unlock for table $tableId');
    } catch (e, stackTrace) {
      debugPrint('_handleTableUnlockedFromAnotherDevice: Error processing unlock for table $tableId: $e');
      debugPrint('Stack trace: $stackTrace');
      // Even on error, try to re-validate the table
      await _syncAndRevalidateTable(tableId);
    }
  }

  /// Sync and re-validate table availability after order status update
  Future<void> _syncAndRevalidateTable(int tableId) async {
    if (!mounted || selectedLocationId == 0) return;

    try {
      debugPrint('_syncAndRevalidateTable: Re-validating table $tableId');

      // Re-validate table availability - this will check the database and update cache
      final tableIds = [tableId];
      final validatedAvailability = await _availabilityManager.autoValidateTableStates(
        tableIds,
        locationId: selectedLocationId,
      );

      bool isAvailable = validatedAvailability[tableId] ?? true;

      // Double-check Firebase lock status
      bool isFirebaseLocked = await _firebaseLockService.isTableLocked(
        tableId: tableId,
        locationId: selectedLocationId,
      );

      // Table is available only if both local DB and Firebase say it's available
      bool isFullyAvailable = isAvailable && !isFirebaseLocked;

      if (mounted) {
        setState(() {
          _tableAvailability[tableId] = isFullyAvailable;
          _firebaseTableLocks[tableId] = isFirebaseLocked;
        });
        _saveCurrentStates();
        debugPrint('_syncAndRevalidateTable: Table $tableId availability set to $isFullyAvailable (local: $isAvailable, Firebase locked: $isFirebaseLocked)');
      }
    } catch (e) {
      debugPrint('_syncAndRevalidateTable: Error re-validating table $tableId: $e');
    }
  }

  /// Start periodic validation to prevent tables from getting stuck in disabled state
  void _startPeriodicValidation() {
    // Auto-refresh table states every 3 seconds for instant updates
    // More frequent updates for real-time experience without manual refresh
    _validationTimer = Timer.periodic(Duration(seconds: 3), (timer) {
      if (mounted && selectedLocationId != 0 && tables.isNotEmpty) {
        _performAutoRefresh();
      }
    });
  }

  /// Perform automatic refresh of table states for real-time updates
  Future<void> _performAutoRefresh() async {
    try {
      debugPrint('Tables screen: Performing auto-refresh for real-time updates');

      final tableIds = tables.map<int>((table) => table['id'] as int).toList();

      // Always perform refresh for real-time updates
      // This ensures instant updates when orders are finalized/cancelled

      final validatedAvailability = await _availabilityManager.autoValidateTableStates(tableIds, locationId: selectedLocationId != 0 ? selectedLocationId : null);
      final shippingAvailable = await _availabilityManager.isShippingAvailable(locationId: selectedLocationId != 0 ? selectedLocationId : null);

      // Real-time updates: enable truly available tables/shipping, preserve currently enabled ones
      // Also check Firebase locks to ensure consistency
      bool hasChanges = false;
      for (int tableId in tableIds) {
        bool isCurrentlyEnabled = _tableAvailability[tableId] ?? true;
        bool isActuallyAvailable = validatedAvailability[tableId] ?? true;

        // Check Firebase lock status for this table - CRITICAL: Must check if locked by anyone (including current user)
        bool isFirebaseLocked = false;
        bool isLockedByOther = _firebaseTableLocks[tableId] ?? false;
        if (selectedLocationId > 0) {
          // Always double-check Firebase lock status for accurate state
          try {
            // Use getTableLockInfo to check if locked by anyone (current user or other user)
            final lockInfo = await _firebaseLockService.getTableLockInfo(
              tableId: tableId,
              locationId: selectedLocationId,
            );

            // If lockInfo is not null, table is locked
            isFirebaseLocked = lockInfo != null;
            final lockedByUserId = lockInfo?['lockedByUserId'] as int?;
            isLockedByOther = isFirebaseLocked && lockedByUserId != Config.userId;

            // Update tracking
            _firebaseTableLocks[tableId] = isLockedByOther; // Track locks by other users
            _firebaseLockedByUser[tableId] = lockInfo?['lockedByUserName'] as String?;

            if (isFirebaseLocked) {
              debugPrint('Tables screen: Auto-refresh detected table $tableId is locked in Firebase (by ${lockedByUserId == Config.userId ? "current user" : "another user"})');
            }
          } catch (e) {
            debugPrint('Tables: Error checking Firebase lock for table $tableId: $e');
            // On error, use cached state
            isFirebaseLocked = isLockedByOther;
          }
        } else {
          // Fallback to cached state if no location
          isFirebaseLocked = isLockedByOther;
        }

        // CRITICAL: If table is unlocked in Firebase but local DB says unavailable (has draft orders),
        // it means the order was completed on another device. We need to sync/update the order status.
        if (!isFirebaseLocked && !isActuallyAvailable && selectedLocationId > 0) {
          debugPrint('Tables screen: Table $tableId is unlocked in Firebase but has draft orders locally - syncing order status');
          // Handle table unlock from another device to sync order status
          // Don't use unawaited - wait for it to complete so we get accurate state
          await _handleTableUnlockedFromAnotherDevice(tableId);
          // Re-validate after syncing
          final reValidatedAvailability = await _availabilityManager.autoValidateTableStates(
            [tableId],
            locationId: selectedLocationId,
          );
          isActuallyAvailable = reValidatedAvailability[tableId] ?? true;
          debugPrint('Tables screen: After sync, table $tableId availability: $isActuallyAvailable');
        }

        // Table is available only if both local DB and Firebase say it's available
        bool isFullyAvailable = isActuallyAvailable && !isFirebaseLocked;

        if (isFullyAvailable && !isCurrentlyEnabled) {
          // Enable if truly available and currently disabled
          _tableAvailability[tableId] = true;
          hasChanges = true;
          debugPrint('Tables screen: Auto-refresh enabled table $tableId');
        } else if (!isFullyAvailable && isCurrentlyEnabled) {
          // Disable if locked in Firebase (even if local DB says available)
          _tableAvailability[tableId] = false;
          hasChanges = true;
          debugPrint('Tables screen: Auto-refresh disabled table $tableId (Firebase locked)');
        }
      }

      // Real-time shipping updates: enable if truly available, preserve currently enabled
      bool isCurrentlyShippingEnabled = _shippingAvailable;
      if (shippingAvailable && !isCurrentlyShippingEnabled) {
        _shippingAvailable = true;
        _shippingAvailabilityInitialized = true;
        hasChanges = true;
        debugPrint('Tables screen: Auto-refresh enabled shipping');
      }
      // Never disable currently enabled shipping during auto-refresh

      // Update UI and save states if there were changes
      if (hasChanges && mounted) {
        setState(() {});
        // Save states after auto-refresh changes
        _saveCurrentStates();
        debugPrint('Tables screen: Auto-refresh completed with updates');
      } else {
        debugPrint('Tables screen: Auto-refresh completed - no changes needed');
      }
    } catch (e) {
      debugPrint('Error in periodic validation: $e');
    }
  }

  Future<void> _loadInitialData() async {
    try {
      // Load essential data first
      await _loadLocations();

      // Set default location if only one exists
      if (locationListMap.length == 2) {
        selectedLocationId = locationListMap[1]['id'] as int;
      }

      // Fetch tables for the selected location
      if (selectedLocationId != 0) {
        await _fetchTables();
        // Initialize table states on first load or when no cached states exist
        await _initializeTableStates();
      }

      // Load non-essential data in background
      unawaited(AppConstants.getData());
    } catch (e) {
      setState(() {
        hasError = true;
      });
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_loading_data'),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _loadLocations() async {
    locationListMap.clear();
    locationListMap.add({'id': 0, 'name': 'set location', 'selling_price_group_id': 0});

    try {
      final locations = await System().get('location');
      final existingIds = <int>{0};

      for (var element in locations) {
        if (element['is_active'].toString() == '1') {
          final id = element['id'];
          if (!existingIds.contains(id)) {
            locationListMap.add({
              'id': id,
              'name': element['name'],
              'selling_price_group_id': element['selling_price_group_id']
            });
            existingIds.add(id);
          }
        }
      }
    } catch (e) {
      throw Exception('Failed to load locations');
    }
  }

  Future<void> _fetchTables() async {
    if (selectedLocationId == 0) {
      setState(() {
        tables = [];
      });
      return;
    }

    try {
      setState(() {
        isLoading = true;
      });

      final dio = Dio();
      final token = await System().getToken();
      dio.options.headers['Authorization'] = "Bearer $token";

      final response = await dio.get(
        Config.baseUrl + 'connector/api/table',
        options: Options(receiveTimeout: Duration(seconds: 10)),
      );

      if (response.statusCode == 200) {
        List filteredTables = response.data['data']
            .where((table) => table['deleted_at'] == null &&
            table['location_id'] == selectedLocationId)
            .toList();



        final docList= (await FirebaseFirestore.instance.collection('Table').get()).docs.map((e) => e.id).toList();



        filteredTables.forEach((element) {
          if(!docList.contains(element['id'])){
            FirebaseFirestore.instance
                .collection('Table')
                .doc('${element['id']}')
                .set({
              "Status":0
            });
          }
        });

        setState(() {
          tables = filteredTables;
        });
      } else {
        throw Exception('Failed to load tables');
      }
    } catch (e,st) {
      print("E::::::$e $st");
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_loading_tables'),
      );
      throw Exception('Failed to fetch tables');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _checkAvailability() async {
    try {
      final tableIds = tables.map<int>((table) => table['id'] as int).toList();

      // Only check availability for tables that don't have a cached state
      // This preserves the existing table states and prevents unnecessary resets
      final Map<int, bool> newTableAvailability = {};

      for (int tableId in tableIds) {
        if (_tableAvailability.containsKey(tableId)) {
          // Preserve existing state for tables that already have a state
          newTableAvailability[tableId] = _tableAvailability[tableId]!;
          debugPrint('Tables screen: Preserving existing state for table $tableId: ${_tableAvailability[tableId]}');
        } else {
          // Only check availability for new tables
          newTableAvailability[tableId] = await _availabilityManager.isTableAvailable(tableId, locationId: selectedLocationId != 0 ? selectedLocationId : null);
          debugPrint('Tables screen: Checking availability for new table $tableId: ${newTableAvailability[tableId]}');
        }
      }

      _tableAvailability = newTableAvailability;

      // Check shipping availability (preserve existing state if available)
      if (!_shippingAvailabilityInitialized) {
        _shippingAvailable = await _availabilityManager.isShippingAvailable(locationId: selectedLocationId != 0 ? selectedLocationId : null);
        _shippingAvailabilityInitialized = true;
        debugPrint('Tables screen: Checking shipping availability: $_shippingAvailable');
      } else {
        debugPrint('Tables screen: Preserving existing shipping availability: $_shippingAvailable');
      }

      if (mounted) {
        setState(() {});
        debugPrint('Tables screen: setState called, shipping available: $_shippingAvailable');
        debugPrint('Tables screen: Table availability: $_tableAvailability');
      }
    } catch (e) {
      debugPrint('Error checking availability: $e');
      // Only set as available if no existing state exists
      final tableIds = tables.map<int>((table) => table['id'] as int).toList();
      for (int tableId in tableIds) {
        if (!_tableAvailability.containsKey(tableId)) {
          _tableAvailability[tableId] = true;
        }
      }
      _shippingAvailable = true;
      if (mounted) {
        setState(() {});
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: true,
      top: false,
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                AppLocalizations.of(context).translate('tables'),
                style: AppTheme.getTextStyle(
                  themeData.textTheme.headline6,
                  fontWeight: 600,
                ),
              ),
              Row(
                children: [
                  // Smart recovery button
                  IconButton(
                    icon: Icon(Icons.refresh, color: Colors.black),
                    onPressed: _emergencyRecovery,
                    // tooltip: 'Smart Recovery - Enable Available Tables Only',
                    tooltip: AppLocalizations.of(context).translate('refresh'),
                  ),
                  Card(
                    //color: Colors.grey,
                      child: _buildLocationDropdown()),
                ],
              ),
            ],
          ),
          bottom: isLoading
              ? PreferredSize(
            preferredSize: Size.fromHeight(4.0),
            child: LinearProgressIndicator(),
          )
              : null,
        ),
        body: _isTabletLandscape(context)
            ? _buildBody() // Full width for landscape tablets
            : (ResponsiveHelper.shouldCenterContent(context)
            ? Container(
          width: ResponsiveHelper.getContentWidth(context, maxWidth: 1200),
          margin: EdgeInsets.symmetric(horizontal: ResponsiveHelper.isTablet(context) ? 24 : 0),
          child: _buildBody(),
        )
            : _buildBody()),
        bottomNavigationBar: posBottomBar('tables', context),
      ),
    );
  }

  Widget _buildBody() {
    if (hasError) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48),
            SizedBox(height: 16),
            Text(AppLocalizations.of(context).translate('error_loading_data')),
            ElevatedButton(
              onPressed: _loadInitialData,
              child: Text(AppLocalizations.of(context).translate('retry')),
            ),
          ],
        ),
      );
    }

    if (isLoading) {
      return Center(child: Text(AppLocalizations.of(context).translate('table_loading')));
    }

    if (tables.isEmpty && selectedLocationId == 0) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.table_chart),
            Text(AppLocalizations.of(context).translate('no_tables_found')),
          ],
        ),
      );
    }

    return _buildTableGrid();
  }

  // Helper method to check if device is tablet in landscape orientation
  bool _isTabletLandscape(BuildContext context) {
    try {
      final orientation = MediaQuery.of(context).orientation;
      final width = MediaQuery.of(context).size.width;
      // Check if it's landscape AND has width >= 600px (tablet or desktop size)
      return orientation == Orientation.landscape && width >= 600;
    } catch (e) {
      return false;
    }
  }

  // Get cross axis count for table grid based on device type and orientation
  int _getTableGridCrossAxisCount(BuildContext context) {
    if (_isTabletLandscape(context)) {
      // For tablets in landscape, use more columns to fill the screen
      final width = MediaQuery.of(context).size.width;
      if (width >= 1200) {
        return 6; // Very large screens get 6 columns
      } else if (width >= 900) {
        return 5; // Large tablets get 5 columns
      } else {
        return 4; // Smaller tablets in landscape get 4 columns
      }
    }
    return ResponsiveHelper.getCrossAxisCount(context,
      mobileCount: 2,
      tabletCount: 3,
      desktopCount: 4,
    );
  }

  Widget _buildTableGrid() {
    return RefreshIndicator(
      onRefresh: _handlePullToRefresh,
      child: StreamBuilder(stream: FirebaseFirestore.instance.collection("Table").snapshots(),
        builder: (context, snapshot) {
          Map docList={};
          if(snapshot.hasData){

            for (var doc in snapshot.data!.docs) {
              docList[doc.id]=doc.data();
            };

          }
          return GridView.builder(
            padding: ResponsiveHelper.getResponsivePadding(context,
              mobilePadding: MySize.size16 ?? 16.0,
              tabletPadding: MySize.size20 ?? 20.0,
              desktopPadding: MySize.size24 ?? 24.0,
            ),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: _getTableGridCrossAxisCount(context),
              mainAxisSpacing: ResponsiveHelper.getResponsiveSpacing(context,
                mobileSpacing: MySize.size16 ?? 16.0,
                tabletSpacing: MySize.size20 ?? 20.0,
                desktopSpacing: MySize.size24 ?? 24.0,
              ),
              crossAxisSpacing: ResponsiveHelper.getResponsiveSpacing(context,
                mobileSpacing: MySize.size16 ?? 16.0,
                tabletSpacing: MySize.size20 ?? 20.0,
                desktopSpacing: MySize.size24 ?? 24.0,
              ),
              childAspectRatio: _isTabletLandscape(context)
                  ? 1.0  // Better aspect ratio for landscape tablets
                  : (ResponsiveHelper.isTablet(context) ? 1.1 : 1.0),
            ),
            itemCount: tables.length + 1, // +1 for shipping card
            itemBuilder: (context, index) {
              if (index == 0) {
                return _buildShippingCard();
              }
              return _buildTableCard(index - 1,docList);
            },
          );
        },
      ),


    );
  }

  /// Handle pull-to-refresh functionality
  Future<void> _handlePullToRefresh() async {
    try {
      debugPrint('Pull-to-refresh: Starting refresh...');

      // Refresh table data
      await _fetchTables();

      // Refresh table availability states
      await _refreshTableAvailability();

      debugPrint('Pull-to-refresh: Refresh completed');

      // Show success message
      Fluttertoast.showToast(
        msg: 'Tables refreshed successfully',
        toastLength: Toast.LENGTH_SHORT,
      );
    } catch (e) {
      debugPrint('Error in pull-to-refresh: $e');
      Fluttertoast.showToast(
        msg: 'Error refreshing tables',
        toastLength: Toast.LENGTH_SHORT,
      );
    }
  }

  /// Refresh table availability states - CONSERVATIVE APPROACH
  /// Only enables truly available tables/shipping, never disables currently enabled ones
  Future<void> _refreshTableAvailability() async {
    try {
      if (tables.isEmpty) return;

      final tableIds = tables.map<int>((table) => table['id'] as int).toList();

      // Get fresh availability status from database
      final validatedAvailability = await _availabilityManager.autoValidateTableStates(tableIds, locationId: selectedLocationId != 0 ? selectedLocationId : null);
      final shippingAvailable = await _availabilityManager.isShippingAvailable(locationId: selectedLocationId != 0 ? selectedLocationId : null);

      // Check Firebase locks for all tables - CRITICAL: Must respect Firebase locks
      Map<int, bool> firebaseLockStates = {}; // Track if locked by anyone (current user or other)
      Map<int, int?> firebaseLockedByUserIds = {}; // Track who locked each table

      for (int tableId in tableIds) {
        try {
          // Get actual lock info to check if locked by anyone (including current user)
          final lockInfo = await _firebaseLockService.getTableLockInfo(
            tableId: tableId,
            locationId: selectedLocationId,
          );

          // If lockInfo is not null, table is locked
          final isLockedInFirebase = lockInfo != null;
          final lockedByUserId = lockInfo?['lockedByUserId'] as int?;
          final isLockedByCurrentUser = isLockedInFirebase && lockedByUserId == Config.userId;
          final isLockedByOther = isLockedInFirebase && lockedByUserId != Config.userId;

          firebaseLockStates[tableId] = isLockedInFirebase;
          firebaseLockedByUserIds[tableId] = lockedByUserId;

          // Update Firebase lock tracking
          _firebaseTableLocks[tableId] = isLockedByOther; // Track locks by other users
          _firebaseLockedByUser[tableId] = lockInfo?['lockedByUserName'] as String?;
        } catch (e) {
          debugPrint('_refreshTableAvailability: Error checking Firebase lock for table $tableId: $e');
          firebaseLockStates[tableId] = false; // Assume not locked on error
        }
      }

      // CONSERVATIVE UPDATE: Only enable truly available AND not locked in Firebase
      setState(() {
        for (int tableId in tableIds) {
          bool isActuallyAvailable = validatedAvailability[tableId] ?? true;
          bool isLockedInFirebase = firebaseLockStates[tableId] ?? false;
          final lockedByUserId = firebaseLockedByUserIds[tableId];
          final isLockedByCurrentUser = isLockedInFirebase && lockedByUserId == Config.userId;
          final isLockedByOther = isLockedInFirebase && lockedByUserId != Config.userId;

          if (isLockedInFirebase) {
            // Table is locked in Firebase (by current user or another user) - disable it
            _tableAvailability[tableId] = false;
            debugPrint('_refreshTableAvailability: Table $tableId is locked in Firebase (by ${isLockedByCurrentUser ? "current user" : "another user"}) - disabling');
          } else if (isActuallyAvailable) {
            // Enable if truly available AND not locked in Firebase
            _tableAvailability[tableId] = true;
          }
          // NEVER disable currently enabled tables during navigation refresh UNLESS locked in Firebase
          // This preserves enabled state when navigating Tables → Product → Tables
        }

        // CONSERVATIVE SHIPPING UPDATE: Only enable if truly available, never disable currently enabled
        bool isCurrentlyShippingEnabled = _shippingAvailable;
        if (shippingAvailable) {
          _shippingAvailable = true;
        }
        // NEVER disable currently enabled shipping during navigation refresh
        // This preserves enabled state when navigating Tables → Product → Tables

        _shippingAvailabilityInitialized = true;
      });

      // Save states after refresh
      _saveCurrentStates();

      debugPrint('_refreshTableAvailability: Conservative refresh completed for ${tableIds.length} tables');
    } catch (e) {
      debugPrint('Error in _refreshTableAvailability: $e');
    }
  }

  Widget _buildShippingCard() {
    final isAvailable = _shippingAvailable;

    return GestureDetector(
      onTap: isAvailable ? () => _handleShippingTap() : null,
      onLongPress: !isAvailable ? () => _showEnableDialog(isShipping: true) : null,
      child: Card(
        color: isAvailable ? Colors.green : Colors.grey,
        elevation: 2,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.local_shipping,
              color: isAvailable ? Colors.white : Colors.grey[300],
              size: MySize.size48 ?? 48.0,
            ),
            SizedBox(height: MySize.size8 ?? 8.0),
            Text(
              AppLocalizations.of(context).translate('shipping'),
              style: AppTheme.getTextStyle(
                themeData.textTheme.subtitle1,
                fontWeight: 600,
                color: isAvailable ? Colors.white : Colors.grey[300],
              ),
            ),
            if (!isAvailable) ...[
              SizedBox(height: MySize.size4 ?? 4.0),
              Text(
                AppLocalizations.of(context).translate('in_use'),
                style: AppTheme.getTextStyle(
                  themeData.textTheme.caption,
                  color: Colors.grey[300],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTableCard(int tableIndex, Map docList) {
    final table = tables[tableIndex];
    final cartKey = table['id'].toString();
    final tableId = table['id'] as int;
    final isAvailable = _tableAvailability[tableId] ?? true;
    final isFirebaseLocked = _firebaseTableLocks[tableId] ?? false;

    // Table is disabled if it's either locally unavailable OR locked in Firebase
    final isDisabled = !isAvailable || isFirebaseLocked;

    // Determine card color: grey if disabled, blue if available
    final cardColor = isDisabled ? Colors.grey : (docList['${table['id']}']['Status'] == 0 ? Colors.blue : Colors.grey);
    final textColor = isDisabled ? Colors.grey[300] : Colors.white;

    return GestureDetector(
      onTap: isDisabled ? null : () => _handleTableTap(table, cartKey),
      onLongPress: isDisabled ? () => _showEnableDialog(isShipping: false, tableId: tableId) : null,
      child: Card(
        color: cardColor,
        elevation: 2,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.table_restaurant,
              size: MySize.size48 ?? 48.0,
              color: textColor,
            ),
            SizedBox(height: MySize.size8 ?? 8.0),
            if (table['name'] != null)
              Text(
                table['name'],
                style: AppTheme.getTextStyle(
                  themeData.textTheme.subtitle1,
                  fontWeight: 600,
                  color: textColor,
                ),
              ),
            if (table['description'] != null)
              Text(
                table['description'],
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText2,
                  fontWeight: 400,
                  color: textColor,
                ),
              ),
            if (isDisabled) ...[
              SizedBox(height: MySize.size4 ?? 4.0),
              Text(
                isFirebaseLocked
                    ? (AppLocalizations.of(context).translate('table_already_in_use') ?? 'Table already in use.')
                    : AppLocalizations.of(context).translate('in_use'),
                style: AppTheme.getTextStyle(
                  themeData.textTheme.caption,
                  color: Colors.grey[300],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _handleShippingTap() async {
    if (selectedLocationId == 0) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('please_set_a_location'),
      );
      return;
    }

    // Check if shipping is available
    if (!_shippingAvailable) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('shipping_in_use'),
      );
      return;
    }

    try {
      const cartKey = 'shipping';
      int? sellId = AppConstants.cartData[cartKey];
      List<Map> existingProducts = [];

      // DEFERRED ORDER CREATION: Check for existing shipping order first, like tables
      if (sellId == null) {
        // Check if there's an existing draft order for shipping
        final existingOrder = await _checkForExistingShippingOrder();
        if (existingOrder != null) {
          sellId = existingOrder;
          setState(() {
            AppConstants.cartData[cartKey] = sellId!;
          });
          await ShareInt().setMap(jsonEncode(AppConstants.cartData));

          // Load existing cart items for this shipping order
          try {
            existingProducts = await SellDatabase().getSellLineBySellId(
                sellId,
                res_table_id: 0,
                includeCompleted: true
            );
            debugPrint('_handleShippingTap: Loaded ${existingProducts.length} existing items for shipping order $sellId');
          } catch (e) {
            debugPrint('_handleShippingTap: Error loading existing products: $e');
          }
        }
        // If no existing order, we'll create one only when products are added (deferred creation)
      }

      // Don't mark shipping as unavailable yet - wait until customer screen

      Navigator.pushNamed(
        context,
        '/products',
        arguments: {
          'locationId': selectedLocationId,
          'sellId': sellId, // This may be null initially - products screen will handle creation
          'cartKey': cartKey,
          'res_table_id': 0,
          'is_shipping': 1,
          'products': existingProducts, // Pass existing products if found
          'isShipping': true,
          'deferredOrderCreation': true, // Flag to indicate deferred creation
        },
      );
    } catch (e) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_creating_sale'),
      );
    }
  }

  Future<void> _handleTableTap(Map table, String cartKey) async {
    if (selectedLocationId == 0) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('please_set_a_location'),
      );
      return;
    }

    final tableId = table['id'] as int;
    final isAvailable = _tableAvailability[tableId] ?? true;
    final isFirebaseLocked = _firebaseTableLocks[tableId] ?? false;

    // Check if table is available locally
    if (!isAvailable) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('table_in_use'),
      );
      return;
    }

    // // Check if table is locked in Firebase by another user
    // if (isFirebaseLocked) {
    //   final lockedByUser = _firebaseLockedByUser[tableId] ?? 'another user';
    //   Fluttertoast.showToast(
    //     msg: AppLocalizations.of(context).translate('table_already_in_use') ??
    //         'Table already in use.',
    //     toastLength: Toast.LENGTH_LONG,
    //   );
    //   return;
    // }

    try {
      // Don't lock table here - lock will happen when first product is added
      // This allows user to navigate to products screen without locking

      int? sellId = AppConstants.cartData[cartKey];

      // DEFERRED ORDER CREATION: Only create order if one doesn't exist
      // This prevents creating blank orders when just navigating to a table
      if (sellId == null) {
        // Check if there's an existing draft order for this table
        final existingOrder = await _checkForExistingTableOrder(table['id']);
        if (existingOrder != null) {
          sellId = existingOrder;
          setState(() {
            AppConstants.cartData[cartKey] = sellId!;
          });
          await ShareInt().setMap(jsonEncode(AppConstants.cartData));
        }
        // If no existing order, we'll create one only when products are added
      }

      // Don't mark table as unavailable yet - wait until customer screen

      Navigator.pushNamed(
        context,
        '/products',
        arguments: {
          'locationId': selectedLocationId,
          'sellId': sellId, // This may be null initially - products screen will handle creation
          'cartKey': cartKey,
          'res_table_id': table['id'],
          'is_shipping': 0,
          'products': [],
          'tableName': table['name'],
          'deferredOrderCreation': true, // Flag to indicate deferred creation
        },
      );
    } catch (e) {
      debugPrint('Error in _handleTableTap: $e');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_creating_sale'),
      );
    }
  }

  Widget _buildLocationDropdown() {
    return DropdownButtonHideUnderline(
      child: DropdownButton<int>(
        dropdownColor: themeData.cardColor,
        icon: Icon(Icons.arrow_drop_down),
        value: selectedLocationId,
        items: locationListMap.map<DropdownMenuItem<int>>((Map value) {
          return DropdownMenuItem<int>(
            value: value['id'],
            child: SizedBox(
              width: MySize.screenWidth! * 0.4,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  '${value['name']}',
                  softWrap: true,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  style: TextStyle(fontSize: 15),
                ),
              ),
            ),
          );
        }).toList(),
        onChanged: (int? newValue) async {
          if (newValue != null) {
            // Handle both location change AND reselection of same location
            if (newValue != selectedLocationId) {
              // Different location selected
              setState(() {
                isLoading = true;
                selectedLocationId = newValue;
                tables = [];
              });
              // Clear table states when location changes
              _tableAvailability.clear();
              _firebaseTableLocks.clear();
              _firebaseLockedByUser.clear();
              _shippingAvailabilityInitialized = false;
              // Cancel Firebase subscription for old location
              _firebaseLockService.cancelLocationSubscription(selectedLocationId);
              await _fetchTables();
              // Initialize table states for the new location
              await _initializeTableStates();
            } else {
              // Same location reselected - reload tables and refresh states
              setState(() {
                isLoading = true;
              });

              // Clear cache to force fresh database queries
              await _availabilityManager.refreshAvailability();

              // Refetch tables for current location
              await _fetchTables();

              // Refresh table availability states to get current status
              await _refreshTableAvailability();

              debugPrint('Tables screen: Location reselected - tables and availability refreshed');
            }
          }
        },
      ),
    );
  }

  /// Check for existing draft orders for a specific table
  Future<int?> _checkForExistingTableOrder(int tableId) async {
    try {
      final db = await SellDatabase().database;
      final result = await db.query(
        'sells',
        columns: ['id'],
        where: 'res_table_id = ? AND sale_status = ? AND is_synced = ? AND is_shipping = ?',
        whereArgs: [tableId, 'draft', 0, 0],
        orderBy: 'id DESC',
        limit: 1,
      );

      if (result.isNotEmpty) {
        final sellId = result.first['id'] as int;
        debugPrint('_checkForExistingTableOrder: Found existing draft order $sellId for table $tableId');
        return sellId;
      }

      debugPrint('_checkForExistingTableOrder: No existing draft order found for table $tableId');
      return null;
    } catch (e) {
      debugPrint('Error checking for existing table order: $e');
      return null;
    }
  }

  /// Check for existing draft orders for shipping
  Future<int?> _checkForExistingShippingOrder() async {
    try {
      final db = await SellDatabase().database;
      final result = await db.query(
        'sells',
        columns: ['id'],
        where: 'res_table_id = ? AND is_shipping = ? AND sale_status = ? AND is_synced = ?',
        whereArgs: [0, 1, 'draft', 0],
        orderBy: 'id DESC',
        limit: 1,
      );

      if (result.isNotEmpty) {
        final sellId = result.first['id'] as int;
        debugPrint('_checkForExistingShippingOrder: Found existing draft order $sellId for shipping');
        return sellId;
      }

      debugPrint('_checkForExistingShippingOrder: No existing draft order found for shipping');
      return null;
    } catch (e) {
      debugPrint('Error checking for existing shipping order: $e');
      return null;
    }
  }

  /// Clean up blank/temporary orders when user navigates back without adding products
  Future<void> _cleanupBlankOrders() async {
    try {
      final db = await SellDatabase().database;

      // Find and delete draft orders that have no sell_lines (blank orders)
      final blankOrders = await db.rawQuery('''
        SELECT s.id, s.res_table_id 
        FROM sells s 
        LEFT JOIN sell_lines sl ON s.id = sl.sell_id 
        WHERE s.sale_status = ? AND s.is_synced = ? AND sl.id IS NULL
      ''', ['draft', 0]);

      for (var order in blankOrders) {
        final sellId = order['id'] as int;
        final resTableId = order['res_table_id'] as int;

        debugPrint('_cleanupBlankOrders: Deleting blank order $sellId for table $resTableId');

        // Delete the blank order
        await db.delete('sells', where: 'id = ?', whereArgs: [sellId]);

        // Clear cart data for this table if it exists
        final cartKey = resTableId.toString();
        if (AppConstants.cartData[cartKey] == sellId) {
          AppConstants.cartData[cartKey] = null;
        }
      }

      if (blankOrders.isNotEmpty) {
        await ShareInt().setMap(jsonEncode(AppConstants.cartData));
        debugPrint('_cleanupBlankOrders: Cleaned up ${blankOrders.length} blank orders');
      }
    } catch (e) {
      debugPrint('Error cleaning up blank orders: $e');
    }
  }

  /// Validate table states when returning from Products screen
  /// This ensures tables with partial orders remain unavailable
  Future<void> _validateTableStatesOnReturn() async {
    try {
      if (selectedLocationId == 0 || tables.isEmpty) {
        return;
      }

      debugPrint('Tables screen: Validating table states on return from Products screen');

      // Check each table to see if it has active orders
      for (var table in tables) {
        final tableId = table['id'] as int;

        // Check if this table has any active orders
        final hasActiveOrders = await _checkTableHasActiveOrders(tableId);

        if (hasActiveOrders) {
          // Table has active orders, mark as unavailable
          _tableAvailability[tableId] = false;
          debugPrint('Tables screen: Table $tableId has active orders, marking as unavailable');
        } else {
          // Table has no active orders, mark as available
          _tableAvailability[tableId] = true;
          debugPrint('Tables screen: Table $tableId has no active orders, marking as available');
        }
      }

      // Update UI
      if (mounted) {
        setState(() {});
      }

      // Save states
      _saveCurrentStates();

      debugPrint('Tables screen: Table state validation completed');
    } catch (e) {
      debugPrint('Error validating table states on return: $e');
    }
  }

  /// Check if a table has any active orders
  Future<bool> _checkTableHasActiveOrders(int tableId) async {
    try {
      final db = await SellDatabase().database;

      // Check for draft orders with sell_lines for this table
      final result = await db.rawQuery('''
        SELECT COUNT(*) as count
        FROM sells s
        INNER JOIN sell_lines sl ON s.id = sl.sell_id
        WHERE s.res_table_id = ? 
        AND s.sale_status = ? 
        AND s.is_synced = ? 
        AND s.location_id = ?
      ''', [tableId, 'draft', 0, selectedLocationId]);

      final count = result.first['count'] as int;
      return count > 0;
    } catch (e) {
      debugPrint('Error checking active orders for table $tableId: $e');
      return false;
    }
  }

  /// Show enable dialog for disabled tables or shipping
  void _showEnableDialog({required bool isShipping, int? tableId}) {
    final title = isShipping
        ? AppLocalizations.of(context).translate('enable_shipping')
        : AppLocalizations.of(context).translate('enable_table');

    final message = isShipping
        ? AppLocalizations.of(context).translate('enable_shipping_message')
        : AppLocalizations.of(context).translate('enable_table_message');

    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: customAppTheme.bgLayer1,
          title: Text(
            title,
            style: AppTheme.getTextStyle(
              themeData.textTheme.headline6,
              color: Colors.black,
              fontWeight: 700,
            ),
          ),
          content: Text(
            message,
            style: AppTheme.getTextStyle(
              themeData.textTheme.subtitle1,
              color: Colors.black,
            ),
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: themeData.colorScheme.primary,
              ),
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                _enableTableOrShipping(isShipping: isShipping, tableId: tableId);
              },
              child: Text(AppLocalizations.of(context).translate('enable')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: themeData.colorScheme.primary,
              ),
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text(AppLocalizations.of(context).translate('cancel')),
            ),
          ],
        );
      },
    );
  }

  /// Enable table or shipping and update availability status
  void _enableTableOrShipping({required bool isShipping, int? tableId}) async {
    try {
      if (isShipping) {
        // Force enable shipping using the new method
        await _availabilityManager.forceEnableTableOrShipping(isShipping: true);
        setState(() {
          _shippingAvailable = true;
          _shippingAvailabilityInitialized = true;
        });

        // Save state after manual enable
        _saveCurrentStates();

        Fluttertoast.showToast(
          msg: AppLocalizations.of(context).translate('shipping') + ' ' + AppLocalizations.of(context).translate('enabled'),
        );

        // Fire event to notify other screens
        EventBus().fire(TableAvailabilityChangedEvent(
          isShipping: true,
          isAvailable: true,
        ));
      } else if (tableId != null) {
        // Force enable table using the new method
        await _availabilityManager.forceEnableTableOrShipping(tableId: tableId, locationId: selectedLocationId != 0 ? selectedLocationId : null);

        // Unlock table in Firebase when manually enabled
        if (selectedLocationId > 0) {
          try {
            await _firebaseLockService.unlockTable(
              tableId: tableId,
              locationId: selectedLocationId,
            );
            debugPrint('Tables: Unlocked table $tableId in Firebase after manual enable');
          } catch (e) {
            debugPrint('Tables: Error unlocking table in Firebase: $e');
          }
        }

        setState(() {
          _tableAvailability[tableId] = true;
          _firebaseTableLocks[tableId] = false; // Update Firebase lock state
        });

        // Save state after manual enable
        _saveCurrentStates();

        Fluttertoast.showToast(
          msg: AppLocalizations.of(context).translate('tables') + ' ' + AppLocalizations.of(context).translate('enabled'),
        );

        // Fire event to notify other screens
        EventBus().fire(TableAvailabilityChangedEvent(
          tableId: tableId,
          isShipping: false,
          isAvailable: true,
        ));
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_enabling'),
      );
      debugPrint('Error enabling table/shipping: $e');
    }
  }

  /// Smart recovery method to enable only tables/shipping without active orders
  /// This should be called when tables are stuck in disabled state
  /// Conservative approach: only enables tables, doesn't disable currently enabled ones
  Future<void> _emergencyRecovery() async {
    try {
      if (tables.isEmpty) return;

      final tableIds = tables.map<int>((table) => table['id'] as int).toList();

      // Clear cache first to ensure fresh database validation
      await _availabilityManager.refreshAvailability();

      // Get current availability status from database (not cache)
      final validatedAvailability = await _availabilityManager.autoValidateTableStates(tableIds, locationId: selectedLocationId != 0 ? selectedLocationId : null);
      final shippingAvailable = await _availabilityManager.isShippingAvailable(locationId: selectedLocationId != 0 ? selectedLocationId : null);

      // Conservative approach: only enable tables that are truly available
      // Don't disable tables that are currently enabled (preserve user navigation state)
      int enabledCount = 0;
      int totalTables = tableIds.length;

      setState(() {
        for (int tableId in tableIds) {
          bool isCurrentlyEnabled = _tableAvailability[tableId] ?? true;
          bool isActuallyAvailable = validatedAvailability[tableId] ?? true;

          // CONSERVATIVE APPROACH: Only enable if actually available, NEVER disable currently enabled
          // This preserves enabled state when navigating Tables → Product → Tables
          if (isActuallyAvailable) {
            _tableAvailability[tableId] = true;
            if (!isCurrentlyEnabled) {
              enabledCount++;
            }
          }
          // NEVER disable currently enabled tables - preserve navigation state
        }

        // CONSERVATIVE SHIPPING APPROACH: Only enable if available, NEVER disable currently enabled
        // This preserves enabled state when navigating Tables → Product → Tables
        bool isCurrentlyShippingEnabled = _shippingAvailable;
        if (shippingAvailable) {
          _shippingAvailable = true;
        }
        // NEVER disable currently enabled shipping - preserve navigation state

        _shippingAvailabilityInitialized = true;
      });

      // Save states after smart recovery
      _saveCurrentStates();

      // Count total enabled tables for message
      int totalEnabledTables = _tableAvailability.values.where((available) => available).length;
      bool shippingEnabled = _shippingAvailable;

      String message = 'Recovery completed: $totalEnabledTables/$totalTables tables enabled';
      if (shippingEnabled) {
        message += ', shipping enabled';
      } else {
        message += ', shipping disabled (has active orders)';
      }

      if (enabledCount > 0) {
        message += ' (+$enabledCount newly enabled)';
      }

      Fluttertoast.showToast(
        msg: message,
      );

      debugPrint('Smart recovery: Conservative approach - $enabledCount newly enabled, $totalEnabledTables/$totalTables total enabled');
      debugPrint('Smart recovery: Shipping enabled: $shippingEnabled');
    } catch (e) {
      debugPrint('Error in smart recovery: $e');
    }
  }
}

class AppConstants {
  static Map<String, int?> cartData = {};

  static Future<void> getData() async {
    try {
      final data = await ShareInt().getMap();
      if (data.isNotEmpty) {
        final decoded = jsonDecode(data);
        if (decoded is Map) {
          cartData = Map<String, int?>.from(decoded);
        }
      }
    } catch (e) {
      print("Error loading cart data: $e");
      cartData = {};
    }
  }

  static Future<void> setData(int id) async {
    cartData.remove(id.toString());
    await ShareInt().setMap(jsonEncode(cartData));
  }
}

class ShareInt {
  static final ShareInt _instance = ShareInt._();
  factory ShareInt() => _instance;
  ShareInt._();

  late SharedPreferences _preferences;
  bool _isInitialized = false;

  Future<void> init() async {
    if (!_isInitialized) {
      _preferences = await SharedPreferences.getInstance();
      _isInitialized = true;
    }
  }

  Future<void> setMap(String value) async {
    await init();
    await _preferences.setString("HEYDATA", value);
  }

  Future<String> getMap() async {
    await init();
    return _preferences.getString("HEYDATA") ?? "";
  }
}
