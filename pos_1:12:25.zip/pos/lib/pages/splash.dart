// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// import '../config.dart';
// import '../helpers/AppTheme.dart';
// import '../helpers/SizeConfig.dart';
// import '../helpers/otherHelpers.dart';
// import '../locale/MyLocalizations.dart';
// import '../pages/login.dart';
//
// // ignore: must_be_immutable
// class Splash extends StatelessWidget {
//   static int themeType = 1;
//   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
//   CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);
//
//   @override
//   Widget build(BuildContext context) {
//     MySize().init(context);
//
//     // Check login status when the widget is built
//     _checkLoginStatus(context);
//
//     return SafeArea(
//       bottom: true,
//       top: false,
//       child: Scaffold(
//         body: Center(
//           child: SingleChildScrollView(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Image.asset(
//                   'assets/images/splash_screen.png',
//                   fit: BoxFit.fill,
//                   height: MySize.screenHeight! * 0.5,
//                   width: MySize.screenWidth,
//                 ),
//                 // CachedNetworkImage(
//                 //   fit: BoxFit.fill,
//                 //   height: MySize.screenHeight! * 0.5,
//                 //   width: MySize.screenWidth,
//                 //   imageUrl: Config().splashScreen,
//                 //   placeholder: (context, url) => Transform.scale(
//                 //     scale: 0.1,
//                 //     child: CircularProgressIndicator(),
//                 //   ),
//                 //   errorWidget: (context, url, error) =>
//                 //       Image.asset('assets/images/splash_screen.png'),
//                 // ),
//                 Text(AppLocalizations.of(context).translate('welcome'),
//                     style: AppTheme.getTextStyle(themeData.textTheme.headline4,
//                         color: themeData.colorScheme.onSurface)),
//                 // ElevatedButton.icon(
//                 //   onPressed: () async {
//                 //     await Helper().requestAppPermission();
//                 //     SharedPreferences prefs =
//                 //         await SharedPreferences.getInstance();
//                 //     if (prefs.getInt('userId') != null) {
//                 //       USERID = prefs.getInt('userId');
//                 //       Config.userId = USERID;
//                 //       Helper().jobScheduler();
//                 //       //Take to home page
//                 //       Navigator.of(context).pushReplacementNamed('/home');
//                 //     } else
//                 //       Navigator.of(context).pushReplacementNamed('/login');
//                 //   },
//                 //   icon: Icon(Icons.navigate_next,
//                 //       color: themeData.colorScheme.primary),
//                 //   label: Text(AppLocalizations.of(context).translate('login'),
//                 //       style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
//                 //           color: themeData.colorScheme.primary, fontWeight: 600)),
//                 //   style: ElevatedButton.styleFrom(
//                 //       primary: themeData.colorScheme.onPrimary,
//                 //       shadowColor: themeData.colorScheme.primary),
//                 // ),
//                 // Only show the login button if user is not logged in
//                 FutureBuilder<bool>(
//                   future: _isLoggedIn(),
//                   builder: (context, snapshot) {
//                     if (snapshot.hasData && !snapshot.data!) {
//                       return ElevatedButton.icon(
//                         onPressed: () async {
//                           await Helper().requestAppPermission();
//                           SharedPreferences prefs =
//                           await SharedPreferences.getInstance();
//                           if (prefs.getInt('userId') != null) {
//                             USERID = prefs.getInt('userId');
//                             Config.userId = USERID;
//                             Helper().jobScheduler();
//                             Navigator.of(context).pushReplacementNamed('/home');
//                           } else {
//                             Navigator.of(context).pushReplacementNamed('/login');
//                           }
//                         },
//                         icon: Icon(Icons.navigate_next,
//                             color: themeData.colorScheme.primary),
//                         label: Text(AppLocalizations.of(context).translate('login'),
//                             style: AppTheme.getTextStyle(
//                                 themeData.textTheme.bodyText1,
//                                 color: themeData.colorScheme.primary,
//                                 fontWeight: 600)),
//                         style: ElevatedButton.styleFrom(
//                             primary: themeData.colorScheme.onPrimary,
//                             shadowColor: themeData.colorScheme.primary),
//                       );
//                     }
//                     return SizedBox.shrink(); // Return empty widget if logged in
//                   },
//                 ),
//                 Visibility(
//                   visible: Config().showRegister,
//                   child: Padding(
//                     padding: EdgeInsets.all(MySize.size10!),
//                     child: GestureDetector(
//                       child: Text(
//                           AppLocalizations.of(context).translate('register'),
//                           style: AppTheme.getTextStyle(
//                               themeData.textTheme.bodyText1,
//                               color: themeData.colorScheme.onBackground,
//                               fontWeight: 600)),
//                       onTap: () async {
//                         await launch('${Config.baseUrl}business/register');
//                       },
//                     ),
//                   ),
//                 )
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   //new added
//   // Function to check if user is logged in
//   Future<bool> _isLoggedIn() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     return prefs.getInt('userId') != null;
//   }
//
//   // Function to handle automatic navigation for logged-in users
//   void _checkLoginStatus(BuildContext context) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     if (prefs.getInt('userId') != null) {
//       USERID = prefs.getInt('userId');
//       Config.userId = USERID;
//       Helper().jobScheduler();
//       // Wait for 5 seconds before navigating to home screen
//       await Future.delayed(Duration(seconds: 3));
//       Navigator.of(context).pushReplacementNamed('/home');
//     }
//   }
// }
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dev/helpers/Responsive_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../helpers/AppTheme.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/otherHelpers.dart';
import '../locale/MyLocalizations.dart';
import '../pages/login.dart';

// ignore: must_be_immutable
class Splash extends StatelessWidget {
  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
  CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);

  @override
  Widget build(BuildContext context) {
    MySize().init(context);

    // Check login status when the widget is built
    _checkLoginStatus(context);

    return SafeArea(
      bottom: true,
      top: false,
      child: Scaffold(
        body: Center(
          child: SingleChildScrollView(
            child: ResponsiveHelper.shouldCenterContent(context)
                ? Container(
              width: ResponsiveHelper.getContentWidth(context, maxWidth: 800),
              child: _buildSplashContent(context),
            )
                : _buildSplashContent(context),
          ),
        ),
      ),
    );
  }

  Widget _buildSplashContent(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          height: MediaQuery.of(context).size.height * 0.30,
          width: double.infinity,
          alignment: Alignment.center,
          child: Image.asset(
            'assets/fwdlogos/Logo PoS6.png',
            fit: BoxFit.contain,
            height: ResponsiveHelper.isTablet(context)
                ? MySize.screenHeight! * 0.4
                : MySize.screenHeight! * 0.5,
            width: ResponsiveHelper.isTablet(context)
                ? MySize.screenWidth! * 0.6
                : MySize.screenWidth,
          ),
        ),
        // CachedNetworkImage(
        //   fit: BoxFit.fill,
        //   height: MySize.screenHeight! * 0.5,
        //   width: MySize.screenWidth,
        //   imageUrl: Config().splashScreen,
        //   placeholder: (context, url) => Transform.scale(
        //     scale: 0.1,
        //     child: CircularProgressIndicator(),
        //   ),
        //   errorWidget: (context, url, error) =>
        //       Image.asset('assets/images/splash_screen.png'),
        // ),
        Padding(
          padding: ResponsiveHelper.getResponsivePadding(context,
            mobilePadding: 16.0,
            tabletPadding: 24.0,
            desktopPadding: 32.0,
          ),
          child: Text(
            AppLocalizations.of(context).translate('welcome'),
            style: AppTheme.getTextStyle(
              themeData.textTheme.headline4,
              color: themeData.colorScheme.onSurface,
              fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                mobileSize: themeData.textTheme.headline4!.fontSize,
                tabletSize: themeData.textTheme.headline4!.fontSize! * 1.2,
                desktopSize: themeData.textTheme.headline4!.fontSize! * 1.4,
              ),
            ),
            textAlign: TextAlign.center,
          ),
        ),
        // Only show the login button if user is not logged in
        FutureBuilder<bool>(
          future: _isLoggedIn(),
          builder: (context, snapshot) {
            if (snapshot.hasData && !snapshot.data!) {
              return Padding(
                padding: ResponsiveHelper.getResponsivePadding(context,
                  mobilePadding: 16.0,
                  tabletPadding: 24.0,
                  desktopPadding: 32.0,
                ),
                child: SizedBox(
                  width: ResponsiveHelper.isTablet(context) ? 200 : null,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      await Helper().requestAppPermission();
                      SharedPreferences prefs =
                      await SharedPreferences.getInstance();
                      if (prefs.getInt('userId') != null) {
                        USERID = prefs.getInt('userId');
                        Config.userId = USERID;
                        Helper().jobScheduler();
                        Navigator.of(context).pushReplacementNamed('/home');
                      } else {
                        Navigator.of(context).pushReplacementNamed('/login');
                      }
                    },
                    icon: Icon(Icons.navigate_next,
                        color: themeData.colorScheme.primary,
                        size: ResponsiveHelper.isTablet(context) ? 24 : 20),
                    label: Text(AppLocalizations.of(context).translate('login'),
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText1,
                            color: themeData.colorScheme.primary,
                            fontWeight: 600,
                            fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                              mobileSize: themeData.textTheme.bodyText1!.fontSize,
                              tabletSize: themeData.textTheme.bodyText1!.fontSize! * 1.1,
                              desktopSize: themeData.textTheme.bodyText1!.fontSize! * 1.2,
                            ))),
                    style: ElevatedButton.styleFrom(
                        primary: themeData.colorScheme.onPrimary,
                        shadowColor: themeData.colorScheme.primary,
                        padding: ResponsiveHelper.isTablet(context)
                            ? EdgeInsets.symmetric(vertical: 16, horizontal: 24)
                            : EdgeInsets.symmetric(vertical: 12, horizontal: 16)),
                  ),
                ),
              );
            }
            return SizedBox.shrink(); // Return empty widget if logged in
          },
        ),
        Visibility(
          visible: Config().showRegister,
          child: Padding(
            padding: ResponsiveHelper.getResponsivePadding(context,
              mobilePadding: 10.0,
              tabletPadding: 16.0,
              desktopPadding: 20.0,
            ),
            child: GestureDetector(
              child: Text(
                  AppLocalizations.of(context).translate('register'),
                  style: AppTheme.getTextStyle(
                      themeData.textTheme.bodyText1,
                      color: themeData.colorScheme.onBackground,
                      fontWeight: 600,
                      fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                        mobileSize: themeData.textTheme.bodyText1!.fontSize,
                        tabletSize: themeData.textTheme.bodyText1!.fontSize! * 1.1,
                        desktopSize: themeData.textTheme.bodyText1!.fontSize! * 1.2,
                      ))),
              onTap: () async {
                await launch('${Config.baseUrl}business/register');
              },
            ),
          ),
        )
      ],
    );
  }

  //new added
  // Function to check if user is logged in
  Future<bool> _isLoggedIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getInt('userId') != null;
  }

  // Function to handle automatic navigation for logged-in users
  void _checkLoginStatus(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getInt('userId') != null) {
      USERID = prefs.getInt('userId');
      Config.userId = USERID;
      Helper().jobScheduler();
      // Reduced delay for faster navigation
      await Future.delayed(Duration(seconds: 3));
      Navigator.of(context).pushReplacementNamed('/home');
    }
  }
}
