// import 'dart:async';
// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import '../apis/api.dart';
// import '../apis/system.dart';
// import '../apis/user.dart';
// import '../config.dart';
// import '../helpers/AppTheme.dart';
// import '../helpers/SizeConfig.dart';
// import '../helpers/otherHelpers.dart';
// import '../locale/MyLocalizations.dart';
// import '../models/contact_model.dart';
// import '../models/database.dart';
// import '../models/sellDatabase.dart';
// import '../models/system.dart';
// import '../models/variations.dart';
// import 'home.dart';
//
// // ignore: non_constant_identifier_names
// int? USERID;
//
// class Login extends StatefulWidget {
//   const Login({super.key});
//
//   @override
//   _LoginState createState() => _LoginState();
// }
//
// class _LoginState extends State<Login> {
//   static int themeType = 1;
//   late ThemeData themeData;
//   final _formKey = GlobalKey<FormState>();
//   final usernameController = TextEditingController();
//   final passwordController = TextEditingController();
//   bool isLoading = false;
//   bool showLoadingScreen = false;
//   bool _passwordVisible = false;
//
//   @override
//   void initState() {
//     super.initState();
//     themeData = AppTheme.getThemeFromThemeMode(themeType);
//   }
//
//   @override
//   void dispose() {
//     usernameController.dispose();
//     passwordController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     themeData = Theme.of(context);
//
//     return Scaffold(
//       body: Stack(
//         children: [
//           SafeArea(
//             child: ListView(
//               padding: const EdgeInsets.all(0),
//               children: <Widget>[
//                 _buildLoginHeader(),
//                 _buildLoginForm(),
//               ],
//             ),
//           ),
//           if (   )
//             Container(
//               color: Colors.black.withOpacity(0.5),
//               child: const Center(
//                 child: CircularProgressIndicator(),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildLoginHeader() {
//     return SizedBox(
//       height: MediaQuery.of(context).size.height * 3 / 10,
//       child: Stack(
//         fit: StackFit.expand,
//         children: <Widget>[
//           FittedBox(
//             fit: BoxFit.fill,
//             child: CachedNetworkImage(
//               imageUrl: Config().loginScreen,
//               placeholder: (context, url) => Transform.scale(
//                 scale: 0.07,
//                 child: const CircularProgressIndicator(),
//               ),
//               errorWidget: (context, url, error) =>
//                   Image.asset('assets/images/login.jpg'),
//             ),
//           ),
//           Align(
//             alignment: Alignment.center,
//             child: Stack(
//               children: <Widget>[
//                 Text(
//                   AppLocalizations.of(context).translate('login'),
//                   style: TextStyle(
//                     fontSize: 40,
//                     foreground: Paint()
//                       ..style = PaintingStyle.stroke
//                       ..strokeWidth = 4
//                       ..color = Colors.blue,
//                   ),
//                 ),
//                 Text(
//                   AppLocalizations.of(context).translate('login'),
//                   style: const TextStyle(
//                     fontSize: 40,
//                     color: Colors.white,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildLoginForm() {
//     return Form(
//       key: _formKey,
//       child: Container(
//         margin: EdgeInsets.symmetric(horizontal: MySize.size16!, vertical: MySize.size16!),
//         child: Card(
//           elevation: 8,
//           child: Padding(
//             padding: EdgeInsets.symmetric(
//               vertical: MySize.size12!,
//               horizontal: MySize.size16!,
//             ),
//             child: Column(
//               children: <Widget>[
//                 TextFormField(
//                   controller: usernameController,
//                   autofocus: true,
//                   validator: (value) {
//                     if (value == null || value.isEmpty) {
//                       return AppLocalizations.of(context)
//                           .translate('please_enter_username');
//                     }
//                     return null;
//                   },
//                   style: AppTheme.getTextStyle(
//                     themeData.textTheme.bodyMedium,
//                     color: themeData.colorScheme.onBackground,
//                     fontWeight: 500,
//                   ),
//                   decoration: InputDecoration(
//                     hintText:
//                     AppLocalizations.of(context).translate('username'),
//                     prefixIcon: const Icon(Icons.person_outline),
//                   ),
//                 ),
//                 SizedBox(height: MySize.size16),
//                 TextFormField(
//                   controller: passwordController,
//                   obscureText: !_passwordVisible,
//                   validator: (value) {
//                     if (value == null || value.isEmpty) {
//                       return AppLocalizations.of(context)
//                           .translate('please_enter_password');
//                     }
//                     return null;
//                   },
//                   style: AppTheme.getTextStyle(
//                     themeData.textTheme.bodyMedium,
//                     color: themeData.colorScheme.onBackground,
//                     fontWeight: 500,
//                   ),
//                   decoration: InputDecoration(
//                     hintText:
//                     AppLocalizations.of(context).translate('password'),
//                     prefixIcon: const Icon(Icons.lock_outline),
//                     suffixIcon: IconButton(
//                       icon: Icon(
//                         _passwordVisible
//                             ? MdiIcons.eyeOutline
//                             : MdiIcons.eyeOffOutline,
//                       ),
//                       onPressed: () {
//                         setState(() {
//                           _passwordVisible = !_passwordVisible;
//                         });
//                       },
//                     ),
//                   ),
//                 ),
//                 SizedBox(height: MySize.size24),
//                 TextButton(
//                   style: TextButton.styleFrom(
//                     padding: EdgeInsets.symmetric(
//                       vertical: MySize.size10!,
//                       horizontal: MySize.size64!,
//                     ),
//                     backgroundColor: themeData.colorScheme.primary,
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(MySize.size24!),
//                     ),
//                   ),
//                   onPressed: _handleLogin,
//                   child: Text(
//                     isLoading
//                         ? AppLocalizations.of(context).translate('loading')
//                         : AppLocalizations.of(context).translate('login'),
//                     style: AppTheme.getTextStyle(
//                       themeData.textTheme.labelLarge,
//                       fontWeight: 600,
//                       color: themeData.colorScheme.onPrimary,
//                       letterSpacing: 0.5,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Future<void> _handleLogin() async {
//     if (isLoading || !(_formKey.currentState?.validate() ?? false)) return;
//
//     if (!await Helper().checkConnectivity()) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context)
//             .translate('no_internet_connection'),
//       );
//       return;
//     }
//
//     setState(() {
//       isLoading = true;
//       showLoadingScreen = true;
//     });
//
//     try {
//       final loginResponse = await Api().login(
//         usernameController.text,
//         passwordController.text,
//       );
//
//       if (loginResponse == null || !loginResponse.containsKey('success')) {
//         throw Exception('Invalid API response');
//       }
//
//       if (loginResponse['success']) {
//         await loadAllData(loginResponse);
//       } else {
//         final errorMsg = loginResponse['message'] ??
//             AppLocalizations.of(context).translate('invalid_credentials');
//         Fluttertoast.showToast(msg: errorMsg);
//       }
//     } catch (e) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context).translate('login_failed') +
//             ': ${e.toString()}',
//       );
//     } finally {
//       if (mounted) {
//         setState(() {
//           isLoading = false;
//           showLoadingScreen = false;
//         });
//       }
//     }
//   }
//
//   Future<void> loadAllData(Map loginResponse) async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       final loggedInUser =
//       await User().get(loginResponse['access_token'] as String);
//
//       if (loggedInUser['id'] == null) {
//         throw Exception('Invalid user data');
//       }
//
//       USERID = loggedInUser['id'] as int;
//       Config.userId = USERID;
//       await prefs.setInt('userId', USERID!);
//       await DbProvider().initializeDatabase(USERID);
//
//       final lastSync = await System().getProductLastSync();
//       final now = DateTime.now();
//
//       await System().empty();
//       await Contact().emptyContact();
//       await System().insertUserDetails(loggedInUser);
//       await System().insertToken(loginResponse['access_token'] as String);
//       await SystemApi().store();
//       await System().insertProductLastSyncDateTimeNow();
//
//       if (prefs.getInt('prevUserId') == null ||
//           prefs.getInt('prevUserId') != prefs.getInt('userId')) {
//         await SellDatabase().deleteSellTables();
//         await Variations().refresh();
//       } else if (lastSync == null ||
//           now.difference(DateTime.parse(lastSync)).inHours > 10) {
//         if (await Helper().checkConnectivity()) {
//           await Variations().refresh();
//           await System().insertProductLastSyncDateTimeNow();
//           await SellDatabase().deleteSellTables();
//         }
//       }
//
//       if (mounted) {
//         Navigator.of(context).pushReplacement(
//           MaterialPageRoute(builder: (_) => Home()),
//         );
//       }
//     } catch (e) {
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context)
//             .translate('data_load_failed') +
//             ': ${e.toString()}',
//       );
//     }
//   }
// }

import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../apis/api.dart';
import '../apis/system.dart';
import '../apis/user.dart';
import '../config.dart';
import '../helpers/AppTheme.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/otherHelpers.dart';
import '../locale/MyLocalizations.dart';
import '../models/contact_model.dart';
import '../models/database.dart';
import '../apis/contact.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import '../models/variations.dart';
import '../helpers/TableAvailabilityManager.dart';
import 'home.dart';
import 'Tables.dart'; // Import for AppConstants

// ignore: non_constant_identifier_names
int? USERID;

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  static int themeType = 1;
  late ThemeData themeData;
  final _formKey = GlobalKey<FormState>();
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();
  bool isLoading = false;
  bool showLoadingScreen = false;
  bool _passwordVisible = false;

  @override
  void initState() {
    super.initState();
    themeData = AppTheme.getThemeFromThemeMode(themeType);
  }

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    themeData = Theme.of(context);
    return SafeArea(
      bottom: true,
      top: false,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: MySize.size24!),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  _buildLoginHeader(),
                  SizedBox(height: MySize.size32),
                  // Text(AppLocalizations.of(context).translate("login")),
                  SizedBox(height: MySize.size32),
                  _buildLoginForm(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoginHeader() {
    return Container(
      height: MediaQuery.of(context).size.height * 0.25,
      width: double.infinity,
      alignment: Alignment.center,
      child: Image.asset(
        'assets/fwdlogos/Logo PoS6.png',
        fit: BoxFit.contain,
      ),
    );
  }

  Widget _buildLoginForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          TextFormField(
            controller: usernameController,
            autofocus: false,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return AppLocalizations.of(context)
                    .translate('please_enter_username');
              }
              return null;
            },
            style: TextStyle(
              fontSize: 16,
              color: Colors.black87,
              fontWeight: FontWeight.w500,
            ),
            decoration: InputDecoration(
              labelText: AppLocalizations.of(context).translate('username'),
              labelStyle: TextStyle(color: Colors.grey[600]),
              prefixIcon: Icon(Icons.person_outline, color: themeData.colorScheme.primary),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: themeData.colorScheme.primary, width: 2),
              ),
              filled: true,
              fillColor: Colors.grey[50],
              contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            ),
          ),
          SizedBox(height: MySize.size20),
          TextFormField(
            controller: passwordController,
            obscureText: !_passwordVisible,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return AppLocalizations.of(context)
                    .translate('please_enter_password');
              }
              return null;
            },
            style: TextStyle(
              fontSize: 16,
              color: Colors.black87,
              fontWeight: FontWeight.w500,
            ),
            decoration: InputDecoration(
              labelText: AppLocalizations.of(context).translate('password'),
              labelStyle: TextStyle(color: Colors.grey[600]),
              prefixIcon: Icon(Icons.lock_outline, color: themeData.colorScheme.primary),
              suffixIcon: IconButton(
                icon: Icon(
                  _passwordVisible
                      ? MdiIcons.eyeOutline
                      : MdiIcons.eyeOffOutline,
                  color: Colors.grey[600],
                ),
                onPressed: () {
                  setState(() {
                    _passwordVisible = !_passwordVisible;
                  });
                },
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: themeData.colorScheme.primary, width: 2),
              ),
              filled: true,
              fillColor: Colors.grey[50],
              contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            ),
          ),
          SizedBox(height: MySize.size40),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: themeData.colorScheme.primary,
                foregroundColor: Colors.white,
                elevation: 4,
                shadowColor: themeData.colorScheme.primary.withOpacity(0.4),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              onPressed: _handleLogin,
              child: isLoading
                  ? SizedBox(
                height: 24,
                width: 24,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2.5,
                ),
              )
                  : Text(
                AppLocalizations.of(context).translate('login'),
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.2,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Future<void> _handleLogin() async {
  //   if (isLoading || !(_formKey.currentState?.validate() ?? false)) return;
  //
  //   if (!await Helper().checkConnectivity()) {
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context)
  //           .translate('no_internet_connection'),
  //     );
  //     return;
  //   }
  //
  //   setState(() {
  //     isLoading = true;
  //     showLoadingScreen = true;
  //   });
  //
  //   try {
  //     // Print the login URL before making the call
  //     print("Login URL: ${Api().apiUrl}login");
  //
  //     final loginResponse = await Api().login(
  //       usernameController.text,
  //       passwordController.text,
  //     );
  //
  //     print(loginResponse);
  //
  //     if (loginResponse == null || !loginResponse.containsKey('success')) {
  //       throw Exception('Invalid API response');
  //     }
  //
  //     if (loginResponse['success']) {
  //       await loadAllData(loginResponse);
  //     } else {
  //       final errorMsg = loginResponse['message'] ??
  //           AppLocalizations.of(context).translate('invalid_credentials');
  //       Fluttertoast.showToast(msg: errorMsg);
  //     }
  //   } catch (e) {
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context).translate('login_failed') +
  //           ': ${e.toString()}',
  //     );
  //   } finally {
  //     if (mounted) {
  //       setState(() {
  //         isLoading = false;
  //         showLoadingScreen = false;
  //       });
  //     }
  //   }
  // }
  Future<void> _handleLogin() async {

    // Dismiss keyboard when login button is tapped
    FocusScope.of(context).unfocus();

    if (isLoading || !(_formKey.currentState?.validate() ?? false)) return;

    if (!await Helper().checkConnectivity()) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context)
            .translate('no_internet_connection'),
      );
      return;
    }

    setState(() {
      isLoading = true;
      showLoadingScreen = true;
    });

    try {
      final loginResponse = await Api().login(
        usernameController.text,
        passwordController.text,
      );

      print("???????${loginResponse}");

      if (loginResponse != null && loginResponse['success']) {
        final accessToken = loginResponse['access_token'];
        final loggedInUser = await User().get(accessToken);

        if (loggedInUser['id'] == null) throw Exception('Invalid user data');

        // ✅ COMPLETE FRESH START - Clear ALL previous session data first
        await _performCompleteFreshStart();

        // ✅ Set new user session immediately
        USERID = loggedInUser['id'] as int;
        Config.userId = USERID;

        // ✅ Initialize empty database for the new user
        await DbProvider().initializeDatabase(USERID);

        // ✅ Store user & token info (instant)
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt('userId', USERID!);
        await System().insertUserDetails(loggedInUser);
        await System().insertToken(accessToken);

        // ✅ Force enable all tables and shipping for new login session
        TableAvailabilityManager().forceEnableAllOnLogin();

        // ✅ Load ONLY essential home screen data before navigation
        // try {
        //   await SystemApi().store(); // This should fetch payment details & balances
        // } catch (e) {
        //   debugPrint("Essential data load failed: $e");
        // }

        // ✅ Fetch only payment details directly from API (FAST) — not full SystemApi().store()
        final paymentDetails = await SystemApi().fetchPaymentDetailsQuick(accessToken);


        // ✅ Navigate instantly to Home (shows empty but correct user)
        if (mounted) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => Home(initialPaymentDetails: paymentDetails)),
          );
        }

        // ✅ Background load real data
        unawaited(_loadBackgroundData());
      } else {
        Fluttertoast.showToast(
          msg: loginResponse?['message'] ??
              AppLocalizations.of(context).translate('invalid_credentials'),
        );
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('login_failed') +
            ': ${e.toString()}',
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
          showLoadingScreen = false;
        });
      }
    }
  }

  Future<void> _loadBackgroundData() async {
    try {
      await Future.wait<void>([
        SystemApi().store(),
        Variations().refresh(),
        _refreshContacts(),
      ]);

      await System().insertProductLastSyncDateTimeNow();
    } catch (e) {
      debugPrint("Background data load error: $e");
    }
  }


  // Future<void> loadAllData(Map loginResponse) async {
  //   try {
  //     final prefs = await SharedPreferences.getInstance();
  //     final accessToken = loginResponse['access_token'] as String;
  //     final loggedInUser = await User().get(accessToken);
  //
  //     if (loggedInUser['id'] == null) {
  //       throw Exception('Invalid user data');
  //     }
  //
  //     USERID = loggedInUser['id'] as int;
  //
  //     Config.userId = USERID;
  //     await prefs.setInt('userId', USERID!);
  //
  //     // Initialize fresh database for this user
  //     await DbProvider().initializeDatabase(USERID);
  //
  //     // Load fresh data
  //     // Clear existing data
  //
  //     await System().empty();
  //     await Contact().emptyContact();
  //
  //     // Store user and token info
  //     await System().insertUserDetails(loggedInUser);
  //     await System().insertToken(accessToken);
  //
  //     // Check if we need to refresh all data
  //     final prevUserId = prefs.getInt('prevUserId');
  //     final lastSync = await System().getProductLastSync();
  //     final now = DateTime.now();
  //     final shouldRefreshAll = prevUserId == null ||
  //         prevUserId != USERID ||
  //         lastSync == null ||
  //         now.difference(DateTime.parse(lastSync)).inHours > 10;
  //
  //     // await SystemApi().store();
  //     // await Variations().refresh();
  //     // await System().insertProductLastSyncDateTimeNow();
  //
  //     // Load data based on conditions
  //     if (shouldRefreshAll) {
  //       if (await Helper().checkConnectivity()) {
  //         // Load essential data in parallel with explicit type
  //         await Future.wait<void>([
  //           SystemApi().store(),
  //           Variations().refresh(),
  //         ]);
  //
  //         await System().insertProductLastSyncDateTimeNow();
  //         await SellDatabase().deleteSellTables();
  //       }
  //     } else {
  //       // Just load system API if refresh not needed
  //       await SystemApi().store();
  //     }
  //
  //     // Store current user as previous user for next time
  //     await prefs.setInt('prevUserId', USERID!);
  //
  //     //await(_loadRemainingData(prefs));
  //
  //     if (mounted) {
  //       Navigator.of(context).pushReplacement(
  //         MaterialPageRoute(builder: (_) => Home()),
  //       );
  //     }
  //   } catch (e, st) {
  //     print("ERROR::::::$e\n\n$st");
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context)
  //           .translate('data_load_failed') +
  //           ': ${e.toString()}',
  //     );
  //   }
  // }
  Future<void> loadAllData(Map loginResponse) async {
    final stopwatch = Stopwatch()..start();

    try {
      // 1. Get user data (essential)
      final loggedInUser = await User().get(loginResponse['access_token']);

      if (loggedInUser['id'] == null) {
        throw Exception('Invalid user data');
      }

      USERID = loggedInUser['id'] as int;
      Config.userId = USERID;

      // 2. Initialize database (required)
      await DbProvider().initializeDatabase(USERID);

      // 3. Store essential data in parallel
      await Future.wait([
        SharedPreferences.getInstance().then((prefs) => prefs.setInt('userId', USERID!)),
        System().insertUserDetails(loggedInUser),
        System().insertToken(loginResponse['access_token']),
      ]);

      // 3.5. Force enable all tables and shipping for new login session
      TableAvailabilityManager().forceEnableAllOnLogin();

      // 4. Load only essential system data for fast startup
      await SystemApi().storeEssential(); // Load only critical data

      // 5. Navigate immediately (should now be under 5 seconds)
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => Home()),
        );
      }

      // 6. Load remaining data in background
      await _loadBackgroundData();

      debugPrint('Total login time: ${stopwatch.elapsedMilliseconds}ms');
    } catch (e, st) {
      debugPrint('Login error: $e\n$st');
      if (mounted) {
        Fluttertoast.showToast(
          msg: AppLocalizations.of(context)
              .translate('data_load_failed') +
              ': ${e.toString()}',
        );
      }
    }
  }

  Future<void> _refreshContacts() async {
    try {
      await CustomerApi().get();
    } catch (e) {
      debugPrint('Contact refresh error: $e');
    }
  }
// Future<void> _loadRemainingData(SharedPreferences prefs) async {
//   try {
//     // Load these in parallel
//
//     List<Future<void>> futures = [
//       SystemApi().store(),
//       Contact().emptyContact(),
//       System().insertProductLastSyncDateTimeNow(),
//     ];
//     await Future.wait(futures);
//
//     // await Future.wait([
//     //   SystemApi().store(),
//     //   Contact().emptyContact(),
//     //   System().insertProductLastSyncDateTimeNow(),
//     // ] as Iterable<Future>);
//
//     final lastSync = await System().getProductLastSync();
//     final now = DateTime.now();
//
//     // Only refresh variations if really needed
//     if (prefs.getInt('prevUserId') == null ||
//         prefs.getInt('prevUserId') != prefs.getInt('userId')) {
//       await SellDatabase().deleteSellTables();
//       await Variations().refresh();
//     } else if (lastSync == null ||
//         now.difference(DateTime.parse(lastSync)).inHours > 10) {
//       if (await Helper().checkConnectivity()) {
//         await Variations().refresh();
//         await System().insertProductLastSyncDateTimeNow();
//         await SellDatabase().deleteSellTables();
//       }
//     }
//   } catch (e) {
//     print("Background data loading error: $e");
//   }
// }

  /// ✅ COMPLETE FRESH START METHOD
  /// Ensures completely clean state before any new login
  Future<void> _performCompleteFreshStart() async {
    debugPrint('🔄 Starting complete fresh start for login...');

    try {
      // 1. Clear ALL SharedPreferences data first
      debugPrint('🧹 Clearing all SharedPreferences...');
      final prefs = await SharedPreferences.getInstance();
      await _clearAllLoginSharedPreferences(prefs);

      // 2. Reset global variables to null
      debugPrint('🔄 Resetting global variables...');
      USERID = null;
      Config.userId = null;

      // 3. Clear any app constants/cache
      debugPrint('🧽 Clearing app constants...');
      try {
        AppConstants.cartData.clear();
      } catch (e) {
        debugPrint('AppConstants.cartData not available: $e');
      }

      // 4. COMPREHENSIVE DATABASE CLEARING
      debugPrint('🗃️ Performing comprehensive database clearing...');
      await _performComprehensiveDatabaseClear();

      debugPrint('✅ Complete fresh start successful!');
    } catch (e) {
      debugPrint('❌ Error during fresh start: $e');
      // Don't rethrow - continue with login even if cleanup fails
    }
  }

  /// Comprehensive database clearing for fresh start
  Future<void> _performComprehensiveDatabaseClear() async {
    try {
      final dbProvider = DbProvider();

      // Try comprehensive table clearing first
      try {
        await dbProvider.clearAllTables();
        debugPrint('✅ Database tables cleared successfully');
      } catch (e) {
        debugPrint('⚠️ Table clearing failed: $e, resetting database...');
        // If table clearing fails, reset the database instance
        DbProvider.resetDatabase();
      }

    } catch (e) {
      debugPrint('❌ Database clearing failed: $e');
      // Continue with login even if database cleanup fails
    }
  }

  /// Clear ALL SharedPreferences for fresh login
  Future<void> _clearAllLoginSharedPreferences(SharedPreferences prefs) async {
    final keys = prefs.getKeys().toList();

    // Clear everything except system settings like language preferences
    for (String key in keys) {
      // Keep only essential system preferences
      if (!key.startsWith('language_') &&
          !key.startsWith('theme_') &&
          !key.startsWith('flutter.')) {
        await prefs.remove(key);
        debugPrint('🗑️ Cleared SharedPreference: $key');
      }
    }

    debugPrint('🧹 Cleared ${keys.length} SharedPreferences for fresh start');
  }
}

// Future<void> loadAllData(Map loginResponse) async {
//   try {
//     final prefs = await SharedPreferences.getInstance();
//     final loggedInUser =
//     await User().get(loginResponse['access_token'] as String);
//
//     String accessToken = loginResponse['access_token'] as String;
//     for (var i = 0; i < accessToken.length; i += 100) {
//       print(accessToken.substring(i, i + 100 > accessToken.length ? accessToken.length : i + 100));
//     }
//
//     if (loggedInUser['id'] == null) {
//       throw Exception('Invalid user data');
//     }
//
//     USERID = loggedInUser['id'] as int;
//     Config.userId = USERID;
//     await prefs.setInt('userId', USERID!);
//     await DbProvider().initializeDatabase(USERID);
//
//     final lastSync = await System().getProductLastSync();
//     final now = DateTime.now();
//
//     await System().empty();
//     await Contact().emptyContact();
//     await System().insertUserDetails(loggedInUser);
//     await System().insertToken(loginResponse['access_token'] as String);
//     await SystemApi().store();
//     await System().insertProductLastSyncDateTimeNow();
//
//     if (prefs.getInt('prevUserId') == null ||
//         prefs.getInt('prevUserId') != prefs.getInt('userId')) {
//       await SellDatabase().deleteSellTables();
//       await Variations().refresh();
//     } else if (lastSync == null ||
//         now.difference(DateTime.parse(lastSync)).inHours > 10) {
//       if (await Helper().checkConnectivity()) {
//         await Variations().refresh();
//         await System().insertProductLastSyncDateTimeNow();
//         await SellDatabase().deleteSellTables();
//       }
//     }
//
//     if (mounted) {
//       Navigator.of(context).pushReplacement(
//         MaterialPageRoute(builder: (_) => Home()),
//       );
//     }
//   } catch (e,st) {
//
//
//
//     print("ERROR::::::$e\n\n$st");
//     Fluttertoast.showToast(
//       msg: AppLocalizations.of(context)
//           .translate('data_load_failed') +
//           ': ${e.toString()}',
//     );
//   }
// }
// Future<void> loadAllData(Map loginResponse) async {
//   try {
//     final prefs = await SharedPreferences.getInstance();
//     final accessToken = loginResponse['access_token'] as String;
//
//     // Parallelize these operations where possible
//     final loggedInUser = await User().get(accessToken);
//
//     if (loggedInUser['id'] == null) {
//       throw Exception('Invalid user data');
//     }
//
//     USERID = loggedInUser['id'] as int;
//     Config.userId = USERID;
//     await prefs.setInt('userId', USERID!);
//
//     // Initialize database in background
//     unawaited(DbProvider().initializeDatabase(USERID));
//
//     // Store minimal required data for home screen first
//     await Future.wait([
//       System().empty(),
//       System().insertUserDetails(loggedInUser),
//       System().insertToken(accessToken),
//     ]);
//
//     // Load remaining data in background after login completes
//     unawaited(_loadRemainingData(prefs));
//
//     if (mounted) {
//       Navigator.of(context).pushReplacement(
//         MaterialPageRoute(builder: (_) => Home()),
//       );
//     }
//   } catch (e, st) {
//     print("ERROR::::::$e\n\n$st");
//     Fluttertoast.showToast(
//       msg: AppLocalizations.of(context)
//           .translate('data_load_failed') +
//           ': ${e.toString()}',
//     );
//   }
// }
