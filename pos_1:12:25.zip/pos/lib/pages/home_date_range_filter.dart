// import 'package:date_picker_plus/date_picker_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import '../locale/MyLocalizations.dart';
//
// class HomeDateRangeFilter extends StatefulWidget {
//   final String? initialStartDate;
//   final String? initialEndDate;
//   final Function(String?, String?) onDateRangeSelected;
//
//   const HomeDateRangeFilter({
//     Key? key,
//     this.initialStartDate,
//     this.initialEndDate,
//     required this.onDateRangeSelected,
//   }) : super(key: key);
//
//   @override
//   _HomeDateRangeFilterState createState() => _HomeDateRangeFilterState();
// }
//
// class _HomeDateRangeFilterState extends State<HomeDateRangeFilter> {
//   String? startDateRange;
//   String? endDateRange;
//
//   @override
//   void initState() {
//     super.initState();
//     startDateRange = widget.initialStartDate;
//     endDateRange = widget.initialEndDate;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       bottom: true,
//       top: false,
//       child: Scaffold(
//         appBar: AppBar(
//           title: Text(AppLocalizations.of(context).translate('select_range')),
//           elevation: 0,
//         ),
//         body: Column(
//           children: [
//             RangeDatePicker(
//               minDate: DateTime(2000),
//               maxDate: DateTime.now(),
//               initialPickerType: PickerType.years,
//               onRangeSelected: (range) {
//                 setState(() {
//                   // Ensure dates don't exceed today
//                   final today = DateTime.now();
//                   final startDate = range.start.isAfter(today) ? today : range.start;
//                   final endDate = range.end.isAfter(today) ? today : range.end;
//                   startDateRange = DateFormat('yyyy-MM-dd').format(startDate);
//                   endDateRange = DateFormat('yyyy-MM-dd').format(endDate);
//                 });
//               },
//             ),
//             Padding(
//               padding: EdgeInsets.symmetric(vertical: 30.0),
//             ),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: [
//                 ElevatedButton(
//                   style: ElevatedButton.styleFrom(
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(20.0),
//                       side: BorderSide(
//                           color: Theme.of(context).colorScheme.primary),
//                     ),
//                     onPrimary: Theme.of(context).colorScheme.primary,
//                   ),
//                   onPressed: () {
//                     setState(() {
//                       startDateRange = null;
//                       endDateRange = null;
//                     });
//                     widget.onDateRangeSelected(null, null);
//                     Navigator.pop(context);
//                   },
//                   child: Text(
//                     'Reset',
//                     style: Theme.of(context).textTheme.headline6?.copyWith(
//                       color: Theme.of(context).colorScheme.onPrimary,
//                     ),
//                   ),
//                 ),
//                 ElevatedButton(
//                   style: ElevatedButton.styleFrom(
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(20.0),
//                       side: BorderSide(
//                           color: Theme.of(context).colorScheme.primary),
//                     ),
//                     onPrimary: Theme.of(context).colorScheme.primary,
//                   ),
//                   onPressed: () {
//                     widget.onDateRangeSelected(startDateRange, endDateRange);
//                     Navigator.pop(context);
//                   },
//                   child: Text(
//                     'OK',
//                     style: Theme.of(context).textTheme.headline6?.copyWith(
//                       color: Theme.of(context).colorScheme.onPrimary,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
