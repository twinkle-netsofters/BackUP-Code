import 'dart:async';
import 'dart:convert';

import 'package:date_picker_plus/date_picker_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:printing/printing.dart';
import 'package:search_choices/search_choices.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../apis/api.dart';
import '../apis/sell.dart';
import '../helpers/AppTheme.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/otherHelpers.dart';
import '../helpers/context_manager.dart';
import '../locale/MyLocalizations.dart';
import '../models/contact_model.dart';
import '../models/invoice.dart';
import '../models/paymentDatabase.dart';
import '../models/sell.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import '../pages/login.dart';
import 'elements.dart';
import '../helpers/TableAvailabilityManager.dart';
import 'event_bus.dart';

class Sales extends StatefulWidget {
  @override
  _SalesState createState() => _SalesState();
}

class _SalesState extends State<Sales> {
  List sellList = [];
  String? startDateRange;
  String? endDateRange;
  List<String> paymentStatuses = ['all'], invoiceStatuses = ['final', 'draft'];
  ScrollController _scrollController = new ScrollController();
  bool isLoading = false,
      isLoadingMore = false,
      synced = true,
      canViewSell = false,
      canEditSell = false,
      canDeleteSell = false,
      showFilter = false,
      changeUrl = false,
      _isLoadingDialogShown = false;
  Map<dynamic, dynamic> selectedLocation = {'id': 0, 'name': 'All'},
      selectedCustomer = {'id': 0, 'name': 'All', 'mobile': ''};
  // String selectedPaymentStatus = 'all';
  String selectedPaymentStatus = 'all';
  // String? startDateRange, endDateRange; // selectedInvoiceStatus = 'all';
  List<Map<dynamic, dynamic>> allSalesListMap = [],
      customerListMap = [
        {'id': 0, 'name': 'All', 'mobile': ''}
      ],
      locationListMap = [
        {'id': 0, 'name': 'All'}
      ];
  String symbol = '';
  String? nextPage = '',

  /// Today's Sales API ====================================================
      url = Api().apiUrl + "sell?order_by_date=desc";

  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
  CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);

  String selectedCurrentSalesFilter = 'ordered';
  List<String> currentSalesFilters = [
    'all', 'paid', 'due',
    //'overdue',
    'partial', 'quotation', 'ordered'
  ];

  // Event subscription for table availability changes
  StreamSubscription? _eventSubscription;

  @override
  void initState() {
    super.initState();
    setCustomers();
    setLocations();
    if ((synced)) refreshSales();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent &&
          nextPage != null &&
          nextPage!.isNotEmpty &&
          !isLoadingMore &&
          !isLoading) {
        setAllSalesList();
      }
    });
    Helper().syncCallLogs();
    _setupEventListeners();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Listen for navigation events to refresh sales when returning from other screens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (ModalRoute.of(context)?.isCurrent == true && !isLoading) {
        // We're back on this screen, refresh the sales list
        sells();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _eventSubscription?.cancel();
    super.dispose();
  }

  /// Setup event listeners for table availability changes
  void _setupEventListeners() {
    _eventSubscription = EventBus().stream.listen((event) {
      if (event is TableAvailabilityChangedEvent) {
        debugPrint(
            'Sales: Received table availability change event: ${event.tableId}, shipping: ${event.isShipping}, available: ${event.isAvailable}');
        // Refresh sales list when table availability changes
        if (mounted) {
          setState(() {
            // Trigger a refresh of the sales list
          });
        }
      } else if (event is DraftSavedEvent) {
        debugPrint('Sales: Received draft saved event');
        // Refresh sales list when a draft is saved
        if (mounted) {
          refreshSales();
        }
      } else if (event is DraftFinalizedEvent) {
        debugPrint('Sales: Received draft finalized event');
        // Refresh sales list when a draft is finalized
        if (mounted) {
          refreshSales();
        }
      } else if (event is QuotationCreatedEvent) {
        debugPrint('Sales: Received quotation created event');
        // Refresh sales list when a quotation is created
        if (mounted) {
          refreshSales();
        }
      }
    });
  }

  /// Manual method to refresh table availability - useful for debugging
  Future<void> refreshTableAvailability() async {
    try {
      final availabilityManager = TableAvailabilityManager();
      await availabilityManager.refreshAvailability();
      debugPrint('Sales: Manually refreshed table availability');
    } catch (e) {
      debugPrint('Sales: Error refreshing table availability: $e');
    }
  }

  setCustomers() async {
    customerListMap.addAll(await Contact().get());
    setState(() {});
  }

  setLocations() async {
    await System().get('location').then((value) {
      value.forEach((element) {
        setState(() {
          locationListMap.add({
            'id': element['id'],
            'name': element['name'],
          });
        });
      });
    });
    await System().refreshPermissionList().then((value) async {
      await getPermission().then((value) {
        changeUrl = true;
        onFilter();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      initialIndex: 0,
      child: SafeArea(
        bottom: true,
        top: false,
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            title: Text(AppLocalizations.of(context).translate('sales'),
                style: AppTheme.getTextStyle(themeData.textTheme.headline6,
                    fontWeight: 600)),
            actions: <Widget>[
              IconButton(
                icon: Icon(Icons.refresh),
                onPressed: () async {
                  if (!isLoading) {
                    // Refresh Recent Sales tab
                    await sells();
                    // Refresh All Sales tab by resetting and reloading
                    nextPage = url;
                    changeUrl = true;
                    setAllSalesList();
                  }
                },
                tooltip: AppLocalizations.of(context).translate('refresh') ?? 'Refresh',
              ),
              // TextButton(
              //   onPressed: () async {
              //     if (await Helper().checkConnectivity()) {
              //       showDialog(
              //         barrierDismissible: true,
              //         context: context,
              //         builder: (BuildContext context) {
              //           return AlertDialog(
              //             content: Row(
              //               children: [
              //                 CircularProgressIndicator(),
              //                 Container(
              //                     margin: EdgeInsets.only(left: 5),
              //                     child: Text(AppLocalizations.of(context)
              //                         .translate('sync_in_progress'))),
              //               ],
              //             ),
              //           );
              //         },
              //       );
              //       await Sell().createApiSell(syncAll: true).then((value) {
              //         Navigator.pop(context);
              //         setState(() {
              //           synced = true;
              //           sells();
              //         });
              //       });
              //     } else
              //       Fluttertoast.showToast(
              //           msg: AppLocalizations.of(context)
              //               .translate('check_connectivity'));
              //   },
              //   child: Text(
              //     AppLocalizations.of(context).translate('sync'),
              //     style: AppTheme.getTextStyle(themeData.textTheme.subtitle1,
              //         fontWeight: (synced) ? 500 : 900, letterSpacing: -0.2),
              //   ),
              // ),
            ],
            bottom: TabBar(tabs: [
              Tab(
                  icon: Icon(Icons.line_weight),
                  child: Text(
                      AppLocalizations.of(context).translate('recent_sales'))),
              Tab(
                icon: Icon(Icons.line_style),
                child:
                Text(AppLocalizations.of(context).translate('all_sales')),
              )
            ]),
          ),
          body: TabBarView(children: [currentSales(), allSales()]),
          bottomNavigationBar: posBottomBar('sale', context),
        ),
      ),
    );
  }

  //Fetch permission from database
  // getPermission() async {
  //   var activeSubscriptionDetails = await System().get('active-subscription');
  //   if (activeSubscriptionDetails.length > 0) {
  //     if (await Helper().getPermission("sell.update")) {
  //       canEditSell = true;
  //     }
  //     if (await Helper().getPermission("sell.delete")) {
  //       canDeleteSell = true;
  //     }
  //   }
  //   if (await Helper().getPermission("view_paid_sells_only")) {
  //     paymentStatuses.add('paid');
  //     selectedPaymentStatus = 'paid';
  //   }
  //   if (await Helper().getPermission("view_due_sells_only")) {
  //     paymentStatuses.add('due');
  //     selectedPaymentStatus = 'due';
  //   }
  //   if (await Helper().getPermission("view_partial_sells_only")) {
  //     paymentStatuses.add('partial');
  //     selectedPaymentStatus = 'partial';
  //   }
  //   if (await Helper().getPermission("view_overdue_sells_only")) {
  //     paymentStatuses.add('overdue');
  //     selectedPaymentStatus = 'overdue';
  //   }
  //   //await Helper().getPermission("sell.view")
  //   if (await Helper().getPermission("direct_sell.view")) {
  //     url = Api().apiUrl + "sell?order_by_date=desc";
  //     if (paymentStatuses.length < 2) {
  //       paymentStatuses.addAll(['paid', 'due', 'partial', 'overdue']);
  //       selectedPaymentStatus = 'all';
  //     }
  //     //setState(() {
  //     canViewSell = true;
  //     // });
  //   } else if (await Helper().getPermission("view_own_sell_only")) {
  //     url = Api().apiUrl + "sell?order_by_date=desc&user_id=$USERID";
  //     if (paymentStatuses.length < 2) {
  //       paymentStatuses.addAll(['paid', 'due', 'partial', 'overdue']);
  //       selectedPaymentStatus = 'all';
  //     }
  //     setState(() {
  //       canViewSell = true;
  //     });
  //   }
  // }//Fetch permission from database
  getPermission() async {
    var activeSubscriptionDetails = await System().get('active-subscription');
    if (activeSubscriptionDetails.length > 0) {
      if (await Helper().getPermission("sell.update")) {
        canEditSell = true;
      }
      if (await Helper().getPermission("sell.delete")) {
        canDeleteSell = true;
      }
    }
    if (await Helper().getPermission("view_paid_sells_only")) {
      paymentStatuses.add('paid');
      // Keep default as 'all' unless this is the only permission
      if (paymentStatuses.length == 1) {
        selectedPaymentStatus = 'paid';
      }
    }
    if (await Helper().getPermission("view_due_sells_only")) {
      paymentStatuses.add('due');
      // Keep default as 'all' unless this is the only permission
      if (paymentStatuses.length == 1) {
        selectedPaymentStatus = 'due';
      }
    }
    if (await Helper().getPermission("view_partial_sells_only")) {
      paymentStatuses.add('partial');
      // Keep default as 'all' unless this is the only permission
      if (paymentStatuses.length == 1) {
        selectedPaymentStatus = 'partial';
      }
    }
    // if (await Helper().getPermission("view_overdue_sells_only")) {
    //   paymentStatuses.add('overdue');
    //   selectedPaymentStatus = 'overdue';
    // }
    //await Helper().getPermission("sell.view")
    if (await Helper().getPermission("direct_sell.view")) {
      url = Api().apiUrl + "sell?order_by_date=desc";
      if (paymentStatuses.length < 2) {
        // paymentStatuses.addAll(['paid', 'due', 'partial', 'overdue']);
        paymentStatuses.addAll(['paid', 'due', 'partial']);
        selectedPaymentStatus = 'all';
      }
      //setState(() {
      canViewSell = true;
      // });
    } else if (await Helper().getPermission("view_own_sell_only")) {
      url = Api().apiUrl + "sell?order_by_date=desc&user_id=$USERID";
      if (paymentStatuses.length < 2) {
        // paymentStatuses.addAll(['paid', 'due', 'partial', 'overdue']);
        paymentStatuses.addAll(['paid', 'due', 'partial']);
        selectedPaymentStatus = 'all';
      }
      setState(() {
        canViewSell = true;
      });
    }
  }

  refreshSales() async {
    if (await Helper().checkConnectivity()) {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Row(
              children: [
                CircularProgressIndicator(),
                Container(
                  margin: EdgeInsets.only(left: 5),
                  child:
                  Text(AppLocalizations.of(context).translate('loading')),
                ),
              ],
            ),
          );
        },
      );
      // Fetch today's sales from API
      if (!isLoading) {
        await sells(); // Wait for data to load fully
      }
      if (mounted && Navigator.of(context).canPop()) {
        Navigator.pop(context);
      }
    } else {
      if (!isLoading) {
        await sells(); // Still try to load (will return early if no connectivity)
      }
      Fluttertoast.showToast(
          msg: AppLocalizations.of(context).translate('check_connectivity'));
    }
  }

  //fetch current sales from API (only today's sales)
  sells() async {
    // Prevent multiple simultaneous calls
    if (isLoading || !mounted) return;

    if (mounted) {
      setState(() {
        isLoading = true;
        sellList = [];
      });
    }

    try {
      // Check connectivity
      if (!await Helper().checkConnectivity()) {
        print('sells(): No connectivity, cannot fetch from API');
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
        return;
      }

      // Get today's date in yyyy-MM-dd format
      DateTime now = DateTime.now();
      String todayDate = DateFormat('yyyy-MM-dd').format(now);

      // Build API URL for today's sales
      final dio = new Dio();
      var token = await System().getToken();
      if (token == null) {
        print('sells(): No token available');
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
        return;
      }

      dio.options.headers['content-Type'] = 'application/json';
      dio.options.headers["Authorization"] = "Bearer $token";

      // Fetch only today's sales from API (with high per_page to get all today's sales)
      String apiUrl = Api().apiUrl + "sell?order_by_date=desc&start_date=$todayDate&end_date=$todayDate&per_page=1000";
      print('sells(): Fetching today\'s sales from API: $apiUrl');

      final response = await dio.get(apiUrl);

      if (response.data != null && response.data['data'] != null) {
        List sales = response.data['data'];
        print('sells(): Received ${sales.length} sales from API for today');

        // Debug: Log all draft orders received from API
        List draftOrders = sales.where((sale) =>
        (sale['payment_status'] == 'draft' || sale['status'] == 'draft') &&
            (sale['is_quotation'] ?? 0) == 0
        ).toList();
        print('sells(): Found ${draftOrders.length} draft (Ordered) orders in API response');
        for (var draft in draftOrders) {
          print('sells(): Draft order - ID: ${draft['id']}, Invoice: ${draft['invoice_no']}, Table: ${draft['res_table_id']}, Shipping: ${draft['is_shipping']}');
        }

        // CRITICAL: Use only ID-based duplicate checking, not invoice_no
        // Multiple draft orders can have similar invoice_no patterns, but each has a unique ID
        Set<int> processedIds = {};

        // Process all sells sequentially to avoid race conditions
        for (var element in sales) {
          // Check for duplicates using only ID (not invoice_no) to allow multiple drafts
          int elementId = element['id'] ?? 0;

          // Only skip if we've already processed this exact ID
          if (elementId != 0 && !processedIds.contains(elementId)) {
            processedIds.add(elementId);

            // Safely get customer details
            Map<String, dynamic>? customerDetail;
            try {
              customerDetail =
              await Contact().getCustomerDetailById(element['contact_id']);
            } catch (e) {
              print('Error getting customer details in sells(): $e');
              customerDetail = null;
            }

            // Safely get location name
            String? locationName;
            try {
              locationName =
              await Helper().getLocationNameById(element['location_id']);
            } catch (e) {
              print('Error getting location name in sells(): $e');
              locationName = 'Unknown Location';
            }

            // Get table name if res_table_id exists
            String? tableName;
            if (element['res_table_id'] != null && element['res_table_id'] != 0) {
              try {
                tableName =
                await Helper().getTableNameById(element['res_table_id']);
              } catch (e) {
                print('Error getting table name in sells(): $e');
                tableName = null;
              }
            }

            // Calculate amounts from API data
            double finalTotal = double.tryParse(element['final_total'].toString()) ?? 0.0;
            List payments = element['payment_lines'] ?? [];
            double totalPaid = 0.00;
            payments.forEach((payment) {
              totalPaid += double.tryParse(payment['amount'].toString()) ?? 0.0;
            });
            double pendingAmount = (finalTotal - totalPaid).clamp(0.0, finalTotal);
            double paidAmount = totalPaid.clamp(0.0, finalTotal);

            // Optimized shipping detection
            int isShippingValue =
                int.tryParse((element['is_shipping'] ?? 0).toString()) ?? 0;
            if (isShippingValue == 0 &&
                (element['res_table_id'] == null || element['res_table_id'] == 0)) {
              isShippingValue = 1;
            }

            sellList.add({
              'id': element['id'],
              'transaction_date': element['transaction_date'],
              'invoice_no': element['invoice_no'],
              'customer_name': (customerDetail != null)
                  ? ("${(customerDetail['name'] != null) ? customerDetail['name'] : ''} "
                  "${(customerDetail['supplier_business_name'] != null) ? customerDetail['supplier_business_name'] : ''}")
                  : 'Unknown Customer',
              'mobile': customerDetail != null ? customerDetail['mobile'] : null,
              'contact_id': element['contact_id'],
              'location_id': element['location_id'],
              'location_name': locationName,
              // CRITICAL: Check both payment_status and status fields for draft detection
              // API might return status='draft' or payment_status='draft'
              'status': element['status'] ?? element['payment_status'] ?? 'final',
              'tax_rate_id': element['tax_rate_id'] ?? element['tax_id'] ?? 0,
              'discount_amount': element['discount_amount'],
              'discount_type': element['discount_type'],
              'sale_note': element['sale_note'],
              'staff_note': element['staff_note'],
              'invoice_amount': finalTotal,
              'pending_amount': pendingAmount,
              'paid_amount': paidAmount,
              'is_quotation': element['is_quotation'] ?? 0,
              'invoice_url': element['invoice_url'],
              'transaction_id': element['id'],
              'is_shipping': isShippingValue,
              'res_table_id': element['res_table_id'],
              'table_name': tableName,
              'products': element['sell_lines'] ?? []
            });
          }
        }

        // Update UI once with all data
        if (mounted) {
          setState(() {});
        }

        // Debug logging
        print('sells(): Processed ${sellList.length} sales items from API for today');

        // Debug: Count draft orders in sellList
        List draftOrdersInList = sellList.where((sale) =>
        sale['status'] == 'draft' && (sale['is_quotation'] ?? 0) == 0
        ).toList();
        print('sells(): Found ${draftOrdersInList.length} draft (Ordered) orders in sellList after processing');
        for (var draft in draftOrdersInList) {
          print('sells(): Draft in sellList - ID: ${draft['id']}, Invoice: ${draft['invoice_no']}, Table: ${draft['res_table_id']}, Shipping: ${draft['is_shipping']}, Customer: ${draft['customer_name']}');
        }

        if (sellList.length > 0) {
          print(
              'sells(): First item - ID: ${sellList[0]['id']}, Invoice: ${sellList[0]['invoice_no']}, Status: ${sellList[0]['status']}');
          print(
              'sells(): Last item - ID: ${sellList.last['id']}, Invoice: ${sellList.last['invoice_no']}, Status: ${sellList.last['status']}');
        }
      } else {
        print('sells(): No data received from API');
        sellList = [];
      }
    } catch (e) {
      print('Error in sells(): $e');
      sellList = [];
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }

    await Helper().getFormattedBusinessDetails().then((value) {
      symbol = value['symbol'];
    });
  }

  // //refresh sales list
  // updateSellsFromApi() async {
  //   //get synced sells transactionId
  //   List transactionIds = await SellDatabase().getTransactionIds();
  //
  //   if (transactionIds.isNotEmpty) {
  //     //fetch specified sells by transactionId from api
  //     List specificSales = await SellApi().getSpecifiedSells(transactionIds);
  //
  //     specificSales.forEach((element) async {
  //       //fetch sell from database with respective transactionId
  //       List sell = await SellDatabase().getSellByTransactionId(element['id']);
  //
  //       if (sell.length > 0) {
  //         //Updating latest data in sell_payments
  //         //delete payment lines with reference to its sellId
  //         await PaymentDatabase().delete(sell[0]['id']);
  //         element['payment_lines'].forEach((value) async {
  //           //store payment lines from response
  //           await PaymentDatabase().store({
  //             'sell_id': sell[0]['id'],
  //             'method': value['method'],
  //             'amount': value['amount'],
  //             'note': value['note'],
  //             'payment_id': value['id'],
  //             'is_return': value['is_return'],
  //             'account_id': value['account_id']
  //           });
  //         });
  //
  //         //Updating latest data in sell_lines
  //         //delete sell_lines with reference to its sellId
  //         await SellDatabase().deleteSellLineBySellId(sell[0]['id']);
  //
  //         element['sell_lines'].forEach((value) async {
  //           //   //store sell lines from response
  //           await SellDatabase().store({
  //             'sell_id': sell[0]['id'],
  //             'product_id': value['product_id'],
  //             'variation_id': value['variation_id'],
  //             'quantity': value['quantity'],
  //             'unit_price': value['unit_price_before_discount'],
  //             'tax_rate_id': value['tax_id'],
  //             'discount_amount': value['line_discount_amount'],
  //             'discount_type': value['line_discount_type'],
  //             'note': value['sell_line_note'],
  //             'is_completed': 1
  //           });
  //         });
  //         //update latest sells details
  //         updateSells(element);
  //       }
  //     });
  //   }
  // }

  //update sells

  updateSells(sells) async {
    var changeReturn = 0.0;
    var pendingAmount = 0.0;
    var totalAmount = 0.0;
    List sell = await SellDatabase().getSellByTransactionId(sells['id']);
    await PaymentDatabase()
        .get(sell[0]['id'], allColumns: true, res_table_id: null)
        .then((value) {
      value.forEach((element) {
        if (element['is_return'] == 1) {
          changeReturn += element['amount'];
        } else {
          totalAmount += element['amount'];
        }
      });
    });
    if (double.parse(sells['final_total']) > totalAmount) {
      pendingAmount = double.parse(sells['final_total']) - totalAmount;
    }

    // FIXED: Preserve original invoice_no from local database instead of using API invoice_no
    // This ensures draft invoice numbers like "DRAFT-1759825990955" are preserved after completion
    Map<String, dynamic> sellsWithOriginalInvoice =
    Map<String, dynamic>.from(sells);
    sellsWithOriginalInvoice['invoice_no'] =
    sell[0]['invoice_no']; // Use original local invoice_no

    Map<String, dynamic> sellMap = Sell()
        .createSellMap(sellsWithOriginalInvoice, changeReturn, pendingAmount);
    await SellDatabase().updateSells(sell[0]['id'], sellMap);

    // Check if the order is being finalized and mark table/shipping as available
    if (sells['status'] == 'final' || sells['sale_status'] == 'final') {
      try {
        // Get the sell details to get table and shipping information
        var sellDetails = await SellDatabase().getSellBySellId(sell[0]['id']);
        if (sellDetails.isNotEmpty) {
          var resTableId = sellDetails[0]['res_table_id'];
          var isShipping = sellDetails[0]['is_shipping'];

          // Call finalizeOrder to mark table/shipping as available
          await Sell().finalizeOrder(sell[0]['id'], resTableId, isShipping);
          debugPrint(
              'Sales: Order ${sell[0]['id']} finalized, table/shipping marked as available');
        }
      } catch (e) {
        debugPrint('Sales: Error finalizing order ${sell[0]['id']}: $e');
      }
    }
  }

  onFilter() {
    if (!mounted) return;

    nextPage = url;
    if (selectedLocation['id'] != 0) {
      nextPage = nextPage! + "&location_id=${selectedLocation['id']}";
    }
    if (selectedCustomer['id'] != 0) {
      nextPage = nextPage! + "&contact_id=${selectedCustomer['id']}";
    }
    if (selectedPaymentStatus != 'all') {
      nextPage = nextPage! + "&payment_status=$selectedPaymentStatus";
    } else if (selectedPaymentStatus == 'all') {
      List<String> status = List.from(paymentStatuses);
      status.remove('all');
      String statuses = status.join(',');
      nextPage = nextPage! + "&payment_status=$statuses";
    }
    if (startDateRange != null && endDateRange != null) {
      nextPage =
          nextPage! + "&start_date=$startDateRange&end_date=$endDateRange";
    }
    changeUrl = true;
    setAllSalesList();
  }

  //Retrieve sales list from api
  // void setAllSalesList() async {
  //   setState(() {
  //     if (changeUrl) {
  //       allSalesListMap = [];
  //       changeUrl = false;
  //       showFilter = false;
  //     }
  //     isLoading = false;
  //   });
  //   final dio = new Dio();
  //   var token = await System().getToken();
  //   dio.options.headers['content-Type'] = 'application/json';
  //   dio.options.headers["Authorization"] = "Bearer $token";
  //   final response = await dio.get(nextPage!);
  //   List sales = response.data['data'];
  //   Map links = response.data['links'];
  //   nextPage = links['next'];
  //   sales.forEach((sell) async {
  //     var paidAmount;
  //     List payments = sell['payment_lines'];
  //     double totalPaid = 0.00;
  //     Map<String, dynamic>? customer =
  //         //sell['contact'];
  //         await Contact().getCustomerDetailById(sell['contact_id']);
  //     var location = await Helper().getLocationNameById(sell['location_id']);
  //     payments.forEach((element) {
  //       totalPaid += double.parse(element['amount']);
  //     });
  //     (totalPaid <= double.parse(sell['final_total']))
  //         ? paidAmount = Helper().formatCurrency(totalPaid)
  //         : paidAmount = Helper().formatCurrency(sell['final_total']);
  //     allSalesListMap.add({
  //       'id': sell['id'],
  //       'location_name': location,
  //       'contact_name': (customer != null)
  //           ? ("${(customer['name'] != null) ? customer['name'] : ''} "
  //               "${(customer['supplier_business_name'] != null) ? customer['supplier_business_name'] : ''}")
  //           : null,
  //       'mobile': (customer != null) ? customer['mobile'] : null,
  //       'invoice_no': sell['invoice_no'],
  //       'invoice_url': sell['invoice_url'],
  //       'date_time': sell['transaction_date'],
  //       'invoice_amount': sell['final_total'],
  //       'status': sell['payment_status'] ?? sell['status'],
  //       'paid_amount': paidAmount,
  //       'is_quotation': sell['is_quotation'].toString()
  //     });
  //     if (this.mounted) {
  //       setState(() {
  //         isLoading = true;
  //       });
  //     }
  //   });
  // }
  void setAllSalesList() async {
    if (!mounted) return;

    // Prevent loading if there's no next page available (unless it's a filter change)
    if (!changeUrl && (nextPage == null || nextPage!.isEmpty)) {
      print('DEBUG: No more pages to load');
      return;
    }

    // Determine if this is initial load or pagination
    bool isInitialLoad = allSalesListMap.isEmpty || changeUrl;

    setState(() {
      if (changeUrl) {
        allSalesListMap = [];
        changeUrl = false;
        showFilter = false;
      }
      // Use isLoading for initial load, isLoadingMore for pagination
      if (isInitialLoad) {
        isLoading = true;
        isLoadingMore = false;
      } else {
        isLoadingMore = true;
        isLoading = false;
      }
    });

    try {
      // Fetch complete sales history from API instead of just local database
      final dio = new Dio();
      var token = await System().getToken();
      if (token == null) {
        print('setAllSalesList: No token available');
        if (mounted) {
          setState(() {
            isLoading = false;
            isLoadingMore = false;
          });
        }
        return;
      }

      dio.options.headers['content-Type'] = 'application/json';
      dio.options.headers["Authorization"] = "Bearer $token";

      // Add pagination limit to improve initial load time
      String apiUrl = nextPage!;
      if (!apiUrl.contains('per_page=') && !apiUrl.contains('limit=')) {
        apiUrl += apiUrl.contains('?') ? '&per_page=50' : '?per_page=50';
      }

      print('DEBUG: Fetching sales history from API: $apiUrl');
      final response = await dio.get(apiUrl);

      if (response.data != null && response.data['data'] != null) {
        List sales = response.data['data'];
        Map links = response.data['links'];

        // Update nextPage for pagination
        nextPage = links['next'];

        print('DEBUG: Received ${sales.length} sales from API');
        print('DEBUG: Next page URL: $nextPage');

        // Process sales with optimized performance
        print('DEBUG: Processing ${sales.length} sales records...');

        // Pre-filter to exclude drafts and quotations early
        List filteredSales = sales.where((sell) {
          bool isDraft =
              sell['status'] == 'draft' || sell['payment_status'] == 'draft';
          bool isQuotation =
              sell['is_quotation'] == 1 || sell['is_quotation'] == '1';
          return !isDraft && !isQuotation;
        }).toList();

        print(
            'DEBUG: After filtering: ${filteredSales.length} sales to process');

        // Process sales with reduced API calls and progress updates
        int processedCount = 0;
        int totalCount = filteredSales.length;

        for (var sell in filteredSales) {
          if (!mounted) return; // Check if widget is still mounted

          processedCount++;

          // Update progress every 10 records or at the end
          if (processedCount % 10 == 0 || processedCount == totalCount) {
            print('DEBUG: Processing sales... ${processedCount}/${totalCount}');
            // Allow UI to update
            await Future.delayed(Duration(milliseconds: 1));
          }

          // Get customer details (keep this as it's needed for display)
          Map<String, dynamic>? customer;
          try {
            customer =
            await Contact().getCustomerDetailById(sell['contact_id']);
          } catch (e) {
            customer = null;
          }

          // Get location name (keep this as it's needed for display)
          String? location;
          try {
            location = await Helper().getLocationNameById(sell['location_id']);
          } catch (e) {
            location = 'Unknown Location';
          }

          // Get table name only if needed (optimization)
          String? tableName;
          if (sell['res_table_id'] != null && sell['res_table_id'] != 0) {
            try {
              tableName = await Helper().getTableNameById(sell['res_table_id']);
            } catch (e) {
              tableName = null;
            }
          }

          // Calculate paid amount
          var paidAmount;
          List payments = sell['payment_lines'] ?? [];
          double totalPaid = 0.00;
          payments.forEach((element) {
            totalPaid += double.tryParse(element['amount'].toString()) ?? 0.0;
          });
          double finalTotal =
              double.tryParse(sell['final_total'].toString()) ?? 0.0;
          (totalPaid <= finalTotal)
              ? paidAmount = Helper().formatCurrency(totalPaid)
              : paidAmount = Helper().formatCurrency(finalTotal);

          // Optimized shipping detection with minimal logging
          int isShippingValue =
              int.tryParse((sell['is_shipping'] ?? 0).toString()) ?? 0;

          // Quick check: res_table_id null or 0 typically means shipping
          if (isShippingValue == 0 &&
              (sell['res_table_id'] == null || sell['res_table_id'] == 0)) {
            isShippingValue = 1;
          }

          // Fallback: Check sell_lines for shipping (only if not already detected)
          if (isShippingValue == 0 && sell['sell_lines'] != null) {
            List sellLines = sell['sell_lines'];
            for (var line in sellLines) {
              // Quick checks for shipping indicators
              if ((line['is_shipping'] != null &&
                  int.tryParse(line['is_shipping'].toString()) == 1) ||
                  (line['product_name'] != null &&
                      line['product_name']
                          .toString()
                          .toLowerCase()
                          .contains('shipping')) ||
                  (line['product_name'] != null &&
                      (line['product_name']
                          .toString()
                          .toLowerCase()
                          .contains('delivery') ||
                          line['product_name']
                              .toString()
                              .toLowerCase()
                              .contains('transport') ||
                          line['product_name']
                              .toString()
                              .toLowerCase()
                              .contains('courier')))) {
                isShippingValue = 1;
                break;
              }
            }
          }

          allSalesListMap.add({
            'id': sell['id'],
            'location_name': location,
            'contact_name': (customer != null)
                ? ("${(customer['name'] != null) ? customer['name'] : ''} "
                "${(customer['supplier_business_name'] != null) ? customer['supplier_business_name'] : ''}")
                : 'Unknown Customer',
            'mobile': (customer != null) ? customer['mobile'] : null,
            'invoice_no': sell['invoice_no'],
            'invoice_url': sell['invoice_url'],
            'date_time': sell['transaction_date'],
            'invoice_amount': sell['final_total'],
            'status': sell['payment_status'] ?? sell['status'],
            'paid_amount': paidAmount,
            'is_quotation': sell['is_quotation'].toString(),
            'is_shipping': isShippingValue,
            'res_table_id': sell['res_table_id'],
            'table_name': tableName,
            'tax_rate_id': sell['tax_rate_id'] ?? sell['tax_id'] ?? 0
          });
        }

        print('DEBUG: Completed processing ${processedCount} sales records');
      }

      if (mounted) {
        setState(() {
          isLoading = false;
          isLoadingMore = false;
        });
        print(
            'DEBUG: All Sales loading completed - ${allSalesListMap.length} records loaded');
      }
    } catch (e) {
      print('Error in setAllSalesList: $e');
      if (mounted) {
        setState(() {
          isLoading = false;
          isLoadingMore = false;
        });
      }
    }

    // Note: Drafts are excluded from All Sales tab as they should only appear in Recent Sales tab
    // Drafts can be accessed through the Recent Sales tab with the draft filter
    // try {
    //   final dio2 = new Dio();
    //   var token2 = await System().getToken();
    //   dio2.options.headers['content-Type'] = 'application/json';
    //   dio2.options.headers["Authorization"] = "Bearer $token2";

    //   final draftsResp = await dio2.get(Api().apiUrl + "sells/drafts?order_by_date=desc");
    //   if (draftsResp.data != null && draftsResp.data['data'] != null) {
    //     List drafts = draftsResp.data['data'];
    //     for (var sell in drafts) {
    //       var paidAmount;
    //       List payments = sell['payment_lines'] ?? [];
    //       double totalPaid = 0.00;
    //       Map<String, dynamic>? customer = await Contact().getCustomerDetailById(sell['contact_id']);
    //       var location = await Helper().getLocationNameById(sell['location_id']);
    //       payments.forEach((element) {
    //         totalPaid += double.tryParse(element['amount'].toString()) ?? 0.0;
    //       });
    //       double finalTotalDraft = double.tryParse(sell['final_total'].toString()) ?? 0.0;
    //       (totalPaid <= finalTotalDraft)
    //           ? paidAmount = Helper().formatCurrency(totalPaid)
    //           : paidAmount = Helper().formatCurrency(finalTotalDraft);
    //       // Get table name if res_table_id exists
    //       String? tableName;
    //       if (sell['res_table_id'] != null && sell['res_table_id'] != 0) {
    //         tableName = await Helper().getTableNameById(sell['res_table_id']);
    //       }

    //       // Only exclude specific ghost draft records: DRAFT invoices with zero amounts and "Unknown Customer"
    //       bool isGhostDraft = sell['invoice_no'] != null &&
    //           sell['invoice_no'].toString().toLowerCase().contains('draft') &&
    //           (sell['final_total'] == null || sell['final_total'] == 0.0) &&
    //           (customer == null || customer['name'] == null || customer['name'].toString().toLowerCase().contains('unknown'));

    //       if (!isGhostDraft) {
    //         allSalesListMap.add({
    //           'id': sell['id'],
    //           'location_name': location,
    //           'contact_name': (customer != null)
    //               ? ("${(customer['name'] != null) ? customer['name'] : ''} "
    //               "${(customer['supplier_business_name'] != null) ? customer['supplier_business_name'] : ''}")
    //               : null,
    //           'mobile': (customer != null) ? customer['mobile'] : null,
    //           'invoice_no': sell['invoice_no'],
    //           'invoice_url': sell['invoice_url'],
    //           'date_time': sell['transaction_date'],
    //           'invoice_amount': sell['final_total'],
    //           'status': 'draft',
    //           'paid_amount': paidAmount,
    //           'is_quotation': '0',
    //           'is_shipping': int.tryParse((sell['is_shipping'] ?? 0).toString()) ?? 0,
    //           'res_table_id': sell['res_table_id'],
    //           'table_name': tableName
    //         });
    //       }
    //     }
    //   }
    // } catch (e) {}

    // Note: Quotations are excluded from All Sales tab as they should only appear in Recent Sales tab
    // Quotations can be accessed through the Recent Sales tab with the quotation filter
    // try {
    //   final dio3 = new Dio();
    //   var token3 = await System().getToken();
    //   dio3.options.headers['content-Type'] = 'application/json';
    //   dio3.options.headers["Authorization"] = "Bearer $token3";

    //   final quotesResp = await dio3.get(Api().apiUrl + "sells/quotations?order_by_date=desc");
    //   if (quotesResp.data != null && quotesResp.data['data'] != null) {
    //     List quotes = quotesResp.data['data'];
    //     for (var sell in quotes) {
    //       var paidAmount;
    //       List payments = sell['payment_lines'] ?? [];
    //       double totalPaid = 0.00;
    //       Map<String, dynamic>? customer = await Contact().getCustomerDetailById(sell['contact_id']);
    //       var location = await Helper().getLocationNameById(sell['location_id']);
    //       payments.forEach((element) {
    //         totalPaid += double.tryParse(element['amount'].toString()) ?? 0.0;
    //       });
    //       double finalTotalDraft = double.tryParse(sell['final_total'].toString()) ?? 0.0;
    //       (totalPaid <= finalTotalDraft)
    //           ? paidAmount = Helper().formatCurrency(totalPaid)
    //           : paidAmount = Helper().formatCurrency(finalTotalDraft);
    //       // Get table name if res_table_id exists
    //       String? tableName;
    //       if (sell['res_table_id'] != null && sell['res_table_id'] != 0) {
    //         tableName = await Helper().getTableNameById(sell['res_table_id']);
    //       }

    //       // Only exclude specific ghost quotation records: DRAFT invoices with zero amounts and "Unknown Customer"
    //       bool isGhostQuotation = sell['invoice_no'] != null &&
    //           sell['invoice_no'].toString().toLowerCase().contains('draft') &&
    //           (sell['final_total'] == null || sell['final_total'] == 0.0) &&
    //           (customer == null || customer['name'] == null || customer['name'].toString().toLowerCase().contains('unknown'));

    //       if (!isGhostQuotation) {
    //         allSalesListMap.add({
    //           'id': sell['id'],
    //           'location_name': location,
    //           'contact_name': (customer != null)
    //               ? ("${(customer['name'] != null) ? customer['name'] : ''} "
    //               "${(customer['supplier_business_name'] != null) ? customer['supplier_business_name'] : ''}")
    //               : null,
    //           'mobile': (customer != null) ? customer['mobile'] : null,
    //           'invoice_no': sell['invoice_no'],
    //           'invoice_url': sell['invoice_url'],
    //           'date_time': sell['transaction_date'],
    //           'invoice_amount': sell['final_total'],
    //           'status': 'draft',
    //           'paid_amount': paidAmount,
    //           'is_quotation': '1',
    //           'is_shipping': int.tryParse((sell['is_shipping'] ?? 0).toString()) ?? 0,
    //           'res_table_id': sell['res_table_id'],
    //           'table_name': tableName
    //         });
    //       }
    //     }
    //   }
    // } catch (e) {}
  }

  //progress indicator
  Widget _buildProgressIndicator() {
    return new Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Center(
        child: FutureBuilder<bool>(
            future: Helper().checkConnectivity(),
            builder: (context, AsyncSnapshot<bool> snapshot) {
              if (snapshot.data == false) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      AppLocalizations.of(context)
                          .translate('check_connectivity'),
                      style: AppTheme.getTextStyle(
                          themeData.textTheme.subtitle1,
                          fontWeight: 700,
                          letterSpacing: -0.2),
                    ),
                    Icon(
                      Icons.error_outline,
                      color: themeData.colorScheme.onBackground,
                    )
                  ],
                );
              } else {
                return CircularProgressIndicator();
              }
            }),
      ),
    );
  }

  //widget for listing sales from api
  Widget currentSales() {
    // Filter the sellList based on selected filter
    List filteredSellList = sellList.where((sale) {
      // Exclude incomplete drafts: drafts with no customer selected (null, 0, or 'Unknown Customer')
      if (sale['status'] == 'draft' && sale['is_quotation'] != 1) {
        bool hasNoCustomer = sale['contact_id'] == null ||
            sale['contact_id'] == 0 ||
            sale['customer_name'] == null ||
            sale['customer_name'] == 'Unknown Customer' ||
            sale['customer_name'].toString().trim().isEmpty;

        // If it's a draft with no customer, exclude it from all views except explicit ordered filter
        if (hasNoCustomer && selectedCurrentSalesFilter != 'ordered') {
          return false;
        }
      }

      if (selectedCurrentSalesFilter == 'all') return true;
      if (selectedCurrentSalesFilter == 'paid')
        //return sale['pending_amount'] <= 0 && sale['is_quotation'] == 0;
        return sale['pending_amount'] <= 0 &&
            sale['is_quotation'] == 0 &&
            sale['status'] != 'draft';

      if (selectedCurrentSalesFilter == 'due')
        return sale['pending_amount'] == sale['invoice_amount'] &&
            // sale['is_quotation'] == 0;
            sale['is_quotation'] == 0 &&
            sale['status'] != 'draft';
      if (selectedCurrentSalesFilter == 'partial') {
        return sale['pending_amount'] > 0 &&
            sale['pending_amount'] < sale['invoice_amount'] &&
            // sale['is_quotation'] == 0;
            sale['is_quotation'] == 0 &&
            sale['status'] != 'draft';
      }
      if (selectedCurrentSalesFilter == 'quotation') {
        return sale['is_quotation'] == 1;
      }
      if (selectedCurrentSalesFilter == 'ordered') {
        // Only show meaningful drafts (those with customers selected)
        bool isDraft = sale['status'] == 'draft' && sale['is_quotation'] == 0;
        bool hasCustomer = sale['contact_id'] != null &&
            sale['contact_id'] != 0 &&
            sale['customer_name'] != null &&
            sale['customer_name'] != 'Unknown Customer' &&
            sale['customer_name'].toString().trim().isNotEmpty;
        return isDraft && hasCustomer;
      }
      return true;
    }).toList();

    return Column(
      children: [
        // Add the filter container here
        Container(
          // padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          margin: EdgeInsets.all(10),
          padding: EdgeInsets.symmetric(horizontal: 3, vertical: 0),
          decoration: BoxDecoration(
            color: customAppTheme.bgLayer1,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: customAppTheme.bgLayer4,
              width: 1,
            ),
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildFilterChip('all'),
                SizedBox(width: 5),
                _buildFilterChip('paid'),
                // SizedBox(width: 5),
                // _buildFilterChip('overdue'),
                SizedBox(width: 5),
                _buildFilterChip('ordered'),
                SizedBox(width: 5),
                _buildFilterChip('quotation'),
                SizedBox(width: 5),
                _buildFilterChip('due'),
                SizedBox(width: 5),
                _buildFilterChip('partial'),
              ],
            ),
          ),
        ),
        // The existing list view
        // (filteredSellList.length > 0)
        //     ? Expanded(
        //         child: ListView.builder(
        //           padding: EdgeInsets.only(
        //             right: 10,
        //             left: 10,
        //             bottom: 10,
        //           ),
        //           controller: _scrollController,
        //           shrinkWrap: true,
        //           itemCount: filteredSellList.length,
        //           itemBuilder: (context, index) {
        //             // Debug logging for Recent Sales
        //             var recentIsShippingValue =
        //                 filteredSellList[index]['is_shipping'];
        //             var recentTableNameValue =
        //                 filteredSellList[index]['table_name'];
        //             var recentResTableIdValue =
        //                 filteredSellList[index]['res_table_id'];
        //             var recentInvoiceNo = filteredSellList[index]['invoice_no'];
        //
        //             print('DEBUG Recent Sales - Invoice: $recentInvoiceNo');
        //             print(
        //                 '  - is_shipping (raw): $recentIsShippingValue (type: ${recentIsShippingValue.runtimeType})');
        //             print(
        //                 '  - is_shipping (converted): ${int.tryParse(recentIsShippingValue.toString()) ?? 0}');
        //             print('  - table_name: $recentTableNameValue');
        //             print('  - res_table_id: $recentResTableIdValue');
        //             print(
        //                 '  - Should show shipping label: ${(int.tryParse(recentIsShippingValue.toString()) ?? 0) == 1}');
        //
        //             return recentSellItem(
        //                 price: Helper().formatCurrency(
        //                     filteredSellList[index]['invoice_amount'] ?? 0.0),
        //                 number: filteredSellList[index]['invoice_no'],
        //                 // status: checkStatus(
        //                 //     filteredSellList[index]['invoice_amount'],
        //                 //     filteredSellList[index]['pending_amount']),
        //                 status: filteredSellList[index]['status'] == 'draft'
        //                     ? 'ordered'
        //                     : checkStatus(
        //                         filteredSellList[index]['invoice_amount'] ??
        //                             0.0,
        //                         filteredSellList[index]['pending_amount'] ??
        //                             0.0),
        //                 time: filteredSellList[index]['transaction_date'],
        //                 paid: Helper().formatCurrency(
        //                     filteredSellList[index]['paid_amount'] ?? 0.0),
        //                 isSynced: filteredSellList[index]['is_synced'],
        //                 customerName: filteredSellList[index]['customer_name'],
        //                 locationName: filteredSellList[index]['location_name'],
        //                 isQuotation: filteredSellList[index]['is_quotation'],
        //                 index: index,
        //                 isShipping: int.tryParse(filteredSellList[index]
        //                             ['is_shipping']
        //                         .toString()) ??
        //                     0,
        //                 tableName: filteredSellList[index]['table_name'],
        //                 res_table_id: filteredSellList[index]['res_table_id']);
        //           },
        //         ),
        //       )
        //     : Expanded(child: Helper().noDataWidget(context)),
        // Show loading dialog when loading
        _buildSalesContent(filteredSellList),
      ],
    );
  }

  // Build sales content with loading dialog and no data handling
  Widget _buildSalesContent(List filteredSellList) {
    // Show loading dialog only for initial load (not for pagination)
    // Only show dialog when loading and there's no existing data
    if (isLoading && filteredSellList.isEmpty && !_isLoadingDialogShown) {
      _isLoadingDialogShown = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && isLoading && filteredSellList.isEmpty) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) {
              return Center(
                child: AlertDialog(
                  content: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(width: 20),
                      Text(
                        AppLocalizations.of(context).translate('loading'),
                        style: TextStyle(color: Colors.black),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }
      });
    }

    // Dismiss loading dialog when not loading or when data exists
    if ((!isLoading || filteredSellList.isNotEmpty) && _isLoadingDialogShown) {
      _isLoadingDialogShown = false;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
      });
    }

    // Show "No Data" when no sales data and not loading
    if (filteredSellList.isEmpty && !isLoading) {
      return Expanded(child: Helper().noDataWidget(context));
    }

    // Show sales list when data exists (even if loading, show existing data)
    if (filteredSellList.isNotEmpty) {
      return Expanded(
        child: ListView.builder(
          key: ValueKey('sellListView'),
          padding: EdgeInsets.all(10),
          controller: _scrollController,
          itemCount: filteredSellList.length,
          itemBuilder: (context, index) {
            return recentSellItem(
              key: ValueKey(filteredSellList[index]['id']),
              data: filteredSellList[index],
              index: index,
              isQuotation: filteredSellList[index]['is_quotation'],
              status: filteredSellList[index]['status'] == 'draft'
                  ? 'ordered'
                  : checkStatus(
                  filteredSellList[index]['invoice_amount'] ?? 0.0,
                  filteredSellList[index]['pending_amount'] ?? 0.0),
            );
          },
        ),
      );
    }

    // Return empty widget while loading and no data
    return Expanded(child: SizedBox.shrink());
  }

  // Updated helper method with colored backgrounds
  Widget _buildFilterChip(String status) {
    // Determine colors based on status
    Color selectedColor;
    Color textColor;

    switch (status) {
      case 'paid':
        selectedColor = Colors.green;
        textColor = Colors.white;
        break;
    // case 'overdue':
    //   selectedColor = Colors.yellow;
    //   textColor = Colors.black; // Black text for better visibility on yellow
    //   break;
      case 'quotation':
        selectedColor = Colors.yellow;
        textColor = Colors.black;
        break;
      case 'ordered':
        selectedColor = Colors.purpleAccent;
        textColor = Colors.white;
        break;
      case 'due':
        selectedColor = Colors.red;
        textColor = Colors.white;
        break;
      case 'partial':
        selectedColor = Colors.orange;
        textColor = Colors.white;
        break;
      default: // 'all' case
        selectedColor = themeData.colorScheme.primary;
        textColor = Colors.white;
        break;
    }

    return ChoiceChip(
      label: Text(
        AppLocalizations.of(context).translate(status),
        style: AppTheme.getTextStyle(
          themeData.textTheme.bodyText2,
          color: selectedCurrentSalesFilter == status
              ? textColor
              : themeData.colorScheme.onBackground,
        ),
      ),
      selected: selectedCurrentSalesFilter == status,
      selectedColor: selectedColor,
      backgroundColor: themeData.backgroundColor,
      side: BorderSide(
        color: selectedCurrentSalesFilter == status
            ? selectedColor
            : customAppTheme.bgLayer4,
        // width: selectedCurrentSalesFilter == status ? 2.0 : 1.0,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      onSelected: (selected) {
        setState(() {
          selectedCurrentSalesFilter = status;
        });
      },
    );
  }

  Widget allSales() {
    return (canViewSell)
        ? Column(
      children: [
        GestureDetector(
          onTap: () {
            setState(() {
              showFilter = !showFilter;
            });
          },
          child: Container(
            padding: EdgeInsets.all(MySize.size12!),
            margin: EdgeInsets.all(MySize.size12!),
            decoration: BoxDecoration(
              borderRadius:
              BorderRadius.all(Radius.circular(MySize.size8!)),
              color: customAppTheme.bgLayer1,
              border:
              Border.all(color: customAppTheme.bgLayer4, width: 1.2),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(
                      (showFilter)
                          ? MdiIcons.chevronUp
                          : MdiIcons.chevronDown,
                      color: themeData.colorScheme.primary,
                    ),
                    Row(
                      children: [
                        Text(
                          AppLocalizations.of(context)
                              .translate('filter'),
                          style: AppTheme.getTextStyle(
                              themeData.textTheme.headline6,
                              color: themeData.colorScheme.primary,
                              fontWeight: 700),
                        ),
                        Icon(
                          MdiIcons.filter,
                          color: themeData.colorScheme.primary,
                        )
                      ],
                    ),
                  ],
                ),
                (showFilter)
                    ? Column(
                  children: [
                    Row(
                      children: [
                        Text(
                          "${AppLocalizations.of(context).translate('location')} : ",
                          style: AppTheme.getTextStyle(
                              themeData.textTheme.bodyText1,
                              fontWeight: 600),
                        ),
                        locations()
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          "${AppLocalizations.of(context).translate('customer')} : ",
                          style: AppTheme.getTextStyle(
                              themeData.textTheme.bodyText1,
                              fontWeight: 600),
                        ),
                        Expanded(child: customers())
                      ],
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context)
                            .push(new MaterialPageRoute<Null>(
                            builder: (BuildContext context) {
                              return dateRangePicker();
                            },
                            fullscreenDialog: true));
                      },
                      child: Container(
                        padding: EdgeInsets.all(MySize.size8!),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(
                              Radius.circular(MySize.size8!)),
                          color: customAppTheme.bgLayer1,
                          border: Border.all(
                              color: customAppTheme.bgLayer4,
                              width: 2),
                        ),
                        child: Row(
                          mainAxisAlignment:
                          MainAxisAlignment.center,
                          children: [
                            Text(
                                (startDateRange != null &&
                                    endDateRange != null)
                                    ? "$startDateRange   -   $endDateRange"
                                    : "Date range",
                                style: AppTheme.getTextStyle(
                                    themeData.textTheme.bodyText1,
                                    fontWeight: 600)),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: MySize.size6!),
                    ),
                    Row(
                      children: [
                        Text(
                          "${AppLocalizations.of(context).translate('payment_status')} : ",
                          style: AppTheme.getTextStyle(
                              themeData.textTheme.bodyText1,
                              fontWeight: 600),
                        ),
                        (paymentStatuses.length > 0)
                            ? paymentStatus()
                            : Container()
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: MySize.size6!),
                    ),
                    Row(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                      children: [
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                    MySize.size20!),
                                side: BorderSide(
                                    color: themeData
                                        .colorScheme.primary)),
                            onPrimary:
                            themeData.colorScheme.primary,
                          ),
                          child: Text(
                            AppLocalizations.of(context)
                                .translate('reset'),
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.button,
                                color:
                                themeData.colorScheme.onPrimary,
                                fontWeight: 600),
                          ),
                          onPressed: () {
                            setState(() {
                              selectedLocation = locationListMap[0];
                              selectedCustomer = customerListMap[0];
                              startDateRange = null;
                              endDateRange = null;
                              selectedPaymentStatus =
                              paymentStatuses[0];
                            });
                            onFilter();
                          },
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                    MySize.size20!),
                                side: BorderSide(
                                    color: themeData
                                        .colorScheme.primary)),
                            onPrimary:
                            themeData.colorScheme.primary,
                          ),
                          child: Text(
                            AppLocalizations.of(context)
                                .translate('ok'),
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.button,
                                color:
                                themeData.colorScheme.onPrimary,
                                fontWeight: 600),
                          ),
                          onPressed: () {
                            onFilter();
                          },
                        ),
                      ],
                    )
                    // Padding(padding: EdgeInsets.symmetric(vertical: MySize.size6),), Row(children: [Text("${AppLocalizations.of(context).translate('invoice_status')} : ", style: AppTheme.getTextStyle(themeData.textTheme.bodyText1, fontWeight: 600),), invoiceStatus()],),
                  ],
                )
                    : Container()
              ],
            ),
          ),
        ),
        Expanded(
          child: (allSalesListMap.length > 0)
              ? ListView.builder(
              padding: EdgeInsets.all(10),
              shrinkWrap: true,
              controller: _scrollController,
              itemCount: allSalesListMap.length + (isLoadingMore ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == allSalesListMap.length) {
                  return (isLoadingMore)
                      ? _buildProgressIndicator()
                      : Container();
                } else {
                  // Debug logging for All Sales
                  var isShippingValue =
                  allSalesListMap[index]['is_shipping'];
                  var tableNameValue =
                  allSalesListMap[index]['table_name'];
                  var resTableIdValue =
                  allSalesListMap[index]['res_table_id'];
                  var invoiceNo =
                  allSalesListMap[index]['invoice_no'];

                  print('DEBUG All Sales - Invoice: $invoiceNo');
                  print(
                      '  - is_shipping (raw): $isShippingValue (type: ${isShippingValue.runtimeType})');
                  print(
                      '  - is_shipping (converted): ${int.tryParse(isShippingValue.toString()) ?? 0}');
                  print('  - table_name: $tableNameValue');
                  print('  - res_table_id: $resTableIdValue');
                  print(
                      '  - Should show shipping label: ${(int.tryParse(isShippingValue.toString()) ?? 0) == 1}');

                  return allSellItem(
                      index: index,
                      price: allSalesListMap[index]['invoice_amount'],
                      number: allSalesListMap[index]['invoice_no'],
                      time: allSalesListMap[index]['date_time'],
                      status: allSalesListMap[index]['status'],
                      paid: allSalesListMap[index]['paid_amount'],
                      customerName: allSalesListMap[index]
                      ['contact_name'],
                      locationName: allSalesListMap[index]
                      ['location_name'],
                      isQuotation: int.parse(allSalesListMap[index]
                      ['is_quotation']
                          .toString()),
                      isShipping: int.tryParse(allSalesListMap[index]
                      ['is_shipping']
                          .toString()) ??
                          0,
                      tableName: allSalesListMap[index]['table_name'],
                      res_table_id: allSalesListMap[index]
                      ['res_table_id']);
                }
              })
              : Helper().noDataWidget(context),
        )
      ],
    )
        : Center(
      child: Text(
        AppLocalizations.of(context).translate('unauthorised'),
        style: TextStyle(color: Colors.black),
      ),
    );
  }

  Widget dateRangePicker() {
    return SafeArea(
      bottom: true,
      top: false,
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppLocalizations.of(context).translate('select_range')),
          elevation: 0,
        ),

        // Inside your widget build:
        body: Column(
          children: [
            RangeDatePicker(
              minDate: DateTime(2000),
              maxDate: DateTime.now(),
              initialPickerType: PickerType.years,
              onRangeSelected: (range) {
                setState(() {
                  // Ensure dates don't exceed today
                  final today = DateTime.now();
                  final startDate = range.start.isAfter(today) ? today : range.start;
                  final endDate = range.end.isAfter(today) ? today : range.end;
                  startDateRange = DateFormat('yyyy-MM-dd').format(startDate);
                  endDateRange = DateFormat('yyyy-MM-dd').format(endDate);
                });
              },
            ),

            // SfDateRangePicker(
            //   view: DateRangePickerView.year,
            //   selectionMode: DateRangePickerSelectionMode.range,
            //   onSelectionChanged: (DateRangePickerSelectionChangedArgs args) {
            //     if (args.value is PickerDateRange) {
            //       DateTime? start = args.value.startDate;
            //       DateTime? end = args.value.endDate;
            //       setState(() {
            //         startDateRange = start != null
            //             ? DateFormat('yyyy-MM-dd').format(start)
            //             : '';
            //         endDateRange =
            //             end != null ? DateFormat('yyyy-MM-dd').format(end) : '';
            //       });
            //     }
            //   },
            // ),

            // RangeDatePicker(
            //   minDate: DateTime(2000),
            //   maxDate: DateTime(2100),
            //   initialPickerType: PickerType.years,
            //   onStartDateChanged: (start) {
            //     setState(() {
            //       startDateRange = DateFormat('yyyy-MM-dd').format(start);
            //     });
            //   },
            //   onEndDateChanged: (end) {
            //     setState(() {
            //       endDateRange = DateFormat('yyyy-MM-dd').format(end);
            //     });
            //   },
            // ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 30.0),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      side: BorderSide(
                          color: Theme.of(context).colorScheme.primary),
                    ),
                    onPrimary: Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: () {
                    setState(() {
                      startDateRange = null;
                      endDateRange = null;
                    });
                    Navigator.pop(context);
                  },
                  child: Text(
                    'Reset',
                    style: Theme.of(context).textTheme.headline6?.copyWith(
                      color: Theme.of(context).colorScheme.onPrimary,
                    ),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      side: BorderSide(
                          color: Theme.of(context).colorScheme.primary),
                    ),
                    onPrimary: Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text(
                    'OK',
                    style: Theme.of(context).textTheme.headline6?.copyWith(
                      color: Theme.of(context).colorScheme.onPrimary,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  //recent sales listing widget

  Widget recentSellItem({
    Key? key,
    required Map<String, dynamic> data,
    required int index,
    status,
    isQuotation,
  }) {
    double space = MySize.size12!;
    // int isQuotation = int.tryParse(data['is_quotation'].toString()) ?? 0; //data['is_quotation'];
    int isShipping = int.tryParse(data['is_shipping'].toString()) ?? 0;
    // String status = data['status']?.toString() ?? '';
    String tableName = data['table_name']?.toString() ?? '';
    int? res_table_id = int.tryParse(data['res_table_id']?.toString() ?? '0');
    // int? res_table_id = data['res_table_id'] is int
    //     ? data['res_table_id']
    //     : int.tryParse(data['res_table_id']?.toString() ?? '0');

    return Container(
      key: key,
      padding: EdgeInsets.only(top: space, right: space, left: space),
      margin: EdgeInsets.only(top: MySize.size0!, bottom: space),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
        color: customAppTheme.bgLayer1,
        border: Border.all(color: customAppTheme.bgLayer4, width: 1.2),
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _formatDateTime(data['transaction_date']),
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText2,
                  fontWeight: 600,
                  letterSpacing: -0.2,
                  color: themeData.colorScheme.onBackground.withAlpha(160),
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        (isQuotation == 0)
                            ? AppLocalizations.of(context)
                            .translate('invoice_no') +
                            "  ${data['invoice_no']},"
                            : AppLocalizations.of(context).translate('ref_no') +
                            "  ${data['invoice_no']},",
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.subtitle1,
                            fontWeight: 700,
                            letterSpacing: -0.2),
                      ),
                      // Text(
                      //   (isQuotation == 1 ? 'Ref No: ' : 'Invoice No: ') +
                      //       "${data['invoice_no']}",
                      //   style: AppTheme.getTextStyle(
                      //     themeData.textTheme.subtitle1,
                      //     fontWeight: 700,
                      //     letterSpacing: -0.2,
                      //   ),
                      // ),
                      Text(
                        AppLocalizations.of(context)
                            .translate('invoice_amount') +
                            ": $symbol ${Helper().formatCurrency(data['invoice_amount'] ?? 0.0)}",
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText2,
                            fontWeight: 600,
                            letterSpacing: 0),
                      ),
                      // Text(
                      //   "Invoice Amount: ${Helper().formatCurrency(data['invoice_amount'] ?? 0.0)}",
                      //   style: AppTheme.getTextStyle(
                      //     themeData.textTheme.bodyText2,
                      //     fontWeight: 600,
                      //     letterSpacing: 0,
                      //   ),
                      // ),

                      (isQuotation == 0)
                          ? Text(
                        AppLocalizations.of(context)
                            .translate('paid_amount') +
                            ": $symbol ${Helper().formatCurrency(data['paid_amount'] ?? 0.0)}",
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText2,
                            fontWeight: 600,
                            letterSpacing: 0),
                      )
                          : SizedBox(),
                      // if (isQuotation == 1)
                      //   Text(
                      //     "Paid Amount: ${Helper().formatCurrency(data['paid_amount'] ?? 0.0)}",
                      //     style: AppTheme.getTextStyle(
                      //       themeData.textTheme.bodyText2,
                      //       fontWeight: 600,
                      //     ),
                      //   ),
                      Text(
                        AppLocalizations.of(context)
                            .translate('customer_name') +
                            ": ${data['customer_name'] ?? ''}",
                        style: AppTheme.getTextStyle(
                          themeData.textTheme.bodyText2,
                          fontWeight: 600,
                        ),
                      ),
                      Text(
                        AppLocalizations.of(context)
                            .translate('location_name') +
                            ": ${data['location_name'] ?? ''}",
                        style: AppTheme.getTextStyle(
                          themeData.textTheme.bodyText2,
                          fontWeight: 600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Visibility(
                visible: index != null,
                child: Row(
                  children: [
                    if (canEditSell &&
                        (status.toLowerCase() == 'ordered' ||
                            // (data['status'].toString().toLowerCase() == 'ordered' ||
                            isQuotation == 1))
                      IconButton(
                        icon: Icon(
                          MdiIcons.fileDocumentEditOutline,
                          color: themeData.colorScheme.onBackground,
                        ),
                        onPressed: () async {
                          int selectedSellId = data['id'];
                          int transactionId = data['transaction_id'] ?? data['id'];
                          int? resTableId = data['res_table_id'];
                          String? tableName = data['table_name'];
                          int isShipping = data['is_shipping'] ?? 0;

                          print(
                              'Sales Edit: Fetching sale data from API for transaction_id: $transactionId');

                          // Show loading dialog
                          showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (context) {
                              return Center(
                                child: AlertDialog(
                                  content: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CircularProgressIndicator(),
                                      SizedBox(width: 20),
                                      Text(
                                        AppLocalizations.of(context)
                                            .translate('loading'),
                                        style: TextStyle(color: Colors.black),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );

                          try {
                            // Check connectivity
                            if (!await Helper().checkConnectivity()) {
                              Navigator.pop(context);
                              Fluttertoast.showToast(
                                msg: AppLocalizations.of(context)
                                    .translate('check_connectivity') ??
                                    'No internet connection',
                              );
                              return;
                            }

                            // Fetch sale data from API
                            List specificSales =
                            await SellApi().getSpecifiedSells([transactionId]);

                            if (specificSales.isEmpty) {
                              Navigator.pop(context);
                              Fluttertoast.showToast(
                                msg: 'Sale not found in server',
                              );
                              return;
                            }

                            var saleData = specificSales[0];

                            // Get the transaction_id from API (this is the API's sale ID)
                            int apiTransactionId = saleData['id'];

                            // OPTIMIZED: Combine database queries - check both transaction_id and selectedSellId in parallel
                            var localSell = await SellDatabase().getSellByTransactionId(apiTransactionId.toString());
                            int localSellId;

                            if (localSell.isNotEmpty) {
                              // Sale exists in local DB, use local sellId
                              localSellId = localSell[0]['id'];
                              print('Sales Edit: Found local sale with sellId: $localSellId for transaction_id: $apiTransactionId');

                              // Update transaction_id if it wasn't set (combine with other updates later)
                              if (localSell[0]['transaction_id'] == null) {
                                await SellDatabase().updateSells(localSellId, {
                                  'transaction_id': apiTransactionId.toString(),
                                });
                              }
                            } else {
                              // Check by selectedSellId in case it's a local draft without transaction_id
                              var localSellById = await SellDatabase().getSellBySellId(selectedSellId);
                              if (localSellById.isNotEmpty && localSellById[0]['transaction_id'] == null) {
                                localSellId = selectedSellId;
                                // Update with transaction_id from API
                                await SellDatabase().updateSells(localSellId, {
                                  'transaction_id': apiTransactionId.toString(),
                                  'is_synced': 1,
                                });
                                print('Sales Edit: Found local sale by ID $localSellId and updated transaction_id');
                              } else {
                                // Sale doesn't exist in local DB, create it
                                print('Sales Edit: Sale not in local DB, creating local sale record for transaction_id: $apiTransactionId');

                                // Create a local sale record from API data
                                int apiIsShipping = saleData['is_shipping'] ?? isShipping;
                                int? effectiveResTableId = apiIsShipping == 1 ? 0 : saleData['res_table_id'];

                                Map<String, dynamic> sellMap = {
                                  'transaction_id': apiTransactionId.toString(),
                                  'invoice_no': saleData['invoice_no'] ?? 'DRAFT-$apiTransactionId',
                                  'contact_id': saleData['contact_id'],
                                  'location_id': saleData['location_id'],
                                  'transaction_date': saleData['transaction_date'],
                                  'status': saleData['status'] ?? saleData['payment_status'] ?? 'draft',
                                  'sale_status': saleData['status'] ?? saleData['payment_status'] ?? 'draft',
                                  'tax_rate_id': saleData['tax_rate_id'] ?? saleData['tax_id'] ?? 0,
                                  'discount_amount': double.tryParse(saleData['discount_amount'].toString()) ?? 0.0,
                                  'discount_type': saleData['discount_type'] ?? 'fixed',
                                  'invoice_amount': double.tryParse(saleData['final_total'].toString()) ?? 0.0,
                                  'pending_amount': double.tryParse(saleData['final_total'].toString()) ?? 0.0,
                                  'is_quotation': saleData['is_quotation'] ?? 0,
                                  'res_table_id': effectiveResTableId,
                                  'is_shipping': apiIsShipping,
                                  'is_synced': 1, // Mark as synced since it's from API
                                };

                                // Store the sale in local database
                                localSellId = await SellDatabase().storeSell(sellMap);
                                print('Sales Edit: Created local sale with sellId: $localSellId');
                              }
                            }

                            // Extract products from API response (do this before closing dialog)
                            List<Map> products = [];
                            if (saleData['sell_lines'] != null) {
                              List sellLines = saleData['sell_lines'];
                              for (var line in sellLines) {
                                products.add({
                                  'product_id': line['product_id'],
                                  'variation_id': line['variation_id'],
                                  'quantity': line['quantity'],
                                  'unit_price': line['unit_price_before_discount'] ?? line['unit_price'],
                                  'tax_rate_id': line['tax_id'] ?? 0,
                                  'discount_amount': line['line_discount_amount'] ?? 0.0,
                                  'discount_type': line['line_discount_type'] ?? 'fixed',
                                  'note': line['sell_line_note'] ?? '',
                                });
                              }
                            }

                            // OPTIMIZED: Calculate values once
                            int apiIsShipping = saleData['is_shipping'] ?? isShipping;
                            int? effectiveResTableId = apiIsShipping == 1 ? 0 : saleData['res_table_id'];

                            // FIXED: Update ALL fields in local database with latest API data
                            // This ensures the UI shows the latest data when editing again
                            await SellDatabase().updateSells(localSellId, {
                              'res_table_id': effectiveResTableId,
                              'is_shipping': apiIsShipping,
                              'contact_id': saleData['contact_id'],
                              'transaction_date': saleData['transaction_date'],
                              'status': saleData['status'] ?? saleData['payment_status'] ?? 'draft',
                              'sale_status': saleData['status'] ?? saleData['payment_status'] ?? 'draft',
                              'tax_rate_id': saleData['tax_rate_id'] ?? saleData['tax_id'] ?? 0,
                              'discount_amount': double.tryParse(saleData['discount_amount'].toString()) ?? 0.0,
                              'discount_type': saleData['discount_type'] ?? 'fixed',
                              'invoice_amount': double.tryParse(saleData['final_total'].toString()) ?? 0.0,
                              'pending_amount': double.tryParse(saleData['final_total'].toString()) ?? 0.0,
                              'is_quotation': saleData['is_quotation'] ?? 0,
                              'invoice_no': saleData['invoice_no'] ?? 'DRAFT-$apiTransactionId',
                              'sale_note': saleData['sale_note'] ?? '',
                              'staff_note': saleData['staff_note'] ?? '',
                              'shipping_charges': double.tryParse(saleData['shipping_charges'].toString()) ?? 0.0,
                              'shipping_details': saleData['shipping_details'] ?? '',
                              'tip_amount': double.tryParse(saleData['tip_amount'].toString()) ?? 0.0,
                              'tip_type': saleData['tip_type'] ?? 'fixed',
                              'transaction_id': apiTransactionId.toString(), // Ensure transaction_id is set
                              'is_synced': 1, // Mark as synced since we fetched from API
                            });

                            print('Sales Edit: Updated local database with latest API data for sellId: $localSellId');

                            // Close loading dialog immediately - before heavy product operations
                            Navigator.pop(context);

                            // OPTIMIZED: Save products (still needed but dialog is already closed)
                            await Sell().ensureCartItemsForSalesToCheckout(
                              sellId: localSellId,
                              resTableId: effectiveResTableId,
                              isShipping: apiIsShipping,
                              products: products,
                            );

                            // Get saved products for navigation
                            List<Map> savedProducts = await Sell().getCartItems(localSellId, effectiveResTableId);
                            print('Sales Edit: Saved ${savedProducts.length} products to database with res_table_id: $effectiveResTableId, is_shipping: $apiIsShipping');

                            // Determine the tableName to pass - use 'Shipping Order' for shipping orders
                            String? finalTableName = apiIsShipping == 1 ? 'Shipping Order' : tableName;
                            print('Sales Edit: Navigating to products - is_shipping: $apiIsShipping, tableName: $finalTableName');

                            // Navigate to products screen with API data
                            // OPTIMIZED: Navigate immediately after closing dialog
                            await Navigator.pushNamed(
                              context,
                              '/products',
                              arguments: Helper().argument(
                                saleEdit: true,
                                sellId: localSellId, // Use local sellId
                                locId: saleData['location_id'],
                                res_table_id: effectiveResTableId, // Use effectiveResTableId directly
                                is_shipping: apiIsShipping,
                                isShipping: apiIsShipping == 1,
                                tableName: finalTableName,
                                products: savedProducts, // Use saved products from database
                                isQuotation: saleData['is_quotation'] ?? 0,
                                customerId: saleData['contact_id'],
                                discountType: saleData['discount_type'] ?? 'fixed',
                                discountAmount:
                                double.tryParse(saleData['discount_amount'].toString()) ?? 0.0,
                                taxId: saleData['tax_rate_id'] ?? saleData['tax_id'] ?? 0,
                                invoiceAmount:
                                double.tryParse(saleData['final_total'].toString()) ?? 0.0,
                              ),
                            );
                          } catch (e) {
                            Navigator.pop(context); // Close loading dialog if still open
                            print('Error fetching sale data from API: $e');
                            Fluttertoast.showToast(
                              msg: 'Error loading sale data. Please try again.',
                            );
                          }
                        },
                      ),
                    IconButton(
                        icon: Icon(
                          MdiIcons.printerWireless,
                          color: Colors.deepPurple,
                        ),
                        onPressed: () async {
                          // Pass invoice data from sales list for API-only sales
                          await printOption(
                            data['id'],
                            invoiceUrl: data['invoice_url'],
                            invoiceNo: data['invoice_no'],
                            taxRateId: data['tax_rate_id'],
                          );
                        }),
                    IconButton(
                        icon: Icon(
                          MdiIcons.shareVariant,
                          color: themeData.colorScheme.primary,
                        ),
                        onPressed: () async {
                          // Show loading dialog immediately
                          showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (context) {
                              return Center(
                                child: AlertDialog(
                                  content: Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.center,
                                    children: [
                                      CircularProgressIndicator(),
                                      SizedBox(width: 20),
                                      Text(
                                        AppLocalizations.of(context)
                                            .translate('loading'),
                                        style:
                                        TextStyle(color: Colors.black),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );

                          try {
                            String? invoiceContent;

                            // Try to download PDF with timeout (2 seconds) for faster response
                            if (await Helper().checkConnectivity() &&
                                data['invoice_url'] != null) {
                              try {
                                final response = await http.Client()
                                    .get(Uri.parse(data['invoice_url']))
                                    .timeout(Duration(seconds: 2));
                                if (response.statusCode == 200) {
                                  invoiceContent = response.body;
                                }
                              } catch (e) {
                                print('Error downloading PDF (will generate locally): $e');
                                // Continue without invoice content - will generate locally for faster response
                              }
                            }

                            // Share PDF (keep loading dialog visible during PDF generation)
                            // Dismiss it right before share dialog appears
                            await Helper().savePdf(
                                data['id'],
                                data['tax_rate_id'],
                                context,
                                data['invoice_no'],
                                invoice: invoiceContent,
                                onBeforeShare: () async {
                                  // Dismiss loading dialog right before sharing
                                  if (Navigator.of(context).canPop()) {
                                    Navigator.of(context).pop();
                                  }
                                });
                          } catch (e) {
                            // Dismiss loading dialog if still showing
                            if (Navigator.of(context).canPop()) {
                              Navigator.of(context).pop();
                            }
                            Fluttertoast.showToast(
                                msg: AppLocalizations.of(context)
                                    .translate('something_went_wrong'));
                          }
                        }),
                    (canEditSell &&
                        (status.toLowerCase() == 'partial' ||
                            status.toLowerCase() == 'due' ||
                            status.toLowerCase() == 'ordered' ||
                            isQuotation == 1))
                        ? IconButton(
                      icon: Icon(
                        MdiIcons.creditCardOutline,
                        color: Colors.purpleAccent,
                      ),
                      // In the checkout IconButton onPressed handler in sales.dart
                      onPressed: () async {
                        int selectedSellId = data['id'];
                        int transactionId = data['transaction_id'] ?? data['id'];
                        int? resTableId = data['res_table_id'];
                        String? tableName = data['table_name'];
                        int isShipping = data['is_shipping'] ?? 0;

                        print(
                            'Sales Checkout: Fetching sale data from API for transaction_id: $transactionId');

                        // Show loading dialog
                        showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (context) {
                            return Center(
                              child: AlertDialog(
                                content: Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.center,
                                  children: [
                                    CircularProgressIndicator(),
                                    SizedBox(width: 20),
                                    Text(
                                      AppLocalizations.of(context)
                                          .translate('loading'),
                                      style:
                                      TextStyle(color: Colors.black),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );

                        try {
                          // Check connectivity
                          if (!await Helper().checkConnectivity()) {
                            Navigator.pop(context);
                            Fluttertoast.showToast(
                              msg: AppLocalizations.of(context)
                                  .translate('check_connectivity') ??
                                  'No internet connection',
                            );
                            return;
                          }

                          // Fetch sale data from API
                          List specificSales =
                          await SellApi().getSpecifiedSells([transactionId]);

                          if (specificSales.isEmpty) {
                            Navigator.pop(context);
                            Fluttertoast.showToast(
                              msg: 'Sale not found in server',
                            );
                            return;
                          }

                          var saleData = specificSales[0];

                          // Get the transaction_id from API (this is the API's sale ID)
                          int apiTransactionId = saleData['id'];

                          // Check if this sale exists in local database by transaction_id
                          var localSell = await SellDatabase().getSellByTransactionId(apiTransactionId.toString());
                          int localSellId;

                          if (localSell.isNotEmpty) {
                            // Sale exists in local DB, use local sellId
                            localSellId = localSell[0]['id'];
                            print('Sales Checkout: Found local sale with sellId: $localSellId for transaction_id: $apiTransactionId');

                            // Update transaction_id if it wasn't set
                            if (localSell[0]['transaction_id'] == null) {
                              await SellDatabase().updateSells(localSellId, {
                                'transaction_id': apiTransactionId.toString(),
                              });
                              print('Sales Checkout: Updated transaction_id for local sale $localSellId');
                            }
                          } else {
                            // Also check by selectedSellId in case it's a local draft without transaction_id
                            var localSellById = await SellDatabase().getSellBySellId(selectedSellId);
                            if (localSellById.isNotEmpty && localSellById[0]['transaction_id'] == null) {
                              localSellId = selectedSellId;
                              // Update with transaction_id from API
                              await SellDatabase().updateSells(localSellId, {
                                'transaction_id': apiTransactionId.toString(),
                                'is_synced': 1,
                              });
                              print('Sales Checkout: Found local sale by ID $localSellId and updated transaction_id');
                            } else {
                              // Sale doesn't exist in local DB, create it
                              print('Sales Checkout: Sale not in local DB, creating local sale record for transaction_id: $apiTransactionId');

                              // Create a local sale record from API data
                              Map<String, dynamic> sellMap = {
                                'transaction_id': apiTransactionId.toString(),
                                'invoice_no': saleData['invoice_no'] ?? 'DRAFT-$apiTransactionId',
                                'contact_id': saleData['contact_id'],
                                'location_id': saleData['location_id'],
                                'transaction_date': saleData['transaction_date'],
                                'status': saleData['status'] ?? saleData['payment_status'] ?? 'draft',
                                'sale_status': saleData['status'] ?? saleData['payment_status'] ?? 'draft',
                                'tax_rate_id': saleData['tax_rate_id'] ?? saleData['tax_id'] ?? 0,
                                'discount_amount': double.tryParse(saleData['discount_amount'].toString()) ?? 0.0,
                                'discount_type': saleData['discount_type'] ?? 'fixed',
                                'invoice_amount': double.tryParse(saleData['final_total'].toString()) ?? 0.0,
                                'pending_amount': double.tryParse(saleData['final_total'].toString()) ?? 0.0,
                                'is_quotation': saleData['is_quotation'] ?? 0,
                                'res_table_id': saleData['res_table_id'],
                                'is_shipping': saleData['is_shipping'] ?? 0,
                                'is_synced': 1, // Mark as synced since it's from API
                              };

                              // Store the sale in local database
                              localSellId = await SellDatabase().storeSell(sellMap);
                              print('Sales Checkout: Created local sale with sellId: $localSellId');
                            }
                          }

                          // Clear any existing context before navigation
                          await ContextManager.clearContext();

                          // Extract products from API response
                          List<Map> cartItems = [];
                          if (saleData['sell_lines'] != null) {
                            List sellLines = saleData['sell_lines'];
                            for (var line in sellLines) {
                              cartItems.add({
                                'product_id': line['product_id'],
                                'variation_id': line['variation_id'],
                                'quantity': line['quantity'],
                                'unit_price': line['unit_price_before_discount'] ?? line['unit_price'],
                                'tax_rate_id': line['tax_id'] ?? 0,
                                'discount_amount': line['line_discount_amount'] ?? 0.0,
                                'discount_type': line['line_discount_type'] ?? 'fixed',
                                'note': line['sell_line_note'] ?? '',
                              });
                            }
                          }

                          // Calculate effective res_table_id (0 for shipping)
                          int? effectiveResTableId = isShipping == 1 ? 0 : resTableId;

                          // Ensure the sale record has the correct res_table_id and is_shipping
                          await SellDatabase().updateSells(localSellId, {
                            'res_table_id': effectiveResTableId,
                            'is_shipping': isShipping,
                          });

                          // Verify the sale record was updated correctly
                          var updatedSell = await SellDatabase().getSellBySellId(localSellId);
                          int? finalResTableId = updatedSell.isNotEmpty ? updatedSell[0]['res_table_id'] : effectiveResTableId;
                          int finalIsShipping = updatedSell.isNotEmpty ? (updatedSell[0]['is_shipping'] ?? 0) : isShipping;

                          // CRITICAL: Ensure cart items are saved to sell_lines database with correct context
                          await Sell().ensureCartItemsForSalesToCheckout(
                            sellId: localSellId, // Use local sellId
                            resTableId: finalResTableId,
                            isShipping: finalIsShipping,
                            products: cartItems,
                          );

                          // Fetch cart items after sync to ensure we have the latest data
                          List<Map> finalCartItems = await Sell()
                              .getCartItems(localSellId, finalResTableId);

                          print('Sales Checkout: Saved ${finalCartItems.length} products to database for sellId: $localSellId with res_table_id: $finalResTableId, is_shipping: $finalIsShipping');

                          Navigator.pop(context); // Close loading dialog

                          String orderType = finalIsShipping == 1
                              ? 'shipping'
                              : 'table $finalResTableId';
                          print(
                              'Sales: Navigating to checkout for $orderType with ${finalCartItems.length} cart items from API');

                          // Navigate to checkout with API data
                          // CRITICAL: Use finalResTableId and finalIsShipping from database
                          // CRITICAL: Pass all the same data fields that are passed to Product Edit screen
                          await Navigator.pushNamed(
                            context,
                            '/checkout',
                            arguments: Helper().argument(
                              invoiceAmount: double.tryParse(saleData['final_total'].toString()) ?? 0.0,
                              customerId: saleData['contact_id'],
                              locId: saleData['location_id'],
                              discountAmount: double.tryParse(saleData['discount_amount'].toString()) ?? 0.0,
                              discountType: saleData['discount_type'] ?? 'fixed',
                              isQuotation: saleData['is_quotation'] ?? 0,
                              taxId: saleData['tax_rate_id'] ?? saleData['tax_id'] ?? 0,
                              sellId: localSellId, // Use the actual sellId from local DB
                              products: finalCartItems,
                              res_table_id: finalResTableId, // Use finalResTableId from database
                              is_shipping: finalIsShipping,
                              isShipping: finalIsShipping == 1,
                              tableName: finalIsShipping == 1
                                  ? 'Shipping Order'
                                  : tableName,
                              fromSalesScreen: true,
                              saleEdit: true,
                              clearFields: true,
                              invoice_no: saleData['invoice_no'],
                              // Pass all additional sale data fields (same as Product Edit screen)
                              transaction_id: apiTransactionId.toString(),
                              status: saleData['status'] ?? saleData['payment_status'] ?? 'draft',
                              payment_status: saleData['payment_status'] ?? saleData['status'] ?? 'draft',
                              transaction_date: saleData['transaction_date'],
                              sale_note: saleData['sale_note'] ?? '',
                              staff_note: saleData['staff_note'] ?? '',
                              shipping_charges: double.tryParse(saleData['shipping_charges'].toString()) ?? 0.0,
                              shipping_details: saleData['shipping_details'] ?? '',
                              tip_amount: double.tryParse(saleData['tip_amount'].toString()) ?? 0.0,
                              tip_type: saleData['tip_type'] ?? 'fixed',
                            ),
                          ).then((_) {
                            print(
                                'Sales: Returned from checkout for $orderType');
                          });
                        } catch (e) {
                          Navigator.pop(context); // Close loading dialog if still open
                          print('Error fetching sale data from API for checkout: $e');
                          Fluttertoast.showToast(
                            msg: 'Error loading sale data. Please try again.',
                          );
                        }
                      },
                    )
                        : Container(),

                    IconButton(
                        icon: Icon(
                          Icons.call_outlined,
                          color: Colors.green,
                        ),
                        onPressed: () async {
                          // call
                          await launch('tel:${data['mobile']}');
                        }),
                    // :
                    Container()
                  ],
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  if ((isShipping == 1 ||
                      (tableName != null && tableName.isNotEmpty) ||
                      (res_table_id != null && res_table_id != 0)))
                    Container(
                      margin: EdgeInsets.only(bottom: MySize.size4!),
                      padding: EdgeInsets.symmetric(
                          horizontal: MySize.size6!, vertical: MySize.size2!),
                      decoration: BoxDecoration(
                        borderRadius:
                        BorderRadius.all(Radius.circular(MySize.size4!)),
                        color: isShipping == 1 ? Colors.green : Colors.blue,
                        border: Border.all(
                            color: isShipping == 1 ? Colors.green : Colors.blue,
                            width: 1.0),
                      ),
                      child: FutureBuilder<String?>(
                        future: isShipping == 1
                            ? Future.value('SHIPPING')
                            : (tableName != null && tableName.isNotEmpty)
                            ? Future.value(tableName)
                            : (res_table_id != null && res_table_id != 0)
                            ? Helper().getTableNameById(res_table_id)
                            : Future.value(null),
                        builder: (context, snapshot) {
                          String displayText;
                          if (isShipping == 1) {
                            displayText = 'SHIPPING';
                          } else if (snapshot.hasData &&
                              snapshot.data != null &&
                              snapshot.data!.isNotEmpty) {
                            displayText = snapshot.data!;
                          } else if (res_table_id != null &&
                              res_table_id != 0) {
                            displayText = 'TABLE $res_table_id';
                          } else {
                            displayText = 'TABLE';
                          }

                          return Text(
                            displayText,
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.caption,
                                fontSize: 9,
                                fontWeight: 700,
                                letterSpacing: 0.1,
                                color: Colors.white),
                          );
                        },
                      ),
                    ),
                  SizedBox(
                    width: 10,
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: MySize.size4!),
                    padding: EdgeInsets.symmetric(
                        horizontal: MySize.size6!, vertical: MySize.size2!),
                    decoration: BoxDecoration(
                        borderRadius:
                        BorderRadius.all(Radius.circular(MySize.size4!)),
                        color: (isQuotation == 0)
                            ? checkStatusColor(status)
                            : Colors.yellowAccent),
                    child: Text(
                      (isQuotation == 0) ? status.toUpperCase() : 'QUOTATION',
                      style: AppTheme.getTextStyle(themeData.textTheme.caption,
                          fontSize: 10, fontWeight: 700, letterSpacing: 0.1),
                    ),
                  ),
                  //   ],
                  // ),
                ],
                // ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Widget recentSellItem(
  //     {number,
  //     time,
  //     status,
  //     price,
  //     paid,
  //     isSynced,
  //     customerName,
  //     locationName,
  //     isQuotation,
  //     index,
  //     isShipping,
  //     tableName,
  //     res_table_id}) {
  //   //Logic for row items
  //   double space = MySize.size12!;
  //   return Container(
  //     padding: EdgeInsets.only(top: space, right: space, left: space),
  //     margin: EdgeInsets.only(top: MySize.size0!, bottom: space),
  //     decoration: BoxDecoration(
  //       borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
  //       color: customAppTheme.bgLayer1,
  //       border: Border.all(color: customAppTheme.bgLayer4, width: 1.2),
  //     ),
  //     child: Stack(
  //       children: [
  //         Column(
  //           crossAxisAlignment: CrossAxisAlignment.start,
  //           children: <Widget>[
  //             Text(
  //               // time,
  //               _formatDateTime(time),
  //               style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
  //                   fontWeight: 600,
  //                   letterSpacing: -0.2,
  //                   color: themeData.colorScheme.onBackground.withAlpha(160)),
  //             ),
  //             Row(
  //               crossAxisAlignment: CrossAxisAlignment.start,
  //               children: <Widget>[
  //                 Column(
  //                   crossAxisAlignment: CrossAxisAlignment.start,
  //                   children: <Widget>[
  //                     Text(
  //                       (isQuotation == 0)
  //                           ? AppLocalizations.of(context)
  //                                   .translate('invoice_no') +
  //                               " $number"
  //                           : AppLocalizations.of(context).translate('ref_no') +
  //                               " $number",
  //                       style: AppTheme.getTextStyle(
  //                           themeData.textTheme.subtitle1,
  //                           fontWeight: 700,
  //                           letterSpacing: -0.2),
  //                     ),
  //                     Text(
  //                       AppLocalizations.of(context)
  //                               .translate('invoice_amount') +
  //                           " $symbol $price",
  //                       style: AppTheme.getTextStyle(
  //                           themeData.textTheme.bodyText2,
  //                           fontWeight: 600,
  //                           letterSpacing: 0),
  //                     ),
  //                     (isQuotation == 0)
  //                         ? Text(
  //                             AppLocalizations.of(context)
  //                                     .translate('paid_amount') +
  //                                 " $symbol $paid",
  //                             style: AppTheme.getTextStyle(
  //                                 themeData.textTheme.bodyText2,
  //                                 fontWeight: 600,
  //                                 letterSpacing: 0),
  //                           )
  //                         : SizedBox(),
  //                     Text(
  //                       AppLocalizations.of(context)
  //                               .translate('customer_name') +
  //                           ": $customerName",
  //                       style: AppTheme.getTextStyle(
  //                           themeData.textTheme.bodyText2,
  //                           fontWeight: 600,
  //                           letterSpacing: 0),
  //                     ),
  //                     Text(
  //                       AppLocalizations.of(context)
  //                               .translate('location_name') +
  //                           ": $locationName",
  //                       style: AppTheme.getTextStyle(
  //                           themeData.textTheme.bodyText2,
  //                           fontWeight: 600,
  //                           letterSpacing: 0),
  //                     ),
  //                   ],
  //                 ),
  //               ],
  //             ),
  //             Visibility(
  //               visible: index != null,
  //               child: Row(
  //                 children: [
  //                   // (canEditSell)
  //                   //     ?
  //                   //     // IconButton(
  //                   //     //     icon: Icon(
  //                   //     //       MdiIcons.fileDocumentEditOutline,
  //                   //     //       color: themeData.colorScheme.onBackground,
  //                   //     //     ),
  //                   //     //     onPressed: () async {
  //                   //     //       // First ensure we have the sell details
  //                   //     //       var sellDetails = await SellDatabase().getSellBySellId(sellList[index]['id']);
  //                   //     //       if (sellDetails.isEmpty) {
  //                   //     //         Fluttertoast.showToast(msg: 'Could not load sale details');
  //                   //     //         return;
  //                   //     //       }
  //                   //     //
  //                   //     //       Navigator.pushNamed(context, '/cart',
  //                   //     //           arguments: Helper().argument(
  //                   //     //               locId: sellList[index]['location_id'],
  //                   //     //               sellId: sellList[index]['id'],
  //                   //     //               isQuotation: sellList[index]['is_quotation'],
  //                   //     //               //products: []
  //                   //     //               products: await SellDatabase().getSellLineBySellId(sellList[index]['id']),
  //                   //     //             res_table_id: sellDetails[0]['res_table_id'], // Add this line
  //                   //     //           ));
  //                   //     //     })
  //                   //(canEditSell && status.toLowerCase() != 'paid')
  //                   (canEditSell &&
  //                           (status.toLowerCase() == 'ordered' ||
  //                               isQuotation == 1))
  //                       ? IconButton(
  //                           icon: Icon(
  //                             MdiIcons.fileDocumentEditOutline,
  //                             color: themeData.colorScheme.onBackground,
  //                           ),
  //                           // onPressed: () async {
  //                           //   var sellDetails = await SellDatabase()
  //                           //       .getSellBySellId(sellList[index]['id']);
  //                           //   if (sellDetails.isEmpty) {
  //                           //     Fluttertoast.showToast(
  //                           //         msg: 'Could not load sale details');
  //                           //     return;
  //                           //   }
  //                           //
  //                           //   int sellId = sellList[index]['id'];
  //                           //   // If the sale is final and synced, re-fetch lines from API and mark as editable (is_completed: 0)
  //                           //   if (sellDetails[0]['status'] == 'final' &&
  //                           //       sellDetails[0]['is_synced'] == 1) {
  //                           //     if (await Helper().checkConnectivity()) {
  //                           //       List specificSales = await SellApi()
  //                           //           .getSpecifiedSells(
  //                           //               [sellDetails[0]['transaction_id']]);
  //                           //       if (specificSales.isNotEmpty) {
  //                           //         var element = specificSales[0];
  //                           //
  //                           //         // Delete existing lines to avoid duplicates
  //                           //         await SellDatabase()
  //                           //             .deleteSellLineBySellId(sellId);
  //                           //
  //                           //         // Store fresh lines from API with is_completed: 0 for editing
  //                           //         for (var value in element['sell_lines']) {
  //                           //           await SellDatabase().store({
  //                           //             'sell_id': sellId,
  //                           //             'product_id': value['product_id'],
  //                           //             'variation_id': value['variation_id'],
  //                           //             'quantity': value['quantity'],
  //                           //             'unit_price': value['unit_price_before_discount'],
  //                           //             'tax_rate_id': value['tax_id'],
  //                           //             'discount_amount': value['line_discount_amount'],
  //                           //             'discount_type': value['line_discount_type'],
  //                           //             'note': value['sell_line_note'],
  //                           //             'is_completed': 0, // Key change: Mark as incomplete/editable
  //                           //             'product_order_category': value['product_order_category'] ?? 'BAR', // Add if needed
  //                           //             'res_table_id': sellDetails[0]['res_table_id'],
  //                           //             'is_shipping': sellList[index]['is_shipping'],
  //                           //           });
  //                           //         }
  //                           //
  //                           //         // Update sale status to 'draft' for editing
  //                           //         await SellDatabase().updateSells(
  //                           //             sellId, {'status': 'draft'});
  //                           //
  //                           //         // Update payments or other details if needed (from API)
  //                           //         await PaymentDatabase().delete(sellId);
  //                           //         for (var payment
  //                           //             in element['payment_lines']) {
  //                           //           await PaymentDatabase().store({
  //                           //             'sell_id': sellId,
  //                           //             'method': payment['method'],
  //                           //             'amount': payment['amount'],
  //                           //             'note': payment['note'],
  //                           //             'payment_id': payment['id'],
  //                           //             'is_return': payment['is_return'],
  //                           //             'account_id': payment['account_id'],
  //                           //           });
  //                           //         }
  //                           //       } else {
  //                           //         Fluttertoast.showToast(
  //                           //             msg:
  //                           //                 'Failed to fetch sale details from server');
  //                           //         return;
  //                           //       }
  //                           //     } else {
  //                           //       Fluttertoast.showToast(
  //                           //           msg: AppLocalizations.of(context)
  //                           //               .translate('check_connectivity'));
  //                           //       return;
  //                           //     }
  //                           //   }
  //                           //
  //                           //   // Now fetch the (updated) cart items
  //                           //   List cartItems = await SellDatabase()
  //                           //       .getSellLineBySellId(sellList[index]['id']);
  //                           //   if (cartItems.isEmpty) {
  //                           //     Fluttertoast.showToast(
  //                           //         msg: 'No items found for this sale');
  //                           //     return;
  //                           //   }
  //                           //
  //                           //   // Get the table name if res_table_id exists
  //                           //   String? tableName;
  //                           //   if (sellDetails[0]['res_table_id'] != null && sellDetails[0]['res_table_id'] != 0) {
  //                           //     tableName = await Helper().getTableNameById(sellDetails[0]['res_table_id']);
  //                           //   }
  //                           //
  //                           //   Navigator.pushNamed(context, '/cart',
  //                           //       arguments: Helper().argument(
  //                           //         locId: sellList[index]['location_id'],
  //                           //         sellId: sellList[index]['id'],
  //                           //         isQuotation: sellList[index]
  //                           //             ['is_quotation'],
  //                           //         // products:
  //                           //         //     cartItems.cast<Map<dynamic, dynamic>>(),
  //                           //         // res_table_id: sellDetails[0]['res_table_id']
  //                           //         //         as int? ??
  //                           //         //     0,
  //                           //         products: await SellDatabase().getSellLineBySellId(sellList[index]['id']),
  //                           //         res_table_id: sellDetails[0]['res_table_id'], // Add this line
  //                           //         is_shipping: sellDetails[0]['is_shipping'], // Add this line
  //                           //         tableName: tableName, // Pass table name if exists
  //                           //       ));
  //                           // },
  //
  //                           // In the edit button onPressed handler
  //                           onPressed: () async {
  //                             // Get the specific sales record details
  //                             int selectedSellId = sellList[index]['id'];
  //                             int? resTableId = sellList[index]['res_table_id'];
  //                             String? tableName = sellList[index]['table_name'];
  //
  //                             // Add comprehensive debug logging
  //                             print(
  //                                 'Selected Sales → ID: $selectedSellId, Table: $tableName, res_table_id: $resTableId');
  //                             print(
  //                                 'DEBUG: Sales Record Selection - sellList[index]: ${jsonEncode(sellList[index])}');
  //
  //                             // FIXED: Clear any existing context before navigation to prevent data mixing
  //                             await ContextManager.clearContext();
  //
  //                             // Use the new helper method to ensure proper sales record isolation
  //                             var isolationResult =
  //                                 await Helper.ensureSalesRecordIsolation(
  //                               sellId: selectedSellId,
  //                               resTableId: resTableId,
  //                               tableName: tableName,
  //                             );
  //
  //                             // Check if validation failed
  //                             if (isolationResult == null ||
  //                                 !(isolationResult['isValid'] ?? false)) {
  //                               print(
  //                                   'ERROR: Sales record isolation failed: ${isolationResult?['error'] ?? 'Unknown error'}');
  //                               print(
  //                                   'DEBUG: isolationResult: ${jsonEncode(isolationResult)}');
  //
  //                               Fluttertoast.showToast(
  //                                   msg:
  //                                       'Unable to load sales data. Please try again.');
  //                               return;
  //                             }
  //
  //                             // Check if this is an API-only record (exists in sales list but not in local DB)
  //                             if (isolationResult['isApiOnly'] == true) {
  //                               print(
  //                                   'DEBUG: Handling API-only record - sellId: $selectedSellId');
  //
  //                               // // Show warning about API-only record
  //                               // if (isolationResult['warning'] != null) {
  //                               //   Fluttertoast.showToast(
  //                               //       msg: isolationResult['warning']);
  //                               // }
  //
  //                               // Navigate with API data from sales list
  //                               Navigator.pushNamed(context, '/products',
  //                                   arguments: Helper().argument(
  //                                     saleEdit: true,
  //                                     sellId: selectedSellId,
  //                                     locId: sellList[index]['location_id'],
  //                                     res_table_id: resTableId,
  //                                     is_shipping:
  //                                         sellList[index]['is_shipping'] ?? 0,
  //                                     isShipping: (sellList[index]
  //                                                 ['is_shipping'] ??
  //                                             0) ==
  //                                         1,
  //                                     tableName: tableName,
  //                                     products: [], // Empty - will be loaded from API if needed
  //                                     isQuotation: sellList[index]
  //                                         ['is_quotation'],
  //                                     customerId: sellList[index]['contact_id'],
  //                                     discountType: sellList[index]
  //                                             ['discount_type'] ??
  //                                         'fixed',
  //                                     discountAmount: sellList[index]
  //                                                 ['discount_amount']
  //                                             ?.toDouble() ??
  //                                         0.0,
  //                                     taxId:
  //                                         sellList[index]['tax_rate_id'] ?? 0,
  //                                     invoiceAmount: sellList[index]
  //                                                 ['invoice_amount']
  //                                             ?.toDouble() ??
  //                                         0.0,
  //                                   ));
  //                               return;
  //                             }
  //
  //                             // Get the validated data
  //                             var sellDetails = [isolationResult['sellRecord']];
  //                             List<Map> cartItems =
  //                                 List<Map>.from(isolationResult['cartItems']);
  //
  //                             print(
  //                                 'DEBUG: Sales record isolation successful for sellId: $selectedSellId, res_table_id: $resTableId');
  //                             print(
  //                                 'DEBUG: Retrieved sell details: ${jsonEncode(sellDetails)}');
  //                             print(
  //                                 'DEBUG: Retrieved cart items for sellId: $selectedSellId, res_table_id: $resTableId, count: ${cartItems.length}');
  //                             print(
  //                                 'DEBUG: Cart items data: ${jsonEncode(cartItems)}');
  //
  //                             // Debug context state after isolation
  //                             await ContextManager.debugContextState();
  //
  //                             // ALWAYS try to fetch from API if sale is synced to ensure fresh data
  //                             if (sellDetails[0]['is_synced'] == 1 &&
  //                                 sellDetails[0]['transaction_id'] != null) {
  //                               if (await Helper().checkConnectivity()) {
  //                                 try {
  //                                   // Show loading dialog
  //                                   showDialog(
  //                                     context: context,
  //                                     barrierDismissible: false,
  //                                     builder: (context) => Center(
  //                                       child:
  //                                           // Column(
  //                                           //   mainAxisSize: MainAxisSize.min,
  //                                           //   children: [
  //                                           //     CircularProgressIndicator(),
  //                                           //     SizedBox(height: 16),
  //                                           //     Text('Loading sale details...'),
  //                                           //   ],
  //                                           // ),
  //                                           AlertDialog(
  //                                         content: Row(
  //                                           mainAxisAlignment:
  //                                               MainAxisAlignment.center,
  //                                           children: [
  //                                             CircularProgressIndicator(),
  //                                             SizedBox(
  //                                               width: 20,
  //                                             ),
  //                                             Text(
  //                                               AppLocalizations.of(context)
  //                                                   .translate('loading'),
  //                                               style: TextStyle(
  //                                                   color: Colors.black),
  //                                             ),
  //                                           ],
  //                                         ),
  //                                       ),
  //                                     ),
  //                                   );
  //
  //                                   // Fetch sale details from API
  //                                   List specificSales = await SellApi()
  //                                       .getSpecifiedSells(
  //                                           [sellDetails[0]['transaction_id']]);
  //
  //                                   print(
  //                                       "object:::${sellList[0]['transaction_id']}");
  //                                   if (specificSales.isNotEmpty) {
  //                                     var element = specificSales[0];
  //
  //                                     // Delete existing lines to avoid duplicates
  //                                     await SellDatabase()
  //                                         .deleteSellLineBySellId(
  //                                             sellList[index]['id']);
  //
  //                                     // Store fresh lines from API with is_completed: 0 for editing
  //                                     for (var value in element['sell_lines']) {
  //                                       await SellDatabase().store({
  //                                         'sell_id': sellList[index]['id'],
  //                                         'product_id': value['product_id'],
  //                                         'variation_id': value['variation_id'],
  //                                         'quantity': value['quantity'],
  //                                         'unit_price': value[
  //                                             'unit_price_before_discount'],
  //                                         'tax_rate_id': value['tax_id'],
  //                                         'discount_amount':
  //                                             value['line_discount_amount'],
  //                                         'discount_type':
  //                                             value['line_discount_type'],
  //                                         'note': value['sell_line_note'],
  //                                         'is_completed':
  //                                             0, // Mark as incomplete/editable
  //                                         'product_order_category':
  //                                             value['product_order_category'] ??
  //                                                 'BAR',
  //                                         'res_table_id': resTableId,
  //                                         'is_shipping': sellList[index]
  //                                             ['is_shipping'],
  //                                       });
  //                                     }
  //
  //                                     // Refresh cart items with proper res_table_id
  //                                     cartItems = await SellDatabase()
  //                                         .getSellLineBySellId(
  //                                             sellList[index]['id'],
  //                                             res_table_id: resTableId,
  //                                             includeCompleted:
  //                                                 true // Include completed items for editing existing sales
  //                                             );
  //
  //                                     // Close loading dialog
  //                                     Navigator.pop(context);
  //
  //                                     Fluttertoast.showToast(
  //                                         msg: 'Sale loaded for editing');
  //                                   } else {
  //                                     Navigator.pop(context);
  //                                     Fluttertoast.showToast(
  //                                         msg:
  //                                             'Failed to fetch sale details from server');
  //                                     return;
  //                                   }
  //                                 } catch (e) {
  //                                   Navigator.pop(context);
  //                                   Fluttertoast.showToast(
  //                                       msg:
  //                                           'Error loading sale: ${e.toString()}');
  //                                   return;
  //                                 }
  //                               } else {
  //                                 Fluttertoast.showToast(
  //                                     msg: AppLocalizations.of(context)
  //                                         .translate('check_connectivity'));
  //                                 return;
  //                               }
  //                             }
  //
  //                             // Try to get saved cart data to ensure we have all the necessary information
  //                             Map<String, dynamic>? savedCartData =
  //                                 await Helper.getCartData(
  //                                     sellList[index]['id']);
  //
  //                             // Get the table name if res_table_id exists
  //                             String? finalTableName;
  //                             if (sellList[index]['res_table_id'] != null &&
  //                                 sellList[index]['res_table_id'] != 0) {
  //                               finalTableName = await Helper()
  //                                   .getTableNameById(
  //                                       sellList[index]['res_table_id']);
  //                             } else if (savedCartData != null &&
  //                                 savedCartData['tableName'] != null) {
  //                               finalTableName = savedCartData['tableName'];
  //                             }
  //
  //                             // Context is already saved by the isolation method
  //                             print(
  //                                 'Sales: Context already saved by isolation method for sellId: $selectedSellId, res_table_id: $resTableId');
  //
  //                             // Enhanced debug logging for navigation
  //                             print(
  //                                 'Sales: Navigating to products with ${cartItems.length} cart items for sellId: $selectedSellId, res_table_id: $resTableId');
  //                             print(
  //                                 'Sales: Cart items being passed: ${jsonEncode(cartItems)}');
  //                             print(
  //                                 'Sales: FIXED - Using selected sales data: sellId=$selectedSellId, res_table_id=$resTableId, is_shipping=${sellList[index]['is_shipping']}');
  //                             print(
  //                                 'Sales: Table name being passed: $finalTableName');
  //                             print(
  //                                 'Sales: Data isolation verified for sellId: $selectedSellId, res_table_id: $resTableId');
  //
  //                             // Navigator.pushNamed(context, '/cart',
  //                             Navigator.pushNamed(context, '/products',
  //                                 arguments: Helper().argument(
  //                                   saleEdit: true,
  //                                   sellId:
  //                                       selectedSellId, // Use the selected sellId
  //                                   locId: sellList[index]['location_id'],
  //                                   res_table_id:
  //                                       resTableId, // Use the selected res_table_id
  //                                   is_shipping:
  //                                       sellList[index]['is_shipping'] ?? 0,
  //                                   isShipping:
  //                                       (sellList[index]['is_shipping'] ?? 0) ==
  //                                           1,
  //                                   tableName: finalTableName,
  //                                   products: cartItems,
  //                                   isQuotation: sellList[index]
  //                                       ['is_quotation'],
  //                                   customerId: sellList[index]['contact_id'],
  //                                   discountType:
  //                                       savedCartData?['discountType'] ??
  //                                           sellDetails[0]['discount_type'] ??
  //                                           'fixed',
  //                                   discountAmount:
  //                                       savedCartData?['discountAmount']
  //                                               ?.toDouble() ??
  //                                           sellDetails[0]['discount_amount']
  //                                               ?.toDouble() ??
  //                                           0.0,
  //                                   taxId: savedCartData?['taxId'] ??
  //                                       sellDetails[0]['tax_rate_id'] ??
  //                                       0,
  //                                   invoiceAmount:
  //                                       savedCartData?['invoiceAmount']
  //                                               ?.toDouble() ??
  //                                           sellDetails[0]['invoice_amount']
  //                                               ?.toDouble() ??
  //                                           0.0,
  //                                 )).then((_) {
  //                               // Don't refresh the sales list when returning from cart/checkout
  //                               // This prevents temporary cart changes from being reflected in the Sales Screen
  //                               // The sales list will only be updated when the user actually saves the changes
  //                               // by tapping "Add Quotation" or "Update Quotation"
  //                               // sells();
  //                             });
  //                           })
  //                       : Container(),
  //                   // (canDeleteSell)
  //                   //     ? IconButton(
  //                   //     icon: Icon(
  //                   //       MdiIcons.deleteOutline,
  //                   //       color: Colors.red,
  //                   //     ),
  //                   //     onPressed: () {
  //                   //       showDialog(
  //                   //         barrierDismissible: true,
  //                   //         context: context,
  //                   //         builder: (BuildContext context) {
  //                   //           return AlertDialog(
  //                   //             title: Icon(
  //                   //               MdiIcons.alert,
  //                   //               color: Colors.red,
  //                   //               size: MySize.size50,
  //                   //             ),
  //                   //             content: Text(
  //                   //                 AppLocalizations.of(context)
  //                   //                     .translate('are_you_sure'),
  //                   //                 textAlign: TextAlign.center,
  //                   //                 style: AppTheme.getTextStyle(
  //                   //                     themeData.textTheme.bodyText1,
  //                   //                     color: themeData
  //                   //                         .colorScheme.onBackground,
  //                   //                     fontWeight: 600,
  //                   //                     muted: true)),
  //                   //             actions: <Widget>[
  //                   //               TextButton(
  //                   //                   style: TextButton.styleFrom(
  //                   //                       backgroundColor: themeData
  //                   //                           .colorScheme.onPrimary,
  //                   //                       primary: themeData
  //                   //                           .colorScheme.primary),
  //                   //                   onPressed: () {
  //                   //                     Navigator.pop(context);
  //                   //                   },
  //                   //                   child: Text(
  //                   //                       AppLocalizations.of(context)
  //                   //                           .translate('cancel'))),
  //                   //               TextButton(
  //                   //                   style: TextButton.styleFrom(
  //                   //                       backgroundColor: Colors.red,
  //                   //                       primary: themeData
  //                   //                           .colorScheme.onError),
  //                   //                   onPressed: () async {
  //                   //                     Navigator.pop(context);
  //                   //                     // await SellDatabase().deleteSell(sellList[index]['id']);
  //                   //                     // await SellApi().delete(sellList[index]['transaction_id']);
  //                   //                     // sells();
  //                   //                     await _deleteSale(sellList[index]);
  //                   //                   },
  //                   //                   child: Text(
  //                   //                       AppLocalizations.of(context)
  //                   //                           .translate('ok')))
  //                   //             ],
  //                   //           );
  //                   //         },
  //                   //       );
  //                   //     })
  //                   //     : Container(),
  //                   IconButton(
  //                       icon: Icon(
  //                         MdiIcons.printerWireless,
  //                         color: Colors.deepPurple,
  //                       ),
  //                       onPressed: () async {
  //                         if (await Helper().checkConnectivity() &&
  //                             sellList[index]['invoice_url'] != null) {
  //                           final response = await http.Client()
  //                               .get(Uri.parse(sellList[index]['invoice_url']));
  //                           if (response.statusCode == 200) {
  //                             await Helper().printDocument(
  //                                 sellList[index]['id'],
  //                                 sellList[index]['tax_rate_id'],
  //                                 context,
  //                                 invoice: response.body);
  //                           } else {
  //                             await Helper().printDocument(
  //                                 sellList[index]['id'],
  //                                 sellList[index]['tax_rate_id'],
  //                                 context);
  //                           }
  //                         } else {
  //                           await Helper().printDocument(sellList[index]['id'],
  //                               sellList[index]['tax_rate_id'], context);
  //                         }
  //                       }),
  //                   IconButton(
  //                       icon: Icon(
  //                         MdiIcons.shareVariant,
  //                         color: themeData.colorScheme.primary,
  //                       ),
  //                       onPressed: () async {
  //                         if (await Helper().checkConnectivity() &&
  //                             sellList[index]['invoice_url'] != null) {
  //                           final response = await http.Client()
  //                               .get(Uri.parse(sellList[index]['invoice_url']));
  //                           if (response.statusCode == 200) {
  //                             await Helper().savePdf(
  //                                 sellList[index]['id'],
  //                                 sellList[index]['tax_rate_id'],
  //                                 context,
  //                                 sellList[index]['invoice_no'],
  //                                 invoice: response.body);
  //                           } else {
  //                             await Helper().savePdf(
  //                                 sellList[index]['id'],
  //                                 sellList[index]['tax_rate_id'],
  //                                 context,
  //                                 sellList[index]['invoice_no']);
  //                           }
  //                         } else {
  //                           await Helper().savePdf(
  //                               sellList[index]['id'],
  //                               sellList[index]['tax_rate_id'],
  //                               context,
  //                               sellList[index]['invoice_no']);
  //                         }
  //                       }),
  //                   // Only show payment button for bills that are not fully paid
  //                   // (status.toLowerCase() != 'paid' && isQuotation == 0 && status.toLowerCase() != 'ordered')
  //                   // Show checkout button for all orders (same as edit button logic)
  //                   (canEditSell &&
  //                           (status.toLowerCase() == 'partial' ||
  //                               status.toLowerCase() == 'due' ||
  //                               status.toLowerCase() == 'ordered' ||
  //                               isQuotation == 1))
  //                       // ? IconButton(
  //                       //     icon: Icon(
  //                       //       MdiIcons.creditCardOutline,
  //                       //       color: Colors.purpleAccent,
  //                       //     ),
  //                       //     // onPressed: () {
  //                       //     onPressed: () async {
  //                       //       // Get the specific sales record details
  //                       //       int selectedSellId = sellList[index]['id'];
  //                       //       int? resTableId = sellList[index]['res_table_id'];
  //                       //       String? tableName = sellList[index]['table_name'];
  //                       //
  //                       //       // Add comprehensive debug logging
  //                       //       print(
  //                       //           'Selected Sales → ID: $selectedSellId, Table: $tableName, res_table_id: $resTableId');
  //                       //       print(
  //                       //           'DEBUG: Sales Record Selection - sellList[index]: ${jsonEncode(sellList[index])}');
  //                       //
  //                       //       // Use the new helper method to ensure proper sales record isolation
  //                       //       var isolationResult =
  //                       //           await Helper.ensureSalesRecordIsolation(
  //                       //         sellId: selectedSellId,
  //                       //         resTableId: resTableId,
  //                       //         tableName: tableName,
  //                       //       );
  //                       //
  //                       //       if (!isolationResult['success']) {
  //                       //         print(
  //                       //             'ERROR: Sales record isolation failed: ${isolationResult['error']}');
  //                       //         Fluttertoast.showToast(
  //                       //             msg:
  //                       //                 'Failed to isolate sales record: ${isolationResult['error']}');
  //                       //         return;
  //                       //       }
  //                       //
  //                       //       // Get the validated data
  //                       //       var sellDetails = [isolationResult['sellRecord']];
  //                       //       List<Map> cartItems =
  //                       //           List<Map>.from(isolationResult['cartItems']);
  //                       //
  //                       //       print(
  //                       //           'DEBUG: Sales record isolation successful for sellId: $selectedSellId, res_table_id: $resTableId');
  //                       //       print(
  //                       //           'DEBUG: Retrieved sell details: ${jsonEncode(sellDetails)}');
  //                       //       print(
  //                       //           'DEBUG: Retrieved cart items for sellId: $selectedSellId, res_table_id: $resTableId, count: ${cartItems.length}');
  //                       //       print(
  //                       //           'DEBUG: Cart items data: ${jsonEncode(cartItems)}');
  //                       //
  //                       //       // Debug context state after isolation
  //                       //       await ContextManager.debugContextState();
  //                       //
  //                       //       // ALWAYS try to fetch from API if sale is synced to ensure fresh data
  //                       //       if (sellDetails[0]['is_synced'] == 1 &&
  //                       //           sellDetails[0]['transaction_id'] != null) {
  //                       //         if (await Helper().checkConnectivity()) {
  //                       //           try {
  //                       //             // Show loading dialog
  //                       //             showDialog(
  //                       //               context: context,
  //                       //               barrierDismissible: false,
  //                       //               builder: (context) => Center(
  //                       //                 child: AlertDialog(
  //                       //                   content: Row(
  //                       //                     mainAxisAlignment:
  //                       //                         MainAxisAlignment.center,
  //                       //                     children: [
  //                       //                       CircularProgressIndicator(),
  //                       //                       SizedBox(
  //                       //                         width: 20,
  //                       //                       ),
  //                       //                       Text(
  //                       //                         AppLocalizations.of(context)
  //                       //                             .translate('loading'),
  //                       //                         style: TextStyle(
  //                       //                             color: Colors.black),
  //                       //                       ),
  //                       //                     ],
  //                       //                   ),
  //                       //                 ),
  //                       //               ),
  //                       //             );
  //                       //
  //                       //             // Fetch sale details from API
  //                       //             List specificSales = await SellApi()
  //                       //                 .getSpecifiedSells(
  //                       //                     [sellDetails[0]['transaction_id']]);
  //                       //
  //                       //             print(
  //                       //                 "object:::${sellList[0]['transaction_id']}");
  //                       //             if (specificSales.isNotEmpty) {
  //                       //               var element = specificSales[0];
  //                       //
  //                       //               // Delete existing lines to avoid duplicates
  //                       //               await SellDatabase()
  //                       //                   .deleteSellLineBySellId(
  //                       //                       sellList[index]['id']);
  //                       //
  //                       //               // Store fresh lines from API with is_completed: 0 for editing
  //                       //               for (var value in element['sell_lines']) {
  //                       //                 await SellDatabase().store({
  //                       //                   'sell_id': sellList[index]['id'],
  //                       //                   'product_id': value['product_id'],
  //                       //                   'variation_id': value['variation_id'],
  //                       //                   'quantity': value['quantity'],
  //                       //                   'unit_price': value[
  //                       //                       'unit_price_before_discount'],
  //                       //                   'tax_rate_id': value['tax_id'],
  //                       //                   'discount_amount':
  //                       //                       value['line_discount_amount'],
  //                       //                   'discount_type':
  //                       //                       value['line_discount_type'],
  //                       //                   'note': value['sell_line_note'],
  //                       //                   'is_completed':
  //                       //                       0, // Mark as incomplete/editable
  //                       //                   'product_order_category':
  //                       //                       value['product_order_category'] ??
  //                       //                           'BAR',
  //                       //                   'res_table_id': resTableId,
  //                       //                   'is_shipping': sellList[index]
  //                       //                       ['is_shipping'],
  //                       //                 });
  //                       //               }
  //                       //
  //                       //               // Refresh cart items with proper res_table_id
  //                       //               cartItems = await SellDatabase()
  //                       //                   .getSellLineBySellId(
  //                       //                       sellList[index]['id'],
  //                       //                       res_table_id: resTableId,
  //                       //                       includeCompleted:
  //                       //                           true // Include completed items for editing existing sales
  //                       //                       );
  //                       //
  //                       //               // Close loading dialog
  //                       //               Navigator.pop(context);
  //                       //
  //                       //               Fluttertoast.showToast(
  //                       //                   msg: 'Sale loaded for checkout');
  //                       //             } else {
  //                       //               Navigator.pop(context);
  //                       //               Fluttertoast.showToast(
  //                       //                   msg:
  //                       //                       'Failed to fetch sale details from server');
  //                       //               return;
  //                       //             }
  //                       //           } catch (e) {
  //                       //             Navigator.pop(context);
  //                       //             Fluttertoast.showToast(
  //                       //                 msg:
  //                       //                     'Error loading sale: ${e.toString()}');
  //                       //             return;
  //                       //           }
  //                       //         } else {
  //                       //           Fluttertoast.showToast(
  //                       //               msg: AppLocalizations.of(context)
  //                       //                   .translate('check_connectivity'));
  //                       //           return;
  //                       //         }
  //                       //       }
  //                       //
  //                       //       // Try to get saved cart data to ensure we have all the necessary information
  //                       //       Map<String, dynamic>? savedCartData =
  //                       //           await Helper.getCartData(
  //                       //               sellList[index]['id']);
  //                       //
  //                       //       // Get the table name if res_table_id exists
  //                       //       String? finalTableName;
  //                       //       if (sellList[index]['res_table_id'] != null &&
  //                       //           sellList[index]['res_table_id'] != 0) {
  //                       //         finalTableName = await Helper()
  //                       //             .getTableNameById(
  //                       //                 sellList[index]['res_table_id']);
  //                       //       } else if (savedCartData != null &&
  //                       //           savedCartData['tableName'] != null) {
  //                       //         finalTableName = savedCartData['tableName'];
  //                       //       }
  //                       //
  //                       //       // Context is already saved by the isolation method
  //                       //       print(
  //                       //           'Sales: Context already saved by isolation method for sellId: $selectedSellId, res_table_id: $resTableId');
  //                       //
  //                       //       // Enhanced debug logging for navigation
  //                       //       print(
  //                       //           'Sales: Navigating to checkout with ${cartItems.length} cart items for sellId: $selectedSellId, res_table_id: $resTableId');
  //                       //       print(
  //                       //           'Sales: Cart items being passed: ${jsonEncode(cartItems)}');
  //                       //       print(
  //                       //           'Sales: FIXED - Using selected sales data: sellId=$selectedSellId, res_table_id=$resTableId, is_shipping=${sellList[index]['is_shipping']}');
  //                       //       print(
  //                       //           'Sales: Table name being passed: $finalTableName');
  //                       //       print(
  //                       //           'Sales: Data isolation verified for sellId: $selectedSellId, res_table_id: $resTableId');
  //                       //
  //                       //       Navigator.pushNamed(context, '/checkout',
  //                       //           arguments: Helper().argument(
  //                       //             invoiceAmount: sellList[index]
  //                       //                 ['invoice_amount'],
  //                       //             customerId: sellList[index]['contact_id'],
  //                       //             locId: sellList[index]['location_id'],
  //                       //             discountAmount: sellList[index]
  //                       //                 ['discount_amount'],
  //                       //             discountType: sellList[index]
  //                       //                 ['discount_type'],
  //                       //             isQuotation: sellList[index]
  //                       //                 ['is_quotation'],
  //                       //             taxId: sellList[index]['tax_rate_id'],
  //                       //             sellId:
  //                       //                 selectedSellId, // Use the selected sellId
  //                       //             products: cartItems,
  //                       //             res_table_id:
  //                       //                 resTableId, // Use the selected res_table_id
  //                       //             is_shipping:
  //                       //                 sellList[index]['is_shipping'] ?? 0,
  //                       //             isShipping:
  //                       //                 (sellList[index]['is_shipping'] ?? 0) ==
  //                       //                     1,
  //                       //             tableName: finalTableName,
  //                       //             fromSalesScreen: true,
  //                       //             saleEdit: true,
  //                       //             clearFields:
  //                       //                 true, // Add flag to clear fields
  //                       //           )).then((_) {
  //                       //         // Don't refresh the sales list when returning from checkout
  //                       //         // This prevents temporary cart changes from being reflected in the Sales Screen
  //                       //         print(
  //                       //             'Sales: Returned from checkout, maintaining current state');
  //                       //       });
  //                       //     })
  //                       ? IconButton(
  //                           icon: Icon(
  //                             MdiIcons.creditCardOutline,
  //                             color: Colors.purpleAccent,
  //                           ),
  //                           // // onPressed: () async {
  //                           // //   int selectedSellId = sellList[index]['id'];
  //                           // //   int? resTableId = sellList[index]['res_table_id'];
  //                           // //   String? tableName = sellList[index]['table_name'];
  //                           // //
  //                           // //   print('Selected Sales → ID: $selectedSellId, Table: $tableName, res_table_id: $resTableId');
  //                           // //   print('DEBUG: Sales Record Selection - sellList[index]: ${jsonEncode(sellList[index])}');
  //                           // //
  //                           // //   // FIXED: Clear any existing context before navigation to prevent data mixing
  //                           // //   await ContextManager.clearContext();
  //                           // //
  //                           // //   // STEP 1: Isolate sales record
  //                           // //   var isolationResult = await Helper.ensureSalesRecordIsolation(
  //                           // //     sellId: selectedSellId,
  //                           // //     resTableId: resTableId,
  //                           // //     tableName: tableName,
  //                           // //   );
  //                           // //
  //                           // //   // Check if validation failed
  //                           // //   if (isolationResult == null || !(isolationResult['isValid'] ?? false)) {
  //                           // //     print('ERROR: Sales record isolation failed for checkout: ${isolationResult?['error'] ?? 'Unknown error'}');
  //                           // //     print('DEBUG: isolationResult: ${jsonEncode(isolationResult)}');
  //                           // //
  //                           // //     Fluttertoast.showToast(
  //                           // //       msg: 'Unable to load sales data for checkout. Please try again.',
  //                           // //     );
  //                           // //     return;
  //                           // //   }
  //                           // //
  //                           // //   // Check if this is an API-only record (exists in sales list but not in local DB)
  //                           // //   if (isolationResult['isApiOnly'] == true) {
  //                           // //     print('DEBUG: Handling API-only record for checkout - sellId: $selectedSellId');
  //                           // //
  //                           // //     // Show warning about API-only record
  //                           // //     if (isolationResult['warning'] != null) {
  //                           // //       Fluttertoast.showToast(
  //                           // //           msg: isolationResult['warning']);
  //                           // //     }
  //                           // //
  //                           // //     // Navigate to checkout with API data from sales list
  //                           // //     Navigator.pushNamed(
  //                           // //       context,
  //                           // //       '/checkout',
  //                           // //       arguments: Helper().argument(
  //                           // //         invoiceAmount: sellList[index]['invoice_amount'],
  //                           // //         customerId: sellList[index]['contact_id'],
  //                           // //         locId: sellList[index]['location_id'],
  //                           // //         discountAmount: sellList[index]['discount_amount'],
  //                           // //         discountType: sellList[index]['discount_type'],
  //                           // //         isQuotation: sellList[index]['is_quotation'],
  //                           // //         taxId: sellList[index]['tax_rate_id'],
  //                           // //         sellId: selectedSellId,
  //                           // //         products: [], // Empty - will be loaded from API if needed
  //                           // //         res_table_id: resTableId,
  //                           // //         is_shipping: sellList[index]['is_shipping'] ?? 0,
  //                           // //         isShipping: (sellList[index]['is_shipping'] ?? 0) == 1,
  //                           // //         tableName: tableName,
  //                           // //         fromSalesScreen: true,
  //                           // //         saleEdit: true,
  //                           // //         clearFields: true,
  //                           // //
  //                           // //       ),
  //                           // //     );
  //                           // //     return;
  //                           // //   }
  //                           // //
  //                           // //   // STEP 2: Show loading dialog while fetching cart
  //                           // //   showDialog(
  //                           // //     context: context,
  //                           // //     barrierDismissible: false,
  //                           // //     builder: (context) {
  //                           // //       return Center(
  //                           // //         child: AlertDialog(
  //                           // //           content: Row(
  //                           // //             mainAxisAlignment: MainAxisAlignment.center,
  //                           // //             children: [
  //                           // //               CircularProgressIndicator(),
  //                           // //               SizedBox(width: 20),
  //                           // //               Text(
  //                           // //                 AppLocalizations.of(context).translate('loading'),
  //                           // //                 style: TextStyle(color: Colors.black),
  //                           // //               ),
  //                           // //             ],
  //                           // //           ),
  //                           // //         ),
  //                           // //       );
  //                           // //     },
  //                           // //   );
  //                           // //
  //                           // //   try {
  //                           // //     // STEP 3: Sync cart data before navigation (same logic as Product screen)
  //                           // //     await _syncCartDataForCheckout(selectedSellId, resTableId);
  //                           // //
  //                           // //     // STEP 4: Fetch cart items after sync
  //                           // //     List<Map> cartItems = await Sell().getCartItems(selectedSellId, resTableId);
  //                           // //
  //                           // //     Navigator.pop(context); // Close the loading dialog properly
  //                           // //
  //                           // //     print('Sales: Navigating to checkout with invoiceAmount: ${sellList[index]['invoice_amount']}, cartItems: $cartItems');
  //                           // //
  //                           // //     // STEP 4: Navigate normally — so back works as expected
  //                           // //     Navigator.pushNamed(
  //                           // //       context,
  //                           // //       '/checkout',
  //                           // //       arguments: Helper().argument(
  //                           // //         invoiceAmount: sellList[index]['invoice_amount'],
  //                           // //         customerId: sellList[index]['contact_id'],
  //                           // //         locId: sellList[index]['location_id'],
  //                           // //         discountAmount: sellList[index]['discount_amount'],
  //                           // //         discountType: sellList[index]['discount_type'],
  //                           // //         isQuotation: sellList[index]['is_quotation'],
  //                           // //         taxId: sellList[index]['tax_rate_id'],
  //                           // //         sellId: selectedSellId,
  //                           // //         products: cartItems,
  //                           // //         res_table_id: resTableId,
  //                           // //         is_shipping: sellList[index]['is_shipping'] ?? 0,
  //                           // //         isShipping: (sellList[index]['is_shipping'] ?? 0) == 1,
  //                           // //         tableName: tableName,
  //                           // //         fromSalesScreen: true,
  //                           // //         saleEdit: true,
  //                           // //         clearFields: true,
  //                           // //       ),
  //                           // //     ).then((_) {
  //                           // //       print('Sales: Returned from checkout, maintaining current state');
  //                           // //     });
  //                           // //   } catch (e) {
  //                           // //     Navigator.pop(context); // Ensure dialog closes if error occurs
  //                           // //     Fluttertoast.showToast(
  //                           // //       msg: AppLocalizations.of(context).translate('error_fetching_cart'),
  //                           // //     );
  //                           // //     print('ERROR fetching cart items: $e');
  //                           // //   }
  //                           // // },
  //                           //
  //                           //
  //                           // // In the checkout IconButton onPressed handler in sales.dart
  //                           // onPressed: () async {
  //                           //   int selectedSellId = sellList[index]['id'];
  //                           //   int? resTableId = sellList[index]['res_table_id'];
  //                           //   String? tableName = sellList[index]['table_name'];
  //                           //   int isShipping = sellList[index]['is_shipping'] ?? 0;
  //                           //
  //                           //   print('Selected Sales → ID: $selectedSellId, Table: $resTableId, TableName: $tableName, is_shipping: $isShipping');
  //                           //
  //                           //   // STEP 1: Clear any existing context and use table-specific context
  //                           //   await ContextManager.clearTableContext(resTableId, isShipping);
  //                           //
  //                           //   // STEP 2: Save table-specific context immediately
  //                           //   await ContextManager.saveContext(
  //                           //     sellId: selectedSellId,
  //                           //     resTableId: resTableId,
  //                           //     isShipping: isShipping,
  //                           //     tableName: tableName,
  //                           //     locationId: sellList[index]['location_id'],
  //                           //   );
  //                           //
  //                           //   // STEP 3: Isolate sales record with table-specific context
  //                           //   var isolationResult = await Helper.ensureSalesRecordIsolation(
  //                           //     sellId: selectedSellId,
  //                           //     resTableId: resTableId,
  //                           //     tableName: tableName,
  //                           //   );
  //                           //
  //                           //   // Check if validation failed
  //                           //   if (isolationResult == null || !(isolationResult['isValid'] ?? false)) {
  //                           //     print('ERROR: Sales record isolation failed for checkout: ${isolationResult?['error'] ?? 'Unknown error'}');
  //                           //
  //                           //     Fluttertoast.showToast(
  //                           //       msg: 'Unable to load sales data for checkout. Please try again.',
  //                           //     );
  //                           //     return;
  //                           //   }
  //                           //
  //                           //   // STEP 4: Ensure cart items are saved to sell_lines for Sales → Checkout navigation
  //                           //   List<Map> cartItems = [];
  //                           //
  //                           //   if (isolationResult['isApiOnly'] == true) {
  //                           //     print('DEBUG: Handling API-only record for checkout - sellId: $selectedSellId');
  //                           //
  //                           //     // For API-only records, use products from sales list
  //                           //     if (sellList[index]['products'] != null) {
  //                           //       List<dynamic> products = sellList[index]['products'];
  //                           //       if (products.isNotEmpty) {
  //                           //         cartItems = products.cast<Map>();
  //                           //       }
  //                           //     }
  //                           //
  //                           //     // Show warning about API-only record
  //                           //     if (isolationResult['warning'] != null) {
  //                           //       Fluttertoast.showToast(msg: isolationResult['warning']);
  //                           //     }
  //                           //   } else {
  //                           //     // For local records, use the cart items from isolation result
  //                           //     List<dynamic> isolationCartItems = isolationResult['cartItems'];
  //                           //     cartItems = isolationCartItems.cast<Map>();
  //                           //   }
  //                           //
  //                           //   // STEP 5: Ensure cart items are saved to sell_lines database with correct table context
  //                           //   await Sell().ensureCartItemsForSalesToCheckout(
  //                           //     sellId: selectedSellId,
  //                           //     resTableId: resTableId,
  //                           //     isShipping: isShipping,
  //                           //     products: cartItems,
  //                           //   );
  //                           //
  //                           //   // STEP 6: Show loading dialog while preparing data
  //                           //   showDialog(
  //                           //     context: context,
  //                           //     barrierDismissible: false,
  //                           //     builder: (context) {
  //                           //       return Center(
  //                           //         child: AlertDialog(
  //                           //           content: Row(
  //                           //             mainAxisAlignment: MainAxisAlignment.center,
  //                           //             children: [
  //                           //               CircularProgressIndicator(),
  //                           //               SizedBox(width: 20),
  //                           //               Text(
  //                           //                 AppLocalizations.of(context).translate('loading'),
  //                           //                 style: TextStyle(color: Colors.black),
  //                           //               ),
  //                           //             ],
  //                           //           ),
  //                           //         ),
  //                           //       );
  //                           //     },
  //                           //   );
  //                           //
  //                           //   try {
  //                           //     // STEP 7: Sync cart data before navigation with correct table context
  //                           //     await _syncCartDataForCheckout(selectedSellId, resTableId);
  //                           //
  //                           //     // STEP 8: Fetch cart items after sync to ensure we have the latest data
  //                           //     List<Map> finalCartItems = await Sell().getCartItems(selectedSellId, resTableId);
  //                           //
  //                           //     Navigator.pop(context); // Close the loading dialog properly
  //                           //
  //                           //     print('Sales: Navigating to checkout for table $resTableId with ${finalCartItems.length} cart items');
  //                           //
  //                           //     // STEP 9: Navigate to checkout with table-specific context
  //                           //     Navigator.pushNamed(
  //                           //       context,
  //                           //       '/checkout',
  //                           //       arguments: Helper().argument(
  //                           //         invoiceAmount: sellList[index]['invoice_amount'],
  //                           //         customerId: sellList[index]['contact_id'],
  //                           //         locId: sellList[index]['location_id'],
  //                           //         discountAmount: sellList[index]['discount_amount'],
  //                           //         discountType: sellList[index]['discount_type'],
  //                           //         isQuotation: sellList[index]['is_quotation'],
  //                           //         taxId: sellList[index]['tax_rate_id'],
  //                           //         sellId: selectedSellId,
  //                           //         products: finalCartItems,
  //                           //         res_table_id: resTableId,
  //                           //         is_shipping: isShipping,
  //                           //         isShipping: isShipping == 1,
  //                           //         tableName: tableName,
  //                           //         fromSalesScreen: true,
  //                           //         saleEdit: true,
  //                           //         clearFields: true,
  //                           //       ),
  //                           //     ).then((_) {
  //                           //       print('Sales: Returned from checkout for table $resTableId');
  //                           //     });
  //                           //   } catch (e) {
  //                           //     Navigator.pop(context); // Ensure dialog closes if error occurs
  //                           //     Fluttertoast.showToast(
  //                           //       msg: AppLocalizations.of(context).translate('error_fetching_cart'),
  //                           //     );
  //                           //     print('ERROR fetching cart items for table $resTableId: $e');
  //                           //   }
  //                           // },
  //
  //                           // In the checkout IconButton onPressed handler in sales.dart
  //                           onPressed: () async {
  //                             int selectedSellId = sellList[index]['id'];
  //                             int? resTableId = sellList[index]['res_table_id'];
  //                             String? tableName = sellList[index]['table_name'];
  //                             int isShipping =
  //                                 sellList[index]['is_shipping'] ?? 0;
  //
  //                             print(
  //                                 'Selected Sales → ID: $selectedSellId, Table: $resTableId, TableName: $tableName, is_shipping: $isShipping');
  //
  //                             // STEP 1: Clear any existing context and use specific context based on order type
  //                             if (isShipping == 1) {
  //                               await ContextManager.clearShippingContext();
  //                             } else {
  //                               await ContextManager.clearTableContext(
  //                                   resTableId, isShipping);
  //                             }
  //
  //                             // STEP 2: Save specific context immediately based on order type
  //                             if (isShipping == 1) {
  //                               await ContextManager.saveShippingContext(
  //                                 sellId: selectedSellId,
  //                                 locationId: sellList[index]['location_id'],
  //                               );
  //                             } else {
  //                               await ContextManager.saveContext(
  //                                 sellId: selectedSellId,
  //                                 resTableId: resTableId,
  //                                 isShipping: isShipping,
  //                                 tableName: tableName,
  //                                 locationId: sellList[index]['location_id'],
  //                               );
  //                             }
  //
  //                             // STEP 3: Isolate sales record with specific context
  //                             var isolationResult =
  //                                 await Helper.ensureSalesRecordIsolation(
  //                               sellId: selectedSellId,
  //                               resTableId: resTableId,
  //                               tableName: tableName,
  //                             );
  //
  //                             // Check if validation failed
  //                             if (isolationResult == null ||
  //                                 !(isolationResult['isValid'] ?? false)) {
  //                               print(
  //                                   'ERROR: Sales record isolation failed for checkout: ${isolationResult?['error'] ?? 'Unknown error'}');
  //
  //                               Fluttertoast.showToast(
  //                                 msg:
  //                                     'Unable to load sales data for checkout. Please try again.',
  //                               );
  //                               return;
  //                             }
  //
  //                             // STEP 4: Ensure cart items are saved to sell_lines for Sales → Checkout navigation
  //                             List<Map> cartItems = [];
  //
  //                             if (isolationResult['isApiOnly'] == true) {
  //                               print(
  //                                   'DEBUG: Handling API-only record for checkout - sellId: $selectedSellId');
  //
  //                               // For API-only records, use products from sales list
  //                               if (sellList[index]['products'] != null) {
  //                                 List<dynamic> products =
  //                                     sellList[index]['products'];
  //                                 if (products.isNotEmpty) {
  //                                   cartItems = products.cast<Map>();
  //                                 }
  //                               }
  //
  //                               // Show warning about API-only record
  //                               if (isolationResult['warning'] != null) {
  //                                 Fluttertoast.showToast(
  //                                     msg: isolationResult['warning']);
  //                               }
  //                             } else {
  //                               // For local records, use the cart items from isolation result
  //                               List<dynamic> isolationCartItems =
  //                                   isolationResult['cartItems'];
  //                               cartItems = isolationCartItems.cast<Map>();
  //                             }
  //
  //                             // STEP 5: Ensure cart items are saved to sell_lines database with correct context
  //                             await Sell().ensureCartItemsForSalesToCheckout(
  //                               sellId: selectedSellId,
  //                               resTableId: isShipping == 1
  //                                   ? 0
  //                                   : resTableId, // Shipping orders use res_table_id = 0
  //                               isShipping: isShipping,
  //                               products: cartItems,
  //                             );
  //
  //                             // STEP 6: Show loading dialog while preparing data
  //                             showDialog(
  //                               context: context,
  //                               barrierDismissible: false,
  //                               builder: (context) {
  //                                 return Center(
  //                                   child: AlertDialog(
  //                                     content: Row(
  //                                       mainAxisAlignment:
  //                                           MainAxisAlignment.center,
  //                                       children: [
  //                                         CircularProgressIndicator(),
  //                                         SizedBox(width: 20),
  //                                         Text(
  //                                           AppLocalizations.of(context)
  //                                               .translate('loading'),
  //                                           style:
  //                                               TextStyle(color: Colors.black),
  //                                         ),
  //                                       ],
  //                                     ),
  //                                   ),
  //                                 );
  //                               },
  //                             );
  //
  //                             try {
  //                               // STEP 7: Sync cart data before navigation with correct context
  //                               int? effectiveResTableId =
  //                                   isShipping == 1 ? 0 : resTableId;
  //                               await _syncCartDataForCheckout(
  //                                   selectedSellId, effectiveResTableId);
  //
  //                               // STEP 8: Fetch cart items after sync to ensure we have the latest data
  //                               List<Map> finalCartItems = await Sell()
  //                                   .getCartItems(
  //                                       selectedSellId, effectiveResTableId);
  //
  //                               Navigator.pop(
  //                                   context); // Close the loading dialog properly
  //
  //                               String orderType = isShipping == 1
  //                                   ? 'shipping'
  //                                   : 'table $resTableId';
  //                               print(
  //                                   'Sales: Navigating to checkout for $orderType with ${finalCartItems.length} cart items');
  //
  //                               // STEP 9: Navigate to checkout with specific context
  //                               Navigator.pushNamed(
  //                                 context,
  //                                 '/checkout',
  //                                 arguments: Helper().argument(
  //                                   invoiceAmount: sellList[index]
  //                                       ['invoice_amount'],
  //                                   customerId: sellList[index]['contact_id'],
  //                                   locId: sellList[index]['location_id'],
  //                                   discountAmount: sellList[index]
  //                                       ['discount_amount'],
  //                                   discountType: sellList[index]
  //                                       ['discount_type'],
  //                                   isQuotation: sellList[index]
  //                                       ['is_quotation'],
  //                                   taxId: sellList[index]['tax_rate_id'],
  //                                   sellId: selectedSellId,
  //                                   products: finalCartItems,
  //                                   res_table_id:
  //                                       effectiveResTableId, // Use 0 for shipping
  //                                   is_shipping: isShipping,
  //                                   isShipping: isShipping == 1,
  //                                   tableName: isShipping == 1
  //                                       ? 'Shipping Order'
  //                                       : tableName,
  //                                   fromSalesScreen: true,
  //                                   saleEdit: true,
  //                                   clearFields: true,
  //                                   invoice_no: sellList[index][
  //                                       'invoice_no'], // Pass original invoice number
  //                                 ),
  //                               ).then((_) {
  //                                 print(
  //                                     'Sales: Returned from checkout for $orderType');
  //                               });
  //                             } catch (e) {
  //                               Navigator.pop(
  //                                   context); // Ensure dialog closes if error occurs
  //                               Fluttertoast.showToast(
  //                                 msg: AppLocalizations.of(context)
  //                                     .translate('error_fetching_cart'),
  //                               );
  //                               String orderType = isShipping == 1
  //                                   ? 'shipping'
  //                                   : 'table $resTableId';
  //                               print(
  //                                   'ERROR fetching cart items for $orderType: $e');
  //                             }
  //                           },
  //                         )
  //                       : Container(),
  //                   // (((sellList[index]['pending_amount'] > 0) && canEditSell) &&
  //                   //         (sellList[index]['mobile'] != null))
  //                   //     ?
  //                   IconButton(
  //                       icon: Icon(
  //                         Icons.call_outlined,
  //                         color: Colors.green,
  //                       ),
  //                       onPressed: () async {
  //                         // call
  //                         await launch('tel:${sellList[index]['mobile']}');
  //                       }),
  //                   // :
  //                   Container()
  //                 ],
  //               ),
  //             ),
  //           ],
  //         ),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.end,
  //           children: [
  //             Row(
  //               mainAxisAlignment: MainAxisAlignment.center,
  //               children: <Widget>[
  //                 // Shipping/Table name container
  //                 if ((isShipping == 1 ||
  //                     (tableName != null && tableName.isNotEmpty) ||
  //                     (res_table_id != null && res_table_id != 0)))
  //                   Container(
  //                     margin: EdgeInsets.only(bottom: MySize.size4!),
  //                     padding: EdgeInsets.symmetric(
  //                         horizontal: MySize.size6!, vertical: MySize.size2!),
  //                     decoration: BoxDecoration(
  //                       borderRadius:
  //                           BorderRadius.all(Radius.circular(MySize.size4!)),
  //                       color: isShipping == 1 ? Colors.green : Colors.blue,
  //                       border: Border.all(
  //                           color: isShipping == 1 ? Colors.green : Colors.blue,
  //                           width: 1.0),
  //                     ),
  //                     child: FutureBuilder<String?>(
  //                       future: isShipping == 1
  //                           ? Future.value('SHIPPING')
  //                           : (tableName != null && tableName.isNotEmpty)
  //                               ? Future.value(tableName)
  //                               : (res_table_id != null && res_table_id != 0)
  //                                   ? Helper().getTableNameById(res_table_id)
  //                                   : Future.value(null),
  //                       builder: (context, snapshot) {
  //                         String displayText;
  //                         if (isShipping == 1) {
  //                           displayText = 'SHIPPING';
  //                         } else if (snapshot.hasData &&
  //                             snapshot.data != null &&
  //                             snapshot.data!.isNotEmpty) {
  //                           displayText = snapshot.data!;
  //                         } else if (res_table_id != null &&
  //                             res_table_id != 0) {
  //                           displayText = 'TABLE $res_table_id';
  //                         } else {
  //                           displayText = 'TABLE';
  //                         }
  //
  //                         return Text(
  //                           displayText,
  //                           style: AppTheme.getTextStyle(
  //                               themeData.textTheme.caption,
  //                               fontSize: 9,
  //                               fontWeight: 700,
  //                               letterSpacing: 0.1,
  //                               color: Colors.white),
  //                         );
  //                       },
  //                     ),
  //                   ),
  //                 SizedBox(
  //                   width: 10,
  //                 ),
  //                 Container(
  //                   margin: EdgeInsets.only(bottom: MySize.size4!),
  //                   padding: EdgeInsets.symmetric(
  //                       horizontal: MySize.size6!, vertical: MySize.size2!),
  //                   decoration: BoxDecoration(
  //                       borderRadius:
  //                           BorderRadius.all(Radius.circular(MySize.size4!)),
  //                       color: (isQuotation == 0)
  //                           ? checkStatusColor(status)
  //                           : Colors.yellowAccent),
  //                   child: Text(
  //                     (isQuotation == 0) ? status.toUpperCase() : 'QUOTATION',
  //                     style: AppTheme.getTextStyle(themeData.textTheme.caption,
  //                         fontSize: 10, fontWeight: 700, letterSpacing: 0.1),
  //                   ),
  //                 ),
  //                 // Visibility(
  //                 //   visible: index != null,
  //                 //   child: Padding(
  //                 //     padding: EdgeInsets.all(MySize.size8!),
  //                 //     child: (isSynced == 0)
  //                 //         ? Icon(
  //                 //             MdiIcons.syncAlert,
  //                 //             color: Colors.black,
  //                 //           )
  //                 //         : Container(),
  //                 //   ),
  //                 // )
  //               ],
  //             ),
  //           ],
  //         )
  //       ],
  //     ),
  //   );
  // }

  Future<void> _deleteSale(Map sale) async {
    try {
      // Show loading
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Center(child: CircularProgressIndicator()),
      );

      // Delete from local database first
      await SellDatabase().deleteSell(sale['id'], deleteSellPayment: true);

      // If synced, delete from server
      if (sale['is_synced'] == 1 && sale['transaction_id'] != null) {
        await SellApi().delete(sale['transaction_id']);
      }

      // Refresh list
      if (!isLoading) {
        await sells();
      }

      // Hide loading
      Navigator.pop(context);

      Fluttertoast.showToast(msg: 'Sale deleted successfully');
    } catch (e) {
      Navigator.pop(context);
      Fluttertoast.showToast(msg: 'Failed to delete sale: ${e.toString()}');
    }
  }

  //all sales listing widget
  Widget allSellItem(
      {number,
        time,
        status,
        price,
        paid,
        isSynced,
        customerName,
        locationName,
        isQuotation,
        index,
        isShipping,
        tableName,
        res_table_id}) {
    //Logic for row items
    double space = MySize.size12!;

    // Debug logging for allSellItem function
    print('DEBUG allSellItem - Invoice: $number');
    print(
        '  - isShipping parameter: $isShipping (type: ${isShipping.runtimeType})');
    print('  - tableName parameter: $tableName');
    print('  - res_table_id parameter: $res_table_id');
    print('  - Condition check: isShipping == 1: ${isShipping == 1}');
    print(
        '  - Condition check: (tableName != null && tableName.isNotEmpty): ${(tableName != null && tableName.isNotEmpty)}');
    print(
        '  - Condition check: (res_table_id != null && res_table_id != 0): ${(res_table_id != null && res_table_id != 0)}');
    print(
        '  - Overall condition: ${(isShipping == 1 || (tableName != null && tableName.isNotEmpty) || (res_table_id != null && res_table_id != 0))}');
    return Container(
      padding: EdgeInsets.only(left: space, right: space, top: space),
      margin: EdgeInsets.only(top: MySize.size0!, bottom: space),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
        color: customAppTheme.bgLayer1,
        border: Border.all(color: customAppTheme.bgLayer4, width: 1.2),
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // Text(time,
              Text(_formatDateTime(time),
                  style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                      fontWeight: 600,
                      letterSpacing: -0.2,
                      color:
                      themeData.colorScheme.onBackground.withAlpha(160))),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        (isQuotation == 0)
                            ? AppLocalizations.of(context)
                            .translate('invoice_no') +
                            " $number"
                            : AppLocalizations.of(context).translate('ref_no') +
                            " $number",
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.subtitle1,
                            fontWeight: 700,
                            letterSpacing: -0.2),
                      ),
                      Text(
                        AppLocalizations.of(context)
                            .translate('invoice_amount') +
                            " $symbol $price",
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText2,
                            fontWeight: 600,
                            letterSpacing: 0),
                      ),
                      (isQuotation == 0)
                          ? Text(
                        AppLocalizations.of(context)
                            .translate('paid_amount') +
                            " $symbol $paid",
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText2,
                            fontWeight: 600,
                            letterSpacing: 0),
                      )
                          : SizedBox(),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${AppLocalizations.of(context).translate('customer_name')}: ",
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.bodyText2,
                                fontWeight: 600,
                                letterSpacing: 0),
                          ),
                          SizedBox(
                            width: MySize.screenWidth! * 0.6,
                            child: Text(
                              "$customerName",
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: AppTheme.getTextStyle(
                                  themeData.textTheme.bodyText2,
                                  fontWeight: 600,
                                  letterSpacing: 0),
                            ),
                          ),
                        ],
                      ),
                      Text(
                        AppLocalizations.of(context)
                            .translate('location_name') +
                            ": $locationName",
                        maxLines: 3,
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText2,
                            fontWeight: 600,
                            letterSpacing: 0),
                      ),
                    ],
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Visibility(
                    visible: index != null,
                    child: Row(
                      children: [
                        // (canEditSell) ? IconButton(icon: Icon(MdiIcons.fileDocumentEditOutline, color: themeData.colorScheme.onBackground,), onPressed: () {Navigator.pushNamed(context, '/cart', arguments: Helper().argument(locId: sellList[index]['location_id'], sellId: sellList[index]['id'], isQuotation: sellList[index]['is_quotation']));}) : Container(),
                        // (canDeleteSell)
                        //     ? IconButton(
                        //     icon: Icon(
                        //       MdiIcons.deleteOutline,
                        //       color: Colors.red,
                        //     ),
                        //     onPressed: () {
                        //       showDialog(
                        //         barrierDismissible: true,
                        //         context: context,
                        //         builder: (BuildContext context) {
                        //           return AlertDialog(
                        //             title: Icon(
                        //               MdiIcons.alert,
                        //               color: Colors.red,
                        //               size: MySize.size50,
                        //             ),
                        //             content: Text(
                        //                 AppLocalizations.of(context)
                        //                     .translate('are_you_sure'),
                        //                 textAlign: TextAlign.center,
                        //                 style: AppTheme.getTextStyle(
                        //                     themeData.textTheme.bodyText1,
                        //                     color: themeData
                        //                         .colorScheme.onBackground,
                        //                     fontWeight: 600,
                        //                     muted: true)),
                        //             actions: <Widget>[
                        //               TextButton(
                        //                   style: TextButton.styleFrom(
                        //                       backgroundColor: themeData
                        //                           .colorScheme.onPrimary,
                        //                       primary: themeData
                        //                           .colorScheme.primary),
                        //                   onPressed: () {
                        //                     Navigator.pop(context);
                        //                   },
                        //                   child: Text(
                        //                       AppLocalizations.of(context)
                        //                           .translate('cancel'))),
                        //               TextButton(
                        //                   style: TextButton.styleFrom(
                        //                       backgroundColor: Colors.red,
                        //                       primary: themeData
                        //                           .colorScheme.onError),
                        //                   onPressed: () async {
                        //                     Navigator.pop(context);
                        //                     await SellApi()
                        //                         .delete(
                        //                         allSalesListMap[index]
                        //                         ['id'])
                        //                         .then((value) {
                        //                       if (value != null) {
                        //                         setState(() {
                        //                           allSalesListMap
                        //                               .removeAt(index);
                        //                         });
                        //                         Fluttertoast.showToast(
                        //                             msg: '${value['msg']}');
                        //                       }
                        //                     });
                        //                   },
                        //                   child: Text(
                        //                       AppLocalizations.of(context)
                        //                           .translate('ok')))
                        //             ],
                        //           );
                        //         },
                        //       );
                        //     })
                        //     : Container(),
                        Visibility(
                          visible:
                          allSalesListMap[index]['invoice_url'] != null,
                          child: IconButton(
                              icon: Icon(
                                MdiIcons.printerWireless,
                                color: Colors.deepPurple,
                              ),
                              onPressed: () async {
                                var saleData = allSalesListMap[index];
                                if (saleData['id'] != null) {
                                  int? taxRateIdValue;
                                  if (saleData['tax_rate_id'] != null) {
                                    taxRateIdValue = int.tryParse(saleData['tax_rate_id'].toString());
                                  }
                                  await printOption(
                                    saleData['id'],
                                    invoiceUrl: saleData['invoice_url'],
                                    invoiceNo: saleData['invoice_no'],
                                    taxRateId: taxRateIdValue,
                                  );
                                } else {
                                  Fluttertoast.showToast(
                                      msg: AppLocalizations.of(context)
                                          ?.translate('error_generating_invoice') ??
                                          'Error: Sale ID not found');
                                }
                              }),
                        ),
                        Visibility(
                          visible:
                          allSalesListMap[index]['invoice_url'] != null,
                          child: IconButton(
                              icon: Icon(
                                MdiIcons.shareVariant,
                                color: themeData.colorScheme.primary,
                              ),
                              onPressed: () async {
                                // Show loading dialog immediately
                                showDialog(
                                  context: context,
                                  barrierDismissible: false,
                                  builder: (context) {
                                    return Center(
                                      child: AlertDialog(
                                        content: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          children: [
                                            CircularProgressIndicator(),
                                            SizedBox(width: 20),
                                            Text(
                                              AppLocalizations.of(context)
                                                  .translate('loading'),
                                              style:
                                              TextStyle(color: Colors.black),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );

                                try {
                                  String? invoiceContent;

                                  // Try to download PDF with timeout (2 seconds) for faster response
                                  if (await Helper().checkConnectivity()) {
                                    try {
                                      final response = await http.Client().get(
                                          Uri.parse(allSalesListMap[index]
                                          ['invoice_url']))
                                          .timeout(Duration(seconds: 2));
                                      if (response.statusCode == 200) {
                                        invoiceContent = response.body;
                                      }
                                      // Continue without invoice content if status not 200 - will generate locally
                                    } catch (e) {
                                      print('Error downloading PDF (will generate locally): $e');
                                      // Continue without invoice content - will generate locally for faster response
                                    }
                                  }

                                  // Share PDF (keep loading dialog visible during PDF generation)
                                  // Dismiss it right before share dialog appears
                                  await Helper().savePdf(0, 0, context,
                                      allSalesListMap[index]['invoice_no'],
                                      invoice: invoiceContent,
                                      onBeforeShare: () async {
                                        // Dismiss loading dialog right before sharing
                                        if (Navigator.of(context).canPop()) {
                                          Navigator.of(context).pop();
                                        }
                                      });
                                } catch (e) {
                                  // Dismiss loading dialog if still showing
                                  if (Navigator.of(context).canPop()) {
                                    Navigator.of(context).pop();
                                  }
                                  Fluttertoast.showToast(
                                      msg: AppLocalizations.of(context)
                                          .translate('something_went_wrong'));
                                }
                              }),
                        ),
                        Visibility(
                          // visible: (allSalesListMap[index]['mobile'] != null &&
                          //     allSalesListMap[index]['status']
                          //             .toString()
                          //             .toLowerCase() !=
                          //         'paid'),
                          child: IconButton(
                              icon: Icon(
                                Icons.call_outlined,
                                color: Colors.green,
                              ),
                              onPressed: () async {
                                await launch(
                                    'tel:${allSalesListMap[index]['mobile']}');
                              }),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  // Shipping/Table name container
                  if ((isShipping == 1 ||
                      (tableName != null && tableName.isNotEmpty) ||
                      (res_table_id != null && res_table_id != 0)))
                    Container(
                      margin: EdgeInsets.only(bottom: MySize.size4!),
                      padding: EdgeInsets.symmetric(
                          horizontal: MySize.size6!, vertical: MySize.size2!),
                      decoration: BoxDecoration(
                        borderRadius:
                        BorderRadius.all(Radius.circular(MySize.size4!)),
                        color: isShipping == 1 ? Colors.green : Colors.blue,
                        border: Border.all(
                            color: isShipping == 1 ? Colors.green : Colors.blue,
                            width: 1.0),
                      ),
                      child: FutureBuilder<String?>(
                        future: isShipping == 1
                            ? Future.value('SHIPPING')
                            : (tableName != null && tableName.isNotEmpty)
                            ? Future.value(tableName)
                            : (res_table_id != null && res_table_id != 0)
                            ? Helper().getTableNameById(res_table_id)
                            : Future.value(null),
                        builder: (context, snapshot) {
                          String displayText;
                          if (isShipping == 1) {
                            displayText = 'SHIPPING';
                          } else if (snapshot.hasData &&
                              snapshot.data != null &&
                              snapshot.data!.isNotEmpty) {
                            displayText = snapshot.data!;
                          } else if (res_table_id != null &&
                              res_table_id != 0) {
                            displayText = 'TABLE $res_table_id';
                          } else {
                            displayText = 'TABLE';
                          }

                          return Text(
                            displayText,
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.caption,
                                fontSize: 9,
                                fontWeight: 700,
                                letterSpacing: 0.1,
                                color: Colors.white),
                          );
                        },
                      ),
                    ),
                  SizedBox(
                    width: 10,
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: MySize.size4!),
                    padding: EdgeInsets.symmetric(
                        horizontal: MySize.size6!, vertical: MySize.size2!),
                    decoration: BoxDecoration(
                        borderRadius:
                        BorderRadius.all(Radius.circular(MySize.size4!)),
                        color: (isQuotation == 0)
                            ? checkStatusColor(status)
                            : Colors.yellowAccent),
                    child: Text(
                      (isQuotation == 0) ? status.toUpperCase() : 'QUOTATION',
                      style: AppTheme.getTextStyle(themeData.textTheme.caption,
                          fontSize: 10, fontWeight: 700, letterSpacing: 0.1),
                    ),
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget customers() {
    return SearchChoices.single(
      underline: Visibility(
        child: Container(),
        visible: false,
      ),
      displayClearIcon: false,
      value: jsonEncode(selectedCustomer),
      items: customerListMap.map<DropdownMenuItem<String>>((Map value) {
        return DropdownMenuItem<String>(
            value: jsonEncode(value),
            child: Container(
              width: MySize.screenWidth! * 0.8,
              child: Text("${value['name']} (${value['mobile'] ?? ' - '})",
                  softWrap: true,
                  overflow: TextOverflow.ellipsis,
                  style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                      color: themeData.colorScheme.onBackground)),
            ));
      }).toList(),
      onChanged: (value) async {
        setState(() {
          selectedCustomer = jsonDecode(value);
        });
      },
      isExpanded: true,
    );
  }

  Widget locations() {
    return PopupMenuButton(
        onSelected: (Map<dynamic, dynamic> item) {
          setState(() {
            selectedLocation = item;
          });
        },
        itemBuilder: (BuildContext context) {
          return locationListMap.map((Map value) {
            return PopupMenuItem(
              value: value,
              child: Text(value['name'],
                  style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                      color: themeData.colorScheme.onBackground)),
            );
          }).toList();
        },
        color: themeData.backgroundColor,
        child: Container(
          padding: EdgeInsets.all(MySize.size8!),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
            color: customAppTheme.bgLayer1,
            border: Border.all(color: customAppTheme.bgLayer3, width: 1),
          ),
          child: Row(
            children: <Widget>[
              Text(
                selectedLocation['name'],
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText1,
                  color: themeData.colorScheme.onBackground,
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: MySize.size4!),
                child: Icon(
                  MdiIcons.chevronDown,
                  size: MySize.size22,
                  color: themeData.colorScheme.onBackground,
                ),
              )
            ],
          ),
        ));
  }

  Widget paymentStatus() {
    return PopupMenuButton(
      onSelected: (String item) {
        setState(() {
          selectedPaymentStatus = item;
        });
      },
      itemBuilder: (BuildContext context) {
        return paymentStatuses.map((String value) {
          return PopupMenuItem(
            value: value,
            child: Text(
                AppLocalizations.of(context).translate(value).toUpperCase(),
                style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                    color: themeData.colorScheme.onBackground)),
          );
        }).toList();
      },
      color: themeData.backgroundColor,
      child: Container(
        padding: EdgeInsets.all(MySize.size8!),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
          color: customAppTheme.bgLayer1,
          border: Border.all(color: customAppTheme.bgLayer3, width: 1),
        ),
        child: Row(
          children: <Widget>[
            Text(
              AppLocalizations.of(context)
                  .translate(selectedPaymentStatus)
                  .toUpperCase(),
              style: AppTheme.getTextStyle(
                themeData.textTheme.bodyText1,
                color: themeData.colorScheme.onBackground,
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: MySize.size4!),
              child: Icon(
                MdiIcons.chevronDown,
                size: MySize.size22,
                color: themeData.colorScheme.onBackground,
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget invoiceStatus() {
    return PopupMenuButton(
      onSelected: (item) {
        setState(() {
          // selectedInvoiceStatus = item;
        });
      },
      itemBuilder: (BuildContext context) {
        return invoiceStatuses.map((String value) {
          return PopupMenuItem(
            value: value,
            child: Text(
                AppLocalizations.of(context).translate(value).toUpperCase(),
                style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                    color: themeData.colorScheme.onBackground)),
          );
        }).toList();
      },
      color: themeData.backgroundColor,
      child: Container(
        padding: EdgeInsets.all(MySize.size8!),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
          color: customAppTheme.bgLayer1,
          border: Border.all(color: customAppTheme.bgLayer3, width: 1),
        ),
        child: Row(
          children: <Widget>[
            Text(
              '',
              // AppLocalizations.of(context)
              //     .translate(selectedInvoiceStatus)
              //     .toUpperCase(),
              style: AppTheme.getTextStyle(
                themeData.textTheme.bodyText1,
                color: themeData.colorScheme.onBackground,
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: MySize.size4!),
              child: Icon(
                MdiIcons.chevronDown,
                size: MySize.size22,
                color: themeData.colorScheme.onBackground,
              ),
            )
          ],
        ),
      ),
    );
  }

  //status color
  Color checkStatusColor(String? status) {
    if (status != null) {
      if (status.toLowerCase() == 'paid')
        return Colors.green;
      else if (status.toLowerCase() == 'due')
        return Colors.red;
      else if (status.toLowerCase() == 'ordered')
        return Colors.purpleAccent;
      else
        return Colors.orange;
    } else {
      return Colors.black12;
    }
  }

  //status status of recent sales
  static String checkStatus(double invoiceAmount, double pendingAmount) {
    if (pendingAmount == invoiceAmount)
      return 'due';
    else if (pendingAmount >= 0.01)
      return 'partial';
    else
      return 'paid';
  }

  String _formatDateTime(String? dateTimeString) {
    if (dateTimeString == null || dateTimeString.isEmpty) {
      return '';
    }

    try {
      // Parse the datetime string (assuming format: yyyy-MM-dd HH:mm:ss)
      DateTime dateTime = DateTime.parse(dateTimeString);

      // Format date part
      String datePart = DateFormat('yyyy-MM-dd').format(dateTime);

      // Format time part
      String timePart = DateFormat('HH:mm:ss').format(dateTime);

      // Return with pipe separator
      return '$datePart | $timePart';
    } catch (e) {
      // If parsing fails, return the original string
      return dateTimeString;
    }
  }

  /// Sync cart data before navigating to checkout (same logic as Product screen)
  Future<void> _syncCartDataForCheckout(int sellId, int? resTableId) async {
    try {
      print(
          'Sales._syncCartDataForCheckout: Syncing cart data for sellId: $sellId, res_table_id: $resTableId');

      // Check if cart items exist in local database
      List<Map> existingCartItems = await SellDatabase().getSellLineBySellId(
          sellId,
          res_table_id: resTableId,
          includeCompleted: true);

      if (existingCartItems.isEmpty) {
        print(
            'Sales._syncCartDataForCheckout: No cart items found, attempting to restore from saved data');

        // Try to load saved cart data (same logic as Product screen)
        Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId);

        if (savedCartData != null) {
          print(
              'Sales._syncCartDataForCheckout: Restoring cart from saved data for sellId: $sellId');

          // Restore cart items from saved data
          if (savedCartData['cartItems'] != null &&
              savedCartData['cartItems'].isNotEmpty) {
            print(
                'Sales._syncCartDataForCheckout: Restoring ${savedCartData['cartItems'].length} cart items');

            // Clear existing cart items
            await SellDatabase().deleteSellLineBySellId(sellId);

            // Add saved items back to cart
            for (var item in savedCartData['cartItems']) {
              await SellDatabase().store({
                'sell_id': sellId,
                'product_id': item['product_id'],
                'variation_id': item['variation_id'],
                'quantity': item['quantity'],
                'unit_price': item['unit_price'],
                'tax_rate_id': item['tax_rate_id'],
                'discount_amount': item['discount_amount'] ?? 0.0,
                'discount_type': item['discount_type'] ?? 'fixed',
                'note': item['note'] ?? '',
                'is_completed': 0,
                'product_order_category':
                item['product_order_category'] ?? 'BAR',
                'res_table_id': savedCartData['res_table_id'] ?? resTableId,
                'is_shipping': savedCartData['is_shipping'] ?? 0,
              });
            }
          }

          // Ensure no duplicate items in cart
          await SellDatabase().ensureNoDuplicateCartItems(sellId, resTableId);

          print(
              'Sales._syncCartDataForCheckout: Successfully restored cart data for sellId: $sellId');
        } else {
          print(
              'Sales._syncCartDataForCheckout: No saved cart data found, trying to fetch from API');

          // Try to fetch from API if no saved data found (same logic as Product screen)
          await _fetchSaleDataFromAPI(sellId, resTableId);
        }
      } else {
        print(
            'Sales._syncCartDataForCheckout: Cart items already exist (${existingCartItems.length} items)');
      }
    } catch (e) {
      print('Sales._syncCartDataForCheckout: Error syncing cart data: $e');
      // Don't throw error, let the navigation continue
    }
  }

  /// Fetch sale data from API (same logic as Product screen)
  Future<void> _fetchSaleDataFromAPI(int sellId, int? resTableId) async {
    try {
      print(
          'Sales._fetchSaleDataFromAPI: Fetching sale data from API for sellId: $sellId');

      // Check if we have connectivity
      if (await Helper().checkConnectivity()) {
        // For now, we'll skip API fetching and just log that we would fetch from API
        // This can be implemented later if needed
        print(
            'Sales._fetchSaleDataFromAPI: API fetching not implemented yet, skipping');

        // TODO: Implement API fetching when the API method is available
        // This is a placeholder for future API integration
      } else {
        print(
            'Sales._fetchSaleDataFromAPI: No connectivity, cannot fetch from API');
      }
    } catch (e) {
      print('Sales._fetchSaleDataFromAPI: Error fetching from API: $e');
      // Don't throw error, let the navigation continue
    }
  }

  Future<void> printOption(int sellId, {String? invoiceUrl, String? invoiceNo, int? taxRateId}) async {
    try {
      print('printOption called with sellId: $sellId, invoiceUrl: $invoiceUrl, invoiceNo: $invoiceNo');
      Map<String, dynamic>? sell;
      String? finalInvoiceUrl;
      String? finalInvoiceNo;
      int? finalTaxRateId;

      // Try to get sale from local database first
      var sells = await SellDatabase().getSellBySellId(sellId);
      if (sells.isNotEmpty && sells[0] is Map<String, dynamic>) {
        sell = sells[0];
        finalInvoiceUrl = sell['invoice_url'];
        finalInvoiceNo = sell['invoice_no'];
        finalTaxRateId = sell['tax_rate_id'];
        print('printOption: Found sale in local database');
      } else {
        // Sale not in local database (API-only sale), use provided parameters or fetch from API
        if (invoiceUrl != null && invoiceUrl.isNotEmpty) {
          finalInvoiceUrl = invoiceUrl;
          finalInvoiceNo = invoiceNo;
          finalTaxRateId = taxRateId;
          print('printOption: Sale not in local database, using provided invoiceUrl');
        } else {
          // Try to fetch from API
          print('printOption: Sale not in local database and no invoiceUrl provided, fetching from API for ID: $sellId');
          try {
            // Try to get transaction_id from local database first (might exist even if sale doesn't)
            var localSell = await SellDatabase().getSellBySellId(sellId);
            int? transactionId;

            if (localSell.isNotEmpty && localSell[0]['transaction_id'] != null) {
              transactionId = int.tryParse(localSell[0]['transaction_id'].toString());
            } else {
              // If no transaction_id in local DB, assume sellId is the transaction_id
              transactionId = sellId;
            }

            if (transactionId != null) {
              List apiSales = await SellApi().getSpecifiedSells([transactionId]);
              if (apiSales.isNotEmpty) {
                var apiSale = apiSales[0];
                finalInvoiceUrl = apiSale['invoice_url'];
                finalInvoiceNo = apiSale['invoice_no'];
                finalTaxRateId = apiSale['tax_rate_id'] ?? apiSale['tax_id'];
                print('printOption: Fetched invoice URL from API: $finalInvoiceUrl');
              } else {
                print('printOption: No sale found in API for transaction ID: $transactionId');
                Fluttertoast.showToast(
                  msg: AppLocalizations.of(context)
                      ?.translate('error_generating_invoice') ??
                      'Error generating invoice: Sale not found',
                );
                return;
              }
            } else {
              print('printOption: Could not determine transaction ID for sellId: $sellId');
              Fluttertoast.showToast(
                msg: AppLocalizations.of(context)
                    ?.translate('error_generating_invoice') ??
                    'Error generating invoice: Sale not found',
              );
              return;
            }
          } catch (e) {
            print('printOption: Error fetching from API: $e');
            Fluttertoast.showToast(
              msg: AppLocalizations.of(context)
                  ?.translate('error_generating_invoice') ??
                  'Error generating invoice: ${e.toString()}',
            );
            return;
          }
        }
      }

      String invoiceHtml;
      String webViewUrl;

      if (finalInvoiceUrl != null &&
          finalInvoiceUrl.isNotEmpty &&
          await Helper().checkConnectivity()) {
        print('printOption: Fetching invoice from URL: $finalInvoiceUrl');
        final response = await http
            .get(Uri.parse(finalInvoiceUrl))
            .timeout(Duration(seconds: 10));
        if (response.statusCode == 200) {
          invoiceHtml = response.body;
          webViewUrl = finalInvoiceUrl;
          print('printOption: Successfully fetched invoice HTML from URL');
        } else {
          print(
              'printOption: Failed to fetch invoice from URL, status: ${response.statusCode}');
          Fluttertoast.showToast(
            msg: AppLocalizations.of(context)
                ?.translate('error_fetching_invoice') ??
                'Failed to fetch invoice from server',
          );
          // Fallback to local invoice generation only if we have sellId and taxRateId
          if (sell != null && finalTaxRateId != null) {
            invoiceHtml = await InvoiceFormatter().generateInvoice(
              sellId,
              finalTaxRateId,
              context,
            );
            webViewUrl =
            'data:text/html;base64,${base64Encode(utf8.encode(invoiceHtml))}';
            print('printOption: Generated local invoice as fallback');
          } else {
            Fluttertoast.showToast(
              msg: AppLocalizations.of(context)
                  ?.translate('error_generating_invoice') ??
                  'Unable to generate invoice',
            );
            return;
          }
        }
      } else {
        print(
            'printOption: No invoice URL or no connectivity, generating local invoice');
        // Only generate local invoice if we have the sale data
        if (sell != null && finalTaxRateId != null) {
          invoiceHtml = await InvoiceFormatter().generateInvoice(
            sellId,
            finalTaxRateId,
            context,
          );
          webViewUrl =
          'data:text/html;base64,${base64Encode(utf8.encode(invoiceHtml))}';
          print('printOption: Generated local invoice HTML');
        } else {
          Fluttertoast.showToast(
            msg: AppLocalizations.of(context)
                ?.translate('error_generating_invoice') ??
                'Unable to generate invoice: No invoice URL and sale not found locally',
          );
          return;
        }
      }

      // Full screen invoice viewer with SafeArea
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Dialog(
          insetPadding: EdgeInsets.zero,
          backgroundColor: Colors.white,
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: SafeArea(
              child: Column(
                children: [
                  // Header with title and buttons
                  Container(
                    width: MediaQuery.of(context).size.width,
                    color: Theme.of(context).primaryColor,
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Text(
                      'Invoice #${finalInvoiceNo ?? sell?['invoice_no'] ?? 'N/A'}',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.start,
                    ),
                  ),
                  // Invoice content
                  Expanded(
                    child: WebView(
                      initialUrl: webViewUrl,
                      javascriptMode: JavascriptMode.unrestricted,
                    ),
                  ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.all(8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        // Print button
                        TextButton(
                          style: TextButton.styleFrom(
                            backgroundColor: Colors.blue,
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius.circular(12),
                            ),
                            shadowColor: Colors.black.withOpacity(0.2),
                            elevation: 3,
                          ),
                          onPressed: () async {
                            await Printing.layoutPdf(
                              onLayout: (format) async =>
                              await Printing.convertHtml(
                                format: format,
                                html: invoiceHtml,
                              ),
                            );
                            Fluttertoast.showToast(
                              msg: AppLocalizations.of(context)
                                  ?.translate('invoice_printed') ??
                                  'Invoice printed',
                            );
                            Navigator.pop(context);
                          },
                          child: Text(
                            AppLocalizations.of(context)?.translate('print') ??
                                'Print',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                        SizedBox(width: 16),
                        // Close button
                        TextButton(
                          style: TextButton.styleFrom(
                            backgroundColor: Colors.red,
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            shadowColor: Colors.black.withOpacity(0.2),
                            elevation: 3,
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text(
                            AppLocalizations.of(context)?.translate('close') ??
                                'Close',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context)?.translate('invoice_displayed') ??
            'Invoice displayed',
      );
    } catch (e) {
      print('Error in printOption: $e');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context)
            ?.translate('error_generating_invoice') ??
            'Error generating invoice: $e',
      );
    }
  }
}

// New class to manage sellList and sells method for access in home.dart
class SalesData {
  List sellList = [];

  Future<void> sells() async {
    sellList = [];
    try {
      // Clear table cache to ensure we get fresh table data
      await Helper().clearTableCache();

      var sells = await SellDatabase().getSells(all: true);

      // Use a Set to track processed IDs for more efficient duplicate checking
      Set<int> processedIds = {};
      Set<String> processedInvoiceNos = {};

      // Process all sells sequentially to avoid race conditions
      for (var element in sells) {
        // Safely get customer details
        Map<String, dynamic>? customerDetail;
        try {
          customerDetail =
          await Contact().getCustomerDetailById(element['contact_id']);
        } catch (e) {
          print('Error getting customer details in SalesData: $e');
          customerDetail = null;
        }

        // Safely get location name
        String? locationName;
        try {
          locationName =
          await Helper().getLocationNameById(element['location_id']);
        } catch (e) {
          print('Error getting location name in SalesData: $e');
          locationName = 'Unknown Location';
        }

        // Safely get table name
        String? tableName;
        try {
          if (element['res_table_id'] != null && element['res_table_id'] != 0) {
            tableName =
            await Helper().getTableNameById(element['res_table_id']);
          }
        } catch (e) {
          print('Error getting table name in SalesData: $e');
          tableName = null;
        }

        // Check for duplicates using Sets for better performance
        int elementId = element['id'] ?? 0;
        String elementInvoiceNo = element['invoice_no'] ?? '';

        if (!processedIds.contains(elementId) &&
            !processedInvoiceNos.contains(elementInvoiceNo)) {
          processedIds.add(elementId);
          processedInvoiceNos.add(elementInvoiceNo);

          // Calculate total amount including tip and shipping charges (like All Sales final_total)
          double baseInvoiceAmount =
          (element['invoice_amount'] ?? 0.0).toDouble();
          double tipAmount = (element['tip_amount'] ?? 0.0).toDouble();
          double shippingCharges =
          (element['shipping_charges'] ?? 0.0).toDouble();
          double pendingAmount = (element['pending_amount'] ?? 0.0).toDouble();

          // Total invoice amount including tip and shipping (equivalent to final_total in All Sales)
          double totalInvoiceAmount =
              baseInvoiceAmount + tipAmount + shippingCharges;

          // Calculate paid amount correctly: total invoice amount - pending amount
          double paidAmount = totalInvoiceAmount - pendingAmount;

          sellList.add({
            'id': element['id'],
            'transaction_date': element['transaction_date'],
            'invoice_no': element['invoice_no'],
            'customer_name': customerDetail != null
                ? customerDetail['name']
                : 'Unknown Customer',
            'mobile': customerDetail != null ? customerDetail['mobile'] : null,
            'contact_id': element['contact_id'],
            'location_id': element['location_id'],
            'location_name': locationName,
            //'status': element['status'],
            'status': element['status'] ?? element['sale_status'] ?? 'final',
            'tax_rate_id': element['tax_rate_id'],
            'discount_amount': element['discount_amount'],
            'discount_type': element['discount_type'],
            'sale_note': element['sale_note'],
            'staff_note': element['staff_note'],
            'invoice_amount':
            totalInvoiceAmount, // Use invoice_amount directly as it now includes everything
            'pending_amount': pendingAmount,
            'paid_amount': paidAmount, // Store calculated paid amount
            'is_synced': element['is_synced'],
            'is_quotation': element['is_quotation'],
            'invoice_url': element['invoice_url'],
            'transaction_id': element['transaction_id'],
            'is_shipping':
            int.tryParse((element['is_shipping'] ?? 0).toString()) ?? 0,
            'res_table_id': element['res_table_id'],
            'table_name': tableName
          });
        }
      }

      // Debug logging
      print('SalesData.sells(): Processed ${sellList.length} sales items');
    } catch (e) {
      print('Error in SalesData.sells(): $e');
    }
  }

  /// Sync cart data before navigating to checkout (same logic as Product screen)
  Future<void> _syncCartDataForCheckout(int sellId, int? resTableId) async {
    try {
      print(
          'Sales._syncCartDataForCheckout: Syncing cart data for sellId: $sellId, res_table_id: $resTableId');

      // Check if cart items exist in local database
      List<Map> existingCartItems = await SellDatabase().getSellLineBySellId(
          sellId,
          res_table_id: resTableId,
          includeCompleted: true);

      if (existingCartItems.isEmpty) {
        print(
            'Sales._syncCartDataForCheckout: No cart items found, attempting to restore from saved data');

        // Try to load saved cart data (same logic as Product screen)
        Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId);

        if (savedCartData != null) {
          print(
              'Sales._syncCartDataForCheckout: Restoring cart from saved data for sellId: $sellId');

          // Restore cart items from saved data
          if (savedCartData['cartItems'] != null &&
              savedCartData['cartItems'].isNotEmpty) {
            print(
                'Sales._syncCartDataForCheckout: Restoring ${savedCartData['cartItems'].length} cart items');

            // Clear existing cart items
            await SellDatabase().deleteSellLineBySellId(sellId);

            // Add saved items back to cart
            for (var item in savedCartData['cartItems']) {
              await SellDatabase().store({
                'sell_id': sellId,
                'product_id': item['product_id'],
                'variation_id': item['variation_id'],
                'quantity': item['quantity'],
                'unit_price': item['unit_price'],
                'tax_rate_id': item['tax_rate_id'],
                'discount_amount': item['discount_amount'] ?? 0.0,
                'discount_type': item['discount_type'] ?? 'fixed',
                'note': item['note'] ?? '',
                'is_completed': 0,
                'product_order_category':
                item['product_order_category'] ?? 'BAR',
                'res_table_id': savedCartData['res_table_id'] ?? resTableId,
                'is_shipping': savedCartData['is_shipping'] ?? 0,
              });
            }
          }

          // Ensure no duplicate items in cart
          await SellDatabase().ensureNoDuplicateCartItems(sellId, resTableId);

          print(
              'Sales._syncCartDataForCheckout: Successfully restored cart data for sellId: $sellId');
        } else {
          print(
              'Sales._syncCartDataForCheckout: No saved cart data found, trying to fetch from API');

          // Try to fetch from API if no saved data found (same logic as Product screen)
          await _fetchSaleDataFromAPI(sellId, resTableId);
        }
      } else {
        print(
            'Sales._syncCartDataForCheckout: Cart items already exist (${existingCartItems.length} items)');
      }
    } catch (e) {
      print('Sales._syncCartDataForCheckout: Error syncing cart data: $e');
      // Don't throw error, let the navigation continue
    }
  }

  /// Fetch sale data from API (same logic as Product screen)
  Future<void> _fetchSaleDataFromAPI(int sellId, int? resTableId) async {
    try {
      print(
          'Sales._fetchSaleDataFromAPI: Fetching sale data from API for sellId: $sellId');

      // Check if we have connectivity
      if (await Helper().checkConnectivity()) {
        // For now, we'll skip API fetching and just log that we would fetch from API
        // This can be implemented later if needed
        print(
            'Sales._fetchSaleDataFromAPI: API fetching not implemented yet, skipping');

        // TODO: Implement API fetching when the API method is available
        // This is a placeholder for future API integration
      } else {
        print(
            'Sales._fetchSaleDataFromAPI: No connectivity, cannot fetch from API');
      }
    } catch (e) {
      print('Sales._fetchSaleDataFromAPI: Error fetching from API: $e');
      // Don't throw error, let the navigation continue
    }
  }
}
