// // import 'dart:async';
// // import 'dart:convert';
// //
// // import 'package:date_time_picker/date_time_picker.dart';
// // import 'package:dev/apis/api.dart';
// // import 'package:dev/config.dart';
// // import 'package:flutter/material.dart';
// // import 'package:flutter/services.dart';
// // import 'package:fluttertoast/fluttertoast.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:intl/intl.dart';
// // import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// // import 'package:printing/printing.dart';
// // import 'package:webview_flutter/webview_flutter.dart';
// // import 'package:sqflite/sqflite.dart';
// //
// // import '../apis/sell.dart';
// // import '../helpers/AppTheme.dart';
// // import '../helpers/SizeConfig.dart';
// // import '../helpers/otherHelpers.dart';
// // import '../locale/MyLocalizations.dart';
// // import '../models/database.dart';
// // import '../models/invoice.dart';
// // import '../models/paymentDatabase.dart';
// // import '../models/sell.dart';
// // import '../models/sellDatabase.dart';
// // import '../models/system.dart';
// // import 'login.dart';
// //
// // class CheckOut extends StatefulWidget {
// //   @override
// //   CheckOutState createState() => CheckOutState();
// // }
// //
// // class CheckOutState extends State<CheckOut> {
// //   List<Map> paymentMethods = [];
// //   int? sellId;
// //   double totalPaying = 0.0;
// //   String symbol = '',
// //       invoiceType = "Mobile",
// //       transactionDate = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());
// //   Map? argument;
// //   List<Map> payments = [],
// //       paymentAccounts = [
// //         {'id': null, 'name': "None"}
// //       ];
// //   List<int> deletedPaymentId = [];
// //   late Map<String, dynamic> paymentLine;
// //   List sellDetail = [];
// //   late double invoiceAmount = 0.00, pendingAmount = 0.00, changeReturn = 0.00;
// //
// //   // Tip details
// //   late double tip_amount = 0.00, maxtipValue;
// //   String selectedTipType = "fixed";
// //   bool proceedNext = true;
// //   bool hasTipTypeColumn = false;
// //
// //   TextEditingController dateController = TextEditingController(),
// //       saleNote = TextEditingController(),
// //       staffNote = TextEditingController(),
// //       shippingDetails = TextEditingController(),
// //       shippingCharges = TextEditingController();
// //   TextEditingController tip_amountController = TextEditingController();
// //
// //   bool _printInvoice = true,
// //       printWebInvoice = false,
// //       saleCreated = false,
// //       isLoading = false;
// //   static int themeType = 1;
// //   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
// //   CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     getInitDetails();
// //     tip_amountController.text = '0.00';
// //     checkTipTypeColumn();
// //   }
// //
// //   // Check if tip_type column exists in sell table
// //   Future<void> checkTipTypeColumn() async {
// //     try {
// //       var db = await DbProvider().database;
// //       hasTipTypeColumn = await DbProvider().checkSchema();
// //       if (!hasTipTypeColumn) {
// //         print('Warning: tip_type column not found in sell table');
// //       }
// //       setState(() {});
// //     } catch (e) {
// //       print('Error checking tip_type column: $e');
// //       setState(() {
// //         hasTipTypeColumn = false;
// //       });
// //     }
// //   }
// //
// //   getInitDetails() async {
// //     setState(() {
// //       isLoading = true;
// //     });
// //     await Helper().getFormattedBusinessDetails().then((value) {
// //       symbol = value['symbol'];
// //       maxtipValue = double.tryParse(value['max_tip_value']?.toString() ?? '100.0') ?? 100.0;
// //       setState(() {
// //         isLoading = false;
// //       });
// //     });
// //   }
// //
// //   setPaymentAccounts() async {
// //     List payments = await System().get('payment_method', argument!['locationId']);
// //     await System().getPaymentAccounts().then((value) {
// //       value.forEach((element) {
// //         List<String> accIds = [];
// //         payments.forEach((paymentMethod) {
// //           if ((paymentMethod['account_id'].toString() == element['id'].toString()) &&
// //               !accIds.contains(element['id'].toString())) {
// //             setState(() {
// //               paymentAccounts.add({'id': element['id'], 'name': element['name']});
// //               accIds.add(element['id'].toString());
// //             });
// //           }
// //         });
// //       });
// //     });
// //   }
// //
// //   @override
// //   void didChangeDependencies() {
// //     argument = ModalRoute.of(context)!.settings.arguments as Map?;
// //     invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
// //         (double.tryParse(tip_amountController.text) ?? 0.00) +
// //         (double.tryParse(shippingCharges.text) ?? 0.00);
// //     setPaymentAccounts().then((value) {
// //       if (argument!['sellId'] == null) {
// //         setPaymentDetails().then((value) {
// //           payments.add({
// //             'amount': invoiceAmount,
// //             'method': paymentMethods[0]['name'],
// //             'note': '',
// //             'account_id': paymentMethods[0]['account_id'],
// //             'received_amount': null,
// //             'change_return': 0.0,
// //           });
// //           calculateMultiPayment();
// //         });
// //       } else {
// //         setPaymentDetails().then((value) {
// //           onEdit(argument!['sellId']);
// //         });
// //       }
// //     });
// //     super.didChangeDependencies();
// //   }
// //
// //   @override
// //   void dispose() {
// //     staffNote.dispose();
// //     saleNote.dispose();
// //     tip_amountController.dispose();
// //     dateController.dispose();
// //     shippingDetails.dispose();
// //     shippingCharges.dispose();
// //     super.dispose();
// //   }
// //
// //   onEdit(sellId) async {
// //     sellDetail = await SellDatabase().getSellBySellId(sellId);
// //     this.sellId = argument!['sellId'];
// //     await SellDatabase().getSellBySellId(sellId).then((value) {
// //       shippingCharges.text = value[0]['shipping_charges']?.toString() ?? '0.00';
// //       shippingDetails.text = value[0]['shipping_details'] ?? '';
// //       saleNote.text = value[0]['sale_note'] ?? '';
// //       staffNote.text = value[0]['staff_note'] ?? '';
// //       tip_amountController.text = value[0]['tip_amount']?.toString() ?? '0.00';
// //       selectedTipType = hasTipTypeColumn ? (value[0]['tip_type'] ?? 'fixed') : 'fixed';
// //       tip_amount = double.tryParse(tip_amountController.text) ?? 0.00;
// //       invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
// //           (double.tryParse(shippingCharges.text) ?? 0.00) +
// //           calculateTipAmount();
// //       setState(() {});
// //     });
// //     payments = [];
// //     List paymentLines = await PaymentDatabase().get(sellId, allColumns: true);
// //     paymentLines.forEach((element) {
// //       if (element['is_return'] == 0) {
// //         payments.add({
// //           'id': element['id'],
// //           'amount': element['amount'],
// //           'method': element['method'],
// //           'note': element['note'],
// //           'account_id': element['account_id'],
// //           'received_amount': element['received_amount'],
// //           'change_return': element['change_return'],
// //         });
// //       }
// //     });
// //     calculateMultiPayment();
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //         appBar: AppBar(
// //           elevation: 0,
// //           title: Text(
// //             AppLocalizations.of(context)?.translate('checkout') ?? 'Checkout',
// //             style: AppTheme.getTextStyle(themeData.textTheme.headline6,
// //                 fontWeight: 600),
// //           ),
// //         ),
// //         body: SingleChildScrollView(
// //           child: isLoading ? Helper().loadingIndicator(context) : paymentBox(),
// //         ));
// //   }
// //
// //   Widget paymentBox() {
// //     return Container(
// //       margin: EdgeInsets.all(MySize.size3!),
// //       child: Column(
// //         children: <Widget>[
// //           Card(
// //             margin: EdgeInsets.all(MySize.size5!),
// //             shadowColor: Colors.blue,
// //             child: DateTimePicker(
// //               use24HourFormat: true,
// //               locale: Locale('en', 'US'),
// //               initialValue: transactionDate,
// //               type: DateTimePickerType.dateTime,
// //               firstDate: DateTime.now().subtract(Duration(days: 366)),
// //               lastDate: DateTime.now(),
// //               dateLabelText: "${AppLocalizations.of(context)?.translate('date') ?? 'Date'}:",
// //               style: AppTheme.getTextStyle(
// //                 themeData.textTheme.bodyText1,
// //                 fontWeight: 700,
// //                 color: themeData.colorScheme.primary,
// //               ),
// //               textAlign: TextAlign.center,
// //               onChanged: (val) {
// //                 setState(() {
// //                   transactionDate = val;
// //                 });
// //               },
// //             ),
// //           ),
// //           ListView.builder(
// //               physics: ScrollPhysics(),
// //               shrinkWrap: true,
// //               itemCount: payments.length,
// //               itemBuilder: (context, index) {
// //                 return Card(
// //                   margin: EdgeInsets.all(MySize.size5!),
// //                   shadowColor: Colors.blue,
// //                   child: Padding(
// //                     padding: EdgeInsets.all(MySize.size8!),
// //                     child: Column(children: <Widget>[
// //                       Row(
// //                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                         children: <Widget>[
// //                           Column(
// //                             crossAxisAlignment: CrossAxisAlignment.start,
// //                             children: <Widget>[
// //                               Text(
// //                                   AppLocalizations.of(context)?.translate('amount') ??
// //                                       'Amount' + ' : ',
// //                                   style: AppTheme.getTextStyle(
// //                                       themeData.textTheme.bodyText1,
// //                                       color: themeData.colorScheme.onBackground,
// //                                       fontWeight: 600,
// //                                       muted: true)),
// //                               SizedBox(
// //                                   height: MySize.size40,
// //                                   width: MySize.safeWidth! * 0.50,
// //                                   child: TextFormField(
// //                                       decoration: InputDecoration(
// //                                         prefix: Text(symbol),
// //                                       ),
// //                                       textAlign: TextAlign.end,
// //                                       initialValue: payments[index]['amount'].toStringAsFixed(2),
// //                                       inputFormatters: [
// //                                         FilteringTextInputFormatter(RegExp(r'^(\d+)?\.?\d{0,2}'), allow: true)
// //                                       ],
// //                                       keyboardType: TextInputType.number,
// //                                       onChanged: (value) {
// //                                         payments[index]['amount'] = Helper().validateInput(value);
// //                                         calculateMultiPayment();
// //                                       }))
// //                             ],
// //                           ),
// //                         ],
// //                       ),
// //                       Padding(padding: EdgeInsets.symmetric(vertical: MySize.size6!)),
// //                       Row(
// //                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                         children: [
// //                           Column(
// //                             children: <Widget>[
// //                               Text(
// //                                   AppLocalizations.of(context)?.translate('payment_method') ??
// //                                       'Payment Method' + ' : ',
// //                                   style: AppTheme.getTextStyle(
// //                                       themeData.textTheme.bodyText1,
// //                                       color: themeData.colorScheme.onBackground,
// //                                       fontWeight: 600,
// //                                       muted: true)),
// //                               DropdownButtonHideUnderline(
// //                                 child: DropdownButton(
// //                                     dropdownColor: themeData.backgroundColor,
// //                                     icon: Icon(Icons.arrow_drop_down),
// //                                     value: payments[index]['method'],
// //                                     items: paymentMethods.map<DropdownMenuItem<String>>((Map value) {
// //                                       return DropdownMenuItem<String>(
// //                                         value: value['name'],
// //                                         child: Container(
// //                                           width: MySize.screenWidth! * 0.35,
// //                                           child: Text(value['value'],
// //                                               softWrap: true,
// //                                               overflow: TextOverflow.ellipsis,
// //                                               style: AppTheme.getTextStyle(
// //                                                   themeData.textTheme.bodyText1,
// //                                                   color: themeData.colorScheme.onBackground,
// //                                                   fontWeight: 800,
// //                                                   muted: true)),
// //                                         ),
// //                                       );
// //                                     }).toList(),
// //                                     onChanged: (newValue) {
// //                                       paymentMethods.forEach((element) {
// //                                         if (element['name'] == newValue) {
// //                                           setState(() {
// //                                             payments[index]['method'] = newValue;
// //                                             payments[index]['account_id'] = element['account_id'];
// //                                           });
// //                                         }
// //                                       });
// //                                     }),
// //                               )
// //                             ],
// //                           ),
// //                           Column(
// //                             children: <Widget>[
// //                               Text(
// //                                   AppLocalizations.of(context)?.translate('payment_account') ??
// //                                       'Payment Account' + ' : ',
// //                                   style: AppTheme.getTextStyle(
// //                                       themeData.textTheme.bodyText1,
// //                                       color: themeData.colorScheme.onBackground,
// //                                       fontWeight: 600,
// //                                       muted: true)),
// //                               DropdownButtonHideUnderline(
// //                                 child: DropdownButton(
// //                                     dropdownColor: themeData.backgroundColor,
// //                                     icon: Icon(Icons.arrow_drop_down),
// //                                     value: payments[index]['account_id'],
// //                                     items: paymentAccounts.map<DropdownMenuItem<int>>((Map value) {
// //                                       return DropdownMenuItem<int>(
// //                                         value: value['id'],
// //                                         child: Container(
// //                                           width: MySize.screenWidth! * 0.35,
// //                                           child: Text(value['name'],
// //                                               softWrap: true,
// //                                               overflow: TextOverflow.ellipsis,
// //                                               style: AppTheme.getTextStyle(
// //                                                   themeData.textTheme.bodyText1,
// //                                                   color: themeData.colorScheme.onBackground,
// //                                                   fontWeight: 800,
// //                                                   muted: true)),
// //                                         ),
// //                                       );
// //                                     }).toList(),
// //                                     onChanged: (newValue) {
// //                                       setState(() {
// //                                         payments[index]['account_id'] = newValue;
// //                                       });
// //                                     }),
// //                               )
// //                             ],
// //                           ),
// //                         ],
// //                       ),
// //                       Row(
// //                         children: <Widget>[
// //                           SizedBox(
// //                             width: MySize.safeWidth! * 0.8,
// //                             child: TextFormField(
// //                                 decoration: InputDecoration(
// //                                     hintText: AppLocalizations.of(context)?.translate('payment_note') ??
// //                                         'Payment Note'),
// //                                 onChanged: (value) {
// //                                   payments[index]['note'] = value;
// //                                 }),
// //                           ),
// //                           Expanded(
// //                               child: (index > 0)
// //                                   ? IconButton(
// //                                   icon: Icon(
// //                                     MdiIcons.deleteForeverOutline,
// //                                     size: MySize.size40,
// //                                     color: Colors.black,
// //                                   ),
// //                                   onPressed: () {
// //                                     alertConfirm(context, index);
// //                                   })
// //                                   : Container())
// //                         ],
// //                       ),
// //                     ]),
// //                   ),
// //                 );
// //               }),
// //           Card(
// //             margin: EdgeInsets.all(MySize.size5!),
// //             child: Container(
// //               padding: EdgeInsets.all(MySize.size5!),
// //               child: Column(
// //                 children: <Widget>[
// //                   OutlinedButton(
// //                     style: OutlinedButton.styleFrom(
// //                       side: BorderSide(color: themeData.colorScheme.primary),
// //                     ),
// //                     onPressed: () {
// //                       setState(() {
// //                         payments.add({
// //                           'amount': pendingAmount,
// //                           'method': paymentMethods[0]['name'],
// //                           'note': '',
// //                           'account_id': paymentMethods[0]['account_id'],
// //                           'received_amount': null,
// //                           'change_return': 0.0,
// //                         });
// //                         calculateMultiPayment();
// //                       });
// //                     },
// //                     child: Text(
// //                       AppLocalizations.of(context)?.translate('add_payment') ?? 'Add Payment',
// //                       style: AppTheme.getTextStyle(
// //                         themeData.textTheme.subtitle1,
// //                         fontWeight: 700,
// //                         color: themeData.colorScheme.primary,
// //                       ),
// //                     ),
// //                   ),
// //                   Row(
// //                     children: [
// //                       Column(
// //                           crossAxisAlignment: CrossAxisAlignment.start,
// //                           children: <Widget>[
// //                             Text(
// //                                 AppLocalizations.of(context)?.translate('shipping_charges') ??
// //                                     'Shipping Charges' + ' : ',
// //                                 style: AppTheme.getTextStyle(
// //                                     themeData.textTheme.bodyText1,
// //                                     color: themeData.colorScheme.onBackground,
// //                                     fontWeight: 600,
// //                                     muted: true)),
// //                             SizedBox(
// //                                 height: MySize.size40,
// //                                 width: MySize.safeWidth! * 0.5,
// //                                 child: TextFormField(
// //                                     controller: shippingCharges,
// //                                     decoration: InputDecoration(prefix: Text(symbol)),
// //                                     textAlign: TextAlign.end,
// //                                     inputFormatters: [
// //                                       FilteringTextInputFormatter(RegExp(r'^(\d+)?\.?\d{0,2}'), allow: true)
// //                                     ],
// //                                     keyboardType: TextInputType.number,
// //                                     onChanged: (value) {
// //                                       setState(() {
// //                                         invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
// //                                             Helper().validateInput(value) +
// //                                             calculateTipAmount();
// //                                         calculateMultiPayment();
// //                                       });
// //                                     })),
// //                             Padding(padding: EdgeInsets.symmetric(vertical: 5)),
// //                             SizedBox(
// //                               width: MySize.safeWidth! * 0.8,
// //                               child: TextFormField(
// //                                   controller: shippingDetails,
// //                                   decoration: InputDecoration(
// //                                       hintText: AppLocalizations.of(context)?.translate('shipping_details') ??
// //                                           'Shipping Details')),
// //                             ),
// //                           ]),
// //                     ],
// //                   ),
// //                   SizedBox(height: 10,),
// //                   Container(
// //                     padding: EdgeInsets.only(left: MySize.size24!, right: MySize.size24!),
// //                     child: Row(
// //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                       children: <Widget>[
// //                         Text(
// //                           AppLocalizations.of(context)?.translate('tip') ?? 'Tip' + ' : ',
// //                           style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
// //                               color: themeData.colorScheme.onBackground,
// //                               fontWeight: 600,
// //                               muted: true),
// //                         ),
// //                         tipDropdown(),
// //                         Expanded(
// //                           child: Container(
// //                             height: MySize.size50,
// //                             child: TextFormField(
// //                               controller: tip_amountController,
// //                               decoration: InputDecoration(
// //                                 prefix: Text(selectedTipType == 'fixed' ? symbol : ''),
// //                                 labelText: AppLocalizations.of(context)?.translate('tip_amount') ?? 'Tip Amount',
// //                                 border: themeData.inputDecorationTheme.border,
// //                                 enabledBorder: themeData.inputDecorationTheme.border,
// //                                 focusedBorder: themeData.inputDecorationTheme.focusedBorder,
// //                               ),
// //                               style: AppTheme.getTextStyle(
// //                                   themeData.textTheme.subtitle2,
// //                                   fontWeight: 400,
// //                                   letterSpacing: -0.2),
// //                               textAlign: TextAlign.end,
// //                               inputFormatters: [
// //                                 FilteringTextInputFormatter(RegExp(r'^(\d+)?\.?\d{0,2}'), allow: true)
// //                               ],
// //                               keyboardType: TextInputType.number,
// //                               onChanged: (value) {
// //                                 setState(() {
// //                                   tip_amount = Helper().validateInput(value);
// //                                   if (maxtipValue != null && tip_amount > maxtipValue) {
// //                                     Fluttertoast.showToast(
// //                                         msg: AppLocalizations.of(context)?.translate('tip_error_message') ??
// //                                             'Tip exceeds maximum value of $maxtipValue',
// //                                         toastLength: Toast.LENGTH_LONG);
// //                                     proceedNext = false;
// //                                   } else {
// //                                     proceedNext = true;
// //                                   }
// //                                   invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
// //                                       (double.tryParse(shippingCharges.text) ?? 0.00) +
// //                                       calculateTipAmount();
// //                                   calculateMultiPayment();
// //                                 });
// //                               },
// //                             ),
// //                           ),
// //                         )
// //                       ],
// //                     ),
// //                   ),
// //                   SizedBox(height: 10,),
// //                   Container(
// //                     child: GridView.count(
// //                         shrinkWrap: true,
// //                         physics: ClampingScrollPhysics(),
// //                         crossAxisCount: 2,
// //                         padding: EdgeInsets.only(
// //                             left: MySize.size16!, right: MySize.size16!, top: MySize.size16!),
// //                         mainAxisSpacing: MySize.size16!,
// //                         childAspectRatio: 8 / 3,
// //                         crossAxisSpacing: MySize.size16!,
// //                         children: <Widget>[
// //                           block(
// //                             amount: Helper().formatCurrency(invoiceAmount),
// //                             subject: AppLocalizations.of(context)?.translate('total_payble') ?? 'Total Payable' + ' : ',
// //                             backgroundColor: Colors.blue,
// //                             textColor: themeData.colorScheme.onBackground,
// //                           ),
// //                           block(
// //                             amount: Helper().formatCurrency(totalPaying),
// //                             subject: AppLocalizations.of(context)?.translate('total_paying') ?? 'Total Paying' + ' : ',
// //                             backgroundColor: Colors.red,
// //                             textColor: themeData.colorScheme.onBackground,
// //                           ),
// //                           block(
// //                             amount: Helper().formatCurrency(changeReturn),
// //                             subject: AppLocalizations.of(context)?.translate('change_return') ?? 'Change Return' + ' : ',
// //                             backgroundColor: Colors.green,
// //                             textColor: (changeReturn >= 0.01) ? Colors.red : themeData.colorScheme.onBackground,
// //                           ),
// //                           block(
// //                             amount: Helper().formatCurrency(pendingAmount),
// //                             subject: AppLocalizations.of(context)?.translate('balance') ?? 'Balance' + ' : ',
// //                             backgroundColor: Colors.orange,
// //                             textColor: (pendingAmount >= 0.01) ? Colors.red : themeData.colorScheme.onBackground,
// //                           ),
// //                         ]),
// //                   ),
// //                   Padding(
// //                     padding: EdgeInsets.all(MySize.size8!),
// //                     child: Column(
// //                       children: <Widget>[
// //                         Row(
// //                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                           children: <Widget>[
// //                             Column(children: <Widget>[
// //                               Text(
// //                                   AppLocalizations.of(context)?.translate('sell_note') ?? 'Sell Note' + ' : ',
// //                                   style: AppTheme.getTextStyle(
// //                                       themeData.textTheme.bodyText1,
// //                                       color: themeData.colorScheme.onBackground,
// //                                       fontWeight: 600,
// //                                       muted: true)),
// //                               SizedBox(
// //                                   height: MySize.size80,
// //                                   width: MySize.screenWidth! * 0.40,
// //                                   child: TextFormField(controller: saleNote))
// //                             ]),
// //                             Column(
// //                               children: <Widget>[
// //                                 Text(
// //                                     AppLocalizations.of(context)?.translate('staff_note') ?? 'Staff Note' + ' : ',
// //                                     style: AppTheme.getTextStyle(
// //                                         themeData.textTheme.bodyText1,
// //                                         color: themeData.colorScheme.onBackground,
// //                                         fontWeight: 600,
// //                                         muted: true)),
// //                                 SizedBox(
// //                                   height: MySize.size80,
// //                                   width: MySize.screenWidth! * 0.40,
// //                                   child: TextFormField(controller: staffNote),
// //                                 ),
// //                               ],
// //                             ),
// //                           ],
// //                         ),
// //                         Container(
// //                           child: Row(
// //                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                             children: [
// //                               Expanded(
// //                                 flex: 1,
// //                                 child: Row(
// //                                   children: [
// //                                     Radio(
// //                                       value: "Mobile",
// //                                       groupValue: invoiceType,
// //                                       onChanged: (value) {
// //                                         setState(() {
// //                                           invoiceType = value.toString();
// //                                           printWebInvoice = false;
// //                                         });
// //                                       },
// //                                       toggleable: true,
// //                                     ),
// //                                     Expanded(
// //                                       child: Text(
// //                                         AppLocalizations.of(context)?.translate('mobile_layout') ?? 'Mobile Layout',
// //                                         maxLines: 2,
// //                                         style: AppTheme.getTextStyle(
// //                                             themeData.textTheme.bodyText2,
// //                                             color: themeData.colorScheme.onBackground,
// //                                             fontWeight: 600),
// //                                       ),
// //                                     ),
// //                                   ],
// //                                 ),
// //                               ),
// //                               Expanded(
// //                                 flex: 1,
// //                                 child: Row(
// //                                   children: [
// //                                     Radio(
// //                                       value: "Web",
// //                                       groupValue: invoiceType,
// //                                       onChanged: (value) async {
// //                                         if (await Helper().checkConnectivity()) {
// //                                           setState(() {
// //                                             invoiceType = value.toString();
// //                                             printWebInvoice = true;
// //                                           });
// //                                         } else {
// //                                           Fluttertoast.showToast(
// //                                               msg: AppLocalizations.of(context)?.translate('check_connectivity') ??
// //                                                   'Please check your internet connection');
// //                                         }
// //                                       },
// //                                       toggleable: true,
// //                                     ),
// //                                     Expanded(
// //                                       child: Text(
// //                                         AppLocalizations.of(context)?.translate('web_layout') ?? 'Web Layout',
// //                                         maxLines: 2,
// //                                         style: AppTheme.getTextStyle(
// //                                             themeData.textTheme.bodyText2,
// //                                             color: themeData.colorScheme.onBackground,
// //                                             fontWeight: 600),
// //                                       ),
// //                                     ),
// //                                   ],
// //                                 ),
// //                               ),
// //                             ],
// //                           ),
// //                         ),
// //                         Row(
// //                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                           children: [
// //                             Expanded(
// //                               flex: 1,
// //                               child: ElevatedButton(
// //                                 style: ElevatedButton.styleFrom(
// //                                     primary: themeData.colorScheme.onPrimary, elevation: 5),
// //                                 onPressed: () {
// //                                   _printInvoice = false;
// //                                   if (pendingAmount >= 0.01) {
// //                                     alertPending(context);
// //                                   } else {
// //                                     if (!saleCreated) {
// //                                       onSubmit();
// //                                     }
// //                                   }
// //                                 },
// //                                 child: Text(
// //                                   AppLocalizations.of(context)?.translate('finalize_n_share') ??
// //                                       'Finalize & Share',
// //                                   style: AppTheme.getTextStyle(
// //                                     themeData.textTheme.subtitle1,
// //                                     fontWeight: 700,
// //                                     color: themeData.colorScheme.primary,
// //                                   ),
// //                                 ),
// //                               ),
// //                             ),
// //                             Padding(padding: EdgeInsets.symmetric(horizontal: MySize.size10!)),
// //                             Expanded(
// //                               flex: 1,
// //                               child: ElevatedButton(
// //                                 style: ElevatedButton.styleFrom(
// //                                     primary: themeData.colorScheme.primary, elevation: 5),
// //                                 onPressed: () {
// //                                   _printInvoice = true;
// //                                   if (pendingAmount >= 0.01) {
// //                                     alertPending(context);
// //                                     print('123456789623');
// //                                   } else {
// //                                     if (!saleCreated) {
// //                                       onSubmit();
// //                                     }
// //                                   }
// //                                 },
// //                                 child: Text(
// //                                   AppLocalizations.of(context)?.translate('finalize_n_print') ??
// //                                       'Finalize & Print',
// //                                   style: AppTheme.getTextStyle(
// //                                     themeData.textTheme.subtitle1,
// //                                     fontWeight: 700,
// //                                     color: themeData.colorScheme.onPrimary,
// //                                   ),
// //                                 ),
// //                               ),
// //                             )
// //                           ],
// //                         ),
// //                       ],
// //                     ),
// //                   )
// //                 ],
// //               ),
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// //
// //   block({Color? backgroundColor, String? subject, amount, Color? textColor}) {
// //     ThemeData themeData = Theme.of(context);
// //     return Card(
// //       clipBehavior: Clip.antiAliasWithSaveLayer,
// //       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(MySize.size8!)),
// //       child: Container(
// //         height: MySize.size30,
// //         child: Container(
// //           padding: EdgeInsets.all(MySize.size2!),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.end,
// //             children: <Widget>[
// //               Text(
// //                 subject!,
// //                 style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
// //                     color: themeData.colorScheme.onBackground, fontWeight: 800, muted: true),
// //               ),
// //               Text(
// //                 "$symbol $amount",
// //                 overflow: TextOverflow.ellipsis,
// //                 style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
// //                     color: textColor, fontWeight: 600, muted: true),
// //               ),
// //             ],
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   calculateMultiPayment() {
// //     totalPaying = 0.0;
// //     payments.forEach((element) {
// //       totalPaying += element['amount'];
// //     });
// //     if (totalPaying > invoiceAmount) {
// //       changeReturn = totalPaying - invoiceAmount;
// //       pendingAmount = 0.0;
// //     } else if (invoiceAmount > totalPaying) {
// //       pendingAmount = invoiceAmount - totalPaying;
// //       changeReturn = 0.0;
// //     } else {
// //       pendingAmount = 0.0;
// //       changeReturn = 0.0;
// //     }
// //     setState(() {});
// //   }
// //
// //   double calculateTipAmount() {
// //     double baseAmount = argument!['invoiceAmount']?.toDouble() ?? 0.00;
// //     double tip;
// //     if (selectedTipType == 'fixed') {
// //       tip = tip_amount;
// //     } else {
// //       tip = baseAmount * (tip_amount / 100.0);
// //     }
// //     return tip;
// //   }
// //
// //   setPaymentDetails() async {
// //     List payments = await System().get('payment_method', argument!['locationId']);
// //     payments.forEach((element) {
// //       setState(() {
// //         paymentMethods.add({
// //           'name': element['name'],
// //           'value': element['label'],
// //           'account_id': (element['account_id'] != null) ? int.parse(element['account_id'].toString()) : null
// //         });
// //       });
// //     });
// //   }
// //
// //   Future<void> onSubmit() async {
// //     setState(() {
// //       isLoading = true;
// //       saleCreated = true;
// //     });
// //     print('onSubmit: Starting sale submission for sellId: $sellId');
// //
// //     try {
// //       // Log token
// //       var token = await System().getToken();
// //       print('onSubmit: Token before processing: $token');
// //
// //       tip_amount = double.tryParse(tip_amountController.text) ?? 0.00;
// //       print('onSubmit: Parsed tip_amount: $tip_amount');
// //
// //       // Check database schema
// //       if (!hasTipTypeColumn) {
// //         print('onSubmit: Database schema outdated');
// //         Fluttertoast.showToast(
// //           msg: AppLocalizations.of(context)?.translate('schema_outdated') ??
// //               'Database schema outdated. Please update the app.',
// //           toastLength: Toast.LENGTH_LONG,
// //         );
// //         setState(() {
// //           isLoading = false;
// //           saleCreated = false;
// //         });
// //         return;
// //       }
// //
// //       // Log argument and products
// //       print('onSubmit: argument = $argument');
// //       print('onSubmit: products = ${argument!['products']}');
// //
// //       // Check database for sell lines
// //       var sellLines = await SellDatabase().getSellLineBySellId(sellId ?? 0);
// //       print('onSubmit: Sell lines for sellId $sellId: $sellLines');
// //
// //       // Prepare sell data
// //       Map<String, dynamic> sellData = {
// //         'invoiceNo': USERID.toString() + "_" + DateFormat('yMdHm').format(DateTime.now()),
// //         'transactionDate': transactionDate,
// //         'changeReturn': changeReturn,
// //         'contactId': argument!['customerId'],
// //         'tip_amount': calculateTipAmount(),
// //         'invoiceAmount': invoiceAmount,
// //         'locId': argument!['locationId'],
// //         'pending': pendingAmount,
// //         'saleNote': saleNote.text,
// //         'saleStatus': 'final',
// //         'sellId': sellId,
// //         'shippingCharges': (shippingCharges.text.isNotEmpty) ? double.parse(shippingCharges.text) : 0.00,
// //         'shippingDetails': shippingDetails.text,
// //         'staffNote': staffNote.text,
// //         'taxId': argument!['taxId'],
// //         'isQuotation': 0,
// //         'tip_type': selectedTipType,
// //       };
// //
// //       // Prepare products
// //       List<Map> products = argument!['products']?.map<Map>((product) {
// //         return {
// //           'product_id': product['product_id'],
// //           'variation_id': product['variation_id'],
// //           'quantity': product['quantity'],
// //           'unit_price': product['unit_price'],
// //           'tax_rate_id': product['tax_rate_id'],
// //           'discount_amount': product['discount_amount'] ?? 0.0,
// //           'discount_type': product['discount_type'] ?? 'fixed',
// //           'note': product['note'] ?? '',
// //           'product_order_category': product['product_order_category'] ?? 'BAR',
// //         };
// //       }).toList() ?? [];
// //
// //       // Validate products
// //       if (products.isEmpty) {
// //         print('onSubmit: Error: No products selected for the sale');
// //         Fluttertoast.showToast(
// //           msg: AppLocalizations.of(context)?.translate('no_products_selected') ??
// //               'Please add at least one product to the sale.',
// //           toastLength: Toast.LENGTH_LONG,
// //         );
// //         setState(() {
// //           isLoading = false;
// //           saleCreated = false;
// //         });
// //         return;
// //       }
// //
// //       // Prepare payments
// //       List<Map> updatedPayments = payments.map((payment) {
// //         return {
// //           'method': payment['method'],
// //           'amount': payment['amount'],
// //           'note': payment['note'] ?? '',
// //           'account_id': payment['account_id'],
// //           'received_amount': payment['received_amount'] ?? null,
// //           'change_return': payment['change_return'] ?? 0.0,
// //         };
// //       }).toList();
// //
// //       // Prepare API payload
// //       Map<String, dynamic> sellPayload = {
// //         'sells': [{
// //           'location_id': sellData['locId'],
// //           'contact_id': sellData['contactId'],
// //           'transaction_date': sellData['transactionDate'],
// //           'invoice_no': sellData['invoiceNo'],
// //           'status': sellData['saleStatus'],
// //           'sub_status': sellData['isQuotation'] == 1 ? 'quotation' : null,
// //           'tax_rate_id': sellData['taxId'] == 0 ? null : sellData['taxId'],
// //           'discount_amount': sellData['discount_amount'] ?? 0.0,
// //           'discount_type': sellData['discount_type'] ?? 'fixed',
// //           'change_return': sellData['changeReturn'],
// //           'products': products,
// //           'sale_note': sellData['saleNote'],
// //           'staff_note': sellData['staffNote'],
// //           'shipping_charges': sellData['shippingCharges'],
// //           'shipping_details': sellData['shippingDetails'],
// //           'tip_amount': sellData['tip_amount'].toString(),
// //           'tip_type': sellData['tip_type'],
// //           'is_quotation': sellData['isQuotation'],
// //           'payments': updatedPayments,
// //         }]
// //       };
// //
// //       print('onSubmit: Prepared sell payload: ${jsonEncode(sellPayload)}');
// //
// //       Map<String, dynamic> sell = await Sell().createSell(
// //         invoiceNo: sellData['invoiceNo'],
// //         transactionDate: sellData['transactionDate'],
// //         changeReturn: sellData['changeReturn'],
// //         contactId: sellData['contactId'],
// //         tip_amount: sellData['tip_amount'],
// //         invoiceAmount: sellData['invoiceAmount'],
// //         locId: sellData['locId'],
// //         pending: sellData['pending'],
// //         saleNote: sellData['saleNote'],
// //         saleStatus: sellData['saleStatus'],
// //         sellId: sellData['sellId'],
// //         shippingCharges: sellData['shippingCharges'],
// //         shippingDetails: sellData['shippingDetails'],
// //         staffNote: sellData['staffNote'],
// //         taxId: sellData['taxId'],
// //         isQuotation: sellData['isQuotation'],
// //         tip_type: hasTipTypeColumn ? sellData['tip_type'] : null,
// //       );
// //
// //       print('onSubmit: Created sell map: ${jsonEncode(sell)}');
// //
// //       int? response;
// //
// //       if (sellId != null) {
// //         print('onSubmit: Updating existing sell: $sellId');
// //         response = sellId;
// //         await SellDatabase().updateSells(sellId!, sell);
// //         print('onSubmit: Updated local sell: $sellId');
// //
// //         for (var element in updatedPayments) {
// //           if (element is Map<String, dynamic>) {
// //             if (element['id'] != null) {
// //               paymentLine = {
// //                 'amount': element['amount'],
// //                 'method': element['method'],
// //                 'note': element['note'],
// //                 'account_id': element['account_id'],
// //                 'received_amount': element['received_amount'],
// //                 'change_return': element['change_return'],
// //               };
// //               print('onSubmit: Updating payment line: ${element['id']}');
// //               await PaymentDatabase().updateEditedPaymentLine(element['id'], paymentLine);
// //             } else {
// //               paymentLine = {
// //                 'sell_id': sellId,
// //                 'method': element['method'],
// //                 'amount': element['amount'],
// //                 'note': element['note'],
// //                 'account_id': element['account_id'],
// //                 'received_amount': element['received_amount'],
// //                 'change_return': element['change_return'],
// //               };
// //               print('onSubmit: Storing new payment line for sell: $sellId');
// //               await PaymentDatabase().store(paymentLine);
// //             }
// //           } else {
// //             print('onSubmit: Invalid payment element: $element');
// //           }
// //         }
// //
// //         if (deletedPaymentId.isNotEmpty) {
// //           print('onSubmit: Deleting payment lines: $deletedPaymentId');
// //           await PaymentDatabase().deletePaymentLineByIds(deletedPaymentId);
// //         }
// //
// //         if (await Helper().checkConnectivity()) {
// //           print('onSubmit: Network available, attempting to sync sell: $sellId');
// //           print('onSubmit: Token before API call: $token');
// //           var apiResult = await Sell().createApiSell(sellId: sellId, payload: sellPayload).timeout(
// //             Duration(seconds: 30),
// //             onTimeout: () {
// //               print('onSubmit: API call timed out after 30 seconds');
// //               return {'error': 'API call timed out'};
// //             },
// //           );
// //           if (apiResult != null && !apiResult.containsKey('error')) {
// //             print('onSubmit: Sell synced successfully: $sellId, Result: $apiResult');
// //             await SellDatabase().updateSells(sellId!, {
// //               'is_synced': 1,
// //               'transaction_id': apiResult['transaction_id'],
// //               'invoice_url': apiResult['invoice_url'] ?? '',
// //               'tip_type': apiResult['tip_type'] ?? 'fixed',
// //               'tip_amount': apiResult['tip_amount']?.toString() ?? '0.00',
// //             });
// //             Fluttertoast.showToast(
// //               msg: AppLocalizations.of(context)?.translate('sell_synced') ?? 'Sell synced successfully',
// //               toastLength: Toast.LENGTH_LONG,
// //             );
// //           } else {
// //             print('onSubmit: Failed to sync sell: $sellId, Error: ${apiResult?['error'] ?? 'Unknown error'}');
// //             Fluttertoast.showToast(
// //               msg: AppLocalizations.of(context)?.translate('api_error_will_sync_later') ??
// //                   'Failed to sync: ${apiResult?['error'] ?? 'Unknown error'}',
// //               toastLength: Toast.LENGTH_LONG,
// //             );
// //           }
// //         } else {
// //           print('onSubmit: No connectivity, storing sell locally: $sellId');
// //           Fluttertoast.showToast(
// //             msg: AppLocalizations.of(context)?.translate('no_connectivity') ??
// //                 'No internet connection, stored locally',
// //             toastLength: Toast.LENGTH_LONG,
// //           );
// //         }
// //       } else {
// //         print('onSubmit: Creating new sell');
// //         response = await SellDatabase().storeSell(sell);
// //         print('onSubmit: Stored sell locally: $response');
// //
// //         for (var product in products) {
// //           await SellDatabase().store({
// //             'sell_id': response,
// //             ...product,
// //             'is_completed': 1,
// //           });
// //         }
// //         await Sell().makePayment(updatedPayments, response);
// //         await SellDatabase().updateSellLine({'sell_id': response, 'is_completed': 1});
// //
// //         if (await Helper().checkConnectivity()) {
// //           print('onSubmit: Network available, attempting to sync sell: $response');
// //           print('onSubmit: Token before API call: $token');
// //           var apiResult = await Sell().createApiSell(sellId: response, payload: sellPayload).timeout(
// //             Duration(seconds: 30),
// //             onTimeout: () {
// //               print('onSubmit: API call timed out after 30 seconds');
// //               return {'error': 'API call timed out'};
// //             },
// //           );
// //           if (apiResult != null && !apiResult.containsKey('error')) {
// //             print('onSubmit: Sell synced successfully: $response, Result: $apiResult');
// //             await SellDatabase().updateSells(response, {
// //               'is_synced': 1,
// //               'transaction_id': apiResult['transaction_id'],
// //               'invoice_url': apiResult['invoice_url'] ?? '',
// //               'tip_type': apiResult['tip_type'] ?? 'fixed',
// //               'tip_amount': apiResult['tip_amount']?.toString() ?? '0.00',
// //             });
// //             Fluttertoast.showToast(
// //               msg: AppLocalizations.of(context)?.translate('sell_synced') ?? 'Sell synced successfully',
// //               toastLength: Toast.LENGTH_LONG,
// //             );
// //           } else {
// //             print('onSubmit: Failed to sync sell: $response, Error: ${apiResult?['error'] ?? 'Unknown error'}');
// //             Fluttertoast.showToast(
// //               msg: AppLocalizations.of(context)?.translate('api_error_will_sync_later') ??
// //                   'Failed to sync: ${apiResult?['error'] ?? 'Unknown error'}',
// //               toastLength: Toast.LENGTH_LONG,
// //             );
// //           }
// //         } else {
// //           print('onSubmit: No connectivity, storing sell locally: $response');
// //           Fluttertoast.showToast(
// //             msg: AppLocalizations.of(context)?.translate('no_connectivity') ??
// //                 'No internet connection, stored locally',
// //             toastLength: Toast.LENGTH_LONG,
// //           );
// //         }
// //       }
// //     } catch (e, stackTrace) {
// //       print('onSubmit: Error: $e');
// //       print('onSubmit: Stack Trace: $stackTrace');
// //       Fluttertoast.showToast(
// //         msg: AppLocalizations.of(context)?.translate('error_submitting_sale') ??
// //             'Error submitting sale: $e',
// //         toastLength: Toast.LENGTH_LONG,
// //       );
// //     } finally {
// //       setState(() {
// //         isLoading = false;
// //         saleCreated = false;
// //       });
// //       print('onSubmit: Completed');
// //     }
// //   }
// //
// //
// //   Future<void> checkLocalSell(int sellId) async {
// //     try {
// //       var sells = await SellDatabase().getSellBySellId(sellId);
// //       print('Local Sell: ${jsonEncode(sells)}');
// //       if (sells is List && sells.isNotEmpty && sells[0] is Map<String, dynamic>) {
// //         print('Local Sell Details: ${sells[0]}');
// //       } else {
// //         print('Error: Invalid sell data format for sellId: $sellId, got: ${sells.runtimeType}');
// //       }
// //     } catch (e) {
// //       print('Error in checkLocalSell: $e');
// //     }
// //   }
// //
// //   Future<void> printOption(int sellId) async {
// //     try {
// //       print('printOption called with sellId: $sellId');
// //       var sells = await SellDatabase().getSellBySellId(sellId);
// //       if (sells.isEmpty || sells[0] is! Map<String, dynamic>) {
// //         print('Error: Sell not found or invalid format for ID: $sellId');
// //         Fluttertoast.showToast(
// //           msg: AppLocalizations.of(context)?.translate('error_generating_invoice') ??
// //               'Error generating invoice',
// //         );
// //         return;
// //       }
// //
// //       var sell = sells[0];
// //       String? invoiceUrl = sell['invoice_url'];
// //       bool isSynced = sell['is_synced'] == 1;
// //
// //       if (isSynced && invoiceUrl != null && invoiceUrl.isNotEmpty) {
// //         print('Opening invoice URL: $invoiceUrl');
// //         Fluttertoast.showToast(
// //           msg: 'Invoice generated: $invoiceUrl',
// //         );
// //       } else {
// //         print('Generating local invoice for sell: $sellId');
// //         String invoiceHtml = await InvoiceFormatter().generateInvoice(
// //           sellId,
// //           sell['tax_rate_id'],
// //           context,
// //         );
// //         print('Local Invoice Content: $invoiceHtml');
// //
// //         showDialog(
// //           context: context,
// //           builder: (context) => AlertDialog(
// //             title: Text('Invoice #${sell['invoice_no']}'),
// //             content: SizedBox(
// //               width: double.maxFinite,
// //               height: 400,
// //               child: WebView(
// //                 initialUrl: 'data:text/html;base64,${base64Encode(utf8.encode(invoiceHtml))}',
// //                 javascriptMode: JavascriptMode.unrestricted,
// //               ),
// //             ),
// //             actions: [
// //               TextButton(
// //                 onPressed: () async {
// //                   await Printing.layoutPdf(
// //                     onLayout: (format) async => await Printing.convertHtml(
// //                       format: format,
// //                       html: invoiceHtml,
// //                     ),
// //                   );
// //                 },
// //                 child: Text('Print'),
// //               ),
// //               TextButton(
// //                 onPressed: () => Navigator.pop(context),
// //                 child: Text('Close'),
// //               ),
// //             ],
// //           ),
// //         );
// //         Fluttertoast.showToast(
// //           msg: 'Local invoice generated (unsynced): ${sell['invoice_no']}',
// //         );
// //       }
// //     } catch (e) {
// //       print('Error in printOption: $e');
// //       Fluttertoast.showToast(
// //         msg: AppLocalizations.of(context)?.translate('error_generating_invoice') ??
// //             'Error generating invoice',
// //       );
// //     }
// //   }
// //
// //   alertPending(BuildContext context) {
// //     AlertDialog alert = AlertDialog(
// //       content: Text(
// //           AppLocalizations.of(context)?.translate('pending_message') ??
// //               'Pending amount exists. Proceed?',
// //           style: AppTheme.getTextStyle(
// //               themeData.textTheme.bodyText2,
// //               color: themeData.colorScheme.onBackground,
// //               fontWeight: 500,
// //               muted: true)),
// //       actions: <Widget>[
// //         TextButton(
// //             style: TextButton.styleFrom(
// //                 primary: themeData.colorScheme.onPrimary, backgroundColor: themeData.colorScheme.primary),
// //             onPressed: () {
// //               Navigator.pop(context);
// //               if (!saleCreated) {
// //                 onSubmit();
// //               }
// //             },
// //             child: Text(AppLocalizations.of(context)?.translate('ok') ?? 'OK')),
// //         TextButton(
// //             style: TextButton.styleFrom(
// //                 primary: themeData.colorScheme.primary, backgroundColor: themeData.colorScheme.onPrimary),
// //             onPressed: () {
// //               Navigator.pop(context);
// //             },
// //             child: Text(AppLocalizations.of(context)?.translate('cancel') ?? 'Cancel'))
// //       ],
// //     );
// //     showDialog(
// //       barrierDismissible: true,
// //       context: context,
// //       builder: (BuildContext context) => alert,
// //     );
// //   }
// //
// //   alertConfirm(BuildContext context, index) {
// //     AlertDialog alert = AlertDialog(
// //       title: Icon(MdiIcons.alert, color: Colors.red, size: MySize.size50),
// //       content: Text(
// //           AppLocalizations.of(context)?.translate('are_you_sure') ?? 'Are you sure?',
// //           textAlign: TextAlign.center,
// //           style: AppTheme.getTextStyle(
// //               themeData.textTheme.bodyText1,
// //               color: themeData.colorScheme.onBackground,
// //               fontWeight: 600,
// //               muted: true)),
// //       actions: <Widget>[
// //         TextButton(
// //             style: TextButton.styleFrom(
// //                 primary: themeData.colorScheme.primary, backgroundColor: themeData.colorScheme.onPrimary),
// //             onPressed: () {
// //               Navigator.pop(context);
// //             },
// //             child: Text(AppLocalizations.of(context)?.translate('cancel') ?? 'Cancel')),
// //         TextButton(
// //             style: TextButton.styleFrom(
// //                 backgroundColor: Colors.red, primary: themeData.colorScheme.onError),
// //             onPressed: () {
// //               Navigator.pop(context);
// //               if (sellId != null && payments[index]['id'] != null) {
// //                 deletedPaymentId.add(payments[index]['id']);
// //               }
// //               payments.removeAt(index);
// //               calculateMultiPayment();
// //             },
// //             child: Text(AppLocalizations.of(context)?.translate('ok') ?? 'OK'))
// //       ],
// //     );
// //     showDialog(
// //       barrierDismissible: true,
// //       context: context,
// //       builder: (BuildContext context) => alert,
// //     );
// //   }
// //
// //   Widget tipDropdown() {
// //     return DropdownButtonHideUnderline(
// //       child: DropdownButton(
// //           dropdownColor: themeData.backgroundColor,
// //           icon: Icon(Icons.arrow_drop_down),
// //           value: selectedTipType,
// //           items: <String>['fixed', 'percentage'].map<DropdownMenuItem<String>>((String value) {
// //             return DropdownMenuItem<String>(
// //               value: value,
// //               child: Text(
// //                 value,
// //                 softWrap: true,
// //                 overflow: TextOverflow.ellipsis,
// //                 style: AppTheme.getTextStyle(
// //                     themeData.textTheme.bodyText1,
// //                     color: themeData.colorScheme.onBackground,
// //                     fontWeight: 600,
// //                     muted: true),
// //               ),
// //             );
// //           }).toList(),
// //           onChanged: (newValue) {
// //             setState(() {
// //               selectedTipType = newValue.toString();
// //               invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
// //                   (double.tryParse(shippingCharges.text) ?? 0.00) +
// //                   calculateTipAmount();
// //               calculateMultiPayment();
// //             });
// //           }),
// //     );
// //   }
// //
// //   Widget inLinetip(index) {
// //     return DropdownButtonHideUnderline(
// //       child: DropdownButton(
// //           dropdownColor: themeData.backgroundColor,
// //           icon: Icon(Icons.arrow_drop_down),
// //           value: index['tip_type'],
// //           items: <String>['fixed', 'percentage'].map<DropdownMenuItem<String>>((String value) {
// //             return DropdownMenuItem<String>(
// //               value: value,
// //               child: Text(value),
// //             );
// //           }).toList(),
// //           onChanged: (newValue) {
// //             if (hasTipTypeColumn) {
// //               SellDatabase().update(index['id'], {'tip_type': '$newValue'});
// //             }
// //           }),
// //     );
// //   }
// // }
//

import 'dart:async';
import 'dart:convert';

import 'package:date_time_picker/date_time_picker.dart';
import 'package:dev/apis/api.dart';
import 'package:dev/config.dart';
import 'package:dev/pages/login.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:printing/printing.dart';
import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:sqflite/sqflite.dart';

import '../apis/sell.dart';
import '../apis/contact_payment.dart';
import '../helpers/AppTheme.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/TableAvailabilityManager.dart';
import '../helpers/otherHelpers.dart';
import '../helpers/context_manager.dart';
import '../helpers/Responsive_helper.dart';
import '../locale/MyLocalizations.dart';
import '../models/database.dart';
import '../models/invoice.dart';
import '../models/paymentDatabase.dart';
import '../models/sell.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import 'Tables.dart';
import 'event_bus.dart';

class CheckOut extends StatefulWidget {
  @override
  CheckOutState createState() => CheckOutState();
}

class CheckOutState extends State<CheckOut> {
  // Add these variables at the top
  String? _tableName;
  bool _isShipping = false;
  bool _isInitialized = false;
  bool _fromSalesScreen = false; // Flag to track if user navigated from sales screen
  double _initialTipAmount = 0.0; // Track initial tip amount when navigating from sales screen
  double _initialShippingCharge = 0.0; // Track initial shipping charge when navigating from sales screen


  List<Map> paymentMethods = [];
  List<Map> payments = [],
      paymentAccounts = [
        {'id': null, 'name': "None"}
      ];
  List<int> deletedPaymentId = [];
  List sellDetail = [];

  int? sellId;
  int? res_table_id; //new added

  double totalPaying = 0.0;
  late double tip_amount = 0.00, maxtipValue;
  late double invoiceAmount = 0.00, pendingAmount = 0.00, changeReturn = 0.00;

  String symbol = '',
      invoiceType = "Mobile",
      transactionDate =
      DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());
  String selectedTipType = "fixed";

  Map? argument;
  late Map<String, dynamic> paymentLine;

  bool _isTipAmountEdited = false;
  bool _isShippingChargeEdited = false;
  bool _tipWarningShown = false;
  bool proceedNext = true;
  bool hasTipTypeColumn = false;
  bool _printInvoice = true,
      printWebInvoice = false,
      saleCreated = false,
      isLoading = false;

  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
  CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);

  TextEditingController dateController = TextEditingController(),
      saleNote = TextEditingController(),
      staffNote = TextEditingController(),
      shippingDetails = TextEditingController(),
      shippingCharges = TextEditingController();
  TextEditingController tip_amountController = TextEditingController();

  @override
  void initState() {
    super.initState();
    debugPrint('CheckOut: initState called, clearing controllers');

    // Reset initialization flag
    _isInitialized = false;

    // Clear all TextEditingControllers
    saleNote.clear();
    staffNote.clear();
    shippingDetails.clear();
    shippingCharges.clear();
    AppConstants.cartData.clear();

    getInitDetails();
    tip_amountController.clear();
    checkTipTypeColumn();
  }

  // Check if tip_type column exists in sell table
  Future<void> checkTipTypeColumn() async {
    try {
      var db = await DbProvider().database;
      hasTipTypeColumn = await DbProvider().checkSchema();
      if (!hasTipTypeColumn) {
        print('Warning: tip_type column not found in sell table');
      }
      setState(() {});
    } catch (e) {
      print('Error checking tip_type column: $e');
      setState(() {
        hasTipTypeColumn = false;
      });
    }
  }

  getInitDetails() async {
    setState(() {
      isLoading = true;
    });
    await Helper().getFormattedBusinessDetails().then((value) {
      symbol = value['symbol'];
      maxtipValue =
          double.tryParse(value['max_tip_value']?.toString() ?? '100.0') ??
              100.0;
      setState(() {
        isLoading = false;
      });
    });
  }

  setPaymentAccounts() async {
    List payments =
    await System().get('payment_method', argument!['locationId']);
    await System().getPaymentAccounts().then((value) {
      value.forEach((element) {
        List<String> accIds = [];
        payments.forEach((paymentMethod) {
          if ((paymentMethod['account_id'].toString() ==
              element['id'].toString()) &&
              !accIds.contains(element['id'].toString())) {
            setState(() {
              paymentAccounts
                  .add({'id': element['id'], 'name': element['name']});
              accIds.add(element['id'].toString());
            });
          }
        });
      });
    });
  }

// //   // //@override
// //   // // void didChangeDependencies() {
// //   // //   argument = ModalRoute.of(context)!.settings.arguments as Map?;
// //   // //   debugPrint('CheckOut: Received arguments: $argument');
// //   // //
// //   // //   if (argument == null || argument!['sellId'] == null || argument!['locationId'] == null) {
// //   // //     debugPrint('CheckOut: Invalid or missing arguments');
// //   // //     Fluttertoast.showToast(
// //   // //       msg: AppLocalizations.of(context)?.translate('invalid_arguments') ?? 'Invalid arguments',
// //   // //       toastLength: Toast.LENGTH_LONG,
// //   // //     );
// //   // //     Navigator.pop(context);
// //   // //     return;
// //   // //   }
// //   // //
// //   // //   // Clear controllers if clearFields is true or sellId is null (new sale)
// //   // //   if (argument!['clearFields'] == true || argument!['sellId'] == null) {
// //   // //     debugPrint('CheckOut: Clearing controllers due to clearFields flag or new sale');
// //   // //     saleNote.clear();
// //   // //     staffNote.clear();
// //   // //     shippingDetails.clear();
// //   // //     shippingCharges.clear();
// //   // //     tip_amountController.text = '0.00';
// //   // //   }
// //   // //
// //   // //   invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
// //   // //       (double.tryParse(tip_amountController.text) ?? 0.00) +
// //   // //       (double.tryParse(shippingCharges.text) ?? 0.00);
// //   // //
// //   // //   sellId = argument!['sellId'];
// //   // //   res_table_id = argument?['res_table_id'];     //new added
// //   // //
// //   // //   debugPrint('CheckOut: Initialized with sellId: $sellId, res_table_id: $res_table_id, invoiceAmount: $invoiceAmount');
// //   // //
// //   // //   setPaymentAccounts().then((value) {
// //   // //     if (argument!['sellId'] == null) {
// //   // //       setPaymentDetails().then((value) {
// //   // //         //new add
// //   // //         payments.clear(); // Clear any existing payments
// //   // //         payments.add({
// //   // //           'amount': invoiceAmount,
// //   // //           'method': paymentMethods[0]['name'],
// //   // //           'note': '',
// //   // //           'account_id': paymentMethods[0]['account_id'],
// //   // //           'received_amount': null,
// //   // //           'change_return': 0.0,
// //   // //           'card_details': null,
// //   // //         });
// //   // //         calculateMultiPayment();
// //   // //       });
// //   // //     } else {
// //   // //       setPaymentDetails().then((value) {
// //   // //         onEdit(argument!['sellId']);
// //   // //       });
// //   // //     }
// //   // //   });
// //   // //   super.didChangeDependencies();
// //   // // }
// //   // @override
// //   // void didChangeDependencies() {
// //   //   argument = ModalRoute.of(context)!.settings.arguments as Map?;
// //   //   debugPrint('CheckOut: Received arguments: $argument');
// //   //
// //   //   if (argument == null || argument!['sellId'] == null || argument!['locationId'] == null) {
// //   //     debugPrint('CheckOut: Invalid or missing arguments');
// //   //     Fluttertoast.showToast(
// //   //       msg: AppLocalizations.of(context)?.translate('invalid_arguments') ?? 'Invalid arguments',
// //   //       toastLength: Toast.LENGTH_LONG,
// //   //     );
// //   //     Navigator.pop(context);
// //   //     return;
// //   //   }
// //   //
// //   //   // Clear controllers if clearFields is true or sellId is null (new sale)
// //   //   if (argument!['clearFields'] == true || argument!['sellId'] == null) {
// //   //     debugPrint('CheckOut: Clearing controllers due to clearFields flag or new sale');
// //   //     saleNote.clear();
// //   //     staffNote.clear();
// //   //     shippingDetails.clear();
// //   //     shippingCharges.clear();
// //   //     tip_amountController.text = '0.00';
// //   //   }
// //   //
// //   //   invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
// //   //       (double.tryParse(tip_amountController.text) ?? 0.00) +
// //   //       (double.tryParse(shippingCharges.text) ?? 0.00);
// //   //
// //   //   sellId = argument!['sellId'];
// //   //   res_table_id = argument?['res_table_id'];
// //   //   debugPrint('CheckOut: Initialized with sellId: $sellId, res_table_id: $res_table_id, invoiceAmount: $invoiceAmount');
// //   //
// //   //   // Initialize payments list and fetch payment methods
// //   //   setState(() {
// //   //     isLoading = true;
// //   //   });
// //   //
// //   //   setPaymentAccounts().then((_) {
// //   //     setPaymentDetails().then((_) {
// //   //       setState(() {
// //   //         payments.clear(); // Clear any existing payments
// //   //
// //   //         if (argument!['sellId'] == null) {
// //   //           // New sale: Initialize with a default payment
// //   //           //setState(() {
// //   //             if (paymentMethods.isNotEmpty) {
// //   //               payments.add({
// //   //                 'amount': invoiceAmount,
// //   //                 'method': paymentMethods[0]['name'],
// //   //                 'note': '',
// //   //                 'account_id': paymentMethods[0]['account_id'],
// //   //                 'received_amount': null,
// //   //                 'change_return': 0.0,
// //   //                 'card_details': null,
// //   //               });
// //   //               debugPrint('CheckOut: Automatically added payment with amount: $invoiceAmount');
// //   //               calculateMultiPayment();
// //   //             }
// //   //             isLoading = false;
// //   //           //});
// //   //         }
// //   //         else {
// //   //           // Existing sale: Fetch and populate payments
// //   //           onEdit(argument!['sellId']).then((_) {
// //   //             setState(() {
// //   //               isLoading = false;
// //   //             });
// //   //           });
// //   //         }
// //   //         isLoading = false;
// //   //       });
// //   //     });
// //   //   });
// //   //   super.didChangeDependencies();
// //   // }
// //   @override
// //   void didChangeDependencies() async {
// //
// //     // Prevent multiple initializations
// //     if (_isInitialized) {
// //       super.didChangeDependencies();
// //       return;
// //     }
// //
// //     argument = ModalRoute.of(context)!.settings.arguments as Map?;
// //     debugPrint('CheckOut: Received arguments: $argument');
// //
// //     // Try to get context from arguments first, then fallback to saved context
// //     Map<String, dynamic>? contextData = argument?.cast<String, dynamic>();
// //     if (contextData == null || contextData['sellId'] == null || contextData['locationId'] == null) {
// //       // Try to get saved context
// //       contextData = await ContextManager.getValidContext();
// //       if (contextData != null) {
// //         debugPrint('CheckOut: Using saved context: $contextData');
// //         // Update the argument with context data for consistency
// //         if (argument == null) {
// //           argument = contextData;
// //         } else {
// //           // Merge context data into existing arguments
// //           argument = {...argument!, ...contextData};
// //         }
// //       }
// //     }
// //
// //     // Extract table/shipping info from arguments
// //     _tableName = argument?['tableName'];
// //     _isShipping = argument?['is_shipping'] == 1;
// //     _fromSalesScreen = argument?['fromSalesScreen'] == true; // Check if navigated from sales screen
// //
// //     // Store initial values when navigating from sales screen
// //     if (_fromSalesScreen) {
// //       _initialTipAmount = double.tryParse(tip_amountController.text) ?? 0.0;
// //       _initialShippingCharge = double.tryParse(shippingCharges.text) ?? 0.0;
// //     }
// //
// //     debugPrint('CheckOut: tableName=$_tableName, isShipping=$_isShipping');
// //
// //     if (argument == null || argument!['locationId'] == null) {
// //       debugPrint('CheckOut: Invalid or missing arguments');
// //       Fluttertoast.showToast(
// //         msg: AppLocalizations.of(context)?.translate('invalid_arguments') ??
// //             'Invalid arguments',
// //         toastLength: Toast.LENGTH_LONG,
// //       );
// //       Navigator.pop(context);
// //       return;
// //     }
// //
// //     // Initialize values
// //     invoiceAmount = argument!['invoiceAmount']?.toDouble() ?? 0.00;
// //     sellId = argument!['sellId'];
// //     res_table_id = argument?['res_table_id'];
// //
// //     // Debug: Log the sellId type and value
// //     debugPrint('CheckOut: sellId=$sellId, type=${sellId.runtimeType}, res_table_id=$res_table_id');
// //
// //     setState(() {
// //       isLoading = true;
// //     });
// //
// //     try {
// //       // Load payment methods and accounts first
// //       await setPaymentAccounts();
// //       await setPaymentDetails();
// //
// //       // Initialize payments only if empty
// //       if (payments.isEmpty) {
// //         if (paymentMethods.isNotEmpty) {
// //           payments = [
// //             {
// //               'amount': invoiceAmount,
// //               'method': paymentMethods[0]['name'],
// //               'note': '',
// //               'account_id': paymentMethods[0]['account_id'],
// //               'received_amount': null,
// //               'change_return': 0.0,
// //               'card_details': null,
// //             }
// //           ];
// //           debugPrint('Initialized payment with amount: $invoiceAmount');
// //         }
// //       }
// //
// //       // For existing sales, load their payments (will override if needed)
// //       if (sellId != null) {
// //         await onEdit(sellId!);
// //       }
// //
// //       calculateMultiPayment();
// //     } catch (e) {
// //       debugPrint('Error in payment initialization: $e');
// //       // Fluttertoast.showToast(
// //       //   msg: 'Error initializing payments',
// //       //   toastLength: Toast.LENGTH_LONG,
// //       //);
// //     } finally {
// //       setState(() {
// //         isLoading = false;
// //         _isInitialized = true; // Mark as initialized
// //
// //       });
// //     }
// //
// //
// //
// //
// // // Ensure cart items are saved for Sales → Checkout navigation
// //     if (_fromSalesScreen && sellId != null && argument!['products'] != null) {
// //       List<dynamic> productsFromArgs = argument!['products'] ?? [];
// //       if (productsFromArgs.isNotEmpty) {
// //         debugPrint('Checkout: Ensuring cart items are saved for Sales → Checkout navigation');
// //
// //         await Sell().ensureCartItemsForSalesToCheckout(
// //           sellId: sellId!,
// //           resTableId: res_table_id,
// //           isShipping: argument!['is_shipping'] ?? 0,
// //           products: productsFromArgs.cast<Map<String, dynamic>>(),
// //         );
// //       }
// //     }
// //
// //
// //
// //
// //
// //
// //
// //
// //     super.didChangeDependencies();
// //   }
//
//     @override
//   void didChangeDependencies() async {
//     // Prevent multiple initializations
//     if (_isInitialized) {
//       super.didChangeDependencies();
//       return;
//     }
//
//     argument = ModalRoute.of(context)!.settings.arguments as Map?;
//     debugPrint('CheckOut: Received arguments: $argument');
//
//     // Try to get context from arguments first, then fallback to table-specific saved context
//     Map<String, dynamic>? contextData = argument?.cast<String, dynamic>();
//     if (contextData == null || contextData['sellId'] == null || contextData['locationId'] == null) {
//       // Try to get table-specific saved context
//       contextData = await ContextManager.getValidContext(
//         resTableId: argument?['res_table_id'],
//         isShipping: argument?['is_shipping'],
//       );
//
//       if (contextData != null) {
//         debugPrint('CheckOut: Using table-specific context: $contextData');
//         // Update the argument with context data for consistency
//         if (argument == null) {
//           argument = contextData;
//         } else {
//           // Merge context data into existing arguments
//           argument = {...argument!, ...contextData};
//         }
//       }
//     }
//
//     // Extract table/shipping info from arguments
//     _tableName = argument?['tableName'];
//     _isShipping = argument?['is_shipping'] == 1;
//     _fromSalesScreen = argument?['fromSalesScreen'] == true; // Check if navigated from sales screen
//
//     // Store initial values when navigating from sales screen
//     if (_fromSalesScreen) {
//       _initialTipAmount = double.tryParse(tip_amountController.text) ?? 0.0;
//       _initialShippingCharge = double.tryParse(shippingCharges.text) ?? 0.0;
//     }
//
//     debugPrint('CheckOut: tableName=$_tableName, isShipping=$_isShipping, fromSalesScreen=$_fromSalesScreen');
//
//     if (argument == null || argument!['locationId'] == null) {
//       debugPrint('CheckOut: Invalid or missing arguments');
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context)?.translate('invalid_arguments') ??
//             'Invalid arguments',
//         toastLength: Toast.LENGTH_LONG,
//       );
//       Navigator.pop(context);
//       return;
//     }
//
//     // Initialize values
//     invoiceAmount = argument!['invoiceAmount']?.toDouble() ?? 0.00;
//     sellId = argument!['sellId'];
//     res_table_id = argument?['res_table_id'];
//
//     // Debug: Log the sellId type and value
//     debugPrint('CheckOut: sellId=$sellId, type=${sellId.runtimeType}, res_table_id=$res_table_id');
//
//     setState(() {
//       isLoading = true;
//     });
//
//     try {
//       // Load payment methods and accounts first
//       await setPaymentAccounts();
//       await setPaymentDetails();
//
//       // Initialize payments only if empty
//       if (payments.isEmpty) {
//         if (paymentMethods.isNotEmpty) {
//           payments = [
//             {
//               'amount': invoiceAmount,
//               'method': paymentMethods[0]['name'],
//               'note': '',
//               'account_id': paymentMethods[0]['account_id'],
//               'received_amount': null,
//               'change_return': 0.0,
//               'card_details': null,
//             }
//           ];
//           debugPrint('Initialized payment with amount: $invoiceAmount');
//         }
//       }
//
//       // For existing sales, load their payments (will override if needed)
//       if (sellId != null) {
//         await onEdit(sellId!);
//       }
//
//       calculateMultiPayment();
//
//       // Ensure cart items are saved for Sales → Checkout navigation with correct table context
//       if (_fromSalesScreen && sellId != null && argument!['products'] != null) {
//         List<dynamic> productsFromArgs = argument!['products'] ?? [];
//         if (productsFromArgs.isNotEmpty) {
//           debugPrint('Checkout: Ensuring cart items are saved for Sales → Checkout navigation for table ${argument!['res_table_id']}');
//
//           // Convert to List<Map> for the method call
//           List<Map> productsList = productsFromArgs.cast<Map>();
//
//           await Sell().ensureCartItemsForSalesToCheckout(
//             sellId: sellId!,
//             resTableId: argument!['res_table_id'],
//             isShipping: argument!['is_shipping'] ?? 0,
//             products: productsList,
//           );
//
//           // Verify the cart items were saved
//           List<Map> savedCartItems = await Sell().getCartItems(sellId, argument!['res_table_id']);
//           debugPrint('Checkout: Verified ${savedCartItems.length} cart items saved for table ${argument!['res_table_id']}');
//         }
//       }
//
//     } catch (e) {
//       debugPrint('Error in payment initialization: $e');
//       Fluttertoast.showToast(
//         msg: 'Error initializing payment data: ${e.toString()}',
//         toastLength: Toast.LENGTH_LONG,
//       );
//     } finally {
//       setState(() {
//         isLoading = false;
//         _isInitialized = true; // Mark as initialized
//       });
//     }
//
//     // Debug: Log the final context state
//     await ContextManager.debugContextState();
//
//     super.didChangeDependencies();
//   }

  @override
  void didChangeDependencies() async {
    // Prevent multiple initializations
    if (_isInitialized) {
      super.didChangeDependencies();
      return;
    }

    argument = ModalRoute.of(context)!.settings.arguments as Map?;
    debugPrint('CheckOut: Received arguments: $argument');

    // Try to get context from arguments first, then fallback to specific saved context
    Map<String, dynamic>? contextData = argument?.cast<String, dynamic>();
    if (contextData == null || contextData['sellId'] == null || contextData['locationId'] == null) {
      // Determine if this is a shipping order or table order
      bool isShippingOrder = argument?['is_shipping'] == 1;

      // Try to get specific saved context based on order type
      if (isShippingOrder) {
        contextData = await ContextManager.getShippingContext();
        debugPrint('CheckOut: Looking for shipping context');
      } else {
        contextData = await ContextManager.getValidContext(
          resTableId: argument?['res_table_id'],
          isShipping: argument?['is_shipping'],
        );
        debugPrint('CheckOut: Looking for table context for res_table_id: ${argument?['res_table_id']}');
      }

      if (contextData != null) {
        debugPrint('CheckOut: Using specific context: $contextData');
        // Update the argument with context data for consistency
        if (argument == null) {
          argument = contextData;
        } else {
          // Merge context data into existing arguments
          argument = {...argument!, ...contextData};
        }
      }
    }

    // Extract table/shipping info from arguments
    _tableName = argument?['tableName'];
    _isShipping = argument?['is_shipping'] == 1;
    _fromSalesScreen = argument?['fromSalesScreen'] == true;

    // Store initial values when navigating from sales screen
    if (_fromSalesScreen) {
      _initialTipAmount = double.tryParse(tip_amountController.text) ?? 0.0;
      _initialShippingCharge = double.tryParse(shippingCharges.text) ?? 0.0;
    }

    debugPrint('CheckOut: tableName=$_tableName, isShipping=$_isShipping, fromSalesScreen=$_fromSalesScreen');

    if (argument == null || argument!['locationId'] == null) {
      debugPrint('CheckOut: Invalid or missing arguments');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context)?.translate('invalid_arguments') ??
            'Invalid arguments',
        toastLength: Toast.LENGTH_LONG,
      );
      Navigator.pop(context);
      return;
    }

    // Initialize values
    invoiceAmount = argument!['invoiceAmount']?.toDouble() ?? 0.00;
    sellId = argument!['sellId'];
    res_table_id = argument?['res_table_id'];

    // For shipping orders, ensure res_table_id is 0
    if (_isShipping && res_table_id != 0) {
      res_table_id = 0;
      debugPrint('CheckOut: Corrected shipping order res_table_id to 0');
    }

    // Debug: Log the order details
    String orderType = _isShipping ? 'SHIPPING' : 'TABLE $res_table_id';
    debugPrint('CheckOut: Processing $orderType order - sellId=$sellId, res_table_id=$res_table_id');

    setState(() {
      isLoading = true;
    });

    try {
      // Load payment methods and accounts first
      await setPaymentAccounts();
      await setPaymentDetails();

      // Initialize payments only if empty
      if (payments.isEmpty) {
        if (paymentMethods.isNotEmpty) {
          payments = [
            {
              'amount': invoiceAmount,
              'method': paymentMethods[0]['name'],
              'note': '',
              'account_id': paymentMethods[0]['account_id'],
              'received_amount': null,
              'change_return': 0.0,
              'card_details': null,
            }
          ];
          debugPrint('Initialized payment with amount: $invoiceAmount');
        }
      }

      // CRITICAL: When coming from Sales screen, update local database with latest sale data from arguments
      // This ensures the updated sale data (status, payment_status, etc.) is stored before proceeding
      if (_fromSalesScreen && sellId != null && argument != null) {
        debugPrint('Checkout: Updating local database with latest sale data from Sales screen');

        Map<String, dynamic> updateData = {};

        // Update transaction_id if provided
        if (argument!['transaction_id'] != null) {
          updateData['transaction_id'] = argument!['transaction_id'].toString();
        }

        // Update status and payment_status if provided
        if (argument!['status'] != null) {
          updateData['status'] = argument!['status'];
          updateData['sale_status'] = argument!['status'];
        }
        if (argument!['payment_status'] != null) {
          updateData['status'] = argument!['payment_status'];
          updateData['sale_status'] = argument!['payment_status'];
        }

        // Update transaction_date if provided
        if (argument!['transaction_date'] != null) {
          updateData['transaction_date'] = argument!['transaction_date'];
        }

        // Update notes if provided
        if (argument!['sale_note'] != null) {
          updateData['sale_note'] = argument!['sale_note'];
        }
        if (argument!['staff_note'] != null) {
          updateData['staff_note'] = argument!['staff_note'];
        }

        // Update shipping data if provided
        if (argument!['shipping_charges'] != null) {
          updateData['shipping_charges'] = argument!['shipping_charges'];
        }
        if (argument!['shipping_details'] != null) {
          updateData['shipping_details'] = argument!['shipping_details'];
        }

        // Update tip data if provided
        if (argument!['tip_amount'] != null) {
          updateData['tip_amount'] = argument!['tip_amount'];
        }
        if (argument!['tip_type'] != null && hasTipTypeColumn) {
          updateData['tip_type'] = argument!['tip_type'];
        }

        // Update the local database with the latest sale data
        if (updateData.isNotEmpty) {
          await SellDatabase().updateSells(sellId!, updateData);
          debugPrint('Checkout: Updated local database with sale data: $updateData');
        }

        // CRITICAL: Load UI controllers from arguments (not from database) when coming from Sales screen
        // This ensures the latest data from API is displayed in the UI
        if (argument!['sale_note'] != null) {
          saleNote.text = argument!['sale_note'];
        }
        if (argument!['staff_note'] != null) {
          staffNote.text = argument!['staff_note'];
        }
        if (argument!['shipping_charges'] != null) {
          shippingCharges.text = argument!['shipping_charges'].toString();
        }
        if (argument!['shipping_details'] != null) {
          shippingDetails.text = argument!['shipping_details'];
        }
        if (argument!['tip_amount'] != null) {
          tip_amountController.text = argument!['tip_amount'].toString();
          tip_amount = double.tryParse(tip_amountController.text) ?? 0.00;
        }
        if (argument!['tip_type'] != null && hasTipTypeColumn) {
          selectedTipType = argument!['tip_type'];
        }
        if (argument!['transaction_date'] != null) {
          transactionDate = argument!['transaction_date'];
          dateController.text = transactionDate;
        }

        debugPrint('Checkout: Loaded UI controllers from Sales screen arguments');
      }

      // For existing sales, load their payments (will override if needed)
      if (sellId != null) {
        await onEdit(sellId!);
      }

      calculateMultiPayment();

      // Ensure cart items are saved for Sales → Checkout navigation with correct context
      // ENHANCED: Always verify products exist when coming from Sales screen, even after round-trip navigation
      if (_fromSalesScreen && sellId != null) {
        List<dynamic> productsFromArgs = argument!['products'] ?? [];
        String contextType = _isShipping ? 'shipping' : 'table ${argument!['res_table_id']}';

        debugPrint('Checkout: Processing Sales → Checkout navigation for $contextType with ${productsFromArgs.length} products in arguments');

        if (productsFromArgs.isNotEmpty) {
          debugPrint('Checkout: Ensuring cart items are saved for Sales → Checkout navigation for $contextType');

          // Convert to List<Map> for the method call
          List<Map> productsList = productsFromArgs.cast<Map>();

          await Sell().ensureCartItemsForSalesToCheckout(
            sellId: sellId!,
            resTableId: argument!['res_table_id'],
            isShipping: argument!['is_shipping'] ?? 0,
            products: productsList,
          );

          // Verify the cart items were saved
          List<Map> savedCartItems = await Sell().getCartItems(sellId, argument!['res_table_id']);
          debugPrint('Checkout: Verified ${savedCartItems.length} cart items saved for $contextType');
        }

        // CRITICAL FIX: Always verify products exist in database, even if they were in arguments
        // This handles the case: Sales → Products → Sales → Checkout where products might be lost
        List<Map> dbProducts = await SellDatabase().getSellLineBySellId(
          sellId!,
          res_table_id: argument!['res_table_id'],
          includeCompleted: true,
        );

        if (dbProducts.isEmpty) {
          // No products in database - this is an error condition
          debugPrint('Checkout: ERROR - No products found in database for $contextType after navigation from Sales');

          // Try to restore from saved cart data as last resort
          Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId!);
          if (savedCartData != null && savedCartData['cartItems'] != null && savedCartData['cartItems'].isNotEmpty) {
            debugPrint('Checkout: Attempting to restore ${savedCartData['cartItems'].length} products from saved cart data');

            // CRITICAL: Ensure the sell record exists before inserting sell_lines
            var existingSellRecord = await SellDatabase().getSellBySellId(sellId!);
            if (existingSellRecord.isEmpty) {
              debugPrint('Checkout: Creating missing sell record for sellId: $sellId');

              // Create the sell record with minimal required fields
              // Use original invoice number if available, otherwise generate a new one
              String invoiceNo = argument!['invoice_no'] ?? 'DRAFT-$sellId';
              debugPrint('Checkout: Using invoice number: $invoiceNo for sellId: $sellId');

              Map<String, dynamic> sellMap = {
                'id': sellId!,
                'invoice_no': invoiceNo, // Use original invoice number
                'transaction_date': DateTime.now().toIso8601String(),
                'change_return': 0.0,
                'contact_id': argument!['customerId'] ?? 1998, // Default walk-in customer
                'invoice_amount': argument!['invoiceAmount']?.toDouble() ?? 0.0,
                'location_id': argument!['locationId'] ?? 88,
                'pending_amount': argument!['invoiceAmount']?.toDouble() ?? 0.0,
                'sale_note': '',
                'sale_status': 'draft',
                'shipping_charges': 0.0,
                'shipping_details': '',
                'staff_note': '',
                'is_quotation': argument!['isQuotation'] == true ? 1 : 0,
                'tip_amount': 0.0,
                'tip_type': 'fixed',
                'discount_amount': argument!['discountAmount']?.toDouble() ?? 0.0,
                'discount_type': argument!['discountType'] ?? 'fixed',
                'res_table_id': argument!['res_table_id'],
                'is_shipping': argument!['is_shipping'] ?? 0,
                'is_synced': 0, // Mark as local draft
                'transaction_id': null,
                'invoice_url': null,
              };

              try {
                await SellDatabase().storeSell(sellMap);
                debugPrint('Checkout: Successfully created sell record for sellId: $sellId');
              } catch (e) {
                debugPrint('Checkout: Error creating sell record for sellId: $sellId: $e');
                // Don't proceed with sell_lines insertion if sell record creation fails
                return;
              }
            }

            // Now restore products to database
            for (var item in savedCartData['cartItems']) {
              // Handle tax_rate_id properly - use 0 if null or invalid
              int? taxRateId = item['tax_rate_id'];
              if (taxRateId == null || taxRateId == 0) {
                taxRateId = 0; // Use 0 instead of null to avoid foreign key issues
              }

              await SellDatabase().store({
                'sell_id': sellId!,
                'product_id': item['product_id'],
                'variation_id': item['variation_id'],
                'quantity': item['quantity'],
                'unit_price': item['unit_price'],
                'tax_rate_id': taxRateId,
                'discount_amount': item['discount_amount'] ?? 0.0,
                'discount_type': item['discount_type'] ?? 'fixed',
                'note': item['note'] ?? '',
                'is_completed': 1, // Mark as completed since from existing sales
                'product_order_category': item['product_order_category'] ?? 'BAR',
                'res_table_id': argument!['res_table_id'],
                'is_shipping': argument!['is_shipping'] ?? 0,
              });
            }

            // Reload from database after restoration
            dbProducts = await SellDatabase().getSellLineBySellId(
              sellId!,
              res_table_id: argument!['res_table_id'],
              includeCompleted: true,
            );
            debugPrint('Checkout: Successfully restored ${dbProducts.length} products from saved cart data');
          }
        }

        // Update argument with products from database to ensure they're available for submission
        if (dbProducts.isNotEmpty) {
          argument!['products'] = dbProducts;
          debugPrint('Checkout: Final verification - ${dbProducts.length} products available for $contextType');
        } else {
          debugPrint('Checkout: CRITICAL WARNING - No products available for $contextType after all recovery attempts');
        }
      }

    } catch (e) {
      debugPrint('Error in payment initialization: $e');
      Fluttertoast.showToast(
        msg: 'Error initializing payment data: ${e.toString()}',
        toastLength: Toast.LENGTH_LONG,
      );
    } finally {
      setState(() {
        isLoading = false;
        _isInitialized = true;
      });
    }

    // Debug: Log the final context state
    await ContextManager.debugContextState();

    super.didChangeDependencies();
  }

  @override
  void dispose() {
    staffNote.dispose();
    saleNote.dispose();
    tip_amountController.dispose();
    dateController.dispose();
    shippingDetails.dispose();
    shippingCharges.dispose();
    super.dispose();
  }

  // onEdit(sellId) async {
  //   sellDetail = await SellDatabase().getSellBySellId(sellId);
  //   this.sellId = argument!['sellId'];
  //   await SellDatabase().getSellBySellId(sellId).then((value) {
  //     shippingCharges.text = value[0]['shipping_charges']?.toString() ?? '0.00';
  //     shippingDetails.text = value[0]['shipping_details'] ?? '';
  //     saleNote.text = value[0]['sale_note'] ?? '';
  //     staffNote.text = value[0]['staff_note'] ?? '';
  //     tip_amountController.text = value[0]['tip_amount']?.toString() ?? '0.00';
  //     selectedTipType = hasTipTypeColumn ? (value[0]['tip_type'] ?? 'fixed') : 'fixed';
  //     tip_amount = double.tryParse(tip_amountController.text) ?? 0.00;
  //     invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
  //         (double.tryParse(shippingCharges.text) ?? 0.00) +
  //         calculateTipAmount();
  //     setState(() {});
  //   });
  //   payments = [];
  //   List paymentLines = await PaymentDatabase().get(sellId, allColumns: true, res_table_id: null);
  //   paymentLines.forEach((element) {
  //     if (element['is_return'] == 0) {
  //       payments.add({
  //         'id': element['id'],
  //         'amount': element['amount'],
  //         'method': element['method'],
  //         'note': element['note'],
  //         'account_id': element['account_id'],
  //         'received_amount': element['received_amount'],
  //         'change_return': element['change_return'],
  //         'card_details': element['card_details'],
  //       });
  //     }
  //   });
  //   calculateMultiPayment();
  // }
  onEdit(sellId) async {
    try {
      sellDetail = await SellDatabase().getSellBySellId(sellId);

      // Only update values if they're not already set
      shippingCharges.text =
          sellDetail[0]['shipping_charges']?.toString() ?? '0.00';
      shippingDetails.text = sellDetail[0]['shipping_details'] ?? '';
      saleNote.text = sellDetail[0]['sale_note'] ?? '';
      staffNote.text = sellDetail[0]['staff_note'] ?? '';
      tip_amountController.text =
          sellDetail[0]['tip_amount']?.toString() ?? '0.00';
      selectedTipType =
      hasTipTypeColumn ? (sellDetail[0]['tip_type'] ?? 'fixed') : 'fixed';
      tip_amount = double.tryParse(tip_amountController.text) ?? 0.00;

      // Check if this is a Partial sale - if so, calculate remaining balance
      double totalAmount = double.tryParse(sellDetail[0]['invoice_amount']?.toString() ?? '0.00') ?? 0.00;
      double pendingAmount = double.tryParse(sellDetail[0]['pending_amount']?.toString() ?? '0.00') ?? 0.00;
      double changeReturn = double.tryParse(sellDetail[0]['change_return']?.toString() ?? '0.00') ?? 0.00;

      // Calculate actual amount paid by checking payments in database
      // This is more accurate than relying on pending_amount which may not be updated correctly
      List paymentLines = await PaymentDatabase()
          .get(sellId, allColumns: true, res_table_id: null);
      double actualAmountPaid = 0.0;
      paymentLines.forEach((payment) {
        if (payment['is_return'] == 0) { // Only count non-return payments
          actualAmountPaid += double.tryParse(payment['amount']?.toString() ?? '0.00') ?? 0.00;
        }
      });

      // Calculate remaining balance more accurately
      double remainingBalance = totalAmount - actualAmountPaid;

      // Determine if this is a Partial sale (has some payment made but not fully paid)
      bool isPartialSale = actualAmountPaid > 0 && remainingBalance > 0;
      // Also check if this is an overpaid sale (customer paid more than total)
      bool isOverpaidSale = actualAmountPaid > totalAmount;

      debugPrint('Sale Analysis: TotalAmount=$totalAmount, PendingAmount=$pendingAmount, ChangeReturn=$changeReturn, ActualAmountPaid=$actualAmountPaid, RemainingBalance=$remainingBalance, IsPartialSale=$isPartialSale, IsOverpaidSale=$isOverpaidSale');

      double newInvoiceAmount;
      if (isPartialSale) {
        // For Partial sales, show the remaining balance as the payable amount
        // This fixes the bug where Partial sales showed 0 as payable amount
        // Instead, we show: remaining_amount = total_amount - amount_paid
        // Don't add shipping again as it's already included in remainingBalance
        newInvoiceAmount = remainingBalance;
        debugPrint('Partial sale detected: Total=$totalAmount, ActualPaid=$actualAmountPaid, Remaining=$remainingBalance, NewInvoiceAmount=$newInvoiceAmount');
      } else if (isOverpaidSale) {
        // For overpaid sales, show 0 as payable amount since customer already paid more than required
        newInvoiceAmount = 0.0;
        debugPrint('Overpaid sale detected: Total=$totalAmount, ActualPaid=$actualAmountPaid, NewInvoiceAmount=$newInvoiceAmount');
      } else {
        // For other sales (paid, due, draft), use the original logic
        double originalInvoiceAmount = argument!['invoiceAmount']?.toDouble() ?? 0.00;
        double originalTipAmount = double.tryParse(sellDetail[0]['tip_amount']?.toString() ?? '0.00') ?? 0.00;
        double originalShippingAmount = double.tryParse(sellDetail[0]['shipping_charges']?.toString() ?? '0.00') ?? 0.00;

        // Check if this is a partial payment scenario (coming from Recent Sales)
        // If the original invoice amount already includes tip and shipping, use it directly
        // Otherwise, calculate the new amount with tip and shipping
        if (originalInvoiceAmount >= (originalTipAmount + originalShippingAmount)) {
          // This is likely a partial payment from Recent Sales where invoice amount already includes tip and shipping
          newInvoiceAmount = originalInvoiceAmount;
        } else {
          // This is a new sale, calculate base amount and add tip and shipping
          double baseAmount = originalInvoiceAmount - originalTipAmount - originalShippingAmount;
          double currentShippingAmount = double.tryParse(shippingCharges.text) ?? 0.00;
          double currentTipAmount = calculateTipAmount();
          newInvoiceAmount = baseAmount + currentShippingAmount + currentTipAmount;
        }
        debugPrint('Non-partial sale: OriginalInvoiceAmount=$originalInvoiceAmount, NewInvoiceAmount=$newInvoiceAmount');
      }

      setState(() {
        invoiceAmount = newInvoiceAmount;
      });

      // Only load payments if we don't have any
      if (payments.isEmpty) {
        List paymentLines = await PaymentDatabase()
            .get(sellId, allColumns: true, res_table_id: null);
        payments = paymentLines
            .where((element) => element['is_return'] == 0)
            .map((element) => {
          'id': element['id'],
          'amount': element['amount'],
          'method': element['method'],
          'note': element['note'],
          'account_id': element['account_id'],
          'received_amount': element['received_amount'],
          'change_return': element['change_return'],
          'card_details': element['card_details'],
        })
            .toList();
      }

      calculateMultiPayment();
    } catch (e) {
      debugPrint('Error in onEdit: $e');
    }
  }

  // Future<void> showCardDetailsDialog(int index) async {
  //   final _formKey = GlobalKey<FormState>();
  //   bool isValid = false;
  //
  //   final TextEditingController cardNumberController = TextEditingController();
  //   final TextEditingController cardHolderNameController = TextEditingController();
  //   final TextEditingController cardTransactionNumberController = TextEditingController();
  //   final TextEditingController cardTypeController = TextEditingController();
  //   final TextEditingController cardMonthController = TextEditingController();
  //   final TextEditingController cardYearController = TextEditingController();
  //   final TextEditingController cardSecurityController = TextEditingController();
  //
  //   await showDialog(
  //     context: context,
  //     barrierDismissible: false, // Prevent dismissing by tapping outside
  //     builder: (BuildContext context) {
  //       return StatefulBuilder(
  //         builder: (BuildContext context, void Function(void Function()) dialogSetState) {
  //           return AlertDialog(
  //             title: Text(
  //               AppLocalizations.of(context)?.translate('card_details') ?? 'Enter Card Details',
  //               style: AppTheme.getTextStyle(themeData.textTheme.headline6, fontWeight: 600),
  //             ),
  //             content: SingleChildScrollView(
  //               child: Form(
  //                 key: _formKey,
  //                 child: Column(
  //                   mainAxisSize: MainAxisSize.min,
  //                   children: [
  //                     TextFormField(
  //                       controller: cardNumberController,
  //                       decoration: InputDecoration(
  //                         labelText: AppLocalizations.of(context)?.translate('card_number') ?? 'Card Number',
  //                       ),
  //                       keyboardType: TextInputType.number,
  //                       inputFormatters: [
  //                         FilteringTextInputFormatter.digitsOnly,
  //                         LengthLimitingTextInputFormatter(16),
  //                       ],
  //                       validator: (value) {
  //                         if (value == null || value.isEmpty) {
  //                           return AppLocalizations.of(context)?.translate('card_number_required') ?? 'Card number is required';
  //                         }
  //                         if (value.length != 15 && value.length != 16) {
  //                           return AppLocalizations.of(context)?.translate('card_number_invalid') ?? 'Card number must be 15 or 16 digits';
  //                         }
  //                         return null;
  //                       },
  //                     ),
  //                     SizedBox(height: 10),
  //                     TextFormField(
  //                       controller: cardHolderNameController,
  //                       decoration: InputDecoration(
  //                         labelText: AppLocalizations.of(context)?.translate('card_holder_name') ?? 'Card Holder Name',
  //                       ),
  //                       validator: (value) {
  //                         if (value == null || value.isEmpty) {
  //                           return AppLocalizations.of(context)?.translate('card_holder_name_required') ?? 'Card holder name is required';
  //                         }
  //                         if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(value)) {
  //                           return AppLocalizations.of(context)?.translate('card_holder_name_invalid') ?? 'Name can only contain letters and spaces';
  //                         }
  //                         return null;
  //                       },
  //                     ),
  //                     SizedBox(height: 10),
  //                     TextFormField(
  //                       controller: cardTransactionNumberController,
  //                       decoration: InputDecoration(
  //                         labelText: AppLocalizations.of(context)?.translate('card_transaction_number') ?? 'Transaction Number',
  //                       ),
  //                       validator: (value) {
  //                         if (value == null || value.isEmpty) {
  //                           return AppLocalizations.of(context)?.translate('transaction_number_required') ?? 'Transaction number is required';
  //                         }
  //                         return null;
  //                       },
  //                     ),
  //                     SizedBox(height: 10),
  //                     // TextFormField(
  //                     //   controller: cardTypeController,
  //                     //   decoration: InputDecoration(
  //                     //     labelText: AppLocalizations.of(context)?.translate('card_type') ?? 'Card Type',
  //                     //   ),
  //                     //   validator: (value) {
  //                     //     if (value == null || value.isEmpty) {
  //                     //       return AppLocalizations.of(context)?.translate('card_type_required') ?? 'Card type is required';
  //                     //     }
  //                     //     return null;
  //                     //   },
  //                     // ),
  //                     DropdownButtonFormField<String>(
  //                       value: cardTypeController.text.isNotEmpty ? cardTypeController.text : null,
  //                       decoration: InputDecoration(
  //                         labelText: AppLocalizations.of(context)?.translate('card_type') ?? 'Card Type',
  //                         prefixIcon: Icon(Icons.credit_card, color: Colors.blueAccent),
  //                         border: OutlineInputBorder(
  //                           borderRadius: BorderRadius.circular(12),
  //                         ),
  //                         enabledBorder: OutlineInputBorder(
  //                           borderSide: BorderSide(color: Colors.grey.shade400),
  //                           borderRadius: BorderRadius.circular(12),
  //                         ),
  //                         focusedBorder: OutlineInputBorder(
  //                           borderSide: BorderSide(color: Colors.blueAccent),
  //                           borderRadius: BorderRadius.circular(12),
  //                         ),
  //                         // filled: true,
  //                         // fillColor: Colors.grey.shade100,
  //                         contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
  //                       ),
  //                       icon: Icon(Icons.keyboard_arrow_down_rounded, color: Colors.blueAccent),
  //                       dropdownColor: Colors.white,
  //                       style: TextStyle(color: Colors.black87, fontSize: 16),
  //                       items: ['Visa', 'MasterCard', 'American Express', 'Discover']
  //                           .map((type) => DropdownMenuItem(
  //                         value: type,
  //                         child: Text(type, style: TextStyle(fontWeight: FontWeight.w500)),
  //                       ))
  //                           .toList(),
  //                       onChanged: (value) {
  //                         cardTypeController.text = value!;
  //                       },
  //                       validator: (value) {
  //                         if (value == null || value.isEmpty) {
  //                           return AppLocalizations.of(context)?.translate('card_type_required') ?? 'Card type is required';
  //                         }
  //                         return null;
  //                       },
  //                     ),
  //                     SizedBox(height: 10),
  //                     // TextFormField(
  //                     //   controller: cardMonthController,
  //                     //   decoration: InputDecoration(
  //                     //     labelText: AppLocalizations.of(context)?.translate('card_month') ?? 'Expiration Month (MM)',
  //                     //   ),
  //                     //   keyboardType: TextInputType.number,
  //                     //   inputFormatters: [
  //                     //     FilteringTextInputFormatter.digitsOnly,
  //                     //     LengthLimitingTextInputFormatter(2),
  //                     //   ],
  //                     //   validator: (value) {
  //                     //     if (value == null || value.isEmpty) {
  //                     //       return AppLocalizations.of(context)?.translate('card_month_required') ?? 'Expiration month is required';
  //                     //     }
  //                     //     int? month = int.tryParse(value);
  //                     //     if (month == null || month < 1 || month > 12) {
  //                     //       return AppLocalizations.of(context)?.translate('card_month_invalid') ?? 'Enter a valid month (01-12)';
  //                     //     }
  //                     //     return null;
  //                     //   },
  //                     // ),
  //                     DropdownButtonFormField<String>(
  //                       value: cardMonthController.text.isNotEmpty ? cardMonthController.text : null,
  //                       decoration: InputDecoration(
  //                         labelText: AppLocalizations.of(context)?.translate('card_month') ?? 'Expiration Month (MM)',
  //                         prefixIcon: Icon(Icons.calendar_today_rounded, color: Colors.blueAccent),
  //                         border: OutlineInputBorder(
  //                           borderRadius: BorderRadius.circular(16.0),
  //                         ),
  //                         enabledBorder: OutlineInputBorder(
  //                           borderSide: BorderSide(color: Colors.grey.shade400, width: 1.2),
  //                           borderRadius: BorderRadius.circular(16.0),
  //                         ),
  //                         focusedBorder: OutlineInputBorder(
  //                           borderSide: BorderSide(color: Colors.blueAccent, width: 1.5),
  //                           borderRadius: BorderRadius.circular(16.0),
  //                         ),
  //                         // filled: true,
  //                         // fillColor: Colors.grey.shade100,
  //                         contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
  //                       ),
  //                       icon: Icon(Icons.keyboard_arrow_down_rounded, color: Colors.blueAccent),
  //                       style: TextStyle(fontSize: 16, color: Colors.black87),
  //                       dropdownColor: Colors.white,
  //                       items: List.generate(12, (index) => (index + 1).toString().padLeft(2, '0'))
  //                           .map((month) => DropdownMenuItem(
  //                         value: month,
  //                         child: Text(month, style: TextStyle(fontWeight: FontWeight.w500)),
  //                       ))
  //                           .toList(),
  //                       onChanged: (value) {
  //                         cardMonthController.text = value!;
  //                       },
  //                       validator: (value) {
  //                         if (value == null || value.isEmpty) {
  //                           return AppLocalizations.of(context)?.translate('card_month_required') ?? 'Expiration month is required';
  //                         }
  //                         int? month = int.tryParse(value);
  //                         if (month == null || month < 1 || month > 12) {
  //                           return AppLocalizations.of(context)?.translate('card_month_invalid') ?? 'Enter a valid month (01-12)';
  //                         }
  //                         return null;
  //                       },
  //                     ),
  //
  //                     SizedBox(height: 10),
  //                     // TextFormField(
  //                     //   controller: cardYearController,
  //                     //   decoration: InputDecoration(
  //                     //     labelText: AppLocalizations.of(context)?.translate('card_year') ?? 'Expiration Year (YYYY)',
  //                     //   ),
  //                     //   keyboardType: TextInputType.number,
  //                     //   inputFormatters: [
  //                     //     FilteringTextInputFormatter.digitsOnly,
  //                     //     LengthLimitingTextInputFormatter(4),
  //                     //   ],
  //                     //   validator: (value) {
  //                     //     if (value == null || value.isEmpty) {
  //                     //       return AppLocalizations.of(context)?.translate('card_year_required') ?? 'Expiration year is required';
  //                     //     }
  //                     //     int? year = int.tryParse(value);
  //                     //     int currentYear = DateTime.now().year;
  //                     //     if (year == null || value.length != 4 || year < currentYear) {
  //                     //       return AppLocalizations.of(context)?.translate('card_year_invalid') ?? 'Enter a valid future year';
  //                     //     }
  //                     //     if (cardMonthController.text.isNotEmpty) {
  //                     //       int? month = int.tryParse(cardMonthController.text);
  //                     //       if (month != null && year == currentYear && month < DateTime.now().month) {
  //                     //         return AppLocalizations.of(context)?.translate('card_expired') ?? 'Card has expired';
  //                     //       }
  //                     //     }
  //                     //     return null;
  //                     //   },
  //                     // ),
  //                     DropdownButtonFormField<String>(
  //                       value: cardYearController.text.isNotEmpty ? cardYearController.text : null,
  //                       decoration: InputDecoration(
  //                         labelText: AppLocalizations.of(context)?.translate('card_year') ?? 'Expiration Year (YYYY)',
  //                         prefixIcon: Icon(Icons.calendar_today_rounded, color: Colors.blueAccent),
  //                         border: OutlineInputBorder(
  //                           borderRadius: BorderRadius.circular(16.0),
  //                         ),
  //                         enabledBorder: OutlineInputBorder(
  //                           borderSide: BorderSide(color: Colors.grey.shade400, width: 1.2),
  //                           borderRadius: BorderRadius.circular(16.0),
  //                         ),
  //                         focusedBorder: OutlineInputBorder(
  //                           borderSide: BorderSide(color: Colors.blueAccent, width: 1.5),
  //                           borderRadius: BorderRadius.circular(16.0),
  //                         ),
  //                         contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
  //                       ),
  //                       icon: Icon(Icons.keyboard_arrow_down_rounded, color: Colors.blueAccent),
  //                       style: TextStyle(fontSize: 16, color: Colors.black87),
  //                       dropdownColor: Colors.white,
  //                       items: List.generate(11, (index) {
  //                         final year = DateTime.now().year + index;
  //                         return DropdownMenuItem(
  //                           value: year.toString(),
  //                           child: Text(year.toString(), style: TextStyle(fontWeight: FontWeight.w500)),
  //                         );
  //                       }),
  //                       onChanged: (value) {
  //                         cardYearController.text = value!;
  //                       },
  //                       validator: (value) {
  //                         if (value == null || value.isEmpty) {
  //                           return AppLocalizations.of(context)?.translate('card_year_required') ?? 'Expiration year is required';
  //                         }
  //                         int? year = int.tryParse(value);
  //                         int currentYear = DateTime.now().year;
  //                         if (year == null || year < currentYear) {
  //                           return AppLocalizations.of(context)?.translate('card_year_invalid') ?? 'Enter a valid future year';
  //                         }
  //                         if (cardMonthController.text.isNotEmpty) {
  //                           int? month = int.tryParse(cardMonthController.text);
  //                           if (month != null && year == currentYear && month < DateTime.now().month) {
  //                             return AppLocalizations.of(context)?.translate('card_expired') ?? 'Card has expired';
  //                           }
  //                         }
  //                         return null;
  //                       },
  //                     ),
  //                     SizedBox(height: 10),
  //                     TextFormField(
  //                       controller: cardSecurityController,
  //                       decoration: InputDecoration(
  //                         labelText: AppLocalizations.of(context)?.translate('card_security') ?? 'Security Code',
  //                       ),
  //                       keyboardType: TextInputType.number,
  //                       inputFormatters: [
  //                         FilteringTextInputFormatter.digitsOnly,
  //                         LengthLimitingTextInputFormatter(4),
  //                       ],
  //                       validator: (value) {
  //                         if (value == null || value.isEmpty) {
  //                           return AppLocalizations.of(context)?.translate('card_security_required') ?? 'Security code is required';
  //                         }
  //                         if (value.length < 3 || value.length > 4) {
  //                           return AppLocalizations.of(context)?.translate('card_security_invalid') ?? 'Security code must be 3-4 digits';
  //                         }
  //                         return null;
  //                       },
  //                     ),
  //                   ],
  //                 ),
  //               ),
  //             ),
  //             actions: [
  //               TextButton(
  //                 onPressed: () {
  //                   Navigator.pop(context);
  //                 },
  //                 child: Text(AppLocalizations.of(context)?.translate('cancel') ?? 'Cancel'),
  //               ),
  //               TextButton(
  //                 onPressed: () {
  //                   dialogSetState(() {
  //                     isValid = _formKey.currentState!.validate();
  //                   });
  //                   if (isValid && mounted) {
  //                     setState(() {
  //                       payments[index]['card_details'] = {
  //                         'card_number': cardNumberController.text,
  //                         'card_holder_name': cardHolderNameController.text,
  //                         'card_transaction_number': cardTransactionNumberController.text,
  //                         'card_type': cardTypeController.text,
  //                         'card_month': cardMonthController.text,
  //                         'card_year': cardYearController.text,
  //                         'card_security': cardSecurityController.text,
  //                       };
  //                       // Ensure payment method remains 'card'
  //                       payments[index]['method'] = 'card';
  //                     });
  //                     debugPrint('Card details saved: ${payments[index]}');
  //                     // Clear controllers after saving
  //                     cardNumberController.dispose();
  //                     cardHolderNameController.dispose();
  //                     cardTransactionNumberController.dispose();
  //                     cardTypeController.dispose();
  //                     cardMonthController.dispose();
  //                     cardYearController.dispose();
  //                     cardSecurityController.dispose();
  //
  //
  //                     Navigator.pop(context);
  //                   }
  //                   print(payments);
  //                 },
  //                 child: Text(AppLocalizations.of(context)?.translate('ok') ?? 'OK'),
  //
  //               ),
  //             ],
  //           );
  //         },
  //       );
  //     },
  //   );
  // }
  Future<void> showCardDetailsDialog(int index) async {
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return CardDetailsDialog(
          index: index,
          onSave: (Map<String, dynamic> cardDetails) {
            setState(() {
              payments[index]['card_details'] = cardDetails;
              payments[index]['method'] = 'card';
            });
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    print("::::${AppConstants.cartData}");

    return SafeArea(
        top: false,
        bottom: true,
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            title: Text(
              AppLocalizations.of(context)?.translate('checkout') ?? 'Checkout',
              style: AppTheme.getTextStyle(themeData.textTheme.headline6,
                  fontWeight: 600),
            ),
          ),
          body: SingleChildScrollView(
            child:
            isLoading ? Helper().loadingIndicator(context) : paymentBox(),
          ),
        ));
  }

  Widget paymentBox() {
    debugPrint('PaymentBox Visible');
    debugPrint('paymentBox: Rendering with payments: $payments');
    debugPrint('Rendering paymentBox with ${payments.length} payments');

    // Check if we're on tablet for responsive layout
    bool isTabletLayout = ResponsiveHelper.isTablet(context) ||
        ResponsiveHelper.isDesktop(context);

    return Container(
      margin: EdgeInsets.all(MySize.size3!),
      child: isTabletLayout ? _buildTabletLayout() : _buildMobileLayout(),
    );
  }

  Widget _buildMobileLayout() {
    return SingleChildScrollView(
      child: Column(
        children: <Widget>[
          if (_tableName != null || _isShipping)
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: themeData.primaryColor.withOpacity(0.1),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isShipping ? Icons.local_shipping : Icons.table_restaurant,
                    color: themeData.primaryColor,
                  ),
                  SizedBox(width: 8),
                  Text(
                    _isShipping
                        ? (AppLocalizations.of(context)
                        .translate('shipping_order') ??
                        'Shipping Order')
                        : '$_tableName',
                    style: TextStyle(
                      color: themeData.primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          SizedBox(
            height: 20,
          ),
          Card(
            margin: EdgeInsets.all(MySize.size5!),
            shadowColor: Colors.blue,
            child: DateTimePicker(
              use24HourFormat: true,
              locale: Locale('en', 'US'),
              initialValue: transactionDate,
              type: DateTimePickerType.dateTime,
              firstDate: DateTime.now().subtract(Duration(days: 366)),
              lastDate: DateTime.now(),
              dateLabelText:
              "${AppLocalizations.of(context)?.translate('date') ?? 'Date'}:",
              style: AppTheme.getTextStyle(
                themeData.textTheme.bodyText1,
                fontWeight: 700,
                color: themeData.colorScheme.primary,
              ),
              textAlign: TextAlign.center,
              onChanged: (val) {
                setState(() {
                  transactionDate = val;
                });
              },
            ),
          ),
          if (payments.isEmpty)
            Padding(
              padding: EdgeInsets.all(MySize.size8!),
              child: Text(
                AppLocalizations.of(context)?.translate('no_payments') ??
                    'No payments added',
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText1,
                  color: Colors.red,
                  fontWeight: 600,
                ),
              ),
            )
          else
            ListView.builder(
              physics: ScrollPhysics(),
              shrinkWrap: true,
              itemCount: payments.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.all(MySize.size5!),
                  shadowColor: Colors.blue,
                  child: Padding(
                    padding: EdgeInsets.all(MySize.size8!),
                    child: Column(
                      children: <Widget>[
                        // Amount details
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  AppLocalizations.of(context)
                                      ?.translate('amount') ??
                                      'Amount' + ' : ',
                                  style: AppTheme.getTextStyle(
                                    themeData.textTheme.bodyText1,
                                    color: themeData.colorScheme.onBackground,
                                    fontWeight: 600,
                                    muted: true,
                                  ),
                                ),
                                SizedBox(
                                  height: MySize.size40,
                                  width: MySize.safeWidth! * 0.50,
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      prefix: Text(symbol),
                                    ),
                                    textAlign: TextAlign.end,
                                    initialValue: (payments[index]['amount'] ??
                                        0.0)
                                        .toStringAsFixed(2), // Use payment amount
                                    inputFormatters: [
                                      FilteringTextInputFormatter(
                                          RegExp(r'^(\d+)?\.?\d{0,2}'),
                                          allow: true)
                                    ],
                                    keyboardType: TextInputType.number,
                                    onChanged: (value) {
                                      payments[index]['amount'] =
                                          Helper().validateInput(value);
                                      calculateMultiPayment();
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Padding(
                            padding:
                            EdgeInsets.symmetric(vertical: MySize.size6!)),
                        // Payment method and account
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              children: <Widget>[
                                Text(
                                  AppLocalizations.of(context)
                                      ?.translate('payment_method') ??
                                      'Payment Method' + ' : ',
                                  style: AppTheme.getTextStyle(
                                    themeData.textTheme.bodyText1,
                                    color: themeData.colorScheme.onBackground,
                                    fontWeight: 600,
                                    muted: true,
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    if (payments[index]['method']
                                        .toLowerCase()
                                        .contains('card')) {
                                      showCardDetailsDialog(index);
                                    }
                                  },
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton(
                                      dropdownColor: themeData.backgroundColor,
                                      icon: Icon(Icons.arrow_drop_down),
                                      value: payments[index]['method'],
                                      items: paymentMethods
                                          .map<DropdownMenuItem<String>>(
                                              (Map value) {
                                            return DropdownMenuItem<String>(
                                              value: value['name'],
                                              child: Container(
                                                width: MySize.screenWidth! * 0.35,
                                                child: Text(
                                                  value['value'],
                                                  softWrap: true,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: AppTheme.getTextStyle(
                                                    themeData.textTheme.bodyText1,
                                                    color: themeData
                                                        .colorScheme.onBackground,
                                                    fontWeight: 800,
                                                    muted: true,
                                                  ),
                                                ),
                                              ),
                                            );
                                          }).toList(),
                                      onChanged: (newValue) {
                                        paymentMethods.forEach((element) {
                                          if (element['name'] == newValue) {
                                            setState(() {
                                              payments[index]['method'] =
                                                  newValue;
                                              payments[index]['account_id'] =
                                              element['account_id'];
                                              if (newValue
                                                  .toString()
                                                  .toLowerCase()
                                                  .contains('card')) {
                                                showCardDetailsDialog(index);
                                              } else {
                                                payments[index]['card_details'] =
                                                null;
                                              }
                                            });
                                          }
                                        });
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              children: <Widget>[
                                Text(
                                  AppLocalizations.of(context)
                                      ?.translate('payment_account') ??
                                      'Payment Account' + ' : ',
                                  style: AppTheme.getTextStyle(
                                    themeData.textTheme.bodyText1,
                                    color: themeData.colorScheme.onBackground,
                                    fontWeight: 600,
                                    muted: true,
                                  ),
                                ),
                                DropdownButtonHideUnderline(
                                  child: DropdownButton(
                                    dropdownColor: themeData.backgroundColor,
                                    icon: Icon(Icons.arrow_drop_down),
                                    value: payments[index]['account_id'],
                                    items: paymentAccounts
                                        .map<DropdownMenuItem<int>>((Map value) {
                                      return DropdownMenuItem<int>(
                                        value: value['id'],
                                        child: Container(
                                          width: MySize.screenWidth! * 0.35,
                                          child: Text(
                                            value['name'],
                                            softWrap: true,
                                            overflow: TextOverflow.ellipsis,
                                            style: AppTheme.getTextStyle(
                                              themeData.textTheme.bodyText1,
                                              color: themeData
                                                  .colorScheme.onBackground,
                                              fontWeight: 800,
                                              muted: true,
                                            ),
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                    onChanged: (newValue) {
                                      setState(() {
                                        payments[index]['account_id'] = newValue;
                                      });
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Row(
                          children: <Widget>[
                            SizedBox(
                              width: MySize.safeWidth! * 0.8,
                              child: TextFormField(
                                decoration: InputDecoration(
                                  hintText: AppLocalizations.of(context)
                                      ?.translate('payment_note') ??
                                      'Payment Note',
                                ),
                                onChanged: (value) {
                                  payments[index]['note'] = value;
                                },
                              ),
                            ),
                            Expanded(
                              child: (index > 0)
                                  ? IconButton(
                                icon: Icon(
                                  MdiIcons.deleteForeverOutline,
                                  size: MySize.size40,
                                  color: Colors.black,
                                ),
                                onPressed: () {
                                  alertConfirm(context, index);
                                },
                              )
                                  : Container(),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

          Card(
            margin: EdgeInsets.all(MySize.size5!),
            child: Container(
              padding: EdgeInsets.all(MySize.size5!),
              child: Column(
                children: <Widget>[
                  // OutlinedButton(
                  //   style: OutlinedButton.styleFrom(
                  //     side: BorderSide(color: themeData.colorScheme.primary),
                  //   ),
                  //   onPressed: () {
                  //     print('Pressed on Add Payment');
                  //     setState(() {
                  //       payments.add({
                  //         'amount': pendingAmount,
                  //         'method': paymentMethods[0]['name'],
                  //         'note': '',
                  //         'account_id': paymentMethods[0]['account_id'],
                  //         'received_amount': null,
                  //         'change_return': 0.0,
                  //         'card_details': null,
                  //       });
                  //       calculateMultiPayment();
                  //     });
                  //   },
                  //   child: Text(
                  //     AppLocalizations.of(context)?.translate('add_payment') ??
                  //         'Add Payment',
                  //     style: AppTheme.getTextStyle(
                  //       themeData.textTheme.subtitle1,
                  //       fontWeight: 700,
                  //       color: themeData.colorScheme.primary,
                  //     ),
                  //   ),
                  // ),
                  Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            AppLocalizations.of(context)
                                ?.translate('shipping_charges') ??
                                'Shipping Charges' + ' : ',
                            style: AppTheme.getTextStyle(
                              themeData.textTheme.bodyText1,
                              color: themeData.colorScheme.onBackground,
                              fontWeight: 600,
                              muted: true,
                            ),
                          ),
                          // SizedBox(
                          //   height: MySize.size40,
                          //   width: MySize.safeWidth! * 0.5,
                          //   child: TextFormField(
                          //     controller: shippingCharges,
                          //     decoration: InputDecoration(
                          //         prefix: Text(symbol)),
                          //     textAlign: TextAlign.end,
                          //     inputFormatters: [
                          //       FilteringTextInputFormatter(RegExp(r'^(\d+)?\.?\d{0,2}'), allow: true),
                          //
                          //       LengthLimitingTextInputFormatter(4),
                          //     ],
                          //     keyboardType: TextInputType.number,
                          //     onTap: () {
                          //       if (!_isShippingChargeEdited) {
                          //         shippingCharges.clear();
                          //         _isShippingChargeEdited = true;
                          //       }
                          //     },
                          //     onChanged: (value) {
                          //       setState(() {
                          //         invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
                          //             Helper().validateInput(value) +
                          //             calculateTipAmount();
                          //         calculateMultiPayment();
                          //       });
                          //     },
                          //   ),
                          // ),
                          SizedBox(
                            height: MySize.size40,
                            width: MySize.safeWidth! * 0.5,
                            child: TextFormField(
                              controller: shippingCharges,
                              enabled: !_fromSalesScreen || _initialShippingCharge == 0.0, // Enable if not from sales screen OR if initial value was 0.0
                              style: TextStyle(
                                color: _fromSalesScreen ? Colors.grey[600] : null,
                              ),
                              decoration: InputDecoration(
                                prefix: Text(symbol),
                                filled: _fromSalesScreen,
                                fillColor: _fromSalesScreen
                                    ? (!_fromSalesScreen || _initialShippingCharge == 0.0 ? Colors.white : Colors.grey[200])
                                    : null,
                                border: _fromSalesScreen ? OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey[400]!),
                                ) : null,
                                enabledBorder: _fromSalesScreen ? OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey[400]!),
                                ) : null,
                                focusedBorder: _fromSalesScreen ? OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey[400]!),
                                ) : null,
                              ),
                              textAlign: TextAlign.end,
                              keyboardType: TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(RegExp(
                                    r'^\d*\.?\d{0,2}$')), // only numbers + 2 decimals
                              ],
                              onTap: () {
                                if (!_isShippingChargeEdited && !_fromSalesScreen) {
                                  shippingCharges.clear();
                                  _isShippingChargeEdited = true;
                                }
                              },
                              onChanged: (value) {
                                if (value.contains('.')) {
                                  // If decimal, check only before the dot
                                  final parts = value.split('.');
                                  if (parts[0].length > 4) {
                                    shippingCharges.clear();
                                    value = "";
                                  }
                                } else {
                                  // No decimal, just check length
                                  if (value.length > 4) {
                                    shippingCharges.clear();
                                    value = "";
                                  }
                                }

                                setState(() {
                                  invoiceAmount =
                                      (argument!['invoiceAmount']?.toDouble() ??
                                          0.00) +
                                          Helper().validateInput(value) +
                                          calculateTipAmount();
                                  calculateMultiPayment();
                                });
                              },
                            ),
                          ),
                          Padding(padding: EdgeInsets.symmetric(vertical: 5)),
                          SizedBox(
                            width: MySize.safeWidth! * 0.8,
                            child: TextFormField(
                              controller: shippingDetails,
                              decoration: InputDecoration(
                                hintText: AppLocalizations.of(context)
                                    ?.translate('shipping_details') ??
                                    'Shipping Details',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Container(
                    padding: EdgeInsets.only(
                        left: MySize.size24!, right: MySize.size24!),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          AppLocalizations.of(context)?.translate('tip') ??
                              'Tip' + ' : ',
                          style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText1,
                            color: themeData.colorScheme.onBackground,
                            fontWeight: 600,
                            muted: true,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        tipDropdown(),
                        SizedBox(
                          width: 5,
                        ),
                        // Expanded(
                        //   child: Container(
                        //     height: MySize.size50,
                        //     child: TextFormField(
                        //       controller: tip_amountController,
                        //       decoration: InputDecoration(
                        //         prefix: Text(
                        //             selectedTipType == 'fixed' ? symbol : ''),
                        //         labelText: AppLocalizations.of(context)
                        //                 ?.translate('tip_amount') ??
                        //             'Tip Amount',
                        //         border: themeData.inputDecorationTheme.border,
                        //         enabledBorder:
                        //             themeData.inputDecorationTheme.border,
                        //         focusedBorder: themeData
                        //             .inputDecorationTheme.focusedBorder,
                        //       ),
                        //       style: AppTheme.getTextStyle(
                        //         themeData.textTheme.subtitle2,
                        //         fontWeight: 600,
                        //         letterSpacing: -0.2,
                        //       ),
                        //       textAlign: TextAlign.end,
                        //       inputFormatters: [
                        //         FilteringTextInputFormatter(
                        //             RegExp(r'^(\d+)?\.?\d{0,2}'),
                        //             allow: true)
                        //       ],
                        //       keyboardType: TextInputType.number,
                        //       onTap: () {
                        //         if (!_isTipAmountEdited) {
                        //           tip_amountController.clear();
                        //           _isTipAmountEdited = true;
                        //         }
                        //       },
                        //       onChanged: (value) {
                        //         setState(() {
                        //           tip_amount = Helper().validateInput(value);
                        //           if (maxtipValue != null &&
                        //               tip_amount > maxtipValue) {
                        //             proceedNext = false;
                        //
                        //             // Fluttertoast.showToast(
                        //             //   msg: AppLocalizations.of(context)?.translate('tip_error_message')??"",
                        //             //   toastLength: Toast.LENGTH_LONG,
                        //             // );
                        //             // Only show the error message if it hasn't been shown yet
                        //             if (!_tipErrorShown) {
                        //               Future.delayed(
                        //                   const Duration(milliseconds: 500),
                        //                   () {
                        //                 Fluttertoast.showToast(
                        //                   msg: AppLocalizations.of(context)
                        //                           ?.translate(
                        //                               'tip_error_message') ??
                        //                       '',
                        //                 );
                        //               });
                        //               _tipErrorShown =
                        //                   true; // Mark that the error has been shown
                        //             }
                        //           } else {
                        //             proceedNext = true;
                        //             _tipErrorShown =
                        //                 false; // Reset the flag when tip becomes valid
                        //           }
                        //           invoiceAmount = (argument!['invoiceAmount']
                        //                       ?.toDouble() ??
                        //                   0.00) +
                        //               (double.tryParse(shippingCharges.text) ??
                        //                   0.00) +
                        //               calculateTipAmount();
                        //           calculateMultiPayment();
                        //         });
                        //       },
                        //     ),
                        //   ),
                        // ),
                        Container(
                          height: MySize.size50,
                          width:
                          MySize.safeWidth! * 0.4, // adjust width as needed
                          child: TextFormField(
                            controller: tip_amountController,
                            enabled: !_fromSalesScreen || _initialTipAmount == 0.0, // Enable if not from sales screen OR if initial value was 0.0
                            style: TextStyle(
                              color: _fromSalesScreen ? Colors.grey[600] : null,
                            ),
                            decoration: InputDecoration(
                              prefix:
                              Text(selectedTipType == 'fixed' ? symbol : ''),
                              labelText: AppLocalizations.of(context)
                                  ?.translate('tip_amount') ??
                                  'Tip Amount',
                              filled: _fromSalesScreen,
                              fillColor: _fromSalesScreen
                                  ? (!_fromSalesScreen || _initialTipAmount == 0.0 ? Colors.white : Colors.grey[200])
                                  : null,
                              border: _fromSalesScreen ? OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.grey[400]!),
                              ) : themeData.inputDecorationTheme.border,
                              enabledBorder: _fromSalesScreen ? OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.grey[400]!),
                              ) : themeData.inputDecorationTheme.border,
                              focusedBorder: _fromSalesScreen ? OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.grey[400]!),
                              ) : themeData.inputDecorationTheme.focusedBorder,
                            ),
                            textAlign: TextAlign.end,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'^\d*\.?\d{0,2}$')),
                            ],
                            onTap: () {
                              if (!_isTipAmountEdited && !_fromSalesScreen) {
                                tip_amountController.clear();
                                _isTipAmountEdited = true;
                              }
                            },
                            onChanged: (value) {
                              // Reset if digits before decimal > 3
                              if (value.contains('.')) {
                                final parts = value.split('.');
                                if (parts[0].length > 3) {
                                  tip_amountController.clear();
                                  value = "";
                                }
                              } else {
                                if (value.length > 3) {
                                  tip_amountController.clear();
                                  value = "";
                                }
                              }

                              setState(() {
                                tip_amount = Helper().validateInput(value);

                                if (maxtipValue != null &&
                                    tip_amount > maxtipValue) {
                                  proceedNext = false;

                                  if (!_tipWarningShown) {
                                    Future.delayed(
                                        const Duration(milliseconds: 500), () {
                                      Fluttertoast.showToast(
                                        msg: AppLocalizations.of(context)
                                            ?.translate(
                                            'tip_error_message') ??
                                            '',
                                      );
                                    });
                                    _tipWarningShown = true;
                                  }
                                } else {
                                  proceedNext = true;
                                  _tipWarningShown = false;
                                }

                                invoiceAmount =
                                    (argument!['invoiceAmount']?.toDouble() ??
                                        0.00) +
                                        (double.tryParse(shippingCharges.text) ??
                                            0.00) +
                                        calculateTipAmount();
                                calculateMultiPayment();
                              });
                            },
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: themeData.colorScheme.primary),
                    ),
                    onPressed: () {
                      print('Pressed on Add Payment');
                      setState(() {
                        payments.add({
                          'amount': pendingAmount,
                          'method': paymentMethods[0]['name'],
                          'note': '',
                          'account_id': paymentMethods[0]['account_id'],
                          'received_amount': null,
                          'change_return': 0.0,
                          'card_details': null,
                        });
                        calculateMultiPayment();
                      });
                    },
                    child: Text(
                      AppLocalizations.of(context)?.translate('add_payment') ??
                          'Add Payment',
                      style: AppTheme.getTextStyle(
                        themeData.textTheme.subtitle1,
                        fontWeight: 700,
                        color: themeData.colorScheme.primary,
                      ),
                    ),
                  ),
                  Container(
                    child: GridView.count(
                      shrinkWrap: true,
                      physics: ClampingScrollPhysics(),
                      crossAxisCount: 2,
                      padding: EdgeInsets.only(
                        left: MySize.size16!,
                        right: MySize.size16!,
                        top: MySize.size16!,
                      ),
                      mainAxisSpacing: MySize.size16!,
                      childAspectRatio: 8 / 3,
                      crossAxisSpacing: MySize.size16!,
                      children: <Widget>[
                        block(
                          amount: Helper().formatCurrency(invoiceAmount),
                          subject: AppLocalizations.of(context)
                              ?.translate('total_payble') ??
                              'Total Payable' + ' : ',
                          backgroundColor: Colors.blue,
                          textColor: themeData.colorScheme.onBackground,
                        ),
                        block(
                          amount: Helper().formatCurrency(totalPaying),
                          subject: AppLocalizations.of(context)
                              ?.translate('total_paying') ??
                              'Total Paying' + ' : ',
                          backgroundColor: Colors.red,
                          textColor: themeData.colorScheme.onBackground,
                        ),
                        block(
                          amount: Helper().formatCurrency(changeReturn),
                          subject: AppLocalizations.of(context)
                              ?.translate('change_return') ??
                              'Change Return' + ' : ',
                          backgroundColor: Colors.green,
                          textColor: (changeReturn >= 0.01)
                              ? Colors.red
                              : themeData.colorScheme.onBackground,
                        ),
                        block(
                          amount: Helper().formatCurrency(pendingAmount),
                          subject: AppLocalizations.of(context)
                              ?.translate('balance') ??
                              'Balance' + ' : ',
                          backgroundColor: Colors.orange,
                          textColor: (pendingAmount >= 0.01)
                              ? Colors.red
                              : themeData.colorScheme.onBackground,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.all(MySize.size8!),
                    child: Column(
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Text(
                                  AppLocalizations.of(context)
                                      ?.translate('sell_note') ??
                                      'Sell Note' + ' : ',
                                  style: AppTheme.getTextStyle(
                                    themeData.textTheme.bodyText1,
                                    color: themeData.colorScheme.onBackground,
                                    fontWeight: 600,
                                    muted: true,
                                  ),
                                ),
                                SizedBox(
                                  height: MySize.size80,
                                  width: MySize.screenWidth! * 0.40,
                                  child: TextFormField(controller: saleNote),
                                ),
                              ],
                            ),
                            Column(
                              children: <Widget>[
                                Text(
                                  AppLocalizations.of(context)
                                      ?.translate('staff_note') ??
                                      'Staff Note' + ' : ',
                                  style: AppTheme.getTextStyle(
                                    themeData.textTheme.bodyText1,
                                    color: themeData.colorScheme.onBackground,
                                    fontWeight: 600,
                                    muted: true,
                                  ),
                                ),
                                SizedBox(
                                  height: MySize.size80,
                                  width: MySize.screenWidth! * 0.40,
                                  child: TextFormField(controller: staffNote),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                flex: 1,
                                child: Row(
                                  children: [
                                    Radio(
                                      value: "Mobile",
                                      groupValue: invoiceType,
                                      onChanged: (value) {
                                        setState(() {
                                          invoiceType = value.toString();
                                          printWebInvoice = false;
                                        });
                                      },
                                      toggleable: true,
                                    ),
                                    Expanded(
                                      child: Text(
                                        AppLocalizations.of(context)
                                            ?.translate('mobile_layout') ??
                                            'Mobile Layout',
                                        maxLines: 2,
                                        style: AppTheme.getTextStyle(
                                          themeData.textTheme.bodyText2,
                                          color:
                                          themeData.colorScheme.onBackground,
                                          fontWeight: 600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: Row(
                                  children: [
                                    Radio(
                                      value: "Web",
                                      groupValue: invoiceType,
                                      onChanged: (value) async {
                                        if (await Helper().checkConnectivity()) {
                                          setState(() {
                                            invoiceType = value.toString();
                                            printWebInvoice = true;
                                          });
                                        } else {
                                          Fluttertoast.showToast(
                                            msg: AppLocalizations.of(context)
                                                ?.translate(
                                                'check_connectivity') ??
                                                'Please check your internet connection',
                                          );
                                        }
                                      },
                                      toggleable: true,
                                    ),
                                    Expanded(
                                      child: Text(
                                        AppLocalizations.of(context)
                                            ?.translate('web_layout') ??
                                            'Web Layout',
                                        maxLines: 2,
                                        style: AppTheme.getTextStyle(
                                          themeData.textTheme.bodyText2,
                                          color:
                                          themeData.colorScheme.onBackground,
                                          fontWeight: 600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              flex: 1,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: themeData.colorScheme.onPrimary,
                                  elevation: 5,
                                ),
                                onPressed: () async {
                                  _printInvoice = false;
                                  if (pendingAmount >= 0.01) {
                                    alertPending(context);
                                  } else if (!saleCreated) {
                                    await onSubmit();
                                    // CRITICAL: Ensure table/shipping is enabled after submission
                                    // Pass the sellId from state or arguments
                                    await _ensureTableOrShippingEnabled(providedSellId: sellId ?? argument?['sellId']);
                                  }
                                },
                                child: Text(
                                  AppLocalizations.of(context)
                                      ?.translate('finalize_n_share') ??
                                      'Finalize & Share',
                                  style: AppTheme.getTextStyle(
                                    themeData.textTheme.subtitle1,
                                    fontWeight: 700,
                                    color: themeData.colorScheme.primary,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: MySize.size10!)),
                            Expanded(
                              flex: 1,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: themeData.colorScheme.primary,
                                  elevation: 5,
                                ),
                                onPressed: () async {
                                  _printInvoice = true;
                                  if (pendingAmount >= 0.01) {
                                    alertPending(context);
                                  } else {
                                    if (!saleCreated) {
                                      int? sellIdBeforeSubmit = sellId ?? argument?['sellId'];
                                      await onSubmit();
                                      // CRITICAL: Wait a bit to ensure database is updated
                                      await Future.delayed(Duration(milliseconds: 300));
                                      // CRITICAL: Ensure table/shipping is enabled after submission
                                      // Pass the sellId from state or arguments (same as Finalize & Share)
                                      // Use sellIdBeforeSubmit as onSubmit might have changed sellId state
                                      await _ensureTableOrShippingEnabled(providedSellId: sellId ?? sellIdBeforeSubmit ?? argument?['sellId']);
                                    }
                                  }
                                },
                                child: Text(
                                  AppLocalizations.of(context)
                                      ?.translate('finalize_n_print') ??
                                      'Finalize & Print',
                                  style: AppTheme.getTextStyle(
                                    themeData.textTheme.subtitle1,
                                    fontWeight: 700,
                                    color: themeData.colorScheme.onPrimary,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabletLayout() {
    return Container(
      padding: ResponsiveHelper.getResponsivePadding(context),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Left side - Payment details and forms
          Expanded(
            flex: 3,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _buildTableShippingIndicator(),
                  SizedBox(
                      height: ResponsiveHelper.getResponsiveSpacing(context)),
                  _buildDatePicker(),
                  SizedBox(
                      height: ResponsiveHelper.getResponsiveSpacing(context)),
                  _buildPaymentsList(),
                  SizedBox(
                      height: ResponsiveHelper.getResponsiveSpacing(context)),
                  _buildFormFields(),
                  SizedBox(
                      height: ResponsiveHelper.getResponsiveSpacing(context)),
                  _buildAddPaymentButton(),
                ],
              ),
            ),
          ),
          SizedBox(width: ResponsiveHelper.getResponsiveSpacing(context)),
          // Right side - Summary and actions
          Expanded(
            flex: 2,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _buildPaymentSummary(),
                  SizedBox(
                      height: ResponsiveHelper.getResponsiveSpacing(context)),
                  _buildActionButtons(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTableShippingIndicator() {
    if (_tableName == null && !_isShipping) return SizedBox.shrink();

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: themeData.primaryColor.withOpacity(0.1),
        borderRadius:
        BorderRadius.circular(ResponsiveHelper.getBorderRadius(context)),
        border: Border.all(
          color: themeData.primaryColor.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _isShipping ? Icons.local_shipping : Icons.table_restaurant,
            color: themeData.primaryColor,
            size: 24,
          ),
          SizedBox(width: 12),
          Text(
            _isShipping
                ? (AppLocalizations.of(context).translate('shipping_order') ??
                'Shipping Order')
                : '$_tableName',
            style: TextStyle(
              color: themeData.primaryColor,
              fontWeight: FontWeight.bold,
              fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                  mobileSize: 16, tabletSize: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDatePicker() {
    return Card(
      margin: EdgeInsets.zero,
      elevation: ResponsiveHelper.getCardElevation(context),
      shape: RoundedRectangleBorder(
        borderRadius:
        BorderRadius.circular(ResponsiveHelper.getBorderRadius(context)),
      ),
      child: Container(
        padding: EdgeInsets.all(ResponsiveHelper.getResponsiveSpacing(context,
            mobileSpacing: 12, tabletSpacing: 16)),
        child: DateTimePicker(
          use24HourFormat: true,
          locale: Locale('en', 'US'),
          initialValue: transactionDate,
          type: DateTimePickerType.dateTime,
          firstDate: DateTime.now().subtract(Duration(days: 366)),
          lastDate: DateTime.now(),
          dateLabelText:
          "${AppLocalizations.of(context)?.translate('date') ?? 'Date'}:",
          style: AppTheme.getTextStyle(
            themeData.textTheme.bodyText1,
            fontWeight: 700,
            color: themeData.colorScheme.primary,
            fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                mobileSize: 14, tabletSize: 16),
          ),
          textAlign: TextAlign.center,
          onChanged: (val) {
            setState(() {
              transactionDate = val;
            });
          },
        ),
      ),
    );
  }

  Widget _buildPaymentsList() {
    if (payments.isEmpty) {
      return Container(
        width: double.infinity,
        padding: EdgeInsets.all(ResponsiveHelper.getResponsiveSpacing(context)),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.1),
          borderRadius:
          BorderRadius.circular(ResponsiveHelper.getBorderRadius(context)),
          border: Border.all(color: Colors.red.withOpacity(0.3)),
        ),
        child: Text(
          AppLocalizations.of(context)?.translate('no_payment_data') ??
              'No payments added',
          textAlign: TextAlign.center,
          style: AppTheme.getTextStyle(
            themeData.textTheme.bodyText1,
            color: Colors.red,
            fontWeight: 600,
            fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                mobileSize: 14, tabletSize: 16),
          ),
        ),
      );
    }

    return ListView.builder(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: payments.length,
      itemBuilder: (context, index) {
        return Card(
          margin: EdgeInsets.only(
              bottom: ResponsiveHelper.getResponsiveSpacing(context,
                  mobileSpacing: 8, tabletSpacing: 12)),
          elevation: ResponsiveHelper.getCardElevation(context),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
                ResponsiveHelper.getBorderRadius(context)),
          ),
          child: Container(
            padding: EdgeInsets.all(ResponsiveHelper.getResponsiveSpacing(
                context,
                mobileSpacing: 12,
                tabletSpacing: 16)),
            child: Column(
              children: <Widget>[
                // Amount details
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          AppLocalizations.of(context)?.translate('amount') ??
                              'Amount' + ' : ',
                          style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText1,
                            color: themeData.colorScheme.onBackground,
                            fontWeight: 600,
                            muted: true,
                            fontSize: ResponsiveHelper.getResponsiveFontSize(
                                context,
                                mobileSize: 14,
                                tabletSize: 16),
                          ),
                        ),
                        SizedBox(
                          height: ResponsiveHelper.isTablet(context)
                              ? 50
                              : MySize.size40,
                          width: ResponsiveHelper.isTablet(context)
                              ? 200
                              : MySize.safeWidth! * 0.30,
                          child: TextFormField(
                            decoration: InputDecoration(
                              prefix: Text(symbol),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            textAlign: TextAlign.end,
                            initialValue: (payments[index]['amount'] ?? 0.0)
                                .toStringAsFixed(2),
                            inputFormatters: [
                              FilteringTextInputFormatter(
                                  RegExp(r'^(\d+)?\.?\d{0,2}'),
                                  allow: true)
                            ],
                            keyboardType: TextInputType.number,
                            onChanged: (value) {
                              payments[index]['amount'] =
                                  Helper().validateInput(value);
                              calculateMultiPayment();
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Padding(padding: EdgeInsets.symmetric(vertical: MySize.size6!)),
                // Payment method and account - Side by side for tablet
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        children: <Widget>[
                          Text(
                            AppLocalizations.of(context)
                                ?.translate('payment_method') ??
                                'Payment Method' + ' : ',
                            style: AppTheme.getTextStyle(
                              themeData.textTheme.bodyText1,
                              color: themeData.colorScheme.onBackground,
                              fontWeight: 600,
                              muted: true,
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              if (payments[index]['method']
                                  .toLowerCase()
                                  .contains('card')) {
                                showCardDetailsDialog(index);
                              }
                            },
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton(
                                dropdownColor: themeData.backgroundColor,
                                icon: Icon(Icons.arrow_drop_down),
                                value: payments[index]['method'],
                                items: paymentMethods
                                    .map<DropdownMenuItem<String>>((Map value) {
                                  return DropdownMenuItem<String>(
                                    value: value['name'],
                                    child: Container(
                                      width: MySize.screenWidth! *
                                          0.20, // Adjusted for tablet
                                      child: Text(
                                        value['value'],
                                        softWrap: true,
                                        overflow: TextOverflow.ellipsis,
                                        style: AppTheme.getTextStyle(
                                          themeData.textTheme.bodyText1,
                                          color: themeData
                                              .colorScheme.onBackground,
                                          fontWeight: 800,
                                          muted: true,
                                        ),
                                      ),
                                    ),
                                  );
                                }).toList(),
                                onChanged: (newValue) {
                                  paymentMethods.forEach((element) {
                                    if (element['name'] == newValue) {
                                      setState(() {
                                        payments[index]['method'] = newValue;
                                        payments[index]['account_id'] =
                                        element['account_id'];
                                        if (newValue
                                            .toString()
                                            .toLowerCase()
                                            .contains('card')) {
                                          showCardDetailsDialog(index);
                                        } else {
                                          payments[index]['card_details'] =
                                          null;
                                        }
                                      });
                                    }
                                  });
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        children: <Widget>[
                          Text(
                            AppLocalizations.of(context)
                                ?.translate('payment_account') ??
                                'Payment Account' + ' : ',
                            style: AppTheme.getTextStyle(
                              themeData.textTheme.bodyText1,
                              color: themeData.colorScheme.onBackground,
                              fontWeight: 600,
                              muted: true,
                            ),
                          ),
                          DropdownButtonHideUnderline(
                            child: DropdownButton(
                              dropdownColor: themeData.backgroundColor,
                              icon: Icon(Icons.arrow_drop_down),
                              value: payments[index]['account_id'],
                              items: paymentAccounts
                                  .map<DropdownMenuItem<int>>((Map value) {
                                return DropdownMenuItem<int>(
                                  value: value['id'],
                                  child: Container(
                                    width: MySize.screenWidth! *
                                        0.20, // Adjusted for tablet
                                    child: Text(
                                      value['name'],
                                      softWrap: true,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTheme.getTextStyle(
                                        themeData.textTheme.bodyText1,
                                        color:
                                        themeData.colorScheme.onBackground,
                                        fontWeight: 800,
                                        muted: true,
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                              onChanged: (newValue) {
                                setState(() {
                                  payments[index]['account_id'] = newValue;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(padding: EdgeInsets.symmetric(vertical: MySize.size6!)),
                // Note field
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                            height: MySize.size40,
                            child: TextFormField(
                              decoration: InputDecoration(
                                hintText: AppLocalizations.of(context)
                                    ?.translate('payment_note') ??
                                    'Payment Note',
                              ),                              onChanged: (value) {
                              payments[index]['payment_note'] = value;
                            },
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 16),
                    // Delete button
                    (payments.length > 1)
                        ? IconButton(
                      icon: Icon(
                        MdiIcons.deleteForeverOutline,
                        size: MySize.size40,
                        color: Colors.red,
                      ),
                      onPressed: () {
                        alertConfirm(context, index);
                      },
                    )
                        : Container(),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void addPayment() {
    setState(() {
      payments.add({
        'amount': pendingAmount,
        'method':
        paymentMethods.isNotEmpty ? paymentMethods[0]['name'] : 'Cash',
        'note': '',
        'account_id':
        paymentMethods.isNotEmpty ? paymentMethods[0]['account_id'] : null,
        'received_amount': null,
        'change_return': 0.0,
        'card_details': null,
      });
      calculateMultiPayment();
    });
  }

  Widget _buildAddPaymentButton() {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(
          vertical: ResponsiveHelper.getResponsiveSpacing(context,
              mobileSpacing: 8, tabletSpacing: 12)),
      child: ElevatedButton.icon(
        onPressed: () {
          addPayment();
        },
        icon: Icon(
          Icons.add,
          size: ResponsiveHelper.isTablet(context) ? 24 : 20,
        ),
        label: Text(
          AppLocalizations.of(context)?.translate('add_payment') ??
              'Add Payment',
          style: TextStyle(
            fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                mobileSize: 16, tabletSize: 18),
            fontWeight: FontWeight.w600,
          ),
        ),
        style: ElevatedButton.styleFrom(
          primary: themeData.colorScheme.primary,
          onPrimary: themeData.colorScheme.onPrimary,
          elevation: ResponsiveHelper.getCardElevation(context),
          padding: EdgeInsets.symmetric(
            vertical: ResponsiveHelper.isTablet(context) ? 16 : 12,
            horizontal: 24,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
                ResponsiveHelper.getBorderRadius(context)),
          ),
        ),
      ),
    );
  }

  Widget _buildFormFields() {
    return Container(
        padding: EdgeInsets.all(ResponsiveHelper.getResponsiveSpacing(context,
            mobileSpacing: 12, tabletSpacing: 16)),
        decoration: BoxDecoration(
          color: themeData.cardColor,
          borderRadius:
          BorderRadius.circular(ResponsiveHelper.getBorderRadius(context)),
          border: Border.all(
            color: themeData.dividerColor.withOpacity(0.2),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Shipping charges and details - side by side on tablet
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        AppLocalizations.of(context)
                            ?.translate('shipping_charges') ??
                            'Shipping Charges' + ' : ',
                        style: AppTheme.getTextStyle(
                          themeData.textTheme.bodyText1,
                          color: themeData.colorScheme.onBackground,
                          fontWeight: 600,
                          muted: true,
                          fontSize: ResponsiveHelper.getResponsiveFontSize(
                              context,
                              mobileSize: 14,
                              tabletSize: 16),
                        ),
                      ),
                      SizedBox(height: 8),
                      SizedBox(
                        height: ResponsiveHelper.isTablet(context)
                            ? 50
                            : MySize.size40,
                        child: TextFormField(
                          controller: shippingCharges,
                          enabled: !_fromSalesScreen || _initialShippingCharge == 0.0, // Enable if not from sales screen OR if initial value was 0.0
                          style: TextStyle(
                            color: _fromSalesScreen ? Colors.grey[600] : null,
                          ),
                          decoration: InputDecoration(
                            prefix: Text(symbol),
                            filled: _fromSalesScreen,
                            fillColor: _fromSalesScreen
                                ? (!_fromSalesScreen || _initialShippingCharge == 0.0 ? Colors.white : Colors.grey[200])
                                : null,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: _fromSalesScreen ? Colors.grey[400]! : Colors.grey[300]!,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: _fromSalesScreen ? Colors.grey[400]! : Colors.grey[300]!,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: _fromSalesScreen ? Colors.grey[400]! : themeData.primaryColor,
                              ),
                            ),
                          ),
                          textAlign: TextAlign.end,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(
                                RegExp(r'^\d*\.?\d{0,2}$')),
                          ],
                          onTap: () {
                            if (!_isShippingChargeEdited && !_fromSalesScreen) {
                              shippingCharges.clear();
                              _isShippingChargeEdited = true;
                            }
                          },
                          onChanged: (value) {
                            if (value.contains('.')) {
                              final parts = value.split('.');
                              if (parts[0].length > 4) {
                                shippingCharges.clear();
                                value = "";
                              }
                            } else {
                              if (value.length > 4) {
                                shippingCharges.clear();
                                value = "";
                              }
                            }

                            setState(() {
                              invoiceAmount =
                                  (argument!['invoiceAmount']?.toDouble() ??
                                      0.00) +
                                      Helper().validateInput(value) +
                                      calculateTipAmount();
                              calculateMultiPayment();
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                    width: ResponsiveHelper.getResponsiveSpacing(context,
                        mobileSpacing: 12, tabletSpacing: 16)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppLocalizations.of(context)
                            ?.translate('shipping_details') ??
                            'Shipping Details',
                        style: AppTheme.getTextStyle(
                          themeData.textTheme.bodyText1,
                          color: themeData.colorScheme.onBackground,
                          fontWeight: 600,
                          muted: true,
                          fontSize: ResponsiveHelper.getResponsiveFontSize(
                              context,
                              mobileSize: 14,
                              tabletSize: 16),
                        ),
                      ),
                      SizedBox(height: 8),
                      SizedBox(
                        height: ResponsiveHelper.isTablet(context)
                            ? 50
                            : MySize.size40,
                        child: TextFormField(
                          controller: shippingDetails,
                          decoration: InputDecoration(
                            hintText: AppLocalizations.of(context)
                                ?.translate('shipping_details') ??
                                'Shipping Details',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
                height: ResponsiveHelper.getResponsiveSpacing(context,
                    mobileSpacing: 12, tabletSpacing: 16)),
            // Tip section - horizontal layout for tablet
            Row(
              children: <Widget>[
                Text(
                  AppLocalizations.of(context)?.translate('tip') ??
                      'Tip' + ' : ',
                  style: AppTheme.getTextStyle(
                    themeData.textTheme.bodyText1,
                    color: themeData.colorScheme.onBackground,
                    fontWeight: 600,
                    muted: true,
                    fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                        mobileSize: 14, tabletSize: 16),
                  ),
                ),
                SizedBox(
                    width: ResponsiveHelper.getResponsiveSpacing(context,
                        mobileSpacing: 12, tabletSpacing: 16)),
                tipDropdown(),
                SizedBox(
                    width: ResponsiveHelper.getResponsiveSpacing(context,
                        mobileSpacing: 12, tabletSpacing: 16)),
                Expanded(
                  child: Container(
                    height:
                    ResponsiveHelper.isTablet(context) ? 50 : MySize.size50,
                    child: TextFormField(
                      controller: tip_amountController,
                      enabled: !_fromSalesScreen || _initialTipAmount == 0.0, // Enable if not from sales screen OR if initial value was 0.0
                      style: TextStyle(
                        color: _fromSalesScreen ? Colors.grey[600] : null,
                      ),
                      decoration: InputDecoration(
                        prefix: Text(selectedTipType == 'fixed' ? symbol : ''),
                        labelText: AppLocalizations.of(context)
                            ?.translate('tip_amount') ??
                            'Tip Amount',
                        filled: _fromSalesScreen,
                        fillColor: _fromSalesScreen
                            ? (!_fromSalesScreen || _initialTipAmount == 0.0 ? Colors.white : Colors.grey[200])
                            : null,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(
                            color: _fromSalesScreen ? Colors.grey[400]! : Colors.grey[300]!,
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(
                            color: _fromSalesScreen ? Colors.grey[400]! : themeData.dividerColor,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(
                            color: _fromSalesScreen ? Colors.grey[400]! : themeData.primaryColor,
                          ),
                        ),
                      ),
                      textAlign: TextAlign.end,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d*\.?\d{0,2}$')),
                      ],
                      onTap: () {
                        if (!_isTipAmountEdited && !_fromSalesScreen) {
                          tip_amountController.clear();
                          _isTipAmountEdited = true;
                        }
                      },
                      onChanged: (value) {
                        if (value.contains('.')) {
                          final parts = value.split('.');
                          if (parts[0].length > 3) {
                            tip_amountController.clear();
                            value = "";
                          }
                        } else {
                          if (value.length > 3) {
                            tip_amountController.clear();
                            value = "";
                          }
                        }

                        setState(() {
                          tip_amount = Helper().validateInput(value);

                          if (maxtipValue != null && tip_amount > maxtipValue) {
                            proceedNext = false;

                            if (!_tipWarningShown) {
                              Future.delayed(const Duration(milliseconds: 500),
                                      () {
                                    Fluttertoast.showToast(
                                      msg: AppLocalizations.of(context)
                                          ?.translate('tip_error_message') ??
                                          '',
                                    );
                                  });
                              _tipWarningShown = true;
                            }
                          } else {
                            proceedNext = true;
                            _tipWarningShown = false;
                          }

                          invoiceAmount =
                              (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
                                  (double.tryParse(shippingCharges.text) ??
                                      0.00) +
                                  calculateTipAmount();
                          calculateMultiPayment();
                        });
                      },
                    ),
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  Widget _buildPaymentSummary() {
    return Container(
      padding: EdgeInsets.all(ResponsiveHelper.getResponsiveSpacing(context,
          mobileSpacing: 12, tabletSpacing: 16)),
      decoration: BoxDecoration(
        color: themeData.cardColor,
        borderRadius:
        BorderRadius.circular(ResponsiveHelper.getBorderRadius(context)),
        border: Border.all(
          color: themeData.dividerColor.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
              height: ResponsiveHelper.getResponsiveSpacing(context,
                  mobileSpacing: 12, tabletSpacing: 16)),
          if (ResponsiveHelper.isTablet(context))
          // Tablet layout - vertical stack
            Column(
              children: [
                _buildSummaryBlock(
                  amount: Helper().formatCurrency(invoiceAmount),
                  subject:
                  AppLocalizations.of(context)?.translate('total_payble') ??
                      'Total Payable',
                  backgroundColor: Colors.blue,
                ),
                SizedBox(
                    height: ResponsiveHelper.getResponsiveSpacing(context,
                        mobileSpacing: 8, tabletSpacing: 12)),
                _buildSummaryBlock(
                  amount: Helper().formatCurrency(totalPaying),
                  subject:
                  AppLocalizations.of(context)?.translate('total_paying') ??
                      'Total Paying',
                  backgroundColor: Colors.red,
                ),
                SizedBox(
                    height: ResponsiveHelper.getResponsiveSpacing(context,
                        mobileSpacing: 8, tabletSpacing: 12)),
                _buildSummaryBlock(
                  amount: Helper().formatCurrency(changeReturn),
                  subject: AppLocalizations.of(context)
                      ?.translate('change_return') ??
                      'Change Return',
                  backgroundColor: Colors.green,
                ),
                SizedBox(
                    height: ResponsiveHelper.getResponsiveSpacing(context,
                        mobileSpacing: 8, tabletSpacing: 12)),
                _buildSummaryBlock(
                  amount: Helper().formatCurrency(pendingAmount),
                  subject: AppLocalizations.of(context)?.translate('balance') ??
                      'Balance',
                  backgroundColor: Colors.orange,
                ),
              ],
            )
          else
          // Mobile layout - grid
            GridView.count(
              shrinkWrap: true,
              physics: ClampingScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: ResponsiveHelper.getResponsiveSpacing(context,
                  mobileSpacing: 8, tabletSpacing: 12),
              crossAxisSpacing: ResponsiveHelper.getResponsiveSpacing(context,
                  mobileSpacing: 8, tabletSpacing: 12),
              childAspectRatio: 8 / 3,
              children: <Widget>[
                block(
                  amount: Helper().formatCurrency(invoiceAmount),
                  subject:
                  AppLocalizations.of(context)?.translate('total_payble') ??
                      'Total Payable' + ' : ',
                  backgroundColor: Colors.blue,
                  textColor: themeData.colorScheme.onBackground,
                ),
                block(
                  amount: Helper().formatCurrency(totalPaying),
                  subject:
                  AppLocalizations.of(context)?.translate('total_paying') ??
                      'Total Paying' + ' : ',
                  backgroundColor: Colors.red,
                  textColor: themeData.colorScheme.onBackground,
                ),
                block(
                  amount: Helper().formatCurrency(changeReturn),
                  subject: AppLocalizations.of(context)
                      ?.translate('change_return') ??
                      'Change Return' + ' : ',
                  backgroundColor: Colors.green,
                  textColor: (changeReturn >= 0.01)
                      ? Colors.red
                      : themeData.colorScheme.onBackground,
                ),
                block(
                  amount: Helper().formatCurrency(pendingAmount),
                  subject: AppLocalizations.of(context)?.translate('balance') ??
                      'Balance' + ' : ',
                  backgroundColor: Colors.orange,
                  textColor: (pendingAmount >= 0.01)
                      ? Colors.red
                      : themeData.colorScheme.onBackground,
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildSummaryBlock({
    required String amount,
    required String subject,
    required Color backgroundColor,
  }) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(ResponsiveHelper.getResponsiveSpacing(context,
          mobileSpacing: 12, tabletSpacing: 16)),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius:
        BorderRadius.circular(ResponsiveHelper.getBorderRadius(context)),
        boxShadow: [
          BoxShadow(
            color: backgroundColor.withOpacity(0.3),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            subject,
            style: AppTheme.getTextStyle(
              themeData.textTheme.bodyText1,
              color: Colors.white,
              fontWeight: 600,
              fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                  mobileSize: 14, tabletSize: 16),
            ),
          ),
          Text(
            amount,
            style: AppTheme.getTextStyle(
              themeData.textTheme.headline6,
              color: Colors.white,
              fontWeight: 700,
              fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                  mobileSize: 16, tabletSize: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Container(
      padding: EdgeInsets.all(ResponsiveHelper.getResponsiveSpacing(context,
          mobileSpacing: 12, tabletSpacing: 16)),
      decoration: BoxDecoration(
        color: themeData.cardColor,
        borderRadius:
        BorderRadius.circular(ResponsiveHelper.getBorderRadius(context)),
        border: Border.all(
          color: themeData.dividerColor.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // Notes section - stacked for tablet
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                AppLocalizations.of(context)?.translate('sell_note') ??
                    'Sell Note',
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText1,
                  color: themeData.colorScheme.onBackground,
                  fontWeight: 600,
                  muted: true,
                  fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                      mobileSize: 14, tabletSize: 16),
                ),
              ),
              SizedBox(height: 8),
              Container(
                height: ResponsiveHelper.isTablet(context) ? 80 : MySize.size80,
                child: TextFormField(
                  controller: saleNote,
                  maxLines: 3,
                  decoration: InputDecoration(
                    hintText:
                    AppLocalizations.of(context)?.translate('sell_note') ??
                        'Sell Note',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
              SizedBox(
                  height: ResponsiveHelper.getResponsiveSpacing(context,
                      mobileSpacing: 12, tabletSpacing: 16)),
              Text(
                AppLocalizations.of(context)?.translate('staff_note') ??
                    'Staff Note',
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText1,
                  color: themeData.colorScheme.onBackground,
                  fontWeight: 600,
                  muted: true,
                  fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                      mobileSize: 14, tabletSize: 16),
                ),
              ),
              SizedBox(height: 8),
              Container(
                height: ResponsiveHelper.isTablet(context) ? 80 : MySize.size80,
                child: TextFormField(
                  controller: staffNote,
                  maxLines: 3,
                  decoration: InputDecoration(
                    hintText:
                    AppLocalizations.of(context)?.translate('staff_note') ??
                        'Staff Note',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
              height: ResponsiveHelper.getResponsiveSpacing(context,
                  mobileSpacing: 12, tabletSpacing: 16)),
          // Invoice type selection
          Container(
            padding: EdgeInsets.all(ResponsiveHelper.getResponsiveSpacing(
                context,
                mobileSpacing: 8,
                tabletSpacing: 12)),
            decoration: BoxDecoration(
              color: themeData.primaryColor.withOpacity(0.05),
              borderRadius: BorderRadius.circular(
                  ResponsiveHelper.getBorderRadius(context)),
              border: Border.all(
                color: themeData.primaryColor.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppLocalizations.of(context)?.translate('invoice_layout') ??
                      'Invoice Layout',
                  style: AppTheme.getTextStyle(
                    themeData.textTheme.bodyText1,
                    color: themeData.colorScheme.onBackground,
                    fontWeight: 600,
                    fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                        mobileSize: 14, tabletSize: 16),
                  ),
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: Row(
                        children: [
                          Radio(
                            value: "Mobile",
                            groupValue: invoiceType,
                            onChanged: (value) {
                              setState(() {
                                invoiceType = value.toString();
                                printWebInvoice = false;
                              });
                            },
                            toggleable: true,
                          ),
                          Expanded(
                            child: Text(
                              AppLocalizations.of(context)
                                  ?.translate('mobile_layout') ??
                                  'Mobile Layout',
                              maxLines: 2,
                              style: AppTheme.getTextStyle(
                                themeData.textTheme.bodyText2,
                                color: themeData.colorScheme.onBackground,
                                fontWeight: 600,
                                fontSize:
                                ResponsiveHelper.getResponsiveFontSize(
                                    context,
                                    mobileSize: 12,
                                    tabletSize: 14),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Row(
                        children: [
                          Radio(
                            value: "Web",
                            groupValue: invoiceType,
                            onChanged: (value) async {
                              if (await Helper().checkConnectivity()) {
                                setState(() {
                                  invoiceType = value.toString();
                                  printWebInvoice = true;
                                });
                              } else {
                                Fluttertoast.showToast(
                                  msg: AppLocalizations.of(context)
                                      ?.translate('check_connectivity') ??
                                      'Please check your internet connection',
                                );
                              }
                            },
                            toggleable: true,
                          ),
                          Expanded(
                            child: Text(
                              AppLocalizations.of(context)
                                  ?.translate('web_layout') ??
                                  'Web Layout',
                              maxLines: 2,
                              style: AppTheme.getTextStyle(
                                themeData.textTheme.bodyText2,
                                color: themeData.colorScheme.onBackground,
                                fontWeight: 600,
                                fontSize:
                                ResponsiveHelper.getResponsiveFontSize(
                                    context,
                                    mobileSize: 12,
                                    tabletSize: 14),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(
              height: ResponsiveHelper.getResponsiveSpacing(context,
                  mobileSpacing: 12, tabletSpacing: 16)),
          // Action buttons - stacked for tablet
          Column(
            children: [
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: themeData.colorScheme.onPrimary,
                    elevation: ResponsiveHelper.getCardElevation(context),
                    padding: EdgeInsets.symmetric(
                      vertical: ResponsiveHelper.isTablet(context) ? 18 : 16,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                          ResponsiveHelper.getBorderRadius(context)),
                    ),
                  ),
                  onPressed: () async {
                    _printInvoice = false;
                    if (pendingAmount >= 0.01) {
                      alertPending(context);
                    } else if (!saleCreated) {
                      await onSubmit();
                      // CRITICAL: Ensure table/shipping is enabled after submission
                      // Pass the sellId from state or arguments
                      await _ensureTableOrShippingEnabled(providedSellId: sellId ?? argument?['sellId']);
                    }
                  },
                  child: Text(
                    AppLocalizations.of(context)
                        ?.translate('finalize_n_share') ??
                        'Finalize & Share',
                    style: AppTheme.getTextStyle(
                      themeData.textTheme.subtitle1,
                      fontWeight: 700,
                      color: themeData.colorScheme.primary,
                      fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                          mobileSize: 16, tabletSize: 18),
                    ),
                  ),
                ),
              ),
              SizedBox(
                  height: ResponsiveHelper.getResponsiveSpacing(context,
                      mobileSpacing: 8, tabletSpacing: 12)),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: themeData.colorScheme.primary,
                    elevation: ResponsiveHelper.getCardElevation(context),
                    padding: EdgeInsets.symmetric(
                      vertical: ResponsiveHelper.isTablet(context) ? 18 : 16,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                          ResponsiveHelper.getBorderRadius(context)),
                    ),
                  ),
                  onPressed: () async {
                    _printInvoice = true;
                    if (pendingAmount >= 0.01) {
                      alertPending(context);
                    } else {
                      if (!saleCreated) {
                        int? sellIdBeforeSubmit = sellId ?? argument?['sellId'];
                        await onSubmit();
                        // CRITICAL: Wait a bit to ensure database is updated
                        await Future.delayed(Duration(milliseconds: 300));
                        // CRITICAL: Ensure table/shipping is enabled after submission
                        // Pass the sellId from state or arguments (same as Finalize & Share)
                        // Use sellIdBeforeSubmit as onSubmit might have changed sellId state
                        await _ensureTableOrShippingEnabled(providedSellId: sellId ?? sellIdBeforeSubmit ?? argument?['sellId']);
                      }
                    }
                  },
                  child: Text(
                    AppLocalizations.of(context)
                        ?.translate('finalize_n_print') ??
                        'Finalize & Print',
                    style: AppTheme.getTextStyle(
                      themeData.textTheme.subtitle1,
                      fontWeight: 700,
                      color: themeData.colorScheme.onPrimary,
                      fontSize: ResponsiveHelper.getResponsiveFontSize(context,
                          mobileSize: 16, tabletSize: 18),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  block({Color? backgroundColor, String? subject, amount, Color? textColor}) {
    ThemeData themeData = Theme.of(context);
    return Card(
      color:
      backgroundColor ?? themeData.cardColor, // Apply backgroundColor here
      clipBehavior: Clip.antiAliasWithSaveLayer,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(MySize.size8!)),
      child: Container(
        margin: EdgeInsets.all(MySize.size4!), // Add margin here
        height: MySize.size30,
        child: Container(
          padding: EdgeInsets.all(MySize.size2!),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(
                subject!,
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText1,
                  //color: themeData.colorScheme.onBackground,
                  color: Colors.white,
                  fontWeight: 800,
                  // muted: true,
                ),
              ),
              Text(
                "$symbol $amount",
                overflow: TextOverflow.ellipsis,
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText1,
                  // color: textColor,
                  color: Colors.white,
                  fontWeight: 600,
                  //muted: true,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // calculateMultiPayment() {
  //   totalPaying = 0.0;
  //   payments.forEach((element) {
  //     totalPaying += element['amount'];
  //   });
  //   if (totalPaying > invoiceAmount) {
  //     changeReturn = totalPaying - invoiceAmount;
  //     pendingAmount = 0.0;
  //   } else if (invoiceAmount > totalPaying) {
  //     pendingAmount = invoiceAmount - totalPaying;
  //     changeReturn = 0.0;
  //   } else {
  //     pendingAmount = 0.0;
  //     changeReturn = 0.0;
  //   }
  //   setState(() {});
  // }
  calculateMultiPayment() {
    totalPaying = 0.0;
    payments.forEach((element) {
      totalPaying += element['amount'];
    });
    if (totalPaying > invoiceAmount) {
      changeReturn = totalPaying - invoiceAmount;
      pendingAmount = 0.0;

      // Update the change_return field in the payment records
      // For simplicity, assign the entire change return to the first payment method
      if (payments.isNotEmpty) {
        // Clear change_return from all payments first
        for (var payment in payments) {
          payment['change_return'] = 0.0;
        }
        // Assign the full change return to the first payment
        payments[0]['change_return'] = changeReturn;
      }
    } else if (invoiceAmount > totalPaying) {
      pendingAmount = invoiceAmount - totalPaying;
      changeReturn = 0.0;

      // Clear change_return from all payments
      for (var payment in payments) {
        payment['change_return'] = 0.0;
      }
    } else {
      pendingAmount = 0.0;
      changeReturn = 0.0;

      // Clear change_return from all payments
      for (var payment in payments) {
        payment['change_return'] = 0.0;
      }
    }
    setState(() {});
  }

  double calculateTipAmount() {
    double baseAmount = argument!['invoiceAmount']?.toDouble() ?? 0.00;

    // If we have sellDetail data (coming from Recent Sales), calculate base amount without tip
    if (sellDetail.isNotEmpty) {
      double originalTipAmount = double.tryParse(sellDetail[0]['tip_amount']?.toString() ?? '0.00') ?? 0.00;
      // Only subtract original tip if the invoice amount is greater than the tip amount
      // This prevents issues in partial payment scenarios
      if (baseAmount > originalTipAmount) {
        baseAmount = baseAmount - originalTipAmount;
      }
    }

    double tip;
    if (selectedTipType == 'fixed') {
      tip = tip_amount;
    } else {
      tip = baseAmount * (tip_amount / 100.0);
    }
    return tip;
  }

  setPaymentDetails() async {
    List payments =
    await System().get('payment_method', argument!['locationId']);
    debugPrint(
        'setPaymentDetails: Fetched ${payments.length} payment methods: $payments');

    // Clear existing payment methods to prevent duplicates
    setState(() {
      paymentMethods.clear();
    });

    payments.forEach((element) {
      setState(() {
        paymentMethods.add({
          'name': element['name'],
          'value': element['label'],
          'account_id': (element['account_id'] != null)
              ? int.parse(element['account_id'].toString())
              : null,
        });
      });
    });
    debugPrint('setPaymentDetails: Updated paymentMethods: $paymentMethods');
  }

  // Future<void> onSubmit() async {
  //   setState(() {
  //     isLoading = true;
  //     saleCreated = true;
  //   });
  //   print('onSubmit: Starting sale submission for sellId: $sellId, res_table_id: $res_table_id');
  //
  //   try {
  //     var token = await System().getToken();
  //     print('onSubmit: Token before processing: $token');
  //
  //     tip_amount = double.tryParse(tip_amountController.text) ?? 0.00;
  //     print('onSubmit: Parsed tip_amount: $tip_amount');
  //
  //     if (!hasTipTypeColumn) {
  //       print('onSubmit: Database schema outdated');
  //       Fluttertoast.showToast(
  //         msg: AppLocalizations.of(context)?.translate('schema_outdated') ??
  //             'Database schema outdated. Please update the app.',
  //         toastLength: Toast.LENGTH_LONG,
  //       );
  //       setState(() {
  //         isLoading = false;
  //         saleCreated = false;
  //       });
  //       return;
  //     }
  //
  //     print('onSubmit: argument = $argument');
  //     print('onSubmit: products = ${argument!['products']}');
  //     print("Card details : ${payments}");
  //
  //     var sellLines = await SellDatabase().getSellLineBySellId(sellId ?? 0);
  //     print('onSubmit: Sell lines for sellId $sellId: $sellLines');
  //
  //     Map<String, dynamic> sellData = {
  //       'invoiceNo': USERID.toString() + "_" + DateFormat('yMdHm').format(DateTime.now()),
  //       'transactionDate': transactionDate,
  //       'changeReturn': changeReturn,
  //       'contactId': argument!['customerId'],
  //       'invoiceAmount': invoiceAmount,
  //       'locId': argument!['locationId'],
  //       'pending': pendingAmount,
  //       'saleNote': saleNote.text,
  //       'saleStatus': 'final',
  //       'sellId': sellId,
  //       'shippingCharges': (shippingCharges.text.isNotEmpty) ? double.parse(shippingCharges.text) : 0.00,
  //       'shippingDetails': shippingDetails.text,
  //       'staffNote': staffNote.text,
  //       'taxId': argument!['taxId'],
  //       'isQuotation': 0,
  //       'tip_amount': calculateTipAmount(),
  //       'tip_type': selectedTipType,
  //       'discount_amount': argument!['discountAmount'] ?? 0.0,
  //       'discount_type': argument!['discountType'] ?? 'fixed',
  //
  //       'res_table_id': argument!['res_table_id'],
  //     };
  //
  //     List<Map> products = argument!['products']?.map<Map>((product) {
  //       return {
  //         'product_id': product['product_id'],
  //         'variation_id': product['variation_id'],
  //         'quantity': product['quantity'],
  //         'unit_price': product['unit_price'],
  //         'tax_rate_id': product['tax_rate_id'],
  //         'discount_amount': product['discount_amount'] ?? 0.0,
  //         'discount_type': product['discount_type'] ?? 'fixed',
  //         'note': product['note'] ?? '',
  //         'product_order_category': product['product_order_category'] ?? 'BAR',
  //       };
  //     }).toList() ?? [];
  //
  //     if (products.isEmpty) {
  //       print('onSubmit: Error: No products selected for the sale');
  //       Fluttertoast.showToast(
  //         msg: AppLocalizations.of(context)?.translate('no_products_selected') ??
  //             'Please add at least one product to the sale.',
  //         toastLength: Toast.LENGTH_LONG,
  //       );
  //       setState(() {
  //         isLoading = false;
  //         saleCreated = false;
  //       });
  //       return;
  //     }
  //
  //     List<Map> updatedPayments = payments.map((payment) {
  //       return {
  //         'method': payment['method'],
  //         'amount': payment['amount'],
  //         'note': payment['note'] ?? '',
  //         'account_id': payment['account_id'],
  //         'received_amount': payment['received_amount'] ?? null,
  //         'change_return': payment['change_return'] ?? 0.0,
  //         'card_details': payment['card_details'],
  //       };
  //     }).toList();
  //
  //     Map<String, dynamic> sellPayload = {
  //       'sells': [
  //         {
  //           'location_id': sellData['locId'],
  //           'contact_id': sellData['contactId'],
  //           'transaction_date': sellData['transactionDate'],
  //           'invoice_no': sellData['invoiceNo'],
  //           'status': sellData['saleStatus'],
  //           'sub_status': sellData['isQuotation'] == 1 ? 'quotation' : null,
  //           'tax_rate_id': sellData['taxId'] == 0 ? null : sellData['taxId'],
  //           'discount_amount': sellData['discount_amount'] ?? 0.0,
  //           'discount_type': sellData['discount_type'] ?? 'fixed',
  //           'change_return': sellData['changeReturn'],
  //           'products': products,
  //           'sale_note': sellData['saleNote'],
  //           'staff_note': sellData['staffNote'],
  //           'shipping_charges': sellData['shippingCharges'],
  //           'shipping_details': sellData['shippingDetails'],
  //           'tip_amount': sellData['tip_amount'].toString(),
  //           'tip_type': sellData['tip_type'],
  //           'is_quotation': sellData['isQuotation'],
  //           'payments': updatedPayments,
  //
  //           'res_table_id': sellData['res_table_id'],
  //         }
  //       ]
  //     };
  //
  //     print('onSubmit: Prepared sell payload: ${jsonEncode(sellPayload)}');
  //
  //     Map<String, dynamic> sell = await Sell().createSell(
  //       invoiceNo: sellData['invoiceNo'],
  //       transactionDate: sellData['transactionDate'],
  //       changeReturn: sellData['changeReturn'],
  //       contactId: sellData['contactId'],
  //       invoiceAmount: sellData['invoiceAmount'],
  //       locId: sellData['locId'],
  //       pending: sellData['pending'],
  //       saleNote: sellData['saleNote'],
  //       saleStatus: sellData['saleStatus'],
  //       sellId: sellData['sellId'],
  //       shippingCharges: sellData['shippingCharges'],
  //       shippingDetails: sellData['shippingDetails'],
  //       staffNote: sellData['staffNote'],
  //       taxId: sellData['taxId'],
  //       isQuotation: sellData['isQuotation'],
  //       tip_amount: sellData['tip_amount'],
  //       tip_type: hasTipTypeColumn ? sellData['tip_type'] : null,
  //
  //       res_table_id: sellData['res_table_id'],
  //     );
  //
  //     print('onSubmit: Created sell map: ${jsonEncode(sell)}');
  //
  //     int? response;
  //
  //     if (sellId != null) {
  //       print('onSubmit: Updating existing sell: $sellId');
  //       response = sellId;
  //       await SellDatabase().updateSells(sellId!, sell);
  //       print('onSubmit: Updated local sell: $sellId');
  //
  //       for (var element in updatedPayments) {
  //         if (element is Map<String, dynamic>) {
  //           if (element['id'] != null) {
  //             paymentLine = {
  //               'amount': element['amount'],
  //               'method': element['method'],
  //               'note': element['note'],
  //               'account_id': element['account_id'],
  //               'received_amount': element['received_amount'],
  //               'change_return': element['change_return'],
  //               'card_details': element['card_details'],
  //             };
  //             print('onSubmit: Updating payment line: ${element['id']}');
  //             await PaymentDatabase().updateEditedPaymentLine(element['id'], paymentLine);
  //           } else {
  //             paymentLine = {
  //               'sell_id': sellId,
  //               'method': element['method'],
  //               'amount': element['amount'],
  //               'note': element['note'],
  //               'account_id': element['account_id'],
  //               'received_amount': element['received_amount'],
  //               'change_return': element['change_return'],
  //               'card_details': element['card_details'],
  //             };
  //             print('onSubmit: Storing new payment line for sell: $sellId');
  //             await PaymentDatabase().store(paymentLine);
  //           }
  //         } else {
  //           print('onSubmit: Invalid payment element: $element');
  //         }
  //       }
  //
  //       if (deletedPaymentId.isNotEmpty) {
  //         print('onSubmit: Deleting payment lines: $deletedPaymentId');
  //         await PaymentDatabase().deletePaymentLineByIds(deletedPaymentId);
  //       }
  //
  //       if (await Helper().checkConnectivity()) {
  //         print('onSubmit: Network available, attempting to sync sell: $sellId');
  //         print('onSubmit: Token before API call: $token');
  //         var apiResult = await Sell().createApiSell(sellId: sellId, payload: sellPayload).timeout(
  //           Duration(seconds: 30),
  //           onTimeout: () {
  //             print('onSubmit: API call timed out after 30 seconds');
  //             return {'error': 'API call timed out'};
  //           },
  //         );
  //         if (apiResult != null && !apiResult.containsKey('error')) {
  //           print('onSubmit: Sell synced successfully: $sellId, Result: $apiResult');
  //           await SellDatabase().updateSells(sellId!, {
  //             'is_synced': 1,
  //             'transaction_id': apiResult['transaction_id'],
  //             'invoice_url': apiResult['invoice_url'] ?? '',
  //             'tip_type': apiResult['tip_type'] ?? 'fixed',
  //             'tip_amount': apiResult['tip_amount']?.toString() ?? '0.00',
  //           });
  //           Fluttertoast.showToast(
  //             msg: AppLocalizations.of(context)?.translate('sell_synced') ?? 'Sell synced successfully',
  //             toastLength: Toast.LENGTH_LONG,
  //           );
  //
  //           //new added for table
  //           // Reset cart for the specific res_table_id
  //           if (argument!['res_table_id'] != null) {
  //             await SellDatabase().resetCartForTable(argument!['res_table_id']);
  //             print('onSubmit: Cart reset for res_table_id: ${argument!['res_table_id']}');
  //           }
  //
  //           if (_printInvoice) {
  //             await printOption(sellId!);
  //           }
  //           // this else added
  //           else {
  //             Navigator.pushNamedAndRemoveUntil(
  //               context,
  //               '/tables',
  //                   (Route<dynamic> route) => false,
  //             );
  //           }
  //         } else {
  //           print('onSubmit: Failed to sync sell: $sellId, Error: ${apiResult?['error'] ?? 'Unknown error'}');
  //           Fluttertoast.showToast(
  //             msg: AppLocalizations.of(context)?.translate('api_error_will_sync_later') ??
  //                 'Failed to sync: ${apiResult?['error'] ?? 'Unknown error'}',
  //             toastLength: Toast.LENGTH_LONG,
  //           );
  //
  //           //new added for table
  //           // Reset cart for the specific res_table_id even if sync fails
  //           if (argument!['res_table_id'] != null) {
  //             await SellDatabase().resetCartForTable(argument!['res_table_id']);
  //             print('onSubmit: Cart reset for res_table_id: ${argument!['res_table_id']}');
  //           }
  //
  //           if (_printInvoice) {
  //             await printOption(sellId!);
  //           }
  //           // this else added
  //           else {
  //             Navigator.pushNamedAndRemoveUntil(
  //               context,
  //               '/tables',
  //                   (Route<dynamic> route) => false,
  //             );
  //           }
  //         }
  //       } else {
  //         print('onSubmit: No connectivity, storing sell locally: $sellId');
  //         Fluttertoast.showToast(
  //           msg: AppLocalizations.of(context)?.translate('no_connectivity') ?? 'No internet connection, stored locally',
  //           toastLength: Toast.LENGTH_LONG,
  //         );
  //
  //         //new added for table
  //         // Reset cart for the specific res_table_id
  //         if (argument!['res_table_id'] != null) {
  //           await SellDatabase().resetCartForTable(argument!['res_table_id']);
  //           print('onSubmit: Cart reset for res_table_id: ${argument!['res_table_id']}');
  //         }
  //
  //         if (_printInvoice) {
  //           await printOption(sellId!);
  //         }
  //         // this else added
  //         else {
  //           Navigator.pushNamedAndRemoveUntil(
  //             context,
  //             '/tables',
  //                 (Route<dynamic> route) => false,
  //           );
  //         }
  //       }
  //     } else {
  //       print('onSubmit: Creating new sell');
  //       response = await SellDatabase().storeSell(sell);
  //       print('onSubmit: Stored sell locally: $response');
  //
  //       for (var product in products) {
  //         await SellDatabase().store({
  //           'sell_id': response,
  //           ...product,
  //           'is_completed': 1,
  //         });
  //       }
  //       await Sell().makePayment(updatedPayments, response);
  //       await SellDatabase().updateSellLine({'sell_id': response, 'is_completed': 1});
  //
  //       if (await Helper().checkConnectivity()) {
  //         print('onSubmit: Network available, attempting to sync sell: $response');
  //         print('onSubmit: Token before API call: $token');
  //         var apiResult = await Sell().createApiSell(sellId: response, payload: sellPayload).timeout(
  //           Duration(seconds: 30),
  //           onTimeout: () {
  //             print('onSubmit: API call timed out after 30 seconds');
  //             return {'error': 'API call timed out'};
  //           },
  //         );
  //         if (apiResult != null && !apiResult.containsKey('error')) {
  //           print('onSubmit: Sell synced successfully: $response, Result: $apiResult');
  //           await SellDatabase().updateSells(response, {
  //             'is_synced': 1,
  //             'transaction_id': apiResult['transaction_id'],
  //             'invoice_url': apiResult['invoice_url'] ?? '',
  //             'tip_type': apiResult['tip_type'] ?? 'fixed',
  //             'tip_amount': apiResult['tip_amount']?.toString() ?? '0.00',
  //           });
  //           Fluttertoast.showToast(
  //             msg: AppLocalizations.of(context)?.translate('sell_synced') ?? 'Sell synced successfully',
  //             toastLength: Toast.LENGTH_LONG,
  //           );
  //
  //           //new added for table
  //           // Reset cart for the specific res_table_id
  //           if (argument!['res_table_id'] != null) {
  //             await SellDatabase().resetCartForTable(argument!['res_table_id']);
  //             print('onSubmit: Cart reset for res_table_id: ${argument!['res_table_id']}');
  //           }
  //
  //           if (_printInvoice) {
  //             await printOption(response);
  //           }
  //           // this else added
  //           else {
  //             Navigator.pushNamedAndRemoveUntil(
  //               context,
  //               '/tables',
  //                   (Route<dynamic> route) => false,
  //             );
  //           }
  //         } else {
  //           print('onSubmit: Failed to sync sell: $response, Error: ${apiResult?['error'] ?? 'Unknown error'}');
  //           Fluttertoast.showToast(
  //             msg: AppLocalizations.of(context)?.translate('api_error_will_sync_later') ??
  //                 'Failed to sync: ${apiResult?['error'] ?? 'Unknown error'}',
  //             toastLength: Toast.LENGTH_LONG,
  //           );
  //
  //           //new added for table
  //           // Reset cart for the specific res_table_id even if sync fails
  //           if (argument!['res_table_id'] != null) {
  //             await SellDatabase().resetCartForTable(argument!['res_table_id']);
  //             print('onSubmit: Cart reset for res_table_id: ${argument!['res_table_id']}');
  //           }
  //
  //           if (_printInvoice) {
  //             await printOption(response);
  //           }
  //           // this else added
  //           else {
  //             Navigator.pushNamedAndRemoveUntil(
  //               context,
  //               '/tables',
  //                   (Route<dynamic> route) => false,
  //             );
  //           }
  //         }
  //       } else {
  //         print('onSubmit: No connectivity, storing sell locally: $response');
  //         Fluttertoast.showToast(
  //           msg: AppLocalizations.of(context)?.translate('no_connectivity') ?? 'No internet connection, stored locally',
  //           toastLength: Toast.LENGTH_LONG,
  //         );
  //
  //         //new added for table
  //         // Reset cart for the specific res_table_id
  //         if (argument!['res_table_id'] != null) {
  //           await SellDatabase().resetCartForTable(argument!['res_table_id']);
  //           print('onSubmit: Cart reset for res_table_id: ${argument!['res_table_id']}');
  //         }
  //
  //         if (_printInvoice) {
  //           await printOption(response);
  //         }
  //         // this else added
  //         else {
  //           Navigator.pushNamedAndRemoveUntil(
  //             context,
  //             '/tables',
  //                 (Route<dynamic> route) => false,
  //           );
  //         }
  //       }
  //     }
  //   } catch (e, stackTrace) {
  //     print('onSubmit: Error: $e');
  //     print('onSubmit: Stack Trace: $stackTrace');
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context)?.translate('error_submitting_sale') ?? 'Error submitting sale: $e',
  //       toastLength: Toast.LENGTH_LONG,
  //     );
  //   } finally {
  //     setState(() {
  //       isLoading = false;
  //       saleCreated = false;
  //     });
  //     print('onSubmit: Completed');
  //   }
  // }

  /// CRITICAL: Ensures table/shipping is enabled after order submission
  /// This method is called after onSubmit() completes to guarantee the table/shipping is enabled
  Future<void> _ensureTableOrShippingEnabled({int? providedSellId}) async {
    try {
      debugPrint('_ensureTableOrShippingEnabled: Starting to ensure table/shipping is enabled');

      // Get the sellId from provided parameter, state, or arguments
      int? currentSellId = providedSellId ?? sellId ?? argument?['sellId'];

      // If still not found, try to get from the most recent sale in database for this table/shipping
      if (currentSellId == null || currentSellId == 0) {
        debugPrint('_ensureTableOrShippingEnabled: No sellId from state/arguments, trying to find from database');
        int? resTableIdFromArg = argument?['res_table_id'];
        int isShippingFromArg = argument?['is_shipping'] ?? 0;
        int? locationIdFromArg = argument?['locationId'];

        if (locationIdFromArg != null) {
          // Try to find the most recent sale for this table/shipping
          try {
            final db = await SellDatabase().database;
            var recentSale = await db.query(
              'sell',
              where: isShippingFromArg == 1
                  ? 'is_shipping = ? AND location_id = ? AND sale_status = ?'
                  : 'res_table_id = ? AND is_shipping = ? AND location_id = ? AND sale_status = ?',
              whereArgs: isShippingFromArg == 1
                  ? [1, locationIdFromArg, 'final']
                  : [resTableIdFromArg, 0, locationIdFromArg, 'final'],
              orderBy: 'id DESC',
              limit: 1,
            );
            if (recentSale.isEmpty) {
              // Try with 'draft' status as well (might be just completed)
              recentSale = await db.query(
                'sell',
                where: isShippingFromArg == 1
                    ? 'is_shipping = ? AND location_id = ? AND (sale_status = ? OR sale_status = ?)'
                    : 'res_table_id = ? AND is_shipping = ? AND location_id = ? AND (sale_status = ? OR sale_status = ?)',
                whereArgs: isShippingFromArg == 1
                    ? [1, locationIdFromArg, 'final', 'draft']
                    : [resTableIdFromArg, 0, locationIdFromArg, 'final', 'draft'],
                orderBy: 'id DESC',
                limit: 1,
              );
            }
            if (recentSale.isNotEmpty) {
              currentSellId = recentSale[0]['id'] as int?;
              debugPrint('_ensureTableOrShippingEnabled: Found recent sale from database: $currentSellId');
            }
          } catch (e) {
            debugPrint('_ensureTableOrShippingEnabled: Error finding recent sale: $e');
          }
        }
      }

      if (currentSellId == null || currentSellId == 0) {
        debugPrint('_ensureTableOrShippingEnabled: No sellId found, cannot enable table/shipping');
        // Fallback: Use arguments directly to enable table/shipping
        int? resTableIdFromArg = argument?['res_table_id'];
        int isShippingFromArg = argument?['is_shipping'] ?? 0;
        int? locationIdFromArg = argument?['locationId'];

        if (locationIdFromArg != null) {
          final availabilityManager = TableAvailabilityManager();
          if (isShippingFromArg == 1) {
            await availabilityManager.forceEnableTableOrShipping(
              tableId: null,
              isShipping: true,
              locationId: locationIdFromArg,
            );
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('_ensureTableOrShippingEnabled: Force enabled shipping using arguments (fallback, cache set)');
          } else if (resTableIdFromArg != null && resTableIdFromArg != 0) {
            await availabilityManager.forceEnableTableOrShipping(
              tableId: resTableIdFromArg,
              isShipping: false,
              locationId: locationIdFromArg,
            );
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('_ensureTableOrShippingEnabled: Force enabled table $resTableIdFromArg using arguments (fallback, cache set)');
          }
        }
        return;
      }

      debugPrint('_ensureTableOrShippingEnabled: Processing sellId=$currentSellId');

      // Get the sale record from database
      var sellRecord = await SellDatabase().getSellBySellId(currentSellId);
      if (sellRecord.isEmpty) {
        debugPrint('_ensureTableOrShippingEnabled: Sale record not found for sellId=$currentSellId, using arguments as fallback');
        // Fallback: Use arguments directly
        int? resTableIdFromArg = argument?['res_table_id'];
        int isShippingFromArg = argument?['is_shipping'] ?? 0;
        int? locationIdFromArg = argument?['locationId'];

        if (locationIdFromArg != null) {
          final availabilityManager = TableAvailabilityManager();
          if (isShippingFromArg == 1) {
            await availabilityManager.forceEnableTableOrShipping(
              tableId: null,
              isShipping: true,
              locationId: locationIdFromArg,
            );
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('_ensureTableOrShippingEnabled: Force enabled shipping using arguments (fallback, cache set)');
          } else if (resTableIdFromArg != null && resTableIdFromArg != 0) {
            await availabilityManager.forceEnableTableOrShipping(
              tableId: resTableIdFromArg,
              isShipping: false,
              locationId: locationIdFromArg,
            );
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('_ensureTableOrShippingEnabled: Force enabled table $resTableIdFromArg using arguments (fallback, cache set)');
          }
        }
        return;
      }

      int? resTableId = sellRecord[0]['res_table_id'];
      int isShipping = sellRecord[0]['is_shipping'] ?? 0;
      int? locationId = sellRecord[0]['location_id'];
      String? currentStatus = sellRecord[0]['sale_status']?.toString();

      debugPrint('_ensureTableOrShippingEnabled: res_table_id=$resTableId, is_shipping=$isShipping, location_id=$locationId, current_status=$currentStatus');

      // CRITICAL: For draft (Ordered) sales, we MUST update sale_status to 'final' before enabling table/shipping
      // This ensures the table/shipping is enabled for ALL draft orders, not just the last one
      if (currentStatus == 'draft' || currentStatus == null || currentStatus.isEmpty) {
        debugPrint('_ensureTableOrShippingEnabled: Current status is draft/null, updating to final for sellId=$currentSellId');
      }

      // CRITICAL: Set sale_status to 'final' using direct SQL (multiple attempts)
      bool statusUpdated = false;
      for (int attempt = 1; attempt <= 5; attempt++) {
        try {
          final db = await SellDatabase().database;
          int rowsUpdated = await db.rawUpdate(
            'UPDATE sell SET sale_status = ? WHERE id = ?',
            ['final', currentSellId],
          );

          if (rowsUpdated == 0) {
            // Try 'sells' table
            rowsUpdated = await db.rawUpdate(
              'UPDATE sells SET sale_status = ? WHERE id = ?',
              ['final', currentSellId],
            );
          }

          debugPrint('_ensureTableOrShippingEnabled: Direct SQL update attempt $attempt affected $rowsUpdated rows');

          // Wait for commit
          await Future.delayed(Duration(milliseconds: 150));

          // Verify the update
          var verifyRecord = await SellDatabase().getSellBySellId(currentSellId);
          if (verifyRecord.isNotEmpty) {
            String? verifiedStatus = verifyRecord[0]['sale_status']?.toString();
            debugPrint('_ensureTableOrShippingEnabled: Verified status after attempt $attempt: $verifiedStatus');
            if (verifiedStatus == 'final') {
              statusUpdated = true;
              debugPrint('_ensureTableOrShippingEnabled: sale_status successfully set to final on attempt $attempt');
              break;
            }
          }

          if (attempt < 5) {
            await Future.delayed(Duration(milliseconds: 200));
          }
        } catch (e) {
          debugPrint('_ensureTableOrShippingEnabled: Direct SQL update attempt $attempt failed: $e');
        }
      }

      if (!statusUpdated) {
        debugPrint('_ensureTableOrShippingEnabled: WARNING - sale_status may not be final after all attempts');
      }

      // CRITICAL: Call finalizeOrder() to enable the table/shipping
      // This will update sale_status to 'final' and enable the table/shipping
      debugPrint('_ensureTableOrShippingEnabled: Calling finalizeOrder() with sellId=$currentSellId, res_table_id=$resTableId, is_shipping=$isShipping');
      await Sell().finalizeOrder(currentSellId, resTableId, isShipping);
      debugPrint('_ensureTableOrShippingEnabled: finalizeOrder() completed');

      // CRITICAL: Verify sale_status was updated to 'final'
      var verifyAfterFinalize = await SellDatabase().getSellBySellId(currentSellId);
      if (verifyAfterFinalize.isNotEmpty) {
        String? statusAfterFinalize = verifyAfterFinalize[0]['sale_status']?.toString();
        debugPrint('_ensureTableOrShippingEnabled: sale_status after finalizeOrder: $statusAfterFinalize');
        if (statusAfterFinalize != 'final') {
          debugPrint('_ensureTableOrShippingEnabled: WARNING - sale_status is still not final after finalizeOrder! Forcing update...');
          // Force update using direct SQL
          try {
            final db = await SellDatabase().database;
            int rowsUpdated = await db.rawUpdate(
              'UPDATE sell SET sale_status = ? WHERE id = ?',
              ['final', currentSellId],
            );
            if (rowsUpdated == 0) {
              rowsUpdated = await db.rawUpdate(
                'UPDATE sells SET sale_status = ? WHERE id = ?',
                ['final', currentSellId],
              );
            }
            debugPrint('_ensureTableOrShippingEnabled: Direct SQL update affected $rowsUpdated rows');
            // Verify again
            await Future.delayed(Duration(milliseconds: 100));
            var finalVerify = await SellDatabase().getSellBySellId(currentSellId);
            if (finalVerify.isNotEmpty) {
              String? finalStatus = finalVerify[0]['sale_status']?.toString();
              debugPrint('_ensureTableOrShippingEnabled: Final verification - sale_status: $finalStatus');
            }
          } catch (e) {
            debugPrint('_ensureTableOrShippingEnabled: Direct SQL update failed: $e');
          }
        }
      }

      // CRITICAL: Force enable table/shipping
      // This ensures the table/shipping is enabled even if there are other draft orders
      // We force enable AFTER updating sale_status to 'final' so the table/shipping
      // becomes available for new orders even if other draft orders exist
      final availabilityManager = TableAvailabilityManager();
      if (isShipping == 1) {
        await availabilityManager.forceEnableTableOrShipping(
          tableId: null,
          isShipping: true,
          locationId: locationId,
        );
        // Don't call refreshAvailability() here as it will clear the cache and re-validate
        // which might find other draft orders and mark it as unavailable again
        // The force enable should persist
        debugPrint('_ensureTableOrShippingEnabled: Force enabled shipping (cache set, not refreshing to avoid re-validation)');
      } else if (resTableId != null && resTableId != 0) {
        await availabilityManager.forceEnableTableOrShipping(
          tableId: resTableId,
          isShipping: false,
          locationId: locationId,
        );
        // Don't call refreshAvailability() here as it will clear the cache and re-validate
        // which might find other draft orders and mark it as unavailable again
        // The force enable should persist
        debugPrint('_ensureTableOrShippingEnabled: Force enabled table $resTableId (cache set, not refreshing to avoid re-validation)');
      }

      debugPrint('_ensureTableOrShippingEnabled: Successfully ensured table/shipping is enabled for sellId=$currentSellId');
    } catch (e, stackTrace) {
      debugPrint('_ensureTableOrShippingEnabled: ERROR - $e');
      debugPrint('_ensureTableOrShippingEnabled: Stack trace: $stackTrace');
    }
  }

  Future<void> onSubmit() async {
    setState(() {
      isLoading = true;
      saleCreated = true;
    });
    debugPrint(
        'onSubmit: Starting sale submission for sellId=$sellId, res_table_id=${argument!['res_table_id']},  is_shipping=${argument!['is_shipping']}');

    try {
      // Use the is_shipping value from arguments directly
      int isShipping = argument!['is_shipping'] ?? 0;
      debugPrint('onSubmit: is_shipping set to $isShipping');
      // Set res_table_id to 0 for shipping sales

      print(">>>>>>>>>>${argument!['is_shipping']}");
      int? effectiveTableId =
      argument!['is_shipping'] == 1 ? 0 : argument!['res_table_id'];
      // Validate that res_table_id is provided for non-shipping sales
      if (effectiveTableId == null && argument!['is_shipping'] != 1) {
        debugPrint(
            'onSubmit: Error: res_table_id is null for non-shipping sale');
        Fluttertoast.showToast(
          msg: AppLocalizations.of(context)?.translate('invalid_table_id') ??
              'Table ID is required for non-shipping sales',
          toastLength: Toast.LENGTH_LONG,
        );
        setState(() {
          isLoading = false;
          saleCreated = false;
        });
        return;
      }

      //Validate res_table_id
      // if (argument!['res_table_id'] == null && argument!['is_shipping'] != 1) {
      //   debugPrint('onSubmit: Error: res_table_id is null and is_shipping is not 1');
      //   Fluttertoast.showToast(
      //     msg: AppLocalizations.of(context)?.translate('invalid_table_id') ?? 'Table ID is required for non-shipping sales',
      //     toastLength: Toast.LENGTH_LONG,
      //   );
      //   setState(() {
      //     isLoading = false;
      //     saleCreated = false;
      //   });
      //   return;
      // }

      var token = await System().getToken();
      debugPrint('onSubmit: Token before processing: $token');

      tip_amount = double.tryParse(tip_amountController.text) ?? 0.00;
      debugPrint('onSubmit: Parsed tip_amount: $tip_amount');

      if (!hasTipTypeColumn) {
        debugPrint('onSubmit: Database schema outdated');

        setState(() {
          isLoading = false;
          saleCreated = false;
        });
        return;
      }

      debugPrint('onSubmit: argument=${jsonEncode(argument)}');
      debugPrint('onSubmit: products=${argument!['products']}');
      debugPrint('onSubmit: Card details: $payments');

      var sellLines = await SellDatabase().getSellLineBySellId(sellId ?? 0, res_table_id: effectiveTableId, includeCompleted: true);
      debugPrint('onSubmit: Sell lines for sellId=$sellId, res_table_id=$effectiveTableId (includeCompleted: true): $sellLines');

      // Debug: Log all incomplete carts before submission
      var allCartsBefore = await SellDatabase()
          .getInCompleteLines(argument!['locationId'], resTableId: null);
      debugPrint(
          'onSubmit: All incomplete sell_lines before submission: $allCartsBefore');

      // CRITICAL: Use sale data from arguments when coming from Sales screen
      // This ensures the updated sale data (status, payment_status, transaction_date, etc.) is used
      String? effectiveTransactionDate = _fromSalesScreen && argument?['transaction_date'] != null
          ? argument!['transaction_date']
          : transactionDate;
      String? effectiveInvoiceNo = _fromSalesScreen && argument?['invoice_no'] != null
          ? argument!['invoice_no']
          : (USERID.toString() + "_" + DateFormat('yMdHm').format(DateTime.now()));
      String? effectiveSaleNote = saleNote.text.isNotEmpty ? saleNote.text : (argument?['sale_note'] ?? '');
      String? effectiveStaffNote = staffNote.text.isNotEmpty ? staffNote.text : (argument?['staff_note'] ?? '');
      String? effectiveShippingDetails = shippingDetails.text.isNotEmpty ? shippingDetails.text : (argument?['shipping_details'] ?? '');
      double effectiveShippingCharges = shippingCharges.text.isNotEmpty
          ? double.parse(shippingCharges.text)
          : (argument?['shipping_charges']?.toDouble() ?? 0.00);
      double effectiveTipAmount = calculateTipAmount();
      String effectiveTipType = selectedTipType;

      // Use tip data from arguments if available and not edited
      if (_fromSalesScreen && argument?['tip_amount'] != null && !_isTipAmountEdited) {
        effectiveTipAmount = argument!['tip_amount']?.toDouble() ?? calculateTipAmount();
      }
      if (_fromSalesScreen && argument?['tip_type'] != null && !_isTipAmountEdited) {
        effectiveTipType = argument!['tip_type'] ?? selectedTipType;
      }

      Map<String, dynamic> sellData = {
        'invoiceNo': effectiveInvoiceNo,
        'transactionDate': effectiveTransactionDate,
        'changeReturn': 0.0,
        'contactId': argument!['customerId'],
        'invoiceAmount': invoiceAmount,
        'locId': argument!['locationId'],
        'pending': pendingAmount,
        'saleNote': effectiveSaleNote,
        'saleStatus': 'final',
        'sellId': sellId,
        'shippingCharges': effectiveShippingCharges,
        'shippingDetails': effectiveShippingDetails,
        'staffNote': effectiveStaffNote,
        'taxId': argument!['taxId'],
        'isQuotation': argument?['isQuotation'] ?? 0,
        'tip_amount': effectiveTipAmount,
        'tip_type': effectiveTipType,
        'discount_amount': argument!['discountAmount'] ?? 0.0,
        'discount_type': argument!['discountType'] ?? 'fixed',
        'res_table_id': effectiveTableId, // Use effectiveTableId
        'is_shipping': isShipping,
      };

      debugPrint('Checkout onSubmit: Using sale data - transactionDate: $effectiveTransactionDate, invoiceNo: $effectiveInvoiceNo, fromSalesScreen: $_fromSalesScreen');

      List<Map> products = argument!['products']?.map<Map>((product) {
        return {
          'product_id': product['product_id'],
          'variation_id': product['variation_id'],
          'quantity': product['quantity'],
          'unit_price': product['unit_price'],
          'tax_rate_id': product['tax_rate_id'],
          'discount_amount': product['discount_amount'] ?? 0.0,
          'discount_type': product['discount_type'] ?? 'fixed',
          'note': product['note'] ?? '',
          'product_order_category':
          product['product_order_category'] ?? 'BAR',
          // 'res_table_id': argument!['res_table_id'], // Added to ensure res_table_id
          'res_table_id': effectiveTableId, // Use effectiveTableId
          'is_shipping': isShipping, // Use the correct is_shipping value
        };
      }).toList() ?? [];

      // If products are empty from arguments, try to get them from database as fallback
      if (products.isEmpty && sellId != null) {
        debugPrint('onSubmit: No products in arguments, trying to get from database for sellId: $sellId');
        var dbSellLines = await SellDatabase().getSellLineBySellId(sellId!, res_table_id: effectiveTableId, includeCompleted: true);
        products = dbSellLines.map<Map>((line) {
          return {
            'product_id': line['product_id'],
            'variation_id': line['variation_id'],
            'quantity': line['quantity'],
            'unit_price': line['unit_price'],
            'tax_rate_id': line['tax_rate_id'],
            'discount_amount': line['discount_amount'] ?? 0.0,
            'discount_type': line['discount_type'] ?? 'fixed',
            'note': line['note'] ?? '',
            'product_order_category': line['product_order_category'] ?? 'BAR',
            'res_table_id': effectiveTableId,
            'is_shipping': isShipping,
          };
        }).toList();
        debugPrint('onSubmit: Retrieved ${products.length} products from database (includeCompleted: true)');
      }

      if (products.isEmpty) {
        debugPrint('onSubmit: Error: No products selected for the sale');
        Fluttertoast.showToast(
          msg:
          AppLocalizations.of(context)?.translate('no_products_selected') ??
              'Please add at least one product to the sale.',
          toastLength: Toast.LENGTH_LONG,
        );
        setState(() {
          isLoading = false;
          saleCreated = false;
        });
        return;
      }

      List<Map> updatedPayments = payments.map((payment) {
        return {
          'method': payment['method'],
          'amount': payment['amount'],
          'note': payment['note'] ?? '',
          'account_id': payment['account_id'],
          'received_amount': payment['received_amount'] ?? null,
          'change_return': payment['change_return'] ?? 0.0,
          'card_details': payment['card_details'],
        };
      }).toList();

      // CRITICAL: Use sale data from arguments when coming from Sales screen
      // This ensures the updated sale data (status, payment_status, transaction_date, etc.) is submitted to server
      // When finalizing payment, status should be 'final', but preserve transaction_date and other fields from arguments
      String? payloadStatus = 'final'; // Always 'final' when finalizing payment
      String? payloadTransactionDate = _fromSalesScreen && argument?['transaction_date'] != null
          ? argument!['transaction_date']
          : sellData['transactionDate'];
      String? payloadSaleNote = _fromSalesScreen && argument?['sale_note'] != null
          ? argument!['sale_note']
          : sellData['saleNote'];
      String? payloadStaffNote = _fromSalesScreen && argument?['staff_note'] != null
          ? argument!['staff_note']
          : sellData['staffNote'];
      double? payloadShippingCharges = _fromSalesScreen && argument?['shipping_charges'] != null
          ? argument!['shipping_charges']?.toDouble()
          : sellData['shippingCharges'];
      String? payloadShippingDetails = _fromSalesScreen && argument?['shipping_details'] != null
          ? argument!['shipping_details']
          : sellData['shippingDetails'];
      double? payloadTipAmount = _fromSalesScreen && argument?['tip_amount'] != null && !_isTipAmountEdited
          ? argument!['tip_amount']?.toDouble()
          : sellData['tip_amount'];
      String? payloadTipType = _fromSalesScreen && argument?['tip_type'] != null && !_isTipAmountEdited
          ? argument!['tip_type']
          : sellData['tip_type'];

      debugPrint('onSubmit: Using sale data from arguments - status: $payloadStatus (final), transaction_date: $payloadTransactionDate, fromSalesScreen: $_fromSalesScreen');

      Map<String, dynamic> sellPayload = {
        'sells': [
          {
            'location_id': sellData['locId'],
            'contact_id': sellData['contactId'],
            'transaction_date': payloadTransactionDate,
            'invoice_no': sellData['invoiceNo'],
            'status': payloadStatus,
            'sub_status': sellData['isQuotation'] == 1 ? 'quotation' : null,
            'tax_rate_id': sellData['taxId'] ?? 0, // Use 0 instead of null to avoid foreign key issues
            'discount_amount': sellData['discount_amount'] ?? 0.0,
            'discount_type': sellData['discount_type'] ?? 'fixed',
            'change_return': sellData['changeReturn'],
            'products': products,
            'sale_note': payloadSaleNote,
            'staff_note': payloadStaffNote,
            'shipping_charges': payloadShippingCharges,
            'shipping_details': payloadShippingDetails,
            'tip_amount': payloadTipAmount?.toString() ?? '0.00',
            'tip_type': payloadTipType ?? 'fixed',
            'is_quotation': sellData['isQuotation'],
            'payments': updatedPayments,
            //'res_table_id': sellData['res_table_id'],
            'res_table_id': effectiveTableId, // Use effectiveTableId
            'is_shipping': sellData['is_shipping'],
          }
        ]
      };

      debugPrint('onSubmit: Prepared sell payload: ${jsonEncode(sellPayload)}');

      print("::herererererer123123::${AppConstants.cartData}");

      Map<String, dynamic> sell = await Sell().createSell(
        invoiceNo: sellData['invoiceNo'],
        transactionDate: sellData['transactionDate'],
        changeReturn: sellData['changeReturn'],
        contactId: sellData['contactId'],
        invoiceAmount: sellData['invoiceAmount'],
        locId: sellData['locId'],
        pending: sellData['pending'],
        saleNote: sellData['saleNote'],
        saleStatus: sellData['saleStatus'],
        sellId: sellData['sellId'],
        shippingCharges: sellData['shippingCharges'],
        shippingDetails: sellData['shippingDetails'],
        staffNote: sellData['staffNote'],
        taxId: sellData['taxId'],
        isQuotation: sellData['isQuotation'],
        tip_amount: sellData['tip_amount'],
        tip_type: hasTipTypeColumn ? sellData['tip_type'] : null,
        res_table_id: sellData['res_table_id'],
        is_shipping: sellData['is_shipping'],
      );

      debugPrint('onSubmit: Created sell map: ${jsonEncode(sell)}');
      print("::herererererer22222222::${AppConstants.cartData}");

      int? response;

      // Ensure sellId is properly converted to int if it's a string
      int? effectiveSellId = sellId is int ? sellId : int.tryParse(sellId?.toString() ?? '');
      debugPrint('onSubmit: sellId=$sellId, effectiveSellId=$effectiveSellId, type=${sellId.runtimeType}');

      // Check if this is a partial payment scenario by looking for existing sales with same invoice pattern
      bool isPartialPayment = false;
      int? existingSaleId;

      if (effectiveSellId != null && effectiveSellId > 0) {
        try {
          var existingSale = await SellDatabase().getSellBySellId(effectiveSellId);
          if (existingSale.isNotEmpty) {
            isPartialPayment = true;
            existingSaleId = effectiveSellId;
            debugPrint('onSubmit: Found existing sale for partial payment: $existingSaleId');
          }
        } catch (e) {
          debugPrint('onSubmit: Error checking existing sale: $e');
        }
      }

      // Additional check: Look for sales with same invoice pattern and table
      if (!isPartialPayment) {
        try {
          String invoicePattern = sell['invoice_no']?.toString() ?? '';
          int? tableId = effectiveTableId;

          // Get all sales for this table
          List allSales = await SellDatabase().getSells(all: true);
          for (var sale in allSales) {
            if (sale['res_table_id'] == tableId &&
                sale['invoice_no']?.toString().contains(invoicePattern.split('_')[0]) == true &&
                sale['is_quotation'] == 0) {
              isPartialPayment = true;
              existingSaleId = sale['id'];
              debugPrint('onSubmit: Found existing sale by invoice pattern: $existingSaleId, invoice: ${sale['invoice_no']}');
              break;
            }
          }
        } catch (e) {
          debugPrint('onSubmit: Error checking sales by pattern: $e');
        }
      }

      if (isPartialPayment && existingSaleId != null) {
        debugPrint('onSubmit: Updating existing sell: $existingSaleId');
        response = existingSaleId;

        // CRITICAL: Set sale_status to 'final' IMMEDIATELY using direct SQL before any other operations
        // This ensures the table/shipping will be enabled even if other operations fail
        try {
          final db = await SellDatabase().database;
          int immediateRows = await db.rawUpdate(
            'UPDATE sell SET sale_status = ? WHERE id = ?',
            ['final', existingSaleId],
          );
          debugPrint('onSubmit: IMMEDIATE direct SQL update set sale_status to final for sellId=$existingSaleId, rows affected: $immediateRows');

          if (immediateRows == 0) {
            // Try 'sells' table
            immediateRows = await db.rawUpdate(
              'UPDATE sells SET sale_status = ? WHERE id = ?',
              ['final', existingSaleId],
            );
            debugPrint('onSubmit: IMMEDIATE direct SQL update on "sells" table affected $immediateRows rows');
          }

          // Verify immediately
          var verifyImmediate = await db.query('sell', where: 'id = ?', whereArgs: [existingSaleId]);
          if (verifyImmediate.isEmpty) {
            verifyImmediate = await db.query('sells', where: 'id = ?', whereArgs: [existingSaleId]);
          }
          if (verifyImmediate.isNotEmpty) {
            String? statusAfterImmediate = verifyImmediate[0]['sale_status']?.toString();
            debugPrint('onSubmit: sale_status after IMMEDIATE update: $statusAfterImmediate');
          }
        } catch (e) {
          debugPrint('onSubmit: IMMEDIATE direct SQL update failed: $e');
        }

        // Delete old payment lines for this sale to prevent duplicates
        await PaymentDatabase().delete(existingSaleId);
        debugPrint('onSubmit: Deleted old payment lines for sale: $existingSaleId');

        // Get the current sale data to preserve discount information and get transaction_id
        var existingSaleData = await SellDatabase().getSellBySellId(existingSaleId);
        // CRITICAL: Use transaction_id from arguments if available (from Sales screen), otherwise use from database
        // This ensures we use the correct transaction_id when updating existing sales from Sales screen
        String? oldTransactionId;
        if (_fromSalesScreen && argument?['transaction_id'] != null) {
          oldTransactionId = argument!['transaction_id'].toString();
          debugPrint('onSubmit: Using transaction_id from Sales screen arguments: $oldTransactionId');
        } else if (existingSaleData.isNotEmpty && existingSaleData[0]['transaction_id'] != null) {
          oldTransactionId = existingSaleData[0]['transaction_id'].toString();
          debugPrint('onSubmit: Using transaction_id from database: $oldTransactionId');
        } else {
          debugPrint('onSubmit: No transaction_id found - will create new sale');
        }

        // CRITICAL: Log the current sale_status before any updates
        if (existingSaleData.isNotEmpty) {
          String? currentStatus = existingSaleData[0]['sale_status']?.toString();
          debugPrint('onSubmit: Current sale_status AFTER IMMEDIATE update: $currentStatus for sellId=$existingSaleId');
        }

        if (existingSaleData.isNotEmpty) {
          // Preserve the discount information from the database
          sell['discount_amount'] = existingSaleData[0]['discount_amount'] ?? 0.0;
          sell['discount_type'] = existingSaleData[0]['discount_type'] ?? 'fixed';
          debugPrint('onSubmit: Preserved discount info - amount=${sell['discount_amount']}, type=${sell['discount_type']}');
        }

        // CRITICAL: Ensure sale_status is set to 'final' when updating existing sale
        sell['sale_status'] = 'final';

        // CRITICAL: Use direct SQL update FIRST to ensure it works
        try {
          final db = await SellDatabase().database;
          int rowsUpdated = await db.rawUpdate(
            'UPDATE sell SET sale_status = ? WHERE id = ?',
            ['final', existingSaleId],
          );
          debugPrint('onSubmit: Direct SQL update set sale_status to final for sellId=$existingSaleId, rows affected: $rowsUpdated');

          // Verify immediately
          var verifyDirect = await db.query('sell', where: 'id = ?', whereArgs: [existingSaleId]);
          if (verifyDirect.isNotEmpty) {
            String? statusAfterDirect = verifyDirect[0]['sale_status']?.toString();
            debugPrint('onSubmit: sale_status after direct SQL: $statusAfterDirect');
          }
        } catch (e) {
          debugPrint('onSubmit: Direct SQL update failed: $e');
        }

        // Update the existing sale with new data (this will update other fields too)
        await SellDatabase().updateSells(existingSaleId, sell);
        debugPrint('onSubmit: Updated local sell: $existingSaleId with sale_status: final');

        // CRITICAL: Verify sale_status was updated before calling finalizeOrder
        var verifyBeforeFinalize = await SellDatabase().getSellBySellId(existingSaleId);
        if (verifyBeforeFinalize.isNotEmpty) {
          String? statusBeforeFinalize = verifyBeforeFinalize[0]['sale_status']?.toString();
          debugPrint('onSubmit: sale_status before finalizeOrder: $statusBeforeFinalize');

          // If still not 'final', force update one more time with direct SQL
          if (statusBeforeFinalize != 'final') {
            debugPrint('onSubmit: sale_status is not final, forcing direct SQL update...');
            try {
              final db = await SellDatabase().database;
              int rowsUpdated = await db.rawUpdate(
                'UPDATE sell SET sale_status = ? WHERE id = ?',
                ['final', existingSaleId],
              );
              debugPrint('onSubmit: Force direct SQL update affected $rowsUpdated rows');

              // Wait a bit for the update to commit
              await Future.delayed(Duration(milliseconds: 200));

              // Verify again
              var verifyAfterForce = await SellDatabase().getSellBySellId(existingSaleId);
              if (verifyAfterForce.isNotEmpty) {
                String? statusAfterForce = verifyAfterForce[0]['sale_status']?.toString();
                debugPrint('onSubmit: sale_status after force update: $statusAfterForce');
              }
            } catch (e) {
              debugPrint('onSubmit: Force direct SQL update failed: $e');
            }
          }
        }

        // CRITICAL: Call finalizeOrder() IMMEDIATELY after updating sale status to 'final'
        // This ensures the table/shipping is enabled right away, before API sync
        var sellRecordForFinalize = await SellDatabase().getSellBySellId(existingSaleId);
        int? finalResTableIdForFinalize = sellRecordForFinalize.isNotEmpty ? sellRecordForFinalize[0]['res_table_id'] : argument!['res_table_id'];
        int finalIsShippingForFinalize = sellRecordForFinalize.isNotEmpty ? (sellRecordForFinalize[0]['is_shipping'] ?? 0) : (argument!['is_shipping'] ?? 0);

        debugPrint('onSubmit: Calling finalizeOrder() with sellId=$existingSaleId, res_table_id=$finalResTableIdForFinalize, is_shipping=$finalIsShippingForFinalize');
        await Sell().finalizeOrder(existingSaleId, finalResTableIdForFinalize, finalIsShippingForFinalize);
        debugPrint('onSubmit: Called finalizeOrder() immediately after updating sale status');

        // CRITICAL: Verify finalizeOrder actually updated the status
        var verifyAfterFinalize = await SellDatabase().getSellBySellId(existingSaleId);
        if (verifyAfterFinalize.isNotEmpty) {
          String? statusAfterFinalize = verifyAfterFinalize[0]['sale_status']?.toString();
          debugPrint('onSubmit: sale_status after finalizeOrder: $statusAfterFinalize');
          if (statusAfterFinalize != 'final') {
            debugPrint('onSubmit: CRITICAL ERROR - sale_status is still not final after finalizeOrder! Using direct SQL...');
            // Last resort: Direct SQL update
            try {
              final db = await SellDatabase().database;
              int rowsUpdated = await db.rawUpdate(
                'UPDATE sell SET sale_status = ? WHERE id = ?',
                ['final', existingSaleId],
              );
              if (rowsUpdated == 0) {
                rowsUpdated = await db.rawUpdate(
                  'UPDATE sells SET sale_status = ? WHERE id = ?',
                  ['final', existingSaleId],
                );
              }
              debugPrint('onSubmit: Direct SQL update affected $rowsUpdated rows');

              // Wait for commit
              await Future.delayed(Duration(milliseconds: 200));

              // Verify one final time
              var finalCheck = await SellDatabase().getSellBySellId(existingSaleId);
              if (finalCheck.isNotEmpty) {
                String? finalStatus = finalCheck[0]['sale_status']?.toString();
                debugPrint('onSubmit: sale_status after direct SQL: $finalStatus');

                // If STILL not final, try updating by transaction_id as well
                if (finalStatus != 'final' && finalCheck[0]['transaction_id'] != null) {
                  String? transactionId = finalCheck[0]['transaction_id']?.toString();
                  debugPrint('onSubmit: Trying to update by transaction_id: $transactionId');
                  try {
                    final db = await SellDatabase().database;
                    int rowsUpdatedByTx = await db.rawUpdate(
                      'UPDATE sell SET sale_status = ? WHERE transaction_id = ?',
                      ['final', transactionId],
                    );
                    debugPrint('onSubmit: Direct SQL update by transaction_id affected $rowsUpdatedByTx rows');
                  } catch (e) {
                    debugPrint('onSubmit: Direct SQL update by transaction_id failed: $e');
                  }
                }
              }
            } catch (e) {
              debugPrint('onSubmit: Direct SQL update failed: $e');
            }
          }
        }

        // CRITICAL: One more direct SQL update RIGHT BEFORE finalizeOrder to ensure it's set
        try {
          final db = await SellDatabase().database;
          int finalRows = await db.rawUpdate(
            'UPDATE sell SET sale_status = ? WHERE id = ?',
            ['final', existingSaleId],
          );
          debugPrint('onSubmit: Final direct SQL update before finalizeOrder affected $finalRows rows');
        } catch (e) {
          debugPrint('onSubmit: Final direct SQL update failed: $e');
        }

        // CRITICAL: Force enable table/shipping immediately after finalization
        // This ensures the table/shipping is marked as available in the UI right away
        // Don't call refreshAvailability() as it will clear cache and re-validate, which might
        // find other draft orders and mark the table as unavailable again
        final availabilityManager = TableAvailabilityManager();
        if (finalIsShippingForFinalize == 1) {
          await availabilityManager.forceEnableTableOrShipping(
            tableId: null,
            isShipping: true,
            locationId: argument!['locationId'],
          );
          // Don't call refreshAvailability() - it will clear cache and re-validate
          debugPrint('onSubmit: Force enabled shipping after finalization (cache set, not refreshing)');
        } else if (finalResTableIdForFinalize != null && finalResTableIdForFinalize != 0) {
          // Force enable this specific table
          await availabilityManager.forceEnableTableOrShipping(
            tableId: finalResTableIdForFinalize,
            isShipping: false,
            locationId: argument!['locationId'],
          );
          // Don't call refreshAvailability() - it will clear cache and re-validate
          debugPrint('onSubmit: Force enabled table ${finalResTableIdForFinalize} after finalization (cache set, not refreshing)');
        }

        // Clean up any duplicate sales for this table and invoice pattern
        // COMMENTED OUT: This was removing older entries for the same table
        // String invoicePattern = sell['invoice_no']?.toString().split('_')[0] ?? '';
        // await SellDatabase().cleanupDuplicateSales(effectiveTableId ?? 0, invoicePattern);

        // CRITICAL: Only delete old sale if we're NOT updating via transaction_id
        // When coming from Sales screen with transaction_id, we're updating, not replacing
        // So we should NOT delete the old sale - the API update will handle it
        bool isUpdatingViaTransactionId = _fromSalesScreen && argument?['transaction_id'] != null && oldTransactionId != null;
        if (!isUpdatingViaTransactionId && oldTransactionId != null && oldTransactionId.isNotEmpty && await Helper().checkConnectivity()) {
          try {
            debugPrint('onSubmit: Deleting old sale from server (not updating via transaction_id): $oldTransactionId');
            var deleteResult = await SellApi().delete(oldTransactionId);
            if (deleteResult != null && !deleteResult.containsKey('error')) {
              debugPrint('onSubmit: Successfully deleted old sale from server: $oldTransactionId');
            } else {
              debugPrint('onSubmit: Failed to delete old sale from server: $oldTransactionId, Error: ${deleteResult?['error']}');
            }
          } catch (e) {
            debugPrint('onSubmit: Error deleting old sale from server: $e');
          }
        } else if (isUpdatingViaTransactionId) {
          debugPrint('onSubmit: Skipping delete - updating existing sale via transaction_id: $oldTransactionId');
        }
        print("::herererererer3333333::${AppConstants.cartData}");

        for (var element in updatedPayments) {
          if (element is Map<String, dynamic>) {
            if (element['id'] != null) {
              paymentLine = {
                'amount': element['amount'],
                'method': element['method'],
                'note': element['note'],
                'account_id': element['account_id'],
                'received_amount': element['received_amount'],
                'change_return': element['change_return'],
                'card_details': element['card_details'],
              };
              debugPrint('onSubmit: Updating payment line: ${element['id']}');
              await PaymentDatabase()
                  .updateEditedPaymentLine(element['id'], paymentLine);
            } else {
              paymentLine = {
                'sell_id': existingSaleId,
                'method': element['method'],
                'amount': element['amount'],
                'note': element['note'],
                'account_id': element['account_id'],
                'received_amount': element['received_amount'],
                'change_return': element['change_return'],
                'card_details': element['card_details'],
              };
              debugPrint(
                  'onSubmit: Storing new payment line for sell: $existingSaleId');
              await PaymentDatabase().store(paymentLine);
            }
          } else {
            debugPrint('onSubmit: Invalid payment element: $element');
          }
        }

        if (deletedPaymentId.isNotEmpty) {
          debugPrint('onSubmit: Deleting payment lines: $deletedPaymentId');
          await PaymentDatabase().deletePaymentLineByIds(deletedPaymentId);
        }

        // Mark sell lines as completed for existing sales (when editing)
        await SellDatabase().updateSellLine(
          {'sell_id': existingSaleId, 'is_completed': 1},
          resTableId: argument!['res_table_id'],
        );

        // Update invoice amount based on current cart items
        // This ensures the Sales Screen shows the correct amount after finalizing the sale
        await Sell()
            .updateInvoiceAmountFromCart(existingSaleId, argument!['res_table_id']);

        // CRITICAL: Ensure transaction_id is in database before API call when coming from Sales screen
        if (_fromSalesScreen && argument?['transaction_id'] != null && oldTransactionId == null) {
          debugPrint('onSubmit: Updating database with transaction_id from arguments before API call');
          await SellDatabase().updateSells(existingSaleId, {
            'transaction_id': argument!['transaction_id'].toString(),
          });
          // Re-fetch to ensure transaction_id is available
          var updatedSell = await SellDatabase().getSellBySellId(existingSaleId);
          if (updatedSell.isNotEmpty && updatedSell[0]['transaction_id'] != null) {
            oldTransactionId = updatedSell[0]['transaction_id'].toString();
            debugPrint('onSubmit: Updated transaction_id in database: $oldTransactionId');
          }
        }

        if (await Helper().checkConnectivity()) {
          debugPrint(
              'onSubmit: Network available, attempting to sync sell: $existingSaleId');
          debugPrint('onSubmit: Token before API call: $token');
          debugPrint('onSubmit: Transaction ID before API call: $oldTransactionId');
          debugPrint('onSubmit: From Sales Screen: $_fromSalesScreen');
          var apiResult = await Sell()
              .createApiSell(
              sellId: existingSaleId,
              payload: sellPayload,
              isDraft: false,
              isQuotation: false)
              .timeout(
            Duration(seconds: 30),
            onTimeout: () {
              debugPrint('onSubmit: API call timed out after 30 seconds');
              return {'error': 'API call timed out'};
            },
          );
          if (apiResult != null && !apiResult.containsKey('error')) {
            debugPrint(
                'onSubmit: Sell synced successfully: $existingSaleId, Result: $apiResult');
            // CRITICAL: Always set sale_status to 'final' after API sync, regardless of API response
            // The API might return 'draft' or other status, but we need it to be 'final' for table enablement
            String apiStatus = apiResult['status']?.toString() ?? 'final';
            String finalStatus = 'final'; // Always use 'final' to ensure table is enabled

            debugPrint('onSubmit: API returned status: $apiStatus, but setting sale_status to: $finalStatus');

            // CRITICAL: Use direct SQL FIRST to ensure sale_status is set to 'final'
            try {
              final db = await SellDatabase().database;
              int directRows = await db.rawUpdate(
                'UPDATE sell SET sale_status = ? WHERE id = ?',
                ['final', existingSaleId],
              );
              debugPrint('onSubmit: Direct SQL update for sale_status=final after API sync affected $directRows rows');

              if (directRows == 0) {
                // Try 'sells' table
                directRows = await db.rawUpdate(
                  'UPDATE sells SET sale_status = ? WHERE id = ?',
                  ['final', existingSaleId],
                );
                debugPrint('onSubmit: Direct SQL update on "sells" table after API sync affected $directRows rows');
              }
            } catch (e) {
              debugPrint('onSubmit: Direct SQL update for sale_status after API sync failed: $e');
            }

            await SellDatabase().updateSells(existingSaleId, {
              'is_synced': 1,
              'transaction_id': apiResult['transaction_id'],
              'invoice_url': apiResult['invoice_url'] ?? '',
              'tip_type': apiResult['tip_type'] ?? 'fixed',
              'tip_amount': apiResult['tip_amount']?.toString() ?? '0.00',
              'pending_amount':
              apiResult['pending_amount']?.toDouble() ?? pendingAmount,
              'sale_status': finalStatus, // CRITICAL: Always 'final' after completion
            });

            // CRITICAL: Verify the update immediately with multiple attempts
            for (int verifyAttempt = 1; verifyAttempt <= 3; verifyAttempt++) {
              await Future.delayed(Duration(milliseconds: 100));
              var verifyAfterApiSync = await SellDatabase().getSellBySellId(existingSaleId);
              if (verifyAfterApiSync.isNotEmpty) {
                String? statusAfterApiSync = verifyAfterApiSync[0]['sale_status']?.toString();
                debugPrint('onSubmit: sale_status after API sync update (attempt $verifyAttempt): $statusAfterApiSync');
                if (statusAfterApiSync == 'final') {
                  debugPrint('onSubmit: sale_status successfully set to final after API sync');
                  break;
                } else if (verifyAttempt < 3) {
                  debugPrint('onSubmit: sale_status is not final, forcing direct SQL update...');
                  try {
                    final db = await SellDatabase().database;
                    await db.rawUpdate(
                      'UPDATE sell SET sale_status = ? WHERE id = ?',
                      ['final', existingSaleId],
                    );
                  } catch (e) {
                    debugPrint('onSubmit: Force direct SQL update failed: $e');
                  }
                }
              }
            }

            // Mark table/shipping as available after successful finalization
            // Get res_table_id and is_shipping from database to ensure accuracy
            var sellRecord = await SellDatabase().getSellBySellId(existingSaleId);
            int? finalResTableId = sellRecord.isNotEmpty ? sellRecord[0]['res_table_id'] : argument!['res_table_id'];
            int finalIsShipping = sellRecord.isNotEmpty ? (sellRecord[0]['is_shipping'] ?? 0) : (argument!['is_shipping'] ?? 0);

            await Sell().finalizeOrder(
                existingSaleId, finalResTableId, finalIsShipping);

            // CRITICAL: Force enable table/shipping immediately after finalization
            // Don't call refreshAvailability() as it will clear cache and re-validate, which might
            // find other draft orders and mark the table as unavailable again
            final availabilityManager = TableAvailabilityManager();
            if (finalIsShipping == 1) {
              await availabilityManager.forceEnableTableOrShipping(
                tableId: null,
                isShipping: true,
                locationId: argument!['locationId'],
              );
              // Don't call refreshAvailability() - it will clear cache and re-validate
              debugPrint('onSubmit: Force enabled shipping after API sync (cache set, not refreshing)');
            } else if (finalResTableId != null && finalResTableId != 0) {
              await availabilityManager.forceEnableTableOrShipping(
                tableId: finalResTableId,
                isShipping: false,
                locationId: argument!['locationId'],
              );
              // Don't call refreshAvailability() - it will clear cache and re-validate
              debugPrint('onSubmit: Force enabled table $finalResTableId after API sync (cache set, not refreshing)');
            }

            // Force refresh customer due data on server by making a dummy API call
            // This ensures the server recalculates pending amounts
            if (argument!['contactId'] != null && argument!['contactId'] != 0) {
              try {
                await ContactPaymentApi().getCustomerDue(argument!['contactId']);
                debugPrint('Checkout: Refreshed customer due data for contact ${argument!['contactId']}');
              } catch (e) {
                debugPrint('Checkout: Error refreshing customer due data: $e');
              }
            }
            Fluttertoast.showToast(
              msg: AppLocalizations.of(context)?.translate('sell_synced') ??
                  'Sell synced successfully',
              toastLength: Toast.LENGTH_LONG,
            );

            // Reset cart for the specific res_table_id or shipping
            if (argument!['is_shipping'] == 1) {
              AppConstants.cartData['shipping'] = null;
              await AppConstants.setData(0); // Update shared preferences
              await SellDatabase()
                  .resetCartForTable(0); // Pass null for shipping
              debugPrint('onSubmit: Cart reset for shipping (res_table_id=0)');

              // Remove only the shipping cart from prefs
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('cart_${argument!['locationId']}_0');
            } else if (argument!['res_table_id'] != null) {
              AppConstants.cartData[argument!['res_table_id'].toString()] =
              null;
              await AppConstants.setData(argument!['res_table_id']);
              await SellDatabase().resetCartForTable(argument!['res_table_id']);

              // Remove only the shipping cart from prefs
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('cart_${argument!['locationId']}_0');
              await prefs.remove(
                  'cart_${argument!['locationId']}_${argument!['res_table_id']}');
              debugPrint(
                  'onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');
            }
            // // Reset cart for the specific res_table_id
            // await SellDatabase().resetCartForTable(argument!['res_table_id']);
            // debugPrint('onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');

            // if (_printInvoice) {
            //   await printOption(sellId!);
            // }
            // else {
            //   Navigator.pushNamedAndRemoveUntil(
            //     context,
            //     '/tables',
            //         (Route<dynamic> route) => false,
            //   );
            // }
            if (!_printInvoice) {
              // Only share if we're not printing
              await shareInvoice(response ?? existingSaleId!);

              // Navigate after sharing
              if (mounted) {
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/tables',
                      (Route<dynamic> route) => false,
                );
              }
            } else {
              // Handle print case
              // CRITICAL: Wait a bit to ensure database is updated
              await Future.delayed(Duration(milliseconds: 200));
              // CRITICAL: Ensure table/shipping is enabled BEFORE showing print dialog
              // Use existingSaleId for existing sales, response for new sales
              int? finalSellIdForPrint = response ?? existingSaleId;
              await _ensureTableOrShippingEnabled(providedSellId: finalSellIdForPrint);
              if (mounted) {
                printOption(finalSellIdForPrint!);
              }
            }
          } else {
            debugPrint(
                'onSubmit: Failed to sync sell: $sellId, Error: ${apiResult?['error'] ?? 'Unknown error'}');
            Fluttertoast.showToast(
              msg: AppLocalizations.of(context)
                  ?.translate('api_error_will_sync_later') ??
                  'Failed to sync: ${apiResult?['error'] ?? 'Unknown error'}',
              toastLength: Toast.LENGTH_LONG,
            );

            // Reset cart for the specific res_table_id or shipping
            if (argument!['is_shipping'] == 1) {
              AppConstants.cartData['shipping'] = null;
              await AppConstants.setData(0); // Update shared preferences
              await SellDatabase()
                  .resetCartForTable(0); // Pass null for shipping
              debugPrint('onSubmit: Cart reset for shipping (res_table_id=0)');
            } else if (argument!['res_table_id'] != null) {
              AppConstants.cartData[argument!['res_table_id'].toString()] =
              null;
              await AppConstants.setData(argument!['res_table_id']);
              await SellDatabase().resetCartForTable(argument!['res_table_id']);
              debugPrint(
                  'onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');
            }
            // // Reset cart for the specific res_table_id even if sync fails
            // await SellDatabase().resetCartForTable(argument!['res_table_id']);
            // debugPrint('onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');

            // if (_printInvoice) {
            //   await printOption(sellId!);
            // } else {
            //   Navigator.pushNamedAndRemoveUntil(
            //     context,
            //     '/tables',
            //         (Route<dynamic> route) => false,
            //   );
            // }
            if (!_printInvoice) {
              // Only share if we're not printing
              await shareInvoice(response ?? existingSaleId!);

              // Navigate after sharing
              if (mounted) {
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/tables',
                      (Route<dynamic> route) => false,
                );
              }
            } else {
              // Handle print case
              // CRITICAL: Wait a bit to ensure database is updated
              await Future.delayed(Duration(milliseconds: 200));
              // CRITICAL: Ensure table/shipping is enabled BEFORE showing print dialog
              // Use existingSaleId for existing sales, response for new sales
              int? finalSellIdForPrint = response ?? existingSaleId;
              await _ensureTableOrShippingEnabled(providedSellId: finalSellIdForPrint);
              if (mounted) {
                printOption(finalSellIdForPrint!);
              }
            }
          }
        } else {
          debugPrint(
              'onSubmit: No connectivity, storing sell locally: $existingSaleId');
          Fluttertoast.showToast(
            msg: AppLocalizations.of(context)?.translate('no_connectivity') ??
                'No internet connection, stored locally',
            toastLength: Toast.LENGTH_LONG,
          );

          // Mark table/shipping as available after local finalization (for existing sales)
          // Get res_table_id and is_shipping from database to ensure accuracy
          var sellRecord = await SellDatabase().getSellBySellId(existingSaleId);
          int? finalResTableId = sellRecord.isNotEmpty ? sellRecord[0]['res_table_id'] : argument!['res_table_id'];
          int finalIsShipping = sellRecord.isNotEmpty ? (sellRecord[0]['is_shipping'] ?? 0) : (argument!['is_shipping'] ?? 0);

          await Sell().finalizeOrder(
              existingSaleId, finalResTableId, finalIsShipping);

          // CRITICAL: Force enable table/shipping immediately after finalization (offline case)
          // Don't call refreshAvailability() as it will clear cache and re-validate, which might
          // find other draft orders and mark the table as unavailable again
          final availabilityManager = TableAvailabilityManager();
          if (finalIsShipping == 1) {
            await availabilityManager.forceEnableTableOrShipping(
              tableId: null,
              isShipping: true,
              locationId: argument!['locationId'],
            );
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('onSubmit: Force enabled shipping (offline case, cache set, not refreshing)');
          } else if (finalResTableId != null && finalResTableId != 0) {
            await availabilityManager.forceEnableTableOrShipping(
              tableId: finalResTableId,
              isShipping: false,
              locationId: argument!['locationId'],
            );
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('onSubmit: Force enabled table $finalResTableId (offline case, cache set, not refreshing)');
          }

          // Additional fix: directly mark shipping as available (don't refresh as it clears cache)
          if (finalIsShipping == 1) {
            final availabilityManager2 = TableAvailabilityManager();
            availabilityManager2.markShippingAvailable();
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('Checkout: Directly marked shipping as available (cache set, not refreshing)');
          }

          // Reset cart for the specific res_table_id or shipping
          if (finalIsShipping == 1) {
            AppConstants.cartData['shipping'] = null;
            await AppConstants.setData(0); // Update shared preferences
            await SellDatabase().resetCartForTable(0); // Pass null for shipping
            debugPrint('onSubmit: Cart reset for shipping (res_table_id=0)');
          } else if (finalResTableId != null) {
            AppConstants.cartData[finalResTableId.toString()] = null;
            await AppConstants.setData(finalResTableId);
            await SellDatabase().resetCartForTable(finalResTableId);
            debugPrint(
                'onSubmit: Cart reset for res_table_id=$finalResTableId');
          }
          // // Reset cart for the specific res_table_id
          // await SellDatabase().resetCartForTable(argument!['res_table_id']);
          // debugPrint('onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');

          // if (_printInvoice) {
          //   await printOption(sellId!);
          // } else {
          //   Navigator.pushNamedAndRemoveUntil(
          //     context,
          //     '/tables',
          //         (Route<dynamic> route) => false,
          //   );
          // }
          if (!_printInvoice) {
            // Only share if we're not printing
            await shareInvoice(response ?? existingSaleId!);

            // Navigate after sharing
            if (mounted) {
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/tables',
                    (Route<dynamic> route) => false,
              );
            }
          } else {
            // Handle print case
            // CRITICAL: Wait a bit to ensure database is updated
            await Future.delayed(Duration(milliseconds: 200));
            // CRITICAL: Ensure table/shipping is enabled BEFORE showing print dialog
            // Use existingSaleId for existing sales, response for new sales
            int? finalSellIdForPrint = response ?? existingSaleId;
            await _ensureTableOrShippingEnabled(providedSellId: finalSellIdForPrint);
            if (mounted) {
              printOption(finalSellIdForPrint!);
            }
          }
        }
        print("::herererererer4444444::${AppConstants.cartData}");
      } else {
        // This branch creates a NEW sale entry - should only happen for new sales, not partial payments
        debugPrint('onSubmit: Creating new sell (sellId was null or sale does not exist)');

        // Clean up any existing duplicate sales before creating new one
        // COMMENTED OUT: This was removing older entries for the same table
        // String invoicePattern = sell['invoice_no']?.toString().split('_')[0] ?? '';
        // await SellDatabase().cleanupDuplicateSales(effectiveTableId ?? 0, invoicePattern);

        // CRITICAL: Ensure sale_status is set to 'final' when creating new sale
        sell['sale_status'] = 'final';

        response = await SellDatabase().storeSell(sell);
        debugPrint('onSubmit: Stored sell locally: $response with sale_status: final');

        for (var product in products) {
          await SellDatabase().store({
            'sell_id': response,
            'res_table_id': argument!['res_table_id'], // Ensure res_table_id
            ...product,
            'is_completed': 1,
          });
        }
        await Sell().makePayment(updatedPayments, response, res_table_id);
        // Modified to include res_table_id
        await SellDatabase().updateSellLine(
          {'sell_id': response, 'is_completed': 1},
          resTableId: argument!['res_table_id'],
        );

        // Update invoice amount based on current cart items
        // This ensures the Sales Screen shows the correct amount after finalizing the sale
        await Sell()
            .updateInvoiceAmountFromCart(response, argument!['res_table_id']);

        // CRITICAL: Call finalizeOrder() IMMEDIATELY after creating new sale
        // This ensures the table/shipping is enabled right away, before API sync
        var sellRecordForFinalize = await SellDatabase().getSellBySellId(response);
        int? finalResTableIdForFinalize = sellRecordForFinalize.isNotEmpty ? sellRecordForFinalize[0]['res_table_id'] : argument!['res_table_id'];
        int finalIsShippingForFinalize = sellRecordForFinalize.isNotEmpty ? (sellRecordForFinalize[0]['is_shipping'] ?? 0) : (argument!['is_shipping'] ?? 0);

        await Sell().finalizeOrder(response, finalResTableIdForFinalize, finalIsShippingForFinalize);
        debugPrint('onSubmit: Called finalizeOrder() immediately after creating new sale');

        // CRITICAL: Force refresh table availability immediately after finalization (new sale)
        final availabilityManagerForNew = TableAvailabilityManager();
        if (finalIsShippingForFinalize == 1) {
          await availabilityManagerForNew.forceEnableTableOrShipping(
            tableId: null,
            isShipping: true,
            locationId: argument!['locationId'],
          );
          // await availabilityManagerForNew.refreshAvailability();
          debugPrint('onSubmit: Force enabled shipping and refreshed availability (new sale)');
        } else if (finalResTableIdForFinalize != null && finalResTableIdForFinalize != 0) {
          await availabilityManagerForNew.forceEnableTableOrShipping(
            tableId: finalResTableIdForFinalize,
            isShipping: false,
            locationId: argument!['locationId'],
          );
          // await availabilityManagerForNew.refreshAvailability();
          debugPrint('onSubmit: Force enabled table $finalResTableIdForFinalize and refreshed availability (new sale)');
        }

        if (await Helper().checkConnectivity()) {
          debugPrint(
              'onSubmit: Network available, attempting to sync sell: $response');
          debugPrint('onSubmit: Token before API call: $token');
          var apiResult = await Sell()
              .createApiSell(
              sellId: response,
              payload: sellPayload,
              isDraft: false,
              isQuotation: false)
              .timeout(
            Duration(seconds: 30),
            onTimeout: () {
              debugPrint('onSubmit: API call timed out after 30 seconds');
              return {'error': 'API call timed out'};
            },
          );
          if (apiResult != null && !apiResult.containsKey('error')) {
            debugPrint(
                'onSubmit: Sell synced successfully: $response, Result: $apiResult');
            // CRITICAL: Always set sale_status to 'final' after API sync for new sales
            // The API might return 'draft' or other status, but we need it to be 'final' for table enablement
            String apiStatus = apiResult['status']?.toString() ?? 'final';
            String finalStatus = 'final'; // Always use 'final' to ensure table is enabled

            debugPrint('onSubmit: API returned status: $apiStatus for new sale, but setting sale_status to: $finalStatus');

            await SellDatabase().updateSells(response, {
              'is_synced': 1,
              'transaction_id': apiResult['transaction_id'],
              'invoice_url': apiResult['invoice_url'] ?? '',
              'tip_type': apiResult['tip_type'] ?? 'fixed',
              'tip_amount': apiResult['tip_amount']?.toString() ?? '0.00',
              'pending_amount':
              apiResult['pending_amount']?.toDouble() ?? pendingAmount,
              'sale_status': finalStatus, // CRITICAL: Always 'final' after completion
            });

            // CRITICAL: Verify the update immediately
            var verifyAfterApiSync = await SellDatabase().getSellBySellId(response);
            if (verifyAfterApiSync.isNotEmpty) {
              String? statusAfterApiSync = verifyAfterApiSync[0]['sale_status']?.toString();
              debugPrint('onSubmit: sale_status after API sync update (new sale): $statusAfterApiSync');
              if (statusAfterApiSync != 'final') {
                debugPrint('onSubmit: WARNING - sale_status is not final after API sync (new sale)! Forcing update...');
                await SellDatabase().updateSells(response, {'sale_status': 'final'});
                await Future.delayed(Duration(milliseconds: 100));
              }
            }

            // Mark table/shipping as available after successful finalization
            // Get res_table_id and is_shipping from database to ensure accuracy
            var sellRecord = await SellDatabase().getSellBySellId(response);
            int? finalResTableId = sellRecord.isNotEmpty ? sellRecord[0]['res_table_id'] : argument!['res_table_id'];
            int finalIsShipping = sellRecord.isNotEmpty ? (sellRecord[0]['is_shipping'] ?? 0) : (argument!['is_shipping'] ?? 0);

            await Sell().finalizeOrder(
                response, finalResTableId, finalIsShipping);

            // Additional fix: directly mark shipping as available (don't refresh as it clears cache)
            if (finalIsShipping == 1) {
              final availabilityManager2 = TableAvailabilityManager();
              availabilityManager2.markShippingAvailable();
              // Don't call refreshAvailability() - it will clear cache and re-validate
              debugPrint('Checkout: Directly marked shipping as available (cache set, not refreshing)');
            }

            // Force refresh customer due data on server by making a dummy API call
            // This ensures the server recalculates pending amounts
            if (argument!['contactId'] != null && argument!['contactId'] != 0) {
              try {
                await ContactPaymentApi().getCustomerDue(argument!['contactId']);
                debugPrint('Checkout: Refreshed customer due data for contact ${argument!['contactId']}');
              } catch (e) {
                debugPrint('Checkout: Error refreshing customer due data: $e');
              }
            }
            Fluttertoast.showToast(
              msg: AppLocalizations.of(context)?.translate('sell_synced') ??
                  'Sell synced successfully',
              toastLength: Toast.LENGTH_LONG,
            );

            // Reset cart for the specific res_table_id or shipping
            if (argument!['is_shipping'] == 1) {
              AppConstants.cartData['shipping'] = null;
              await AppConstants.setData(0); // Update shared preferences
              await SellDatabase()
                  .resetCartForTable(0); // Pass null for shipping
              debugPrint('onSubmit: Cart reset for shipping (res_table_id=0)');
            } else if (argument!['res_table_id'] != null) {
              AppConstants.cartData[argument!['res_table_id'].toString()] =
              null;
              await AppConstants.setData(argument!['res_table_id']);
              await SellDatabase().resetCartForTable(argument!['res_table_id']);
              debugPrint(
                  'onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');
            }
            // // Reset cart for the specific res_table_id
            // await SellDatabase().resetCartForTable(argument!['res_table_id']);
            // debugPrint('onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');

            // if (_printInvoice) {
            //   await printOption(response);
            // } else {
            //   Navigator.pushNamedAndRemoveUntil(
            //     context,
            //     '/tables',
            //         (Route<dynamic> route) => false,
            //   );
            // }
            if (!_printInvoice) {
              // Only share if we're not printing
              await shareInvoice(response ?? existingSaleId!);

              // Navigate after sharing
              if (mounted) {
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/tables',
                      (Route<dynamic> route) => false,
                );
              }
            } else {
              // Handle print case
              // CRITICAL: Wait a bit to ensure database is updated
              await Future.delayed(Duration(milliseconds: 200));
              // CRITICAL: Ensure table/shipping is enabled BEFORE showing print dialog
              // Use existingSaleId for existing sales, response for new sales
              int? finalSellIdForPrint = response ?? existingSaleId;
              await _ensureTableOrShippingEnabled(providedSellId: finalSellIdForPrint);
              if (mounted) {
                printOption(finalSellIdForPrint!);
              }
            }
          } else {
            debugPrint(
                'onSubmit: Failed to sync sell: $response, Error: ${apiResult?['error'] ?? 'Unknown error'}');
            Fluttertoast.showToast(
              msg: AppLocalizations.of(context)
                  ?.translate('api_error_will_sync_later') ??
                  'Failed to sync: ${apiResult?['error'] ?? 'Unknown error'}',
              toastLength: Toast.LENGTH_LONG,
            );

            // Mark table/shipping as available after local finalization
            // Get res_table_id and is_shipping from database to ensure accuracy
            // Use existingSaleId if available (for existing sales), otherwise use response (for new sales)
            int? sellIdForFinalize = existingSaleId ?? response;
            var sellRecord = await SellDatabase().getSellBySellId(sellIdForFinalize);
            int? finalResTableId = sellRecord.isNotEmpty ? sellRecord[0]['res_table_id'] : argument!['res_table_id'];
            int finalIsShipping = sellRecord.isNotEmpty ? (sellRecord[0]['is_shipping'] ?? 0) : (argument!['is_shipping'] ?? 0);

            await Sell().finalizeOrder(
                sellIdForFinalize, finalResTableId, finalIsShipping);

            // CRITICAL: Force enable table/shipping immediately after finalization (API error case)
            // Don't call refreshAvailability() as it will clear cache and re-validate, which might
            // find other draft orders and mark the table as unavailable again
            final availabilityManager = TableAvailabilityManager();
            if (finalIsShipping == 1) {
              await availabilityManager.forceEnableTableOrShipping(
                tableId: null,
                isShipping: true,
                locationId: argument!['locationId'],
              );
              // Don't call refreshAvailability() - it will clear cache and re-validate
              debugPrint('onSubmit: Force enabled shipping (API error case, cache set, not refreshing)');
            } else if (finalResTableId != null && finalResTableId != 0) {
              await availabilityManager.forceEnableTableOrShipping(
                tableId: finalResTableId,
                isShipping: false,
                locationId: argument!['locationId'],
              );
              // Don't call refreshAvailability() - it will clear cache and re-validate
              debugPrint('onSubmit: Force enabled table $finalResTableId (API error case, cache set, not refreshing)');
            }

            // Reset cart for the specific res_table_id or shipping
            if (finalIsShipping == 1) {
              AppConstants.cartData['shipping'] = null;
              await AppConstants.setData(0); // Update shared preferences
              await SellDatabase()
                  .resetCartForTable(0); // Pass null for shipping
              debugPrint('onSubmit: Cart reset for shipping (res_table_id=0)');
            } else if (argument!['res_table_id'] != null) {
              AppConstants.cartData[argument!['res_table_id'].toString()] =
              null;
              await AppConstants.setData(argument!['res_table_id']);
              await SellDatabase().resetCartForTable(argument!['res_table_id']);
              debugPrint(
                  'onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');
            }
            // // Reset cart for the specific res_table_id even if sync fails
            // await SellDatabase().resetCartForTable(argument!['res_table_id']);
            // debugPrint('onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');

            // if (_printInvoice) {
            //   await printOption(response);
            // } else {
            //   Navigator.pushNamedAndRemoveUntil(
            //     context,
            //     '/tables',
            //         (Route<dynamic> route) => false,
            //   );
            // }
            if (!_printInvoice) {
              // Only share if we're not printing
              await shareInvoice(response ?? existingSaleId!);

              // Navigate after sharing
              if (mounted) {
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/tables',
                      (Route<dynamic> route) => false,
                );
              }
            } else {
              // Handle print case
              // CRITICAL: Wait a bit to ensure database is updated
              await Future.delayed(Duration(milliseconds: 200));
              // CRITICAL: Ensure table/shipping is enabled BEFORE showing print dialog
              // Use existingSaleId for existing sales, response for new sales
              int? finalSellIdForPrint = response ?? existingSaleId;
              await _ensureTableOrShippingEnabled(providedSellId: finalSellIdForPrint);
              if (mounted) {
                printOption(finalSellIdForPrint!);
              }
            }
          }
        } else {
          debugPrint(
              'onSubmit: No connectivity, storing sell locally: $response');
          Fluttertoast.showToast(
            msg: AppLocalizations.of(context)?.translate('no_connectivity') ??
                'No internet connection, stored locally',
            toastLength: Toast.LENGTH_LONG,
          );

          // Mark table/shipping as available after local finalization
          // Get res_table_id and is_shipping from database to ensure accuracy
          var sellRecord = await SellDatabase().getSellBySellId(response);
          int? finalResTableId = sellRecord.isNotEmpty ? sellRecord[0]['res_table_id'] : argument!['res_table_id'];
          int finalIsShipping = sellRecord.isNotEmpty ? (sellRecord[0]['is_shipping'] ?? 0) : (argument!['is_shipping'] ?? 0);

          await Sell().finalizeOrder(
              response, finalResTableId, finalIsShipping);

          // CRITICAL: Force enable table/shipping immediately after finalization (new sale, offline case)
          // Don't call refreshAvailability() as it will clear cache and re-validate, which might
          // find other draft orders and mark the table as unavailable again
          final availabilityManager = TableAvailabilityManager();
          if (finalIsShipping == 1) {
            await availabilityManager.forceEnableTableOrShipping(
              tableId: null,
              isShipping: true,
              locationId: argument!['locationId'],
            );
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('onSubmit: Force enabled shipping (new sale, offline case, cache set, not refreshing)');
          } else if (finalResTableId != null && finalResTableId != 0) {
            await availabilityManager.forceEnableTableOrShipping(
              tableId: finalResTableId,
              isShipping: false,
              locationId: argument!['locationId'],
            );
            // Don't call refreshAvailability() - it will clear cache and re-validate
            debugPrint('onSubmit: Force enabled table $finalResTableId (new sale, offline case, cache set, not refreshing)');
          }

          // Reset cart for the specific res_table_id or shipping
          if (argument!['is_shipping'] == 1) {
            AppConstants.cartData['shipping'] = null;
            await AppConstants.setData(0); // Update shared preferences
            await SellDatabase().resetCartForTable(0); // Pass null for shipping
            debugPrint('onSubmit: Cart reset for shipping (res_table_id=0)');
          } else if (argument!['res_table_id'] != null) {
            AppConstants.cartData[argument!['res_table_id'].toString()] = null;
            await AppConstants.setData(argument!['res_table_id']);
            await SellDatabase().resetCartForTable(argument!['res_table_id']);
            debugPrint(
                'onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');
          }
          // // Reset cart for the specific res_table_id
          // await SellDatabase().resetCartForTable(argument!['res_table_id']);
          // debugPrint('onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');

          // if (_printInvoice) {
          //   await printOption(response);
          // } else {
          //   Navigator.pushNamedAndRemoveUntil(
          //     context,
          //     '/tables',
          //         (Route<dynamic> route) => false,
          //   );
          // }
          if (!_printInvoice) {
            // Only share if we're not printing
            await shareInvoice(response ?? existingSaleId!);

            // Navigate after sharing
            if (mounted) {
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/tables',
                    (Route<dynamic> route) => false,
              );
            }
          } else {
            // Handle print case
            // CRITICAL: Wait a bit to ensure database is updated
            await Future.delayed(Duration(milliseconds: 200));
            // CRITICAL: Ensure table/shipping is enabled BEFORE showing print dialog
            // Use existingSaleId for existing sales, response for new sales
            int? finalSellIdForPrint = response ?? existingSaleId;
            await _ensureTableOrShippingEnabled(providedSellId: finalSellIdForPrint);
            if (mounted) {
              printOption(finalSellIdForPrint!);
            }
          }
        }
      }

      // After successful sale completion, fire the event
      EventBus().fire(SaleFinalizedEvent(invoiceAmount));

      // Debug: Log all incomplete carts after submission
      var allCartsAfter = await SellDatabase().getInCompleteLines(
        argument!['locationId'],
        resTableId: argument!['res_table_id'],
      );
      debugPrint(
          'onSubmit: All incomplete sell_lines after submission: $allCartsAfter');
    } catch (e, stackTrace) {
      debugPrint('onSubmit: Error: $e::::');
      debugPrint('onSubmit: Stack Trace: $stackTrace');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context)?.translate('error_submitting_sale') ??
            'Error submitting sale: $e',
        toastLength: Toast.LENGTH_LONG,
      );
    } finally {
      setState(() {
        isLoading = false;
        saleCreated = false;

        // Clear all specified TextEditingControllers
        saleNote.clear();
        staffNote.clear();
        shippingDetails.clear();
        shippingCharges.clear();
        tip_amountController.clear();
      });
      debugPrint('onSubmit: Completed');
    }
  }

  Future<void> shareInvoice(int sellId) async {
    try {
      Map<String, dynamic>? sell;
      String? invoiceUrl;
      String? invoiceNo;
      int? taxRateId;

      // Try to get sale from local database first
      var sells = await SellDatabase().getSellBySellId(sellId);
      if (sells.isNotEmpty && sells[0] is Map<String, dynamic>) {
        sell = sells[0];
        invoiceUrl = sell['invoice_url'];
        invoiceNo = sell['invoice_no'];
        taxRateId = sell['tax_rate_id'];
        debugPrint('shareInvoice: Found sale in local database for sellId: $sellId');
      } else {
        // Sale not in local database, try to fetch from API using transaction_id
        debugPrint('shareInvoice: Sale not in local database, fetching from API for sellId: $sellId');
        try {
          // Try to get transaction_id from local database first (might exist even if sale doesn't)
          var localSell = await SellDatabase().getSellBySellId(sellId);
          int? transactionId;

          if (localSell.isNotEmpty && localSell[0]['transaction_id'] != null) {
            transactionId = int.tryParse(localSell[0]['transaction_id'].toString());
          } else {
            // If no transaction_id in local DB, assume sellId is the transaction_id
            transactionId = sellId;
          }

          if (transactionId != null) {
            List apiSales = await SellApi().getSpecifiedSells([transactionId]);
            if (apiSales.isNotEmpty) {
              var apiSale = apiSales[0];
              invoiceUrl = apiSale['invoice_url'];
              invoiceNo = apiSale['invoice_no'];
              taxRateId = apiSale['tax_rate_id'] ?? apiSale['tax_id'];
              debugPrint('shareInvoice: Fetched invoice URL from API: $invoiceUrl');
            }
          }
        } catch (e) {
          debugPrint('shareInvoice: Error fetching from API: $e');
        }
      }

      // If we have invoice URL, share it
      if (invoiceUrl != null && invoiceUrl.isNotEmpty) {
        await Share.share(
          '${AppLocalizations.of(context)?.translate('invoice') ?? 'Invoice'}: $invoiceUrl',
          subject:
          '${AppLocalizations.of(context)?.translate('invoice_for_sale') ?? 'Invoice for sale'} #${invoiceNo ?? sellId}',
        );
      } else if (sell != null && taxRateId != null) {
        // If no URL but we have local sale data, generate local invoice and share as text
        try {
          String invoiceHtml = await InvoiceFormatter().generateInvoice(
            sellId,
            taxRateId,
            context,
          );

          String invoiceText =
              '${AppLocalizations.of(context)?.translate('invoice') ?? 'Invoice'} #${sell['invoice_no'] ?? sellId}\n'
              '${AppLocalizations.of(context)?.translate('date') ?? 'Date'}: ${sell['transaction_date'] ?? ''}\n'
              '${AppLocalizations.of(context)?.translate('total') ?? 'Total'}: ${sell['final_total'] ?? 0}';

          await Share.share(
            invoiceText,
            subject:
            '${AppLocalizations.of(context)?.translate('invoice_for_sale') ?? 'Invoice for sale'} #${sell['invoice_no'] ?? sellId}',
          );
        } catch (e) {
          debugPrint('shareInvoice: Error generating local invoice: $e');
          Fluttertoast.showToast(
            msg: AppLocalizations.of(context)
                ?.translate('error_generating_invoice') ??
                'Error generating invoice',
          );
        }
      } else {
        // No sale data available
        debugPrint('shareInvoice: No sale data available for sellId: $sellId');
        Fluttertoast.showToast(
          msg: AppLocalizations.of(context)
              ?.translate('error_generating_invoice') ??
              'Error generating invoice: Sale not found',
        );
      }
    } catch (e) {
      debugPrint('shareInvoice: Error sharing invoice: $e');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context)?.translate('error_sharing_invoice') ??
            'Error sharing invoice',
      );
    }
  }

  Future<void> checkLocalSell(int sellId) async {
    try {
      var sells = await SellDatabase().getSellBySellId(sellId);
      print('Local Sell: ${jsonEncode(sells)}');
      if (sells is List &&
          sells.isNotEmpty &&
          sells[0] is Map<String, dynamic>) {
        print('Local Sell Details: ${sells[0]}');
      } else {
        print(
            'Error: Invalid sell data format for sellId: $sellId, got: ${sells.runtimeType}');
      }
    } catch (e) {
      print('Error in checkLocalSell: $e');
    }
  }

  ///original code
  // Future<void> printOption(int sellId) async {
  //   try {
  //     print('printOption called with sellId: $sellId');
  //     var sells = await SellDatabase().getSellBySellId(sellId);
  //     if (sells.isEmpty || sells[0] is! Map<String, dynamic>) {
  //       print('Error: Sell not found or invalid format for ID: $sellId');
  //       Fluttertoast.showToast(
  //         msg: AppLocalizations.of(context)?.translate('error_generating_invoice') ?? 'Error generating invoice',
  //       );
  //       return;
  //     }
  //
  //     var sell = sells[0];
  //     String? invoiceUrl = sell['invoice_url'];
  //     String invoiceHtml;
  //     String webViewUrl;
  //
  //     if (invoiceUrl != null && invoiceUrl.isNotEmpty && await Helper().checkConnectivity()) {
  //       print('printOption: Fetching invoice from URL: $invoiceUrl');
  //       final response = await http.get(Uri.parse(invoiceUrl)).timeout(Duration(seconds: 10));
  //       if (response.statusCode == 200) {
  //         invoiceHtml = response.body;
  //         webViewUrl = invoiceUrl;
  //         print('printOption: Successfully fetched invoice HTML from URL');
  //       } else {
  //         print('printOption: Failed to fetch invoice from URL, status: ${response.statusCode}');
  //         Fluttertoast.showToast(
  //           msg: AppLocalizations.of(context)?.translate('error_fetching_invoice') ?? 'Failed to fetch invoice from server',
  //         );
  //         // Fallback to local invoice generation
  //         invoiceHtml = await InvoiceFormatter().generateInvoice(
  //           sellId,
  //           sell['tax_rate_id'],
  //           context,
  //         );
  //         webViewUrl = 'data:text/html;base64,${base64Encode(utf8.encode(invoiceHtml))}';
  //         print('printOption: Generated local invoice as fallback');
  //       }
  //     } else {
  //       print('printOption: No invoice URL or no connectivity, generating local invoice');
  //       invoiceHtml = await InvoiceFormatter().generateInvoice(
  //         sellId,
  //         sell['tax_rate_id'],
  //         context,
  //       );
  //       webViewUrl = 'data:text/html;base64,${base64Encode(utf8.encode(invoiceHtml))}';
  //       print('printOption: Generated local invoice HTML');
  //     }
  //
  //     showDialog(
  //       context: context,
  //       barrierDismissible: false,
  //       builder: (context) => AlertDialog(
  //         title: Text('Invoice #${sell['invoice_no']}'),
  //
  //         content: SizedBox(
  //           width: double.maxFinite,
  //           height: 400,
  //           child: WebView(
  //             initialUrl: webViewUrl,
  //             javascriptMode: JavascriptMode.unrestricted,
  //           ),
  //         ),
  //         actions: [
  //           TextButton(
  //             onPressed: () async {
  //               await Printing.layoutPdf(
  //                 onLayout: (format) async => await Printing.convertHtml(
  //                   format: format,
  //                   html: invoiceHtml,
  //                 ),
  //               );
  //               Fluttertoast.showToast(
  //                 msg: AppLocalizations.of(context)?.translate('invoice_printed') ?? 'Invoice printed',
  //               );
  //               Navigator.pop(context); // Close the invoice dialog
  //               Navigator.pushNamedAndRemoveUntil(
  //                 context,
  //                 '/tables',
  //                     (Route<dynamic> route) => false, // Clear the navigation stack
  //               );
  //             },
  //             child: Text(AppLocalizations.of(context)?.translate('print') ?? 'Print'),
  //           ),
  //           TextButton(
  //             onPressed: () {
  //               Fluttertoast.showToast(
  //                 msg: AppLocalizations.of(context)?.translate('close') ?? 'Close',
  //               );
  //               Navigator.pop(context); // Close the invoice dialog
  //               Navigator.pushNamedAndRemoveUntil(
  //                 context,
  //                 '/tables',
  //                     (Route<dynamic> route) => false, // Clear the navigation stack
  //               );
  //             },
  //             child: Text(AppLocalizations.of(context)?.translate('close') ?? 'Close'),
  //           ),
  //         ],
  //       ),
  //     );
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context)?.translate('invoice_displayed') ?? 'Invoice displayed',
  //     );
  //   } catch (e) {
  //     print('Error in printOption: $e');
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context)?.translate('error_generating_invoice') ?? 'Error generating invoice: $e',
  //     );
  //   }
  // }
  Future<void> printOption(int sellId) async {
    try {
      debugPrint('printOption called with sellId: $sellId');
      Map<String, dynamic>? sell;
      String? invoiceUrl;
      String? invoiceNo;
      int? taxRateId;

      // Try to get sale from local database first
      var sells = await SellDatabase().getSellBySellId(sellId);
      if (sells.isNotEmpty && sells[0] is Map<String, dynamic>) {
        sell = sells[0];
        invoiceUrl = sell['invoice_url'];
        invoiceNo = sell['invoice_no'];
        taxRateId = sell['tax_rate_id'];
        debugPrint('printOption: Found sale in local database for sellId: $sellId');
      } else {
        // Sale not in local database, try to fetch from API
        debugPrint('printOption: Sale not in local database, fetching from API for sellId: $sellId');
        try {
          // Try to get transaction_id from local database first (might exist even if sale doesn't)
          var localSell = await SellDatabase().getSellBySellId(sellId);
          int? transactionId;

          if (localSell.isNotEmpty && localSell[0]['transaction_id'] != null) {
            transactionId = int.tryParse(localSell[0]['transaction_id'].toString());
          } else {
            // If no transaction_id in local DB, assume sellId is the transaction_id
            transactionId = sellId;
          }

          if (transactionId != null) {
            List apiSales = await SellApi().getSpecifiedSells([transactionId]);
            if (apiSales.isNotEmpty) {
              var apiSale = apiSales[0];
              invoiceUrl = apiSale['invoice_url'];
              invoiceNo = apiSale['invoice_no'];
              taxRateId = apiSale['tax_rate_id'] ?? apiSale['tax_id'];
              // Create a temporary sell map for compatibility
              sell = {
                'invoice_url': invoiceUrl,
                'invoice_no': invoiceNo,
                'tax_rate_id': taxRateId,
              };
              debugPrint('printOption: Fetched invoice URL from API: $invoiceUrl');
            } else {
              debugPrint('printOption: No sale found in API for transaction ID: $transactionId');
              Fluttertoast.showToast(
                msg: AppLocalizations.of(context)
                    ?.translate('error_generating_invoice') ??
                    'Error generating invoice: Sale not found',
              );
              return;
            }
          } else {
            debugPrint('printOption: Could not determine transaction ID for sellId: $sellId');
            Fluttertoast.showToast(
              msg: AppLocalizations.of(context)
                  ?.translate('error_generating_invoice') ??
                  'Error generating invoice: Sale not found',
            );
            return;
          }
        } catch (e) {
          debugPrint('printOption: Error fetching from API: $e');
          Fluttertoast.showToast(
            msg: AppLocalizations.of(context)
                ?.translate('error_generating_invoice') ??
                'Error generating invoice: ${e.toString()}',
          );
          return;
        }
      }

      if (sell == null) {
        debugPrint('printOption: No sale data available for sellId: $sellId');
        Fluttertoast.showToast(
          msg: AppLocalizations.of(context)
              ?.translate('error_generating_invoice') ??
              'Error generating invoice: Sale not found',
        );
        return;
      }
      String invoiceHtml;
      String webViewUrl;

      if (invoiceUrl != null &&
          invoiceUrl.isNotEmpty &&
          await Helper().checkConnectivity()) {
        print('printOption: Fetching invoice from URL: $invoiceUrl');
        final response = await http
            .get(Uri.parse(invoiceUrl))
            .timeout(Duration(seconds: 10));
        if (response.statusCode == 200) {
          invoiceHtml = response.body;
          webViewUrl = invoiceUrl;
          print('printOption: Successfully fetched invoice HTML from URL');
        } else {
          print(
              'printOption: Failed to fetch invoice from URL, status: ${response.statusCode}');
          Fluttertoast.showToast(
            msg: AppLocalizations.of(context)
                ?.translate('error_fetching_invoice') ??
                'Failed to fetch invoice from server',
          );
          // Fallback to local invoice generation
          invoiceHtml = await InvoiceFormatter().generateInvoice(
            sellId,
            taxRateId ?? sell?['tax_rate_id'],
            context,
          );
          webViewUrl =
          'data:text/html;base64,${base64Encode(utf8.encode(invoiceHtml))}';
          print('printOption: Generated local invoice as fallback');
        }
      } else {
        print(
            'printOption: No invoice URL or no connectivity, generating local invoice');
        invoiceHtml = await InvoiceFormatter().generateInvoice(
          sellId,
          taxRateId ?? sell?['tax_rate_id'],
          context,
        );
        webViewUrl =
        'data:text/html;base64,${base64Encode(utf8.encode(invoiceHtml))}';
        print('printOption: Generated local invoice HTML');
      }

      // ✅ Full screen invoice viewer with SafeArea
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Dialog(
          insetPadding: EdgeInsets.zero,
          backgroundColor: Colors.white,
          // backgroundColor: Theme.of(context).primaryColor,
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: SafeArea(
              child: Column(
                children: [
                  // Header with title and buttons
                  Container(
                    width: MediaQuery.of(context).size.width,
                    color: Theme.of(context).primaryColor,
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Text(
                      'Invoice #${invoiceNo ?? sell?['invoice_no'] ?? sellId}',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.start,
                    ),
                  ),
                  // Invoice content
                  Expanded(
                    child: WebView(
                      initialUrl: webViewUrl,
                      javascriptMode: JavascriptMode.unrestricted,
                    ),
                  ),
                  // Container(
                  //   color: Colors.white,
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.end,
                  //     children: [
                  //       TextButton(
                  //         onPressed: () async {
                  //           await Printing.layoutPdf(
                  //             onLayout: (format) async => await Printing.convertHtml(
                  //               format: format,
                  //               html: invoiceHtml,
                  //             ),
                  //           );
                  //           Fluttertoast.showToast(
                  //             msg: AppLocalizations.of(context)?.translate('invoice_printed') ?? 'Invoice printed',
                  //           );
                  //           Navigator.pop(context);
                  //           Navigator.pushNamedAndRemoveUntil(
                  //             context,
                  //             '/tables',
                  //                 (Route<dynamic> route) => false,
                  //           );
                  //         },
                  //         child: Text(
                  //           AppLocalizations.of(context)?.translate('print') ?? 'Print',
                  //          // style: TextStyle(color: Colors.black),
                  //         ),
                  //       ),
                  //       SizedBox(width: 16),
                  //       TextButton(
                  //         onPressed: () {
                  //           Fluttertoast.showToast(
                  //             msg: AppLocalizations.of(context)?.translate('close') ?? 'Close',
                  //           );
                  //           Navigator.pop(context);
                  //           Navigator.pushNamedAndRemoveUntil(
                  //             context,
                  //             '/tables',
                  //                 (Route<dynamic> route) => false,
                  //           );
                  //         },
                  //         child: Text(
                  //           AppLocalizations.of(context)?.translate('close') ?? 'Close',
                  //           //style: TextStyle(color: Colors.black),
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  // ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.all(
                        8), // Add some spacing inside the container
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        // Print button
                        TextButton(
                          style: TextButton.styleFrom(
                            backgroundColor: Colors.blue, // Button background
                            foregroundColor: Colors.white, // Text color
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius.circular(12), // Rounded corners
                            ),
                            shadowColor: Colors.black.withOpacity(0.2),
                            elevation: 3, // Shadow effect
                          ),
                          onPressed: () async {
                            await Printing.layoutPdf(
                              onLayout: (format) async =>
                              await Printing.convertHtml(
                                format: format,
                                html: invoiceHtml,
                              ),
                            );
                            Fluttertoast.showToast(
                              msg: AppLocalizations.of(context)
                                  ?.translate('invoice_printed') ??
                                  'Invoice printed',
                            );
                            Navigator.pop(context);
                            Navigator.pushNamedAndRemoveUntil(
                              context,
                              '/tables',
                                  (Route<dynamic> route) => false,
                            );
                          },
                          child: Text(
                            AppLocalizations.of(context)?.translate('print') ??
                                'Print',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                        SizedBox(width: 16),
                        // Close button
                        TextButton(
                          style: TextButton.styleFrom(
                            backgroundColor:
                            Colors.red, // Different color for "Close"
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            shadowColor: Colors.black.withOpacity(0.2),
                            elevation: 3,
                          ),
                          onPressed: () {
                            Fluttertoast.showToast(
                              msg: AppLocalizations.of(context)
                                  ?.translate('close') ??
                                  'Close',
                            );
                            Navigator.pop(context);
                            Navigator.pushNamedAndRemoveUntil(
                              context,
                              '/tables',
                                  (Route<dynamic> route) => false,
                            );
                          },
                          child: Text(
                            AppLocalizations.of(context)?.translate('close') ??
                                'Close',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      );

      Fluttertoast.showToast(
        msg: AppLocalizations.of(context)?.translate('invoice_displayed') ??
            'Invoice displayed',
      );
    } catch (e) {
      print('Error in printOption: $e');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context)
            ?.translate('error_generating_invoice') ??
            'Error generating invoice: $e',
      );
    }
  }

  alertPending(BuildContext context) {
    AlertDialog alert = AlertDialog(
      content: Text(
        AppLocalizations.of(context)?.translate('pending_message') ??
            'Pending amount exists. Proceed?',
        style: AppTheme.getTextStyle(
          themeData.textTheme.bodyText2,
          color: themeData.colorScheme.onBackground,
          fontWeight: 500,
          muted: true,
        ),
      ),
      actions: <Widget>[
        TextButton(
          style: TextButton.styleFrom(
            primary: themeData.colorScheme.onPrimary,
            backgroundColor: themeData.colorScheme.primary,
          ),
          onPressed: () {
            Navigator.pop(context);
            if (!saleCreated) {
              onSubmit();
            }
          },
          child: Text(AppLocalizations.of(context)?.translate('ok') ?? 'OK'),
        ),
        TextButton(
          style: TextButton.styleFrom(
            primary: themeData.colorScheme.primary,
            backgroundColor: themeData.colorScheme.onPrimary,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text(
              AppLocalizations.of(context)?.translate('cancel') ?? 'Cancel'),
        ),
      ],
    );
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => alert,
    );
  }

  alertConfirm(BuildContext context, index) {
    AlertDialog alert = AlertDialog(
      title: Icon(MdiIcons.alert, color: Colors.red, size: MySize.size50),
      content: Text(
        AppLocalizations.of(context)?.translate('are_you_sure') ??
            'Are you sure?',
        textAlign: TextAlign.center,
        style: AppTheme.getTextStyle(
          themeData.textTheme.bodyText1,
          color: themeData.colorScheme.onBackground,
          fontWeight: 600,
          muted: true,
        ),
      ),
      actions: <Widget>[
        TextButton(
          style: TextButton.styleFrom(
            primary: themeData.colorScheme.primary,
            backgroundColor: themeData.colorScheme.onPrimary,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text(
              AppLocalizations.of(context)?.translate('cancel') ?? 'Cancel'),
        ),
        TextButton(
          style: TextButton.styleFrom(
            backgroundColor: Colors.red,
            primary: themeData.colorScheme.onError,
          ),
          onPressed: () {
            Navigator.pop(context);
            if (sellId != null && payments[index]['id'] != null) {
              deletedPaymentId.add(payments[index]['id']);
            }
            payments.removeAt(index);
            calculateMultiPayment();
          },
          child: Text(AppLocalizations.of(context)?.translate('ok') ?? 'OK'),
        ),
      ],
    );
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => alert,
    );
  }

  Widget tipDropdown() {
    return DropdownButtonHideUnderline(
      child: DropdownButton(
        dropdownColor: themeData.backgroundColor,
        icon: Icon(Icons.arrow_drop_down),
        value: selectedTipType,
        items: <String>['fixed', 'percentage']
            .map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(
              value,
              softWrap: true,
              overflow: TextOverflow.ellipsis,
              style: AppTheme.getTextStyle(
                themeData.textTheme.bodyText1,
                color: themeData.colorScheme.onBackground,
                fontWeight: 600,
                muted: true,
              ),
            ),
          );
        }).toList(),
        onChanged: (newValue) {
          setState(() {
            selectedTipType = newValue.toString();
            invoiceAmount = (argument!['invoiceAmount']?.toDouble() ?? 0.00) +
                (double.tryParse(shippingCharges.text) ?? 0.00) +
                calculateTipAmount();
            calculateMultiPayment();
          });
        },
      ),
    );
  }

  Widget inLinetip(index) {
    return DropdownButtonHideUnderline(
      child: DropdownButton(
        dropdownColor: themeData.backgroundColor,
        icon: Icon(Icons.arrow_drop_down),
        value: index['tip_type'],
        items: <String>['fixed', 'percentage']
            .map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
        onChanged: (newValue) {
          if (hasTipTypeColumn) {
            SellDatabase().update(index['id'], {'tip_type': '$newValue'});
          }
        },
      ),
    );
  }
}

class CardDetailsDialog extends StatefulWidget {
  final int index;
  final Function(Map<String, dynamic>) onSave;

  const CardDetailsDialog({
    Key? key,
    required this.index,
    required this.onSave,
  }) : super(key: key);

  @override
  _CardDetailsDialogState createState() => _CardDetailsDialogState();
}

class _CardDetailsDialogState extends State<CardDetailsDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController cardNumberController;
  late final TextEditingController cardHolderNameController;
  late final TextEditingController cardTransactionNumberController;
  late final TextEditingController cardTypeController;
  late final TextEditingController cardMonthController;
  late final TextEditingController cardYearController;
  late final TextEditingController cardSecurityController;

  @override
  void initState() {
    super.initState();
    cardNumberController = TextEditingController();
    cardHolderNameController = TextEditingController();
    cardTransactionNumberController = TextEditingController();
    cardTypeController = TextEditingController();
    cardMonthController = TextEditingController();
    cardYearController = TextEditingController();
    cardSecurityController = TextEditingController();
  }

  @override
  void dispose() {
    cardNumberController.dispose();
    cardHolderNameController.dispose();
    cardTransactionNumberController.dispose();
    cardTypeController.dispose();
    cardMonthController.dispose();
    cardYearController.dispose();
    cardSecurityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeData = Theme.of(context);

    return AlertDialog(
      title: Text(
        AppLocalizations.of(context)?.translate('card_details') ??
            'Enter Card Details',
        style: AppTheme.getTextStyle(themeData.textTheme.headline6,
            fontWeight: 600),
      ),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: cardNumberController,
                decoration: InputDecoration(
                  labelText:
                  AppLocalizations.of(context)?.translate('card_number') ??
                      'Card Number',
                ),
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(16),
                ],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context)
                        ?.translate('card_number_required') ??
                        'Card number is required';
                  }
                  if (value.length != 15 && value.length != 16) {
                    return AppLocalizations.of(context)
                        ?.translate('card_number_invalid') ??
                        'Card number must be 15 or 16 digits';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: cardHolderNameController,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context)
                      ?.translate('card_holder_name') ??
                      'Card Holder Name',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context)
                        ?.translate('card_holder_name_required') ??
                        'Card holder name is required';
                  }
                  if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(value)) {
                    return AppLocalizations.of(context)
                        ?.translate('card_holder_name_invalid') ??
                        'Name can only contain letters and spaces';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: cardTransactionNumberController,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context)
                      ?.translate('card_transaction_number') ??
                      'Transaction Number',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context)
                        ?.translate('transaction_number_required') ??
                        'Transaction number is required';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: cardTypeController.text.isNotEmpty
                    ? cardTypeController.text
                    : null,
                decoration: InputDecoration(
                  labelText:
                  AppLocalizations.of(context)?.translate('card_type') ??
                      'Card Type',
                  prefixIcon: Icon(Icons.credit_card, color: Colors.blueAccent),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  contentPadding:
                  EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                icon: Icon(Icons.keyboard_arrow_down_rounded,
                    color: Colors.blueAccent),
                dropdownColor: Colors.white,
                style: TextStyle(color: Colors.black87, fontSize: 16),
                items: ['Visa', 'MasterCard', 'American Express', 'Discover']
                    .map((type) => DropdownMenuItem(
                  value: type,
                  child: Text(type,
                      style: TextStyle(fontWeight: FontWeight.w500)),
                ))
                    .toList(),
                onChanged: (value) {
                  cardTypeController.text = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context)
                        ?.translate('card_type_required') ??
                        'Card type is required';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: cardMonthController.text.isNotEmpty
                    ? cardMonthController.text
                    : null,
                decoration: InputDecoration(
                  labelText:
                  AppLocalizations.of(context)?.translate('card_month') ??
                      'Expiration Month (MM)',
                  prefixIcon: Icon(Icons.calendar_today_rounded,
                      color: Colors.blueAccent),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16)),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  contentPadding:
                  EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                icon: Icon(Icons.keyboard_arrow_down_rounded,
                    color: Colors.blueAccent),
                dropdownColor: Colors.white,
                style: TextStyle(fontSize: 16, color: Colors.black87),
                items: List.generate(
                    12, (index) => (index + 1).toString().padLeft(2, '0'))
                    .map((month) => DropdownMenuItem(
                  value: month,
                  child: Text(month,
                      style: TextStyle(fontWeight: FontWeight.w500)),
                ))
                    .toList(),
                onChanged: (value) {
                  cardMonthController.text = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context)
                        ?.translate('card_month_required') ??
                        'Expiration month is required';
                  }
                  int? month = int.tryParse(value);
                  if (month == null || month < 1 || month > 12) {
                    return AppLocalizations.of(context)
                        ?.translate('card_month_invalid') ??
                        'Enter a valid month (01-12)';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: cardYearController.text.isNotEmpty
                    ? cardYearController.text
                    : null,
                decoration: InputDecoration(
                  labelText:
                  AppLocalizations.of(context)?.translate('card_year') ??
                      'Expiration Year (YYYY)',
                  prefixIcon: Icon(Icons.calendar_today_rounded,
                      color: Colors.blueAccent),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16)),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  contentPadding:
                  EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                icon: Icon(Icons.keyboard_arrow_down_rounded,
                    color: Colors.blueAccent),
                style: TextStyle(fontSize: 16, color: Colors.black87),
                dropdownColor: Colors.white,
                items: List.generate(11, (index) {
                  final year = DateTime.now().year + index;
                  return DropdownMenuItem(
                    value: year.toString(),
                    child: Text(year.toString(),
                        style: TextStyle(fontWeight: FontWeight.w500)),
                  );
                }),
                onChanged: (value) {
                  cardYearController.text = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context)
                        ?.translate('card_year_required') ??
                        'Expiration year is required';
                  }
                  int? year = int.tryParse(value);
                  int currentYear = DateTime.now().year;
                  if (year == null || year < currentYear) {
                    return AppLocalizations.of(context)
                        ?.translate('card_year_invalid') ??
                        'Enter a valid future year';
                  }
                  if (cardMonthController.text.isNotEmpty) {
                    int? month = int.tryParse(cardMonthController.text);
                    if (month != null &&
                        year == currentYear &&
                        month < DateTime.now().month) {
                      return AppLocalizations.of(context)
                          ?.translate('card_expired') ??
                          'Card has expired';
                    }
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: cardSecurityController,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context)
                      ?.translate('card_security') ??
                      'Security Code',
                ),
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(4),
                ],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context)
                        ?.translate('card_security_required') ??
                        'Security code is required';
                  }
                  if (value.length < 3 || value.length > 4) {
                    return AppLocalizations.of(context)
                        ?.translate('card_security_invalid') ??
                        'Security code must be 3-4 digits';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(
              AppLocalizations.of(context)?.translate('cancel') ?? 'Cancel'),
        ),
        TextButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              widget.onSave({
                'card_number': cardNumberController.text,
                'card_holder_name': cardHolderNameController.text,
                'card_transaction_number': cardTransactionNumberController.text,
                'card_type': cardTypeController.text,
                'card_month': cardMonthController.text,
                'card_year': cardYearController.text,
                'card_security': cardSecurityController.text,
              });
              Navigator.pop(context);
            }
          },
          child: Text(AppLocalizations.of(context)?.translate('ok') ?? 'OK'),
        ),
      ],
    );
  }
}
