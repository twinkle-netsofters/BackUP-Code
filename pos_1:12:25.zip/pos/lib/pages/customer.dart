// import 'dart:convert';
//
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:intl/intl.dart';
// import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// import 'package:search_choices/search_choices.dart';
//
// import '../apis/contact.dart';
// import '../helpers/AppTheme.dart';
// import '../helpers/SizeConfig.dart';
// import '../helpers/otherHelpers.dart';
// import '../helpers/style.dart' as style;
// import '../locale/MyLocalizations.dart';
// import '../models/contact_model.dart';
// import '../models/sell.dart';
// import '../models/sellDatabase.dart';
// import 'elements.dart';
// import 'login.dart';
//
// class Customer extends StatefulWidget {
//   @override
//   _CustomerState createState() => _CustomerState();
// }
//
// class _CustomerState extends State<Customer> {
//   Map? argument;
//   final _formKey = GlobalKey<FormState>();
//
//   String transactionDate =
//       DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now());
//   List<Map<String, dynamic>> customerListMap = [];
//   Map<String, dynamic> selectedCustomer = {
//     'id': 0,
//     'name': 'select customer',
//     'mobile': ' - '
//   };
//   TextEditingController prefix = new TextEditingController(),
//       firstName = new TextEditingController(),
//       middleName = new TextEditingController(),
//       lastName = new TextEditingController(),
//       mobile = new TextEditingController(),
//       addressLine1 = new TextEditingController(),
//       addressLine2 = new TextEditingController(),
//       city = new TextEditingController(),
//       state = new TextEditingController(),
//       country = new TextEditingController(),
//       zip = new TextEditingController();
//
//   static int themeType = 1;
//   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
//   CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);
//
//   @override
//   void initState() {
//     super.initState();
//     selectCustomer();
//   }
//
//   @override
//   void didChangeDependencies() {
//     argument = ModalRoute.of(context)!.settings.arguments as Map?;
//
//     if (argument!['customerId'] != null) {
//       Future.delayed(Duration(milliseconds: 400), () async {
//         await Contact()
//             .getCustomerDetailById(argument!['customerId'])
//             .then((value) {
//           if (this.mounted) {
//             setState(() {
//               selectedCustomer = {
//                 'id': argument!['customerId'],
//                 'name': value['name'],
//                 'mobile': value['mobile']
//               };
//             });
//           }
//         });
//       });
//     }
//     super.didChangeDependencies();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           elevation: 0,
//           title: Text(AppLocalizations.of(context).translate('customer'),
//               style: AppTheme.getTextStyle(themeData.textTheme.headline6,
//                   fontWeight: 600)),
//         ),
//         floatingActionButton: FloatingActionButton(
//           onPressed: () {
//             Navigator.of(context).push(new MaterialPageRoute<Null>(
//                 builder: (BuildContext context) {
//                   return newCustomer();
//                 },
//                 fullscreenDialog: true));
//           },
//           child: Icon(MdiIcons.accountPlus),
//           elevation: 2,
//         ),
//         body: SingleChildScrollView(
//           child: Column(
//             children: <Widget>[
//               Padding(
//                 padding:
//                     EdgeInsets.only(top: MySize.size120!, left: MySize.size20!),
//                 child: Card(child: customerList()),
//               ),
//               Center(
//                 child: Visibility(
//                   visible: (selectedCustomer['id'] == 0),
//                   child: Text(
//                       AppLocalizations.of(context).translate(
//                           'please_select_a_customer_for_checkout_option'),
//                       style: TextStyle(color: Colors.red)),
//                 ),
//               ),
//             ],
//           ),
//         ),
//         bottomNavigationBar: Visibility(
//           visible: (selectedCustomer['id'] != 0),
//           child: Row(
//             mainAxisAlignment: (argument!['is_quotation'] == null)
//                 ? MainAxisAlignment.spaceAround
//                 : MainAxisAlignment.center,
//             children: [
//               Visibility(
//                 visible: argument!['is_quotation'] == null,
//                 child: TextButton(
//                   onPressed: (addQuotation),
//                   style: TextButton.styleFrom(
//                       primary: Colors.black,
//                       backgroundColor: style.StyleColors().mainColor(1),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(40.0),
//                       )),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Icon(
//                         Icons.add,
//                         color: Theme.of(context).colorScheme.surface,
//                       ),
//                       Text(
//                         AppLocalizations.of(context).translate('add_quotation'),
//                         style: AppTheme.getTextStyle(
//                             Theme.of(context).textTheme.bodyText1,
//                             color: Theme.of(context).colorScheme.surface),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               cartBottomBar(
//                   '/checkout',
//                   AppLocalizations.of(context).translate('pay_&_checkout'),
//                   context,
//                   Helper().argument(
//                       locId: argument!['locationId'],
//                       taxId: argument!['taxId'],
//                       discountType: argument!['discountType'],
//                       discountAmount: argument!['discountAmount'],
//                       invoiceAmount: argument!['invoiceAmount'],
//                       customerId: selectedCustomer['id'],
//                       sellId: argument!['sellId'])),
//             ],
//           ),
//         ));
//   }
//
//   //add quotation
//   addQuotation() async {
//     Map sell = await Sell().createSell(
//         changeReturn: 0.00,
//         transactionDate: transactionDate,
//         pending: argument!['invoiceAmount'],
//         shippingCharges: 0.00,
//         shippingDetails: '',
//         invoiceNo: USERID.toString() +
//             "_" +
//             DateFormat('yMdHm').format(DateTime.now()),
//         contactId: selectedCustomer['id'],
//         discountAmount: argument!['discountAmount'],
//         discountType: argument!['discountType'],
//         invoiceAmount: argument!['invoiceAmount'],
//         locId: argument!['locationId'],
//         saleStatus: 'draft',
//         sellId: argument!['sellId'],
//         taxId: argument!['taxId'],
//
//         ///Employee Tip added
//         tip_amount: 0.00,
//         isQuotation: 1);
//     confirmDialog(sell);
//   }
//
//   //confirmation dialogBox
//   confirmDialog(sell) {
//     showDialog(
//       barrierDismissible: true,
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           backgroundColor: customAppTheme.bgLayer1,
//           title: Text(AppLocalizations.of(context).translate('quotation'),
//               style: AppTheme.getTextStyle(themeData.textTheme.headline6,
//                   color: themeData.colorScheme.onBackground, fontWeight: 700)),
//           actions: [
//             ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                 primary: themeData.colorScheme.primary,
//               ),
//               onPressed: () async {
//                 if (argument!['sellId'] != null) {
//                   //update sell
//                 } else {
//                   await SellDatabase().storeSell(sell).then((value) async {
//                     SellDatabase()
//                         .updateSellLine({'sell_id': value, 'is_completed': 1});
//                     if (await Helper().checkConnectivity()) {
//                       await Sell().createApiSell(sellId: value);
//                     }
//                     Navigator.pushNamedAndRemoveUntil(
//                         context, '/products', ModalRoute.withName('/home'));
//                   });
//                 }
//               },
//               child: Text(AppLocalizations.of(context).translate('save')),
//             ),
//             ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                 primary: themeData.colorScheme.primary,
//               ),
//               onPressed: () async {
//                 await SellDatabase().storeSell(sell).then((value) async {
//                   SellDatabase()
//                       .updateSellLine({'sell_id': value, 'is_completed': 1});
//                   if (await Helper().checkConnectivity()) {
//                     await Sell().createApiSell(sellId: value);
//                   }
//                   Helper()
//                       .printDocument(value, argument!['taxId'], context)
//                       .then((value) {
//                     Navigator.pushNamedAndRemoveUntil(
//                         context, '/products', ModalRoute.withName('/home'));
//                     Fluttertoast.showToast(
//                         msg: AppLocalizations.of(context)
//                             .translate('quotation_added'));
//                   });
//                 });
//               },
//               child:
//                   Text(AppLocalizations.of(context).translate('save_n_print')),
//             )
//           ],
//         );
//       },
//     );
//   }
//
//   //show add customer alert box
//   Widget newCustomer() {
//     return Scaffold(
//       appBar: new AppBar(
//         title: Text(AppLocalizations.of(context).translate('create_contact'),
//             style: themeData.appBarTheme.textTheme!.headline6),
//       ),
//       body: Container(
//         height: MediaQuery.of(context).size.height,
//         padding: EdgeInsets.only(top: 8, bottom: 8, left: 16, right: 16),
//         child: SingleChildScrollView(
//           child: Column(
//             children: <Widget>[
//               Form(
//                 key: _formKey,
//                 child: Column(
//                   mainAxisSize: MainAxisSize.min,
//                   children: <Widget>[
//                     Row(
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: <Widget>[
//                         Container(
//                           width: 64,
//                           child: Center(
//                             child: Icon(
//                               MdiIcons.accountChildCircle,
//                               color: themeData.colorScheme.onBackground,
//                             ),
//                           ),
//                         ),
//                         Expanded(
//                           flex: 1,
//                           child: Container(
//                             margin: EdgeInsets.only(left: 16),
//                             child: Column(
//                               children: <Widget>[
//                                 Row(
//                                   children: <Widget>[
//                                     Container(
//                                       width: 50,
//                                       child: TextFormField(
//                                         controller: prefix,
//                                         style: themeData.textTheme.subtitle2!
//                                             .merge(TextStyle(
//                                                 color: themeData
//                                                     .colorScheme.onBackground)),
//                                         decoration: InputDecoration(
//                                           hintStyle: themeData
//                                               .textTheme.subtitle2!
//                                               .merge(TextStyle(
//                                                   color: themeData.colorScheme
//                                                       .onBackground)),
//                                           hintText: AppLocalizations.of(context)
//                                               .translate('prefix'),
//                                           border: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .border!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                           enabledBorder: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .enabledBorder!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                           focusedBorder: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .focusedBorder!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                         ),
//                                         textCapitalization:
//                                             TextCapitalization.sentences,
//                                       ),
//                                     ),
//                                     Padding(
//                                         padding: EdgeInsets.symmetric(
//                                             horizontal: 4)),
//                                     Expanded(
//                                       child: TextFormField(
//                                         controller: firstName,
//                                         validator: (value) {
//                                           if (value!.length < 1) {
//                                             return AppLocalizations.of(context)
//                                                 .translate(
//                                                     'please_enter_your_name');
//                                           } else {
//                                             return null;
//                                           }
//                                         },
//                                         style: themeData.textTheme.subtitle2!
//                                             .merge(TextStyle(
//                                                 color: themeData
//                                                     .colorScheme.onBackground)),
//                                         decoration: InputDecoration(
//                                           hintStyle: themeData
//                                               .textTheme.subtitle2!
//                                               .merge(TextStyle(
//                                                   color: themeData.colorScheme
//                                                       .onBackground)),
//                                           hintText: AppLocalizations.of(context)
//                                               .translate('first_name'),
//                                           border: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .border!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                           enabledBorder: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .enabledBorder!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                           focusedBorder: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .focusedBorder!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                         ),
//                                         textCapitalization:
//                                             TextCapitalization.sentences,
//                                       ),
//                                     )
//                                   ],
//                                 ),
//                                 Row(
//                                   mainAxisAlignment:
//                                       MainAxisAlignment.spaceBetween,
//                                   children: <Widget>[
//                                     Container(
//                                       width: MySize.screenWidth! * 0.35,
//                                       child: TextFormField(
//                                         controller: middleName,
//                                         style: themeData.textTheme.subtitle2!
//                                             .merge(TextStyle(
//                                                 color: themeData
//                                                     .colorScheme.onBackground)),
//                                         decoration: InputDecoration(
//                                           hintStyle: themeData
//                                               .textTheme.subtitle2!
//                                               .merge(TextStyle(
//                                                   color: themeData.colorScheme
//                                                       .onBackground)),
//                                           hintText: AppLocalizations.of(context)
//                                               .translate('middle_name'),
//                                           border: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .border!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                           enabledBorder: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .enabledBorder!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                           focusedBorder: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .focusedBorder!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                         ),
//                                         textCapitalization:
//                                             TextCapitalization.sentences,
//                                       ),
//                                     ),
//                                     Container(
//                                       width: MySize.screenWidth! * 0.35,
//                                       child: TextFormField(
//                                         controller: lastName,
//                                         style: themeData.textTheme.subtitle2!
//                                             .merge(TextStyle(
//                                                 color: themeData
//                                                     .colorScheme.onBackground)),
//                                         decoration: InputDecoration(
//                                           hintStyle: themeData
//                                               .textTheme.subtitle2!
//                                               .merge(TextStyle(
//                                                   color: themeData.colorScheme
//                                                       .onBackground)),
//                                           hintText: AppLocalizations.of(context)
//                                               .translate('last_name'),
//                                           border: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .border!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                           enabledBorder: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .enabledBorder!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                           focusedBorder: UnderlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: themeData
//                                                     .inputDecorationTheme
//                                                     .focusedBorder!
//                                                     .borderSide
//                                                     .color),
//                                           ),
//                                         ),
//                                         textCapitalization:
//                                             TextCapitalization.sentences,
//                                       ),
//                                     )
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                         )
//                       ],
//                     ),
//                     Container(
//                       margin: EdgeInsets.only(top: 8),
//                       child: Row(
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         children: <Widget>[
//                           Container(
//                             width: 64,
//                             child: Center(
//                               child: Icon(
//                                 MdiIcons.homeCityOutline,
//                                 color: themeData.colorScheme.onBackground,
//                               ),
//                             ),
//                           ),
//                           Expanded(
//                             flex: 1,
//                             child: Container(
//                               margin: EdgeInsets.only(left: 16),
//                               child: Column(
//                                 children: <Widget>[
//                                   TextFormField(
//                                     controller: addressLine1,
//                                     style: themeData.textTheme.subtitle2!.merge(
//                                         TextStyle(
//                                             color: themeData
//                                                 .colorScheme.onBackground)),
//                                     decoration: InputDecoration(
//                                       hintStyle: themeData.textTheme.subtitle2!
//                                           .merge(TextStyle(
//                                               color: themeData
//                                                   .colorScheme.onBackground)),
//                                       hintText: AppLocalizations.of(context)
//                                           .translate('address_line_1'),
//                                       border: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .border!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                       enabledBorder: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .enabledBorder!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                       focusedBorder: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .focusedBorder!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                     ),
//                                     textCapitalization:
//                                         TextCapitalization.sentences,
//                                   ),
//                                   TextFormField(
//                                     controller: addressLine2,
//                                     style: themeData.textTheme.subtitle2!.merge(
//                                         TextStyle(
//                                             color: themeData
//                                                 .colorScheme.onBackground)),
//                                     decoration: InputDecoration(
//                                       hintStyle: themeData.textTheme.subtitle2!
//                                           .merge(TextStyle(
//                                               color: themeData
//                                                   .colorScheme.onBackground)),
//                                       hintText: AppLocalizations.of(context)
//                                           .translate('address_line_2'),
//                                       border: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .border!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                       enabledBorder: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .enabledBorder!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                       focusedBorder: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .focusedBorder!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                     ),
//                                     textCapitalization:
//                                         TextCapitalization.sentences,
//                                   )
//                                 ],
//                               ),
//                             ),
//                           )
//                         ],
//                       ),
//                     ),
//                     Container(
//                       margin: EdgeInsets.only(top: 8),
//                       child: Row(
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         children: <Widget>[
//                           Container(
//                             width: 64,
//                             child: Center(
//                               child: Icon(
//                                 MdiIcons.phoneOutline,
//                                 color: themeData.colorScheme.onBackground,
//                               ),
//                             ),
//                           ),
//                           Expanded(
//                             flex: 1,
//                             child: Container(
//                               margin: EdgeInsets.only(left: 16),
//                               child: Column(
//                                 children: <Widget>[
//                                   TextFormField(
//                                     controller: mobile,
//                                     keyboardType: TextInputType.number,
//                                     validator: (value) {
//                                       if (value!.length < 1) {
//                                         return AppLocalizations.of(context)
//                                             .translate(
//                                                 'please_enter_your_number');
//                                       } else {
//                                         return null;
//                                       }
//                                     },
//                                     style: themeData.textTheme.subtitle2!.merge(
//                                         TextStyle(
//                                             color: themeData
//                                                 .colorScheme.onBackground)),
//                                     decoration: InputDecoration(
//                                       hintStyle: themeData.textTheme.subtitle2!
//                                           .merge(TextStyle(
//                                               color: themeData
//                                                   .colorScheme.onBackground)),
//                                       hintText: AppLocalizations.of(context)
//                                           .translate('phone'),
//                                       border: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .border!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                       enabledBorder: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .enabledBorder!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                       focusedBorder: UnderlineInputBorder(
//                                         borderSide: BorderSide(
//                                             color: themeData
//                                                 .inputDecorationTheme
//                                                 .focusedBorder!
//                                                 .borderSide
//                                                 .color),
//                                       ),
//                                     ),
//                                     textCapitalization:
//                                         TextCapitalization.sentences,
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           )
//                         ],
//                       ),
//                     ),
//                     Container(
//                       margin: EdgeInsets.only(top: 8),
//                       child: Row(
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         children: <Widget>[
//                           Container(
//                             width: 64,
//                             child: Center(
//                               child: Icon(
//                                 MdiIcons.homeCityOutline,
//                                 color: themeData.colorScheme.onBackground,
//                               ),
//                             ),
//                           ),
//                           Expanded(
//                             flex: 1,
//                             child: Container(
//                               margin: EdgeInsets.only(left: 16),
//                               child: Column(
//                                 children: <Widget>[
//                                   Row(
//                                     mainAxisAlignment:
//                                         MainAxisAlignment.spaceBetween,
//                                     children: <Widget>[
//                                       Container(
//                                         width: MySize.screenWidth! * 0.35,
//                                         child: TextFormField(
//                                           controller: city,
//                                           style: themeData.textTheme.subtitle2!
//                                               .merge(TextStyle(
//                                                   color: themeData.colorScheme
//                                                       .onBackground)),
//                                           decoration: InputDecoration(
//                                             hintStyle: themeData
//                                                 .textTheme.subtitle2!
//                                                 .merge(TextStyle(
//                                                     color: themeData.colorScheme
//                                                         .onBackground)),
//                                             hintText:
//                                                 AppLocalizations.of(context)
//                                                     .translate('city'),
//                                             border: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .border!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                             enabledBorder: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .enabledBorder!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                             focusedBorder: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .focusedBorder!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                           ),
//                                           textCapitalization:
//                                               TextCapitalization.sentences,
//                                         ),
//                                       ),
//                                       Container(
//                                         width: MySize.screenWidth! * 0.35,
//                                         child: TextFormField(
//                                           controller: state,
//                                           style: themeData.textTheme.subtitle2!
//                                               .merge(TextStyle(
//                                                   color: themeData.colorScheme
//                                                       .onBackground)),
//                                           decoration: InputDecoration(
//                                             hintStyle: themeData
//                                                 .textTheme.subtitle2!
//                                                 .merge(TextStyle(
//                                                     color: themeData.colorScheme
//                                                         .onBackground)),
//                                             hintText:
//                                                 AppLocalizations.of(context)
//                                                     .translate('state'),
//                                             border: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .border!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                             enabledBorder: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .enabledBorder!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                             focusedBorder: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .focusedBorder!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                           ),
//                                           textCapitalization:
//                                               TextCapitalization.sentences,
//                                         ),
//                                       )
//                                     ],
//                                   ),
//                                   Row(
//                                     mainAxisAlignment:
//                                         MainAxisAlignment.spaceBetween,
//                                     children: <Widget>[
//                                       Container(
//                                         width: MySize.screenWidth! * 0.35,
//                                         child: TextFormField(
//                                           controller: country,
//                                           style: themeData.textTheme.subtitle2!
//                                               .merge(TextStyle(
//                                                   color: themeData.colorScheme
//                                                       .onBackground)),
//                                           decoration: InputDecoration(
//                                             hintStyle: themeData
//                                                 .textTheme.subtitle2!
//                                                 .merge(TextStyle(
//                                                     color: themeData.colorScheme
//                                                         .onBackground)),
//                                             hintText:
//                                                 AppLocalizations.of(context)
//                                                     .translate('country'),
//                                             border: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .border!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                             enabledBorder: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .enabledBorder!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                             focusedBorder: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .focusedBorder!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                           ),
//                                           textCapitalization:
//                                               TextCapitalization.sentences,
//                                         ),
//                                       ),
//                                       Container(
//                                         width: MySize.screenWidth! * 0.35,
//                                         child: TextFormField(
//                                           controller: zip,
//                                           keyboardType: TextInputType.number,
//                                           style: themeData.textTheme.subtitle2!
//                                               .merge(TextStyle(
//                                                   color: themeData.colorScheme
//                                                       .onBackground)),
//                                           decoration: InputDecoration(
//                                             hintStyle: themeData
//                                                 .textTheme.subtitle2!
//                                                 .merge(TextStyle(
//                                                     color: themeData.colorScheme
//                                                         .onBackground)),
//                                             hintText:
//                                                 AppLocalizations.of(context)
//                                                     .translate('zip_code'),
//                                             border: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .border!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                             enabledBorder: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .enabledBorder!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                             focusedBorder: UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: themeData
//                                                       .inputDecorationTheme
//                                                       .focusedBorder!
//                                                       .borderSide
//                                                       .color),
//                                             ),
//                                           ),
//                                           textCapitalization:
//                                               TextCapitalization.sentences,
//                                         ),
//                                       )
//                                     ],
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           )
//                         ],
//                       ),
//                     ),
//                     Container(
//                       margin: EdgeInsets.only(top: 16),
//                       child: TextButton(
//                         style: TextButton.styleFrom(
//                           shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(4)),
//                           padding:
//                               EdgeInsets.symmetric(vertical: 8, horizontal: 48),
//                           backgroundColor: themeData.colorScheme.primary,
//                         ),
//                         onPressed: () async {
//                           if (await Helper().checkConnectivity()) {
//                             if (_formKey.currentState!.validate()) {
//                               Map newCustomer = {
//                                 'type': 'customer',
//                                 'prefix': prefix.text,
//                                 'first_name': firstName.text,
//                                 'middle_name': middleName.text,
//                                 'last_name': lastName.text,
//                                 'mobile': mobile.text,
//                                 'address_line_1': addressLine1.text,
//                                 'address_line_2': addressLine2.text,
//                                 'city': city.text,
//                                 'state': state.text,
//                                 'country': country.text,
//                                 'zip_code': zip.text
//                               };
//                               await CustomerApi()
//                                   .add(newCustomer)
//                                   .then((value) {
//                                 if (value['data'] != null) {
//                                   Contact()
//                                       .insertContact(
//                                           Contact().contactModel(value['data']))
//                                       .then((value) {
//                                     selectCustomer();
//                                     selectedCustomer = customerListMap[0];
//                                     Navigator.pop(context);
//                                     _formKey.currentState!.reset();
//                                   });
//                                 }
//                               });
//                             }
//                           } else {
//                             Fluttertoast.showToast(
//                                 msg: AppLocalizations.of(context)
//                                     .translate('check_connectivity'));
//                           }
//                         },
//                         child: Text(
//                             AppLocalizations.of(context)
//                                 .translate('add_to_contact')
//                                 .toUpperCase(),
//                             style: AppTheme.getTextStyle(
//                                 themeData.textTheme.bodyText1,
//                                 color: themeData.colorScheme.onPrimary,
//                                 letterSpacing: 0.3)),
//                       ),
//                     ),
//                   ],
//                 ),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   //dropdown widget for selecting customer
//   Widget customerList() {
//     return SearchChoices.single(
//       underline: Visibility(
//         child: Container(),
//         visible: false,
//       ),
//       displayClearIcon: false,
//       value: jsonEncode(selectedCustomer),
//       items: customerListMap.map<DropdownMenuItem<String>>((Map value) {
//         return DropdownMenuItem<String>(
//             value: jsonEncode(value),
//             child: Container(
//               width: MySize.screenWidth! * 0.8,
//               child: Text("${value['name']} (${value['mobile'] ?? ' - '})",
//                   softWrap: true,
//                   maxLines: 5,
//                   overflow: TextOverflow.ellipsis,
//                   style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
//                       color: themeData.colorScheme.onBackground)),
//             ));
//       }).toList(),
//       iconEnabledColor: Colors.blue,
//       iconDisabledColor: Colors.black,
//       onChanged: (newValue) {
//         setState(() {
//           selectedCustomer = jsonDecode(newValue);
//         });
//       },
//       isExpanded: true,
//     );
//   }
//
//   selectCustomer() async {
//     customerListMap = [
//       {'id': 0, 'name': 'select customer', 'mobile': ' - '}
//     ];
//     List customers = await Contact().get();
//
//     customers.forEach((value) {
//       setState(() {
//         customerListMap.add({
//           'id': value['id'],
//           'name': value['name'],
//           'mobile': value['mobile']
//         });
//       });
//       if (value['name'] == 'Walk-In Customer') {
//         selectedCustomer = {
//           'id': value['id'],
//           'name': value['name'],
//           'mobile': value['mobile']
//         };
//       }
//     });
//   }
// }
import 'dart:convert';

import 'package:dev/pages/sales.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:search_choices/search_choices.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../apis/contact.dart';
import '../helpers/AppTheme.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/otherHelpers.dart';
import '../helpers/style.dart' as style;
import '../locale/MyLocalizations.dart';
import '../models/contact_model.dart';
import '../models/paymentDatabase.dart';
import '../models/sell.dart';
import '../models/sellDatabase.dart';
import '../helpers/TableAvailabilityManager.dart';
import 'Tables.dart';
import 'event_bus.dart';
import 'elements.dart';
import 'login.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

class Customer extends StatefulWidget {
  @override
  _CustomerState createState() => _CustomerState();
}

class _CustomerState extends State<Customer> {
  String? _tableName;
  bool _isShipping = false;
  bool _isAddingContact = false;

  Map? argument;
  final _formKey = GlobalKey<FormState>();

  String transactionDate =
  DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now());
  List<Map<String, dynamic>> customerListMap = [];
  Map<String, dynamic> selectedCustomer = {
    'id': 0,
    'name': 'select customer',
    'mobile': ' - '
  };
  TextEditingController prefix = new TextEditingController(),
      firstName = new TextEditingController(),
      middleName = new TextEditingController(),
      lastName = new TextEditingController(),
      mobile = new TextEditingController(),
      addressLine1 = new TextEditingController(),
      addressLine2 = new TextEditingController(),
      city = new TextEditingController(),
      state = new TextEditingController(),
      country = new TextEditingController(),
      zip = new TextEditingController();

  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
  CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);

  @override
  void initState() {
    super.initState();
    selectCustomer();

    AppConstants.cartData.clear(); //new add
  }

  @override
  void didChangeDependencies() {
    argument = ModalRoute.of(context)!.settings.arguments as Map?;

    // Capture table/shipping info
    _tableName = argument?['tableName'];
    _isShipping = argument?['is_shipping'] == 1;

    // Table/shipping will be marked unavailable only when user confirms with "yes"
    // _markTableOrShippingUnavailable();

    if (argument!['customerId'] != null) {
      Future.delayed(Duration(milliseconds: 400), () async {
        await Contact()
            .getCustomerDetailById(argument!['customerId'])
            .then((value) {
          if (this.mounted) {
            setState(() {
              selectedCustomer = {
                'id': argument!['customerId'],
                'name': value['name'],
                'mobile': value['mobile']
              };
            });
          }
        });
      });
    }
    super.didChangeDependencies();
  }

  /// Mark table or shipping as unavailable when customer screen is reached
  Future<void> _markTableOrShippingUnavailable() async {
    if (argument == null) return;

    final availabilityManager = TableAvailabilityManager();

    if (argument!['is_shipping'] == 1) {
      // This is a shipping order - mark shipping as unavailable
      await availabilityManager.markShippingUnavailable();
      debugPrint('Customer screen: Marked shipping as unavailable');

      // Fire event to notify Tables screen
      EventBus().fire(TableAvailabilityChangedEvent(
        isShipping: true,
        isAvailable: false,
      ));
    } else if (argument!['res_table_id'] != null &&
        argument!['res_table_id'] > 0) {
      // This is a table order - mark table as unavailable
      await availabilityManager.markTableUnavailable(argument!['res_table_id']);
      debugPrint(
          'Customer screen: Marked table ${argument!['res_table_id']} as unavailable');

      // Fire event to notify Tables screen
      EventBus().fire(TableAvailabilityChangedEvent(
        tableId: argument!['res_table_id'],
        isShipping: false,
        isAvailable: false,
      ));
    }
  }

  /// Restore table or shipping availability when navigating back from customer screen
  void _restoreTableOrShippingAvailability() {
    if (argument == null) return;

    final availabilityManager = TableAvailabilityManager();

    if (argument!['is_shipping'] == 1) {
      // This is a shipping order - mark shipping as available
      availabilityManager.markShippingAvailable();
      debugPrint(
          'Customer screen: Marked shipping as available (navigating back)');

      // Fire event to notify Tables screen
      EventBus().fire(TableAvailabilityChangedEvent(
        isShipping: true,
        isAvailable: true,
      ));
    } else if (argument!['res_table_id'] != null &&
        argument!['res_table_id'] > 0) {
      // This is a table order - mark table as available
      availabilityManager.markTableAvailable(argument!['res_table_id']);
      debugPrint(
          'Customer screen: Marked table ${argument!['res_table_id']} as available (navigating back)');

      // Fire event to notify Tables screen
      EventBus().fire(TableAvailabilityChangedEvent(
        tableId: argument!['res_table_id'],
        isShipping: false,
        isAvailable: true,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    print("::::${AppConstants.cartData}");
    return WillPopScope(
      onWillPop: () async {
        // Restore table/shipping availability when navigating back
        _restoreTableOrShippingAvailability();

        // Note: Removed automatic draft cleanup here as it was deleting active cart items
        // when users navigate back to modify their order. Cleanup should only happen
        // when orders are truly abandoned, not during normal navigation flow.

        return true;
      },
      child: SafeArea(
        top: false,
        bottom: true,
        child: Scaffold(
            appBar: AppBar(
              elevation: 0,
              title: Text(AppLocalizations.of(context).translate('customer'),
                  style: AppTheme.getTextStyle(themeData.textTheme.headline6,
                      fontWeight: 600)),
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () {
                Navigator.of(context).push(new MaterialPageRoute<Null>(
                    builder: (BuildContext context) {
                      return newCustomer();
                    },
                    fullscreenDialog: true));
              },
              child: Icon(MdiIcons.accountPlus),
              elevation: 2,
            ),
            body: Column(
              children: [
                // Table/Shipping indicator
                if (_tableName != null || _isShipping)
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    color: themeData.primaryColor.withOpacity(0.1),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _isShipping
                              ? Icons.local_shipping
                              : Icons.table_restaurant,
                          color: themeData.primaryColor,
                        ),
                        SizedBox(width: 8),
                        Text(
                          _isShipping
                              ? (AppLocalizations.of(context)
                              .translate('shipping_order') ??
                              'Shipping Order')
                              : '$_tableName',
                          style: TextStyle(
                            color: themeData.primaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),

                // Scrollable content area
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(
                              top: MySize.size120!,
                              left: MySize.size20!,
                              right: MySize.size20!),
                          child: Card(
                              color: Colors.grey.shade300,
                              child: customerList()),
                        ),
                        Center(
                          child: Visibility(
                            visible: (selectedCustomer['id'] == 0),
                            child: Text(
                                AppLocalizations.of(context).translate(
                                    'please_select_a_customer_for_checkout_option'),
                                style: TextStyle(color: Colors.red)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            bottomNavigationBar: Visibility(
              visible: (selectedCustomer['id'] != 0),
              child: Row(
                // mainAxisAlignment: (argument!['is_quotation'] == null)
                //     ? MainAxisAlignment.spaceAround
                //     : MainAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Visibility(
                    //   visible: argument!['is_quotation'] == null,
                    //   child: TextButton(
                    //     onPressed: (addQuotation),
                    //     style: TextButton.styleFrom(
                    //         primary: Colors.black,
                    //         backgroundColor: style.StyleColors().mainColor(1),
                    //         shape: RoundedRectangleBorder(
                    //           borderRadius: BorderRadius.circular(40.0),
                    //         )),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //       children: [
                    //         Icon(
                    //           Icons.add,
                    //           color: Theme.of(context).colorScheme.surface,
                    //         ),
                    //         Text(
                    //           AppLocalizations.of(context).translate('add_quotation'),
                    //           style: AppTheme.getTextStyle(
                    //               Theme.of(context).textTheme.bodyText1,
                    //               color: Theme.of(context).colorScheme.surface),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    // Show only "Add Quotation" button if it's a quotation flow
                    if (argument?['isQuotationFlow'] == true)
                      ElevatedButton(
                        onPressed: addQuotation,
                        style: ElevatedButton.styleFrom(
                          primary: themeData.colorScheme.primary,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40.0)),
                          minimumSize: Size(150, 40),
                          padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        ),
                        child: Text(
                          AppLocalizations.of(context)
                              .translate('add_quotation'),
                          style: AppTheme.getTextStyle(
                            Theme.of(context).textTheme.bodyText1,
                            color: Theme.of(context).colorScheme.surface,
                            fontWeight: 600,
                          ),
                        ),
                      ),

                    // Show normal buttons if it's not a quotation flow
                    if (argument?['isQuotationFlow'] != true) ...[
                      // Draft button (no action)
                      ElevatedButton(
                        onPressed: () =>
                            showDraftDialog(), // Call the dialog function
                        style: ElevatedButton.styleFrom(
                          primary: Colors.grey,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40.0)),
                          minimumSize: Size(150, 40),
                          padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        ),
                        child: Text(
                          AppLocalizations.of(context).translate('send_order'),
                          style: AppTheme.getTextStyle(
                            Theme.of(context).textTheme.bodyText1,
                            color: Theme.of(context).colorScheme.surface,
                            fontWeight: 600,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      FutureBuilder<List<Map>>(
                        future: Sell().getCartItems(argument!['sellId'],
                            argument!['res_table_id']), // Fetch cart items
                        builder: (context, snapshot) {
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return CircularProgressIndicator();
                          } else if (snapshot.hasError) {
                            Fluttertoast.showToast(
                                msg: AppLocalizations.of(context)
                                    .translate('error_fetching_cart'));
                            return Container();
                          } else {
                            List<Map> cartItems = snapshot.data ?? [];
                            debugPrint(
                                'Customer: Navigating to checkout with invoiceAmount: ${argument!['invoiceAmount']}, cartItems: $cartItems');
                            return cartBottomBar(
                                '/checkout',
                                AppLocalizations.of(context)
                                    .translate('pay_&_checkout'),
                                context,
                                Helper().argument(
                                  locId: argument!['locationId'],
                                  taxId: argument!['taxId'],
                                  discountType: argument!['discountType'],
                                  discountAmount: argument!['discountAmount'],
                                  invoiceAmount: argument!['invoiceAmount'],
                                  customerId: selectedCustomer['id'],
                                  sellId: argument!['sellId'],
                                  products: cartItems,
                                  res_table_id: argument?['res_table_id'],
                                  is_shipping: argument?['is_shipping'],
                                  isShipping: (argument?['is_shipping'] ?? 0) ==
                                      1, // Add isShipping flag
                                  tableName:
                                  _tableName, // Pass table name forward
                                  clearFields: true, // Add flag to clear fields
                                )); // Pass cart items
                          }
                        },
                      ),
                    ],
                  ]),
            )),
      ),
    );
  }

  // Show draft options dialog
// Show draft confirmation dialog
  void showDraftDialog() {
    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: customAppTheme.bgLayer1,
          title: Text(
            AppLocalizations.of(context).translate('be_send_order'),
            style: AppTheme.getTextStyle(
              themeData.textTheme.headline6,
              color: Colors.black,
              fontWeight: 700,
            ),
          ),
          content: Text(
            AppLocalizations.of(context)
                .translate('are_you_sure_to_send_this_order'),
            style: AppTheme.getTextStyle(
              themeData.textTheme.subtitle1,
              color: Colors.black,
            ),
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: themeData.colorScheme.primary,
              ),
              onPressed: () async {
                Navigator.of(context).pop(); // Close the dialog

                // Show instant loading indicator
                // showDialog(
                //   context: context,
                //   barrierDismissible: false,
                //   builder: (BuildContext context) {
                //     return AlertDialog(
                //       content: Row(
                //         children: [
                //           CircularProgressIndicator(),
                //           Container(
                //             margin: EdgeInsets.only(left: 5),
                //             child: Text(AppLocalizations.of(context)
                //                 .translate('loading')),
                //           ),
                //         ],
                //       ),
                //     );
                //   },
                // );

                // Mark table/shipping as unavailable when user confirms with "yes"
                await _markTableOrShippingUnavailable();

                await saveDraft(shouldPrint: false); // Save without printing
              },
              child: Text(AppLocalizations.of(context).translate('yes')),
            ),
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: themeData.colorScheme.primary,
                ),
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text(AppLocalizations.of(context).translate('no'))),
          ],
        );
      },
    );
  }

  // Save draft with optional printing
  Future<void> saveDraft({required bool shouldPrint}) async {
    try {
      // Get cart items before creating the sell
      List<Map> cartItems = await Sell()
          .getCartItems(argument!['sellId'], argument!['res_table_id']);

      // Create a new mutable map for the sale data
      final Map<String, dynamic> sellData = {
        'changeReturn': 0.00,
        'transactionDate': transactionDate,
        'pending': argument?['invoiceAmount'] ?? 0.0,
        'shippingCharges': 0.00,
        'shippingDetails': '',
        'invoiceNo': '${USERID}_${DateFormat('yMdHm').format(DateTime.now())}',
        'contactId': selectedCustomer['id'],
        'discountAmount': argument?['discountAmount'] ?? 0.0,
        'discountType': argument?['discountType'] ?? 'fixed',
        'invoiceAmount': argument?['invoiceAmount'] ?? 0.0,
        'locId': argument?['locationId'],
        'saleStatus': 'draft',
        'sellId': argument?['sellId'],
        'taxId': argument?['taxId'],
        'tip_amount': 0.00,
        'isQuotation': 0,
        'res_table_id': argument?['res_table_id'],
      };

      // Create the sale using Sell class
      final Map<String, dynamic> sell = await Sell().createSell(
        changeReturn: sellData['changeReturn'],
        transactionDate: sellData['transactionDate'],
        pending: sellData['pending'],
        shippingCharges: sellData['shippingCharges'],
        shippingDetails: sellData['shippingDetails'],
        invoiceNo: sellData['invoiceNo'],
        contactId: sellData['contactId'],
        discountAmount: sellData['discountAmount'],
        discountType: sellData['discountType'],
        invoiceAmount: sellData['invoiceAmount'],
        locId: sellData['locId'],
        saleStatus: sellData['saleStatus'],
        sellId: sellData['sellId'],
        taxId: sellData['taxId'],
        tip_amount: sellData['tip_amount'],
        isQuotation: sellData['isQuotation'],
        res_table_id: sellData['res_table_id'],
        is_shipping: argument?['is_shipping'] ?? 0,
      );

      // Save to database
      int? newSellId;
      if (argument?['sellId'] != null) {
        // CRITICAL FIX: Preserve the original invoice_no when updating an existing sell
        var existingSaleData =
        await SellDatabase().getSellBySellId(argument!['sellId']);
        if (existingSaleData.isNotEmpty &&
            existingSaleData[0]['invoice_no'] != null) {
          sell['invoice_no'] = existingSaleData[0]['invoice_no'];
          debugPrint(
              'saveDraft: Preserved original invoice_no - ${sell['invoice_no']}');
        }
        await SellDatabase().updateSells(argument!['sellId'], sell);
        newSellId = argument!['sellId'];
      } else {
        newSellId = await SellDatabase().storeSell(sell);
        await SellDatabase().updateSellLine(
          {'sell_id': newSellId, 'is_completed': 1},
          resTableId: argument?['res_table_id'],
        );
      }

      // Update invoice amount based on current cart items
      // This ensures the Sales Screen shows the correct amount after saving
      await Sell()
          .updateInvoiceAmountFromCart(newSellId, argument?['res_table_id']);

      // Save cart data to SharedPreferences
      if (newSellId != null) {
        Map<String, dynamic> cartData = {
          'cartItems': cartItems,
          'discountType': argument?['discountType'] ?? 'fixed',
          'discountAmount': argument?['discountAmount'] ?? 0.0,
          'taxId': argument?['taxId'],
          'invoiceAmount': argument?['invoiceAmount'] ?? 0.0,
          'res_table_id': argument?['res_table_id'],
          'is_shipping': argument?['is_shipping'],
          'tableName': argument?['tableName'],
        };

        await Helper.saveCartData(newSellId, cartData);
      }

      // Sync with API if online (mirror checkout payload)
      if (await Helper().checkConnectivity()) {
        try {
          debugPrint('saveDraft: Starting API sync for sellId: $newSellId');

          // Build products for payload from cartItems
          List<Map> products = cartItems.map((item) {
            return {
              'product_id': item['product_id'],
              'variation_id': item['variation_id'],
              'quantity': item['quantity'],
              'unit_price': item['unit_price'],
              'tax_rate_id': item['tax_rate_id'],
              'discount_amount': item['discount_amount'] ?? 0.0,
              'discount_type': item['discount_type'] ?? 'fixed',
              'note': item['note'] ?? '',
              'product_order_category': item['product_order_category'] ?? 'BAR',
              'res_table_id': argument?['res_table_id'],
              'is_shipping': argument?['is_shipping'] ?? 0,
            };
          }).toList();

          debugPrint('saveDraft: Prepared ${products.length} products for API');

          // Draft: no payments
          List<Map> updatedPayments = [];

          Map<String, dynamic> sellPayload = {
            'sells': [
              {
                'location_id': sellData['locId'],
                'contact_id': sellData['contactId'],
                'transaction_date': sellData['transactionDate'],
                'invoice_no': sellData['invoiceNo'],
                'status': 'draft',
                'sub_status': sellData['isQuotation'] == 1 ? 'quotation' : null,
                'tax_rate_id':
                sellData['taxId'] == 0 ? null : sellData['taxId'],
                'discount_amount': sellData['discountAmount'] ?? 0.0,
                'discount_type': sellData['discountType'] ?? 'fixed',
                'change_return': sellData['changeReturn'],
                'products': products,
                'sale_note': null,
                'staff_note': null,
                'shipping_charges': sellData['shippingCharges'],
                'shipping_details': sellData['shippingDetails'],
                'tip_amount': sellData['tip_amount'].toString(),
                'tip_type': sellData['tip_type'] ?? 'fixed',
                'is_quotation': sellData['isQuotation'],
                'payments': updatedPayments,
                'res_table_id': sellData['res_table_id'],
                'is_shipping': argument?['is_shipping'] ?? 0,
              }
            ]
          };

          debugPrint('saveDraft: Calling createApiSell with sellId: $newSellId');
          var apiResult = await Sell().createApiSell(
              sellId: newSellId,
              payload: sellPayload,
              isDraft: true,
              isQuotation: sellData['isQuotation'] == 1);

          if (apiResult != null && apiResult.containsKey('error')) {
            debugPrint('saveDraft: API sync failed: ${apiResult['error']}');
            Fluttertoast.showToast(
              msg: 'API sync failed: ${apiResult['error']}',
              toastLength: Toast.LENGTH_LONG,
            );
          } else {
            debugPrint('saveDraft: API sync successful');
          }
        } catch (e, stackTrace) {
          debugPrint('saveDraft: API sync error: $e');
          debugPrint('saveDraft: Stack trace: $stackTrace');
          Fluttertoast.showToast(
            msg: 'API sync error: $e',
            toastLength: Toast.LENGTH_LONG,
          );
        }
      } else {
        debugPrint('saveDraft: No connectivity, skipping API sync');
      }

      // Print if requested
      if (shouldPrint && newSellId != null) {
        await printWithPermissions(newSellId, argument?['taxId'], context);
      }

      // Reset cart for the specific res_table_id or shipping
      if (argument!['is_shipping'] == 1) {
        AppConstants.cartData['shipping'] = null;
        await AppConstants.setData(0); // Update shared preferences
        await SellDatabase().resetCartForTable(0); // Pass null for shipping
        debugPrint('onSubmit: Cart reset for shipping (res_table_id=0)');

        // Remove only the shipping cart from prefs
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove('cart_${argument!['locationId']}_0');
      } else if (argument!['res_table_id'] != null) {
        AppConstants.cartData[argument!['res_table_id'].toString()] = null;
        await AppConstants.setData(argument!['res_table_id']);
        await SellDatabase().resetCartForTable(argument!['res_table_id']);

        // Remove only the shipping cart from prefs
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove('cart_${argument!['locationId']}_0');
        await prefs.remove(
            'cart_${argument!['locationId']}_${argument!['res_table_id']}');
        debugPrint(
            'onSubmit: Cart reset for res_table_id=${argument!['res_table_id']}');
      }

      // Show loading indicator
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Row(
              children: [
                CircularProgressIndicator(),
                Container(
                  margin: EdgeInsets.only(left: 5),
                  child:
                  Text(AppLocalizations.of(context).translate('loading')),
                ),
              ],
            ),
          );
        },
      );

      // Add a small delay to ensure the dialog is visible
      await Future.delayed(Duration(milliseconds: 500));

      // Navigate back (dialog will be closed automatically)
      // For draft orders, navigate back to sales screen while preserving the navigation flow
      Navigator.of(context)
          .pushNamedAndRemoveUntil('/sale', (Route<dynamic> route) => false,
          // arguments: _getSalesScreenArguments()

          arguments: Helper().argument(
            locId: argument!['locationId'],
            taxId: argument!['taxId'],
            discountType: argument!['discountType'],
            discountAmount: argument!['discountAmount'],
            invoiceAmount: argument!['invoiceAmount'],
            customerId: selectedCustomer['id'],
            sellId: argument!['sellId'],
            products: cartItems,
            res_table_id: argument?['res_table_id'],
            is_shipping: argument?['is_shipping'],
            isShipping: (argument?['is_shipping'] ?? 0) == 1,
            tableName: _tableName,
            clearFields: true,
            // Add any additional parameters that Sales screen might need
            fromCustomerScreen:
            true, // Optional: flag to indicate navigation source
          ));

      // In saveDraft method, after successful save:
      EventBus().fire(DraftSavedEvent());

      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('saved_successfully'),
      );

      // After successful save, fire the appropriate event
      if (argument?['isQuotationFlow'] == true) {
        EventBus()
            .fire(QuotationFinalizedEvent(argument!['invoiceAmount'] ?? 0.0));
      } else {
        EventBus().fire(DraftFinalizedEvent(argument!['invoiceAmount'] ?? 0.0));
      }
    } catch (e, stackTrace) {
      debugPrint('Error saving draft: $e');
      debugPrint('Stack trace: $stackTrace');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_saving'),
      );
    }
  }

  // //add quotation
  // addQuotation() async {
  //   debugPrint(
  //       'addQuotation: Starting for sellId=${argument!['sellId']}, res_table_id=${argument!['res_table_id']}');
  //   Map sell = await Sell().createSell(
  //     changeReturn: 0.00,
  //     transactionDate: transactionDate,
  //     pending: argument!['invoiceAmount'],
  //     shippingCharges: 0.00,
  //     shippingDetails: '',
  //     invoiceNo:
  //         USERID.toString() + "_" + DateFormat('yMdHm').format(DateTime.now()),
  //     contactId: selectedCustomer['id'],
  //     discountAmount: argument!['discountAmount'],
  //     discountType: argument!['discountType'],
  //     invoiceAmount: argument!['invoiceAmount'],
  //     locId: argument!['locationId'],
  //     saleStatus: 'draft',
  //     sellId: argument!['sellId'],
  //     taxId: argument!['taxId'],
  //     tip_amount: 0.00,
  //     isQuotation: 1,
  //     res_table_id: argument!['res_table_id'],
  //   );
  //   debugPrint('addQuotation: Created sell map: ${jsonEncode(sell)}');
  //   confirmDialog(sell);
  // }

  addQuotation() async {
    debugPrint(
        'addQuotation: Starting for sellId=${argument!['sellId']}, res_table_id=${argument!['res_table_id']}');

    // Get cart items before creating the sell
    List<Map> cartItems = await Sell()
        .getCartItems(argument!['sellId'], argument!['res_table_id']);

    Map sell = await Sell().createSell(
      changeReturn: 0.00,
      transactionDate: transactionDate,
      pending: argument!['invoiceAmount'],
      shippingCharges: 0.00,
      shippingDetails: '',
      invoiceNo:
      USERID.toString() + "_" + DateFormat('yMdHm').format(DateTime.now()),
      contactId: selectedCustomer['id'],
      discountAmount: argument!['discountAmount'],
      discountType: argument!['discountType'],
      invoiceAmount: argument!['invoiceAmount'],
      locId: argument!['locationId'],
      saleStatus: 'draft',
      sellId: argument!['sellId'],
      taxId: argument!['taxId'],
      tip_amount: 0.00,
      isQuotation: 1,
      res_table_id: argument!['res_table_id'],
      is_shipping: argument!['is_shipping'] ?? 0,
    );

    // Save cart data to SharedPreferences
    if (argument!['sellId'] != null) {
      Map<String, dynamic> cartData = {
        'cartItems': cartItems,
        'discountType': argument!['discountType'],
        'discountAmount': argument!['discountAmount'],
        'taxId': argument!['taxId'],
        'invoiceAmount': argument!['invoiceAmount'],
        'res_table_id': argument!['res_table_id'],
        'is_shipping': argument!['is_shipping'],
        'tableName': argument!['tableName'],
      };

      await Helper.saveCartData(argument!['sellId'], cartData);
    }

    debugPrint('addQuotation: Created sell map: ${jsonEncode(sell)}');
    confirmDialog(sell);
  }

  // Apply pending discount changes when user confirms in customer screen
  Future<void> applyPendingDiscountChangesForCustomerConfirmation(
      int sellId, int? resTableId) async {
    try {
      debugPrint(
          'applyPendingDiscountChangesForCustomerConfirmation: Applying discount changes for sellId=$sellId');

      // Get saved cart data that contains the pending discount changes
      Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId);
      if (savedCartData == null) {
        debugPrint(
            'applyPendingDiscountChangesForCustomerConfirmation: No saved cart data found');
        return;
      }

      // Apply cart-level discount changes to the sell record
      double finalTotal = argument!['invoiceAmount']?.toDouble() ?? 0.0;
      await SellDatabase().updateSells(sellId, {
        'discount_amount': savedCartData['discountAmount'] ?? 0.0,
        'discount_type': savedCartData['discountType'] ?? 'fixed',
        'invoice_amount': finalTotal,
        'pending_amount': finalTotal,
      });

      debugPrint(
          'applyPendingDiscountChangesForCustomerConfirmation: Applied cart-level discount - amount=${savedCartData['discountAmount']}, type=${savedCartData['discountType']}');

      // Apply product-level discount changes
      List<Map> cartItems = savedCartData['cartItems'] ?? [];
      for (var item in cartItems) {
        if (item['id'] != null) {
          double discountAmount = item['discount_amount']?.toDouble() ?? 0.0;
          String discountType = item['discount_type'] ?? 'fixed';

          await SellDatabase().update(item['id'], {
            'discount_amount': discountAmount,
            'discount_type': discountType,
          });

          debugPrint(
              'applyPendingDiscountChangesForCustomerConfirmation: Applied product discount for item ${item['id']} - amount=$discountAmount, type=$discountType');
        }
      }

      debugPrint(
          'applyPendingDiscountChangesForCustomerConfirmation: All discount changes applied successfully');
    } catch (e) {
      debugPrint(
          'applyPendingDiscountChangesForCustomerConfirmation: Error applying discount changes: $e');
    }
  }

  //confirmation dialogBox
  confirmDialog(sell) {
    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: customAppTheme.bgLayer1,
          title: Text(AppLocalizations.of(context).translate('quotation'),
              style: AppTheme.getTextStyle(themeData.textTheme.headline6,
                  color: themeData.colorScheme.onBackground, fontWeight: 700)),
          content: Text(
            AppLocalizations.of(context)
                .translate('are_you_sure_to_send_this_order_for_quotation'),
            style: AppTheme.getTextStyle(
              themeData.textTheme.subtitle1,
              color: Colors.black,
            ),
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: themeData.colorScheme.primary,
              ),
              onPressed: () async {
                if (argument!['res_table_id'] == null) {
                  Fluttertoast.showToast(
                    msg: AppLocalizations.of(context)
                        .translate('invalid_table_id') ??
                        'Table ID is required',
                    toastLength: Toast.LENGTH_LONG,
                  );
                  return;
                }

                // Show instant loading indicator
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      content: Row(
                        children: [
                          CircularProgressIndicator(),
                          Container(
                            margin: EdgeInsets.only(left: 5),
                            child: Text(AppLocalizations.of(context)
                                .translate('loading')),
                          ),
                        ],
                      ),
                    );
                  },
                );

                // Get cart items before creating the sell
                List<Map> cartItems = await Sell().getCartItems(
                    argument!['sellId'], argument!['res_table_id']);

                try {
                  int? effectiveSellId;
                  if (argument!['sellId'] != null) {
                    // Apply pending discount changes before updating the sell record
                    await applyPendingDiscountChangesForCustomerConfirmation(
                        argument!['sellId'], argument!['res_table_id']);

                    // CRITICAL FIX: Preserve the original invoice_no when updating an existing sell
                    var existingSaleData = await SellDatabase()
                        .getSellBySellId(argument!['sellId']);
                    if (existingSaleData.isNotEmpty &&
                        existingSaleData[0]['invoice_no'] != null) {
                      sell['invoice_no'] = existingSaleData[0]['invoice_no'];
                      debugPrint(
                          'confirmDialog: Preserved original invoice_no - ${sell['invoice_no']}');
                    }

                    await SellDatabase().updateSells(argument!['sellId'], sell);
                    effectiveSellId = argument!['sellId'];

                    // Mark all incomplete sell lines as completed for existing sales
                    await SellDatabase().updateSellLine(
                      {'is_completed': 1},
                      sellId: argument!['sellId'],
                      resTableId: argument!['res_table_id'],
                    );
                  } else {
                    int? newSellId = await SellDatabase().storeSell(sell);
                    effectiveSellId = newSellId;
                    await SellDatabase().updateSellLine(
                      {'sell_id': newSellId, 'is_completed': 1},
                      resTableId: argument!['res_table_id'],
                    );
                  }

                  // Update invoice amount based on current cart items
                  // This ensures the Sales Screen shows the correct amount after saving
                  await Sell().updateInvoiceAmountFromCart(
                      effectiveSellId, argument!['res_table_id']);

                  // Ensure a payment line exists for the quotation before sync
                  // if (effectiveSellId != null) {
                  //   List<Map<String, dynamic>> payments = [
                  //     {
                  //       'method': 'cash',
                  //       'amount': argument!['invoiceAmount'] ?? 0.0,
                  //       'note': 'Quotation payment',
                  //       'account_id': null,
                  //       'received_amount': argument!['invoiceAmount'] ?? 0.0,
                  //       'change_return': 0.0,
                  //       'card_details': null,
                  //     }
                  //   ];
                  //   await Sell().makePayment(payments, effectiveSellId, argument!['res_table_id']);
                  // }

                  /// Quotations should not have payment lines - they are just estimates
                  List<Map<String, dynamic>> paymentLines = [];

                  if (await Helper().checkConnectivity()) {
                    try {
                      debugPrint('addQuotation: Starting API sync for sellId: $effectiveSellId');

                      // Build products from current cart for payload
                      List<Map> cartItemsForPayload = await Sell().getCartItems(
                          effectiveSellId, argument!['res_table_id']);
                      debugPrint('addQuotation: Retrieved ${cartItemsForPayload.length} cart items for API');

                      List<Map> products = cartItemsForPayload.map((item) {
                        return {
                          'product_id': item['product_id'],
                          'variation_id': item['variation_id'],
                          'quantity': item['quantity'],
                          'unit_price': item['unit_price'],
                          'tax_rate_id': item['tax_rate_id'],
                          'discount_amount': item['discount_amount'] ?? 0.0,
                          'discount_type': item['discount_type'] ?? 'fixed',
                          'note': item['note'] ?? '',
                          'product_order_category':
                          item['product_order_category'] ?? 'BAR',
                          'res_table_id': argument!['res_table_id'],
                          'is_shipping': argument!['is_shipping'] ?? 0,
                        };
                      }).toList();

                      /// Quotations should not have payment lines - they are just estimates
                      List<Map<String, dynamic>> paymentLines = [];

                      Map<String, dynamic> sellPayload = {
                        'sells': [
                          {
                            'location_id':
                            sell['location_id'] ?? argument!['locationId'],
                            'contact_id':
                            sell['contact_id'] ?? selectedCustomer['id'],
                            'transaction_date':
                            sell['transaction_date'] ?? transactionDate,
                            'invoice_no': sell['invoice_no'],
                            'status': 'draft',
                            'sub_status': 'quotation',
                            'tax_rate_id': (sell['tax_rate_id'] == 0)
                                ? null
                                : sell['tax_rate_id'],
                            'discount_amount': sell['discount_amount'] ?? 0.0,
                            'discount_type': sell['discount_type'] ?? 'fixed',
                            'change_return': sell['change_return'],
                            'products': products,
                            'sale_note': sell['sale_note'],
                            'staff_note': sell['staff_note'],
                            'shipping_charges': sell['shipping_charges'],
                            'shipping_details': sell['shipping_details'],
                            'tip_amount':
                            (sell['tip_amount']?.toString() ?? '0.00'),
                            'tip_type': sell['tip_type'] ?? 'fixed',
                            'is_quotation': 1,
                            'payments': paymentLines,
                            'res_table_id': argument!['res_table_id'],
                            'is_shipping': argument!['is_shipping'] ?? 0,
                          }
                        ]
                      };

                      debugPrint('addQuotation: Calling createApiSell with sellId: $effectiveSellId, products: ${products.length}');
                      var apiResult = await Sell().createApiSell(
                          sellId: effectiveSellId,
                          payload: sellPayload,
                          isQuotation: true,
                          isDraft: true);

                      if (apiResult != null && apiResult.containsKey('error')) {
                        debugPrint('addQuotation: API sync failed: ${apiResult['error']}');
                        Fluttertoast.showToast(
                          msg: 'API sync failed: ${apiResult['error']}',
                          toastLength: Toast.LENGTH_LONG,
                        );
                      } else {
                        debugPrint('addQuotation: API sync successful');
                      }
                    } catch (apiError) {
                      debugPrint('addQuotation: API sync error: $apiError');
                      Fluttertoast.showToast(
                        msg: 'API sync error: $apiError',
                        toastLength: Toast.LENGTH_LONG,
                      );
                    }
                  } else {
                    debugPrint('addQuotation: No connectivity, skipping API sync');
                  }

                  // Reset cart for the specific res_table_id or shipping (same as draft)
                  if (argument!['is_shipping'] == 1) {
                    AppConstants.cartData['shipping'] = null;
                    await AppConstants.setData(0); // Update shared preferences
                    await SellDatabase()
                        .resetCartForTable(0); // Pass null for shipping
                    debugPrint(
                        'addQuotation: Cart reset for shipping (res_table_id=0)');

                    // Remove only the shipping cart from prefs
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.remove('cart_${argument!['locationId']}_0');
                  } else if (argument!['res_table_id'] != null) {
                    AppConstants
                        .cartData[argument!['res_table_id'].toString()] = null;
                    await AppConstants.setData(argument!['res_table_id']);
                    await SellDatabase()
                        .resetCartForTable(argument!['res_table_id']);

                    // Remove only the shipping cart from prefs
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.remove('cart_${argument!['locationId']}_0');
                    await prefs.remove(
                        'cart_${argument!['locationId']}_${argument!['res_table_id']}');
                    debugPrint(
                        'addQuotation: Cart reset for res_table_id=${argument!['res_table_id']}');
                  }

                  // Show loading indicator
                  // showDialog(
                  //   context: context,
                  //   barrierDismissible: false,
                  //   builder: (BuildContext context) {
                  //     return AlertDialog(
                  //       content: Row(
                  //         children: [
                  //           CircularProgressIndicator(),
                  //           Container(
                  //             margin: EdgeInsets.only(left: 5),
                  //             child: Text(AppLocalizations.of(context)
                  //                 .translate('loading')),
                  //           ),
                  //         ],
                  //       ),
                  //     );
                  //   },
                  // );

                  // Add a small delay to ensure the dialog is visible
                  await Future.delayed(Duration(milliseconds: 500));

                  // Mark table/shipping as unavailable when user confirms with "yes"
                  await _markTableOrShippingUnavailable();

                  // Successful save - navigate to Sales (dialog will be closed automatically)
                  Navigator.of(context).pushNamedAndRemoveUntil(
                      '/sale', (Route<dynamic> route) => false,
                      // arguments: _getSalesScreenArguments(),
                      arguments: Helper().argument(
                        locId: argument!['locationId'],
                        taxId: argument!['taxId'],
                        discountType: argument!['discountType'],
                        discountAmount: argument!['discountAmount'],
                        invoiceAmount: argument!['invoiceAmount'],
                        customerId: selectedCustomer['id'],
                        sellId: argument!['sellId'],
                        products: cartItems,
                        res_table_id: argument?['res_table_id'],
                        is_shipping: argument?['is_shipping'],
                        isShipping: (argument?['is_shipping'] ?? 0) == 1,
                        tableName: _tableName,
                        clearFields: true,
                        // Add any additional parameters that Sales screen might need
                        fromCustomerScreen:
                        true, // Optional: flag to indicate navigation source
                      ));
                  // In addQuotation method, after successful save:
                  EventBus().fire(QuotationCreatedEvent());

                  Fluttertoast.showToast(
                    msg: AppLocalizations.of(context)
                        .translate('saved_successfully'),
                  );
                } catch (e) {
                  Fluttertoast.showToast(
                    msg: AppLocalizations.of(context).translate('error_saving'),
                  );
                  debugPrint('Error saving quotation: $e');
                }
              },
              //child: Text(AppLocalizations.of(context).translate('save')),
              child: Text(AppLocalizations.of(context).translate('yes')),
            ),

            // ElevatedButton(
            //   style: ElevatedButton.styleFrom(
            //     primary: themeData.colorScheme.primary,
            //   ),
            //   onPressed: () async {
            //     if (argument!['res_table_id'] == null) {
            //       Fluttertoast.showToast(msg: "Table ID is required");
            //       return;
            //     }
            //
            //     try {
            //       int? newSellId;
            //       if (argument!['sellId'] != null) {
            //         await SellDatabase().updateSells(argument!['sellId'], sell);
            //         newSellId = argument!['sellId'];
            //       } else {
            //         newSellId = await SellDatabase().storeSell(sell);
            //         await SellDatabase().updateSellLine(
            //           {'sell_id': newSellId, 'is_completed': 1},
            //           resTableId: argument!['res_table_id'],
            //         );
            //       }
            //
            //       // Request permissions before printing
            //       await printWithPermissions(
            //           newSellId!, argument!['taxId'], context);
            //
            //       // Navigate to Sales screen
            //       Navigator.of(context).pop(); // Close the dialog
            //       Navigator.of(context).pushNamedAndRemoveUntil(
            //         '/sale',
            //         (Route<dynamic> route) => false,
            //       );
            //       Fluttertoast.showToast(
            //         msg: AppLocalizations.of(context)
            //             .translate('saved_successfully'),
            //       );
            //     } catch (e) {
            //       debugPrint("Error: $e");
            //       Fluttertoast.showToast(msg: "Error_saving_and_printing");
            //     }
            //   },
            //   child:
            //       Text(AppLocalizations.of(context).translate('save_n_print')),
            // ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: themeData.colorScheme.primary,
              ),
              onPressed: () async {
                Navigator.pop(context);

                // When user clicks "No", restore original saved state
                if (argument!['sellId'] != null && argument!['sellId'] != 0) {
                  try {
                    // Delete temporary cart items (is_completed = 0) to restore original state
                    await SellDatabase().deleteIncompleteSellLines(
                        argument!['sellId'], argument!['res_table_id']);
                    debugPrint(
                        'Customer: Restored original state for sellId: ${argument!['sellId']}');

                    // Navigate back to cart to show only saved products
                    Navigator.pushReplacementNamed(
                      context,
                      '/cart',
                      arguments: Helper().argument(
                        sellId: argument!['sellId'],
                        locId: argument!['locationId'],
                        res_table_id: argument!['res_table_id'],
                        is_shipping: argument!['is_shipping'],
                        isShipping: argument!['is_shipping'] == 1,
                        tableName: argument!['tableName'],
                        products: [],
                      ),
                    );
                  } catch (e) {
                    debugPrint('Customer: Error restoring original state: $e');
                    // Still navigate back even if there's an error
                    Navigator.pushReplacementNamed(
                      context,
                      '/sale',
                    );
                  }
                } else {
                  // No sellId, just go back to sales
                  Navigator.pushReplacementNamed(
                    context,
                    '/sale',
                  );
                }
              },
              child: Text(AppLocalizations.of(context).translate('no')),
            )
          ],
        );
      },
    );
  }

  Map _getSalesScreenArguments() {
    return Helper().argument(
      locId: argument!['locationId'],
      taxId: argument!['taxId'],
      discountType: argument!['discountType'],
      discountAmount: argument!['discountAmount'],
      invoiceAmount: argument!['invoiceAmount'],
      customerId: selectedCustomer['id'],
      sellId: argument!['sellId'],
      products: [], // You might need to fetch this separately
      res_table_id: argument?['res_table_id'],
      is_shipping: argument?['is_shipping'],
      isShipping: (argument?['is_shipping'] ?? 0) == 1,
      tableName: _tableName,
      clearFields: true,
      fromCustomerScreen: true,
    );
  }

  Future<void> printWithPermissions(
      int sellId, int taxId, BuildContext context) async {
    // Request storage permissions
    var status = await Permission.storage.request();
    if (!status.isGranted) {
      Fluttertoast.showToast(msg: "Storage permission required for printing");
      return;
    }

    // Get a writable directory
    final directory = await getTemporaryDirectory();
    final path = directory.path;

    try {
      await Helper().printDocument(sellId, taxId, context);
      Fluttertoast.showToast(msg: "Printed successfully");
    } catch (e) {
      debugPrint("Printing error: $e");
      Fluttertoast.showToast(msg: "Error printing document");
    }
  }

  //show add customer alert box
  Widget newCustomer() {
    // Only clear and initialize controllers if they are empty (first time opening)
    if (prefix.text.isEmpty) {
      // Clear all TextEditingController fields when the newCustomer screen is initialized
      prefix.clear();
      firstName.clear();
      middleName.clear();
      lastName.clear();
      mobile.clear();
      addressLine1.clear();
      addressLine2.clear();
      city.clear();
      state.clear();
      country.clear();
      zip.clear();

      // Set "Mr." as the default value for the prefix field
      prefix.text = 'Mr';
    }

    return SafeArea(
      top: false,
      bottom: true,
      child: Scaffold(
        appBar: new AppBar(
          title: Text(
            AppLocalizations.of(context).translate('create_contact'),
            style: themeData.appBarTheme.titleTextStyle,
          ),
        ),
        body: Container(
          height: MediaQuery.of(context).size.height,
          padding: EdgeInsets.only(top: 8, bottom: 8, left: 16, right: 16),
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            width: 64,
                            child: Center(
                              child: Icon(
                                MdiIcons.accountChildCircle,
                                color: themeData.colorScheme.onBackground,
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Container(
                              margin: EdgeInsets.only(left: 16),
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      //for Prefix
                                      // Container(
                                      //   width: 50,
                                      //   child: TextFormField(
                                      //     keyboardType: TextInputType.name,
                                      //     controller: prefix,
                                      //     inputFormatters: [
                                      //       FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z]')),
                                      //      // FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z]+$')),
                                      //       LengthLimitingTextInputFormatter(5),
                                      //     ],
                                      //     //maxLength: 5,
                                      //     style: themeData.textTheme.subtitle2!
                                      //         .merge(TextStyle(
                                      //         color: themeData
                                      //             .colorScheme.onBackground)),
                                      //     decoration: InputDecoration(
                                      //       hintStyle: themeData
                                      //           .textTheme.subtitle2!
                                      //           .merge(TextStyle(
                                      //           color: themeData.colorScheme
                                      //               .onBackground)),
                                      //       hintText: AppLocalizations.of(context)
                                      //           .translate('prefix'),
                                      //       border: UnderlineInputBorder(
                                      //         borderSide: BorderSide(
                                      //             color: themeData
                                      //                 .inputDecorationTheme
                                      //                 .border!
                                      //                 .borderSide
                                      //                 .color),
                                      //       ),
                                      //       enabledBorder: UnderlineInputBorder(
                                      //         borderSide: BorderSide(
                                      //             color: themeData
                                      //                 .inputDecorationTheme
                                      //                 .enabledBorder!
                                      //                 .borderSide
                                      //                 .color),
                                      //       ),
                                      //       focusedBorder: UnderlineInputBorder(
                                      //         borderSide: BorderSide(
                                      //             color: themeData
                                      //                 .inputDecorationTheme
                                      //                 .focusedBorder!
                                      //                 .borderSide
                                      //                 .color),
                                      //       ),
                                      //     ),
                                      //     textCapitalization:
                                      //     TextCapitalization.sentences,
                                      //   ),
                                      // ),
                                      Container(
                                        width: 65,
                                        child: GestureDetector(
                                          onTap: () async {
                                            final selected =
                                            await showModalBottomSheet<
                                                String>(
                                              context: context,
                                              backgroundColor: Colors
                                                  .white, // White dropdown background
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                BorderRadius.vertical(
                                                    top: Radius.circular(
                                                        16)),
                                              ),
                                              builder: (context) {
                                                final options = [
                                                  'Mr',
                                                  'Mrs',
                                                  'Ms',
                                                  'Dr'
                                                ]; // Your dropdown options
                                                return ListView.separated(
                                                  shrinkWrap: true,
                                                  itemCount: options.length,
                                                  separatorBuilder: (_, __) =>
                                                      Divider(height: 1),
                                                  itemBuilder:
                                                      (context, index) {
                                                    return ListTile(
                                                      title:
                                                      Text(options[index]),
                                                      onTap: () {
                                                        Navigator.pop(
                                                            context,
                                                            options[
                                                            index]); // Return selected value
                                                      },
                                                    );
                                                  },
                                                );
                                              },
                                            );

                                            if (selected != null) {
                                              prefix.text =
                                                  selected; // Store selected prefix in controller
                                            }
                                          },
                                          child: AbsorbPointer(
                                            // Disable manual typing
                                            child: TextFormField(
                                              controller: prefix,
                                              style: themeData
                                                  .textTheme.subtitle2!
                                                  .merge(
                                                TextStyle(
                                                    color: themeData.colorScheme
                                                        .onBackground),
                                              ),
                                              decoration: InputDecoration(
                                                hintStyle: themeData
                                                    .textTheme.subtitle2!
                                                    .merge(
                                                  TextStyle(
                                                      color: themeData
                                                          .colorScheme
                                                          .onBackground),
                                                ),
                                                hintText:
                                                AppLocalizations.of(context)
                                                    .translate('prefix'),
                                                border: UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .border!
                                                        .borderSide
                                                        .color,
                                                  ),
                                                ),
                                                enabledBorder:
                                                UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .enabledBorder!
                                                        .borderSide
                                                        .color,
                                                  ),
                                                ),
                                                focusedBorder:
                                                UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .focusedBorder!
                                                        .borderSide
                                                        .color,
                                                  ),
                                                ),
                                                suffixIcon: Icon(
                                                    Icons.arrow_drop_down,
                                                    color: themeData.colorScheme
                                                        .onBackground),
                                              ),
                                              readOnly: true, // Prevent typing
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 10)),
                                      Expanded(
                                        child: TextFormField(
                                          controller: firstName,
                                          inputFormatters: [
                                            FilteringTextInputFormatter.allow(
                                                RegExp(r'[a-zA-Z]')),
                                          ],
                                          validator: (value) {
                                            if (value!.length < 1) {
                                              return AppLocalizations.of(
                                                  context)
                                                  .translate(
                                                  'please_enter_your_name');
                                            } else {
                                              return null;
                                            }
                                          },
                                          style: themeData.textTheme.subtitle2!
                                              .merge(TextStyle(
                                              color: themeData.colorScheme
                                                  .onBackground)),
                                          decoration: InputDecoration(
                                            hintStyle: themeData
                                                .textTheme.subtitle2!
                                                .merge(TextStyle(
                                                color: themeData.colorScheme
                                                    .onBackground)),
                                            hintText:
                                            AppLocalizations.of(context)
                                                .translate('first_name'),
                                            border: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .border!
                                                      .borderSide
                                                      .color),
                                            ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .enabledBorder!
                                                      .borderSide
                                                      .color),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .focusedBorder!
                                                      .borderSide
                                                      .color),
                                            ),
                                          ),
                                          textCapitalization:
                                          TextCapitalization.sentences,
                                        ),
                                      )
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Container(
                                        width: MySize.screenWidth! * 0.35,
                                        child: TextFormField(
                                          controller: middleName,
                                          inputFormatters: [
                                            FilteringTextInputFormatter.allow(
                                                RegExp(r'[a-zA-Z]')),
                                          ],
                                          style: themeData.textTheme.subtitle2!
                                              .merge(TextStyle(
                                              color: themeData.colorScheme
                                                  .onBackground)),
                                          decoration: InputDecoration(
                                            hintStyle: themeData
                                                .textTheme.subtitle2!
                                                .merge(TextStyle(
                                                color: themeData.colorScheme
                                                    .onBackground)),
                                            hintText:
                                            AppLocalizations.of(context)
                                                .translate('middle_name'),
                                            border: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .border!
                                                      .borderSide
                                                      .color),
                                            ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .enabledBorder!
                                                      .borderSide
                                                      .color),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .focusedBorder!
                                                      .borderSide
                                                      .color),
                                            ),
                                          ),
                                          textCapitalization:
                                          TextCapitalization.sentences,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Container(
                                        width: MySize.screenWidth! * 0.35,
                                        child: TextFormField(
                                          controller: lastName,
                                          inputFormatters: [
                                            FilteringTextInputFormatter.allow(
                                                RegExp(r'[a-zA-Z]')),
                                          ],
                                          style: themeData.textTheme.subtitle2!
                                              .merge(TextStyle(
                                              color: themeData.colorScheme
                                                  .onBackground)),
                                          decoration: InputDecoration(
                                            hintStyle: themeData
                                                .textTheme.subtitle2!
                                                .merge(TextStyle(
                                                color: themeData.colorScheme
                                                    .onBackground)),
                                            hintText:
                                            AppLocalizations.of(context)
                                                .translate('last_name'),
                                            border: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .border!
                                                      .borderSide
                                                      .color),
                                            ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .enabledBorder!
                                                      .borderSide
                                                      .color),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: themeData
                                                      .inputDecorationTheme
                                                      .focusedBorder!
                                                      .borderSide
                                                      .color),
                                            ),
                                          ),
                                          textCapitalization:
                                          TextCapitalization.sentences,
                                        ),
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              width: 64,
                              child: Center(
                                child: Icon(
                                  MdiIcons.homeCityOutline,
                                  color: themeData.colorScheme.onBackground,
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Container(
                                margin: EdgeInsets.only(left: 16),
                                child: Column(
                                  children: <Widget>[
                                    TextFormField(
                                      controller: addressLine1,
                                      style: themeData.textTheme.subtitle2!
                                          .merge(TextStyle(
                                          color: themeData
                                              .colorScheme.onBackground)),
                                      decoration: InputDecoration(
                                        hintStyle: themeData
                                            .textTheme.subtitle2!
                                            .merge(TextStyle(
                                            color: themeData
                                                .colorScheme.onBackground)),
                                        hintText: AppLocalizations.of(context)
                                            .translate('address_line_1'),
                                        border: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: themeData
                                                  .inputDecorationTheme
                                                  .border!
                                                  .borderSide
                                                  .color),
                                        ),
                                        enabledBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: themeData
                                                  .inputDecorationTheme
                                                  .enabledBorder!
                                                  .borderSide
                                                  .color),
                                        ),
                                        focusedBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: themeData
                                                  .inputDecorationTheme
                                                  .focusedBorder!
                                                  .borderSide
                                                  .color),
                                        ),
                                      ),
                                      textCapitalization:
                                      TextCapitalization.sentences,
                                    ),
                                    TextFormField(
                                      controller: addressLine2,
                                      style: themeData.textTheme.subtitle2!
                                          .merge(TextStyle(
                                          color: themeData
                                              .colorScheme.onBackground)),
                                      decoration: InputDecoration(
                                        hintStyle: themeData
                                            .textTheme.subtitle2!
                                            .merge(TextStyle(
                                            color: themeData
                                                .colorScheme.onBackground)),
                                        hintText: AppLocalizations.of(context)
                                            .translate('address_line_2'),
                                        border: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: themeData
                                                  .inputDecorationTheme
                                                  .border!
                                                  .borderSide
                                                  .color),
                                        ),
                                        enabledBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: themeData
                                                  .inputDecorationTheme
                                                  .enabledBorder!
                                                  .borderSide
                                                  .color),
                                        ),
                                        focusedBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: themeData
                                                  .inputDecorationTheme
                                                  .focusedBorder!
                                                  .borderSide
                                                  .color),
                                        ),
                                      ),
                                      textCapitalization:
                                      TextCapitalization.sentences,
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      // Container(
                      //   margin: EdgeInsets.only(top: 8),
                      //   child: Row(
                      //     crossAxisAlignment: CrossAxisAlignment.center,
                      //     children: <Widget>[
                      //       Container(
                      //         width: 64,
                      //         child: Center(
                      //           child: Icon(
                      //             MdiIcons.phoneOutline,
                      //             color: themeData.colorScheme.onBackground,
                      //           ),
                      //         ),
                      //       ),
                      //       Expanded(
                      //         flex: 1,
                      //         child: Container(
                      //           margin: EdgeInsets.only(left: 16),
                      //           child: Column(
                      //             children: <Widget>[
                      //               TextFormField(
                      //                 controller: mobile,
                      //                 inputFormatters: [
                      //                   FilteringTextInputFormatter.digitsOnly,
                      //                   LengthLimitingTextInputFormatter(15)
                      //                 ],
                      //                 keyboardType: TextInputType.number,
                      //                 validator: (value) {
                      //                   if (value!.length < 1) {
                      //                     return AppLocalizations.of(context)
                      //                         .translate(
                      //                         'please_enter_your_number');
                      //                   } else {
                      //                     return null;
                      //                   }
                      //                 },
                      //                 style: themeData.textTheme.subtitle2!.merge(
                      //                     TextStyle(
                      //                         color: themeData
                      //                             .colorScheme.onBackground)),
                      //                 decoration: InputDecoration(
                      //                   hintStyle: themeData.textTheme.subtitle2!
                      //                       .merge(TextStyle(
                      //                       color: themeData
                      //                           .colorScheme.onBackground)),
                      //                   hintText: AppLocalizations.of(context)
                      //                       .translate('phone'),
                      //                   border: UnderlineInputBorder(
                      //                     borderSide: BorderSide(
                      //                         color: themeData
                      //                             .inputDecorationTheme
                      //                             .border!
                      //                             .borderSide
                      //                             .color),
                      //                   ),
                      //                   enabledBorder: UnderlineInputBorder(
                      //                     borderSide: BorderSide(
                      //                         color: themeData
                      //                             .inputDecorationTheme
                      //                             .enabledBorder!
                      //                             .borderSide
                      //                             .color),
                      //                   ),
                      //                   focusedBorder: UnderlineInputBorder(
                      //                     borderSide: BorderSide(
                      //                         color: themeData
                      //                             .inputDecorationTheme
                      //                             .focusedBorder!
                      //                             .borderSide
                      //                             .color),
                      //                   ),
                      //                 ),
                      //                 textCapitalization:
                      //                 TextCapitalization.sentences,
                      //               ),
                      //             ],
                      //           ),
                      //         ),
                      //       )
                      //     ],
                      //   ),
                      // ),

                      Container(
                        margin: EdgeInsets.only(top: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              width: 64,
                              child: Center(
                                child: Icon(
                                  MdiIcons.phoneOutline,
                                  color: themeData.colorScheme.onBackground,
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Container(
                                margin: EdgeInsets.only(left: 16),
                                child: IntlPhoneField(
                                  controller: mobile,
                                  keyboardType: TextInputType.phone,
                                  decoration: InputDecoration(
                                    hintText: AppLocalizations.of(context)
                                        .translate('phone'),
                                    hintStyle:
                                    themeData.textTheme.subtitle2!.merge(
                                      TextStyle(
                                          color: themeData
                                              .colorScheme.onBackground),
                                    ),
                                    border: UnderlineInputBorder(
                                      borderSide: BorderSide(
                                        color: themeData.inputDecorationTheme
                                            .border!.borderSide.color,
                                      ),
                                    ),
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide: BorderSide(
                                        color: themeData.inputDecorationTheme
                                            .enabledBorder!.borderSide.color,
                                      ),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide: BorderSide(
                                        color: themeData.inputDecorationTheme
                                            .focusedBorder!.borderSide.color,
                                      ),
                                    ),
                                    contentPadding: EdgeInsets.only(
                                        left: 8,
                                        top: 10), // Space inside text field
                                  ),
                                  initialCountryCode:
                                  'FR', // 🇫🇷 France (+33) Default
                                  flagsButtonPadding: const EdgeInsets.only(
                                      right:
                                      12), // 👈 Space between dropdown & number
                                  dropdownIconPosition: IconPosition
                                      .trailing, // Icon after country code
                                  onChanged: (phone) {
                                    print(phone.completeNumber); // +1 234567890
                                  },
                                  validator: (value) {
                                    if (value == null || value.number.isEmpty) {
                                      return AppLocalizations.of(context)
                                          .translate(
                                          'please_enter_your_number');
                                    }
                                    return null;
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(top: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              width: 64,
                              child: Center(
                                child: Icon(
                                  MdiIcons.homeCityOutline,
                                  color: themeData.colorScheme.onBackground,
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Container(
                                margin: EdgeInsets.only(left: 16),
                                child: Column(
                                  children: <Widget>[
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Container(
                                          width: MySize.screenWidth! * 0.35,
                                          child: TextFormField(
                                            controller: city,
                                            inputFormatters: [
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-zA-Z]')),
                                            ],
                                            style: themeData
                                                .textTheme.subtitle2!
                                                .merge(TextStyle(
                                                color: themeData.colorScheme
                                                    .onBackground)),
                                            decoration: InputDecoration(
                                              hintStyle: themeData
                                                  .textTheme.subtitle2!
                                                  .merge(TextStyle(
                                                  color: themeData
                                                      .colorScheme
                                                      .onBackground)),
                                              hintText:
                                              AppLocalizations.of(context)
                                                  .translate('city'),
                                              border: UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .border!
                                                        .borderSide
                                                        .color),
                                              ),
                                              enabledBorder:
                                              UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .enabledBorder!
                                                        .borderSide
                                                        .color),
                                              ),
                                              focusedBorder:
                                              UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .focusedBorder!
                                                        .borderSide
                                                        .color),
                                              ),
                                            ),
                                            textCapitalization:
                                            TextCapitalization.sentences,
                                          ),
                                        ),
                                        Container(
                                          width: MySize.screenWidth! * 0.35,
                                          child: TextFormField(
                                            controller: state,
                                            inputFormatters: [
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-zA-Z]')),
                                            ],
                                            style: themeData
                                                .textTheme.subtitle2!
                                                .merge(TextStyle(
                                                color: themeData.colorScheme
                                                    .onBackground)),
                                            decoration: InputDecoration(
                                              hintStyle: themeData
                                                  .textTheme.subtitle2!
                                                  .merge(TextStyle(
                                                  color: themeData
                                                      .colorScheme
                                                      .onBackground)),
                                              hintText:
                                              AppLocalizations.of(context)
                                                  .translate('state'),
                                              border: UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .border!
                                                        .borderSide
                                                        .color),
                                              ),
                                              enabledBorder:
                                              UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .enabledBorder!
                                                        .borderSide
                                                        .color),
                                              ),
                                              focusedBorder:
                                              UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .focusedBorder!
                                                        .borderSide
                                                        .color),
                                              ),
                                            ),
                                            textCapitalization:
                                            TextCapitalization.sentences,
                                          ),
                                        )
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Container(
                                          width: MySize.screenWidth! * 0.35,
                                          child: TextFormField(
                                            controller: country,
                                            inputFormatters: [
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-zA-Z]')),
                                            ],
                                            style: themeData
                                                .textTheme.subtitle2!
                                                .merge(TextStyle(
                                                color: themeData.colorScheme
                                                    .onBackground)),
                                            decoration: InputDecoration(
                                              hintStyle: themeData
                                                  .textTheme.subtitle2!
                                                  .merge(TextStyle(
                                                  color: themeData
                                                      .colorScheme
                                                      .onBackground)),
                                              hintText:
                                              AppLocalizations.of(context)
                                                  .translate('country'),
                                              border: UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .border!
                                                        .borderSide
                                                        .color),
                                              ),
                                              enabledBorder:
                                              UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .enabledBorder!
                                                        .borderSide
                                                        .color),
                                              ),
                                              focusedBorder:
                                              UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .focusedBorder!
                                                        .borderSide
                                                        .color),
                                              ),
                                            ),
                                            textCapitalization:
                                            TextCapitalization.sentences,
                                          ),
                                        ),
                                        Container(
                                          width: MySize.screenWidth! * 0.35,
                                          child: TextFormField(
                                            controller: zip,
                                            inputFormatters: [
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-zA-Z0-9 \-]')),
                                              LengthLimitingTextInputFormatter(
                                                  12),
                                            ],
                                            keyboardType: TextInputType.number,
                                            style: themeData
                                                .textTheme.subtitle2!
                                                .merge(TextStyle(
                                                color: themeData.colorScheme
                                                    .onBackground)),
                                            decoration: InputDecoration(
                                              hintStyle: themeData
                                                  .textTheme.subtitle2!
                                                  .merge(TextStyle(
                                                  color: themeData
                                                      .colorScheme
                                                      .onBackground)),
                                              hintText:
                                              AppLocalizations.of(context)
                                                  .translate('zip_code'),
                                              border: UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .border!
                                                        .borderSide
                                                        .color),
                                              ),
                                              enabledBorder:
                                              UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .enabledBorder!
                                                        .borderSide
                                                        .color),
                                              ),
                                              focusedBorder:
                                              UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: themeData
                                                        .inputDecorationTheme
                                                        .focusedBorder!
                                                        .borderSide
                                                        .color),
                                              ),
                                            ),
                                            textCapitalization:
                                            TextCapitalization.sentences,
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 16),
                        child: TextButton(
                          style: TextButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4)),
                            padding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 48),
                            backgroundColor: themeData.colorScheme.primary,
                          ),
                          onPressed: _isAddingContact
                              ? null
                              : () async {
                            if (await Helper().checkConnectivity()) {
                              if (_formKey.currentState!.validate()) {
                                setState(() {
                                  _isAddingContact = true;
                                });

                                // Show loading dialog
                                showDialog(
                                  context: context,
                                  barrierDismissible: false,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      content: Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        children: [
                                          CircularProgressIndicator(),
                                          SizedBox(
                                            width: 20,
                                          ),
                                          Text(
                                            AppLocalizations.of(context)
                                                .translate('loading'),
                                            style: TextStyle(
                                                color: Colors.black),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                );

                                Map newCustomer = {
                                  'type': 'customer',
                                  'prefix': prefix.text,
                                  'first_name': firstName.text,
                                  'middle_name': middleName.text,
                                  'last_name': lastName.text,
                                  'mobile': mobile.text,
                                  'address_line_1': addressLine1.text,
                                  'address_line_2': addressLine2.text,
                                  'city': city.text,
                                  'state': state.text,
                                  'country': country.text,
                                  'zip_code': zip.text
                                };

                                try {
                                  await CustomerApi()
                                      .add(newCustomer)
                                      .then((value) {
                                    if (value['data'] != null) {
                                      Contact()
                                          .insertContact(Contact()
                                          .contactModel(
                                          value['data']))
                                          .then((value) {
                                        selectCustomer();
                                        selectedCustomer =
                                        customerListMap[0];
                                        Navigator.pop(
                                            context); // Close loading dialog
                                        Navigator.pop(
                                            context); // Close the form
                                        _formKey.currentState!.reset();
                                        setState(() {
                                          _isAddingContact = false;
                                        });
                                      });
                                    } else {
                                      Navigator.pop(
                                          context); // Close loading dialog
                                      setState(() {
                                        _isAddingContact = false;
                                      });
                                    }
                                  });
                                } catch (e) {
                                  Navigator.pop(
                                      context); // Close loading dialog
                                  setState(() {
                                    _isAddingContact = false;
                                  });
                                  Fluttertoast.showToast(
                                      msg: AppLocalizations.of(context)
                                          .translate('error_occurred'));
                                }
                              } else {
                                setState(() {
                                  _isAddingContact = false;
                                });
                              }
                            } else {
                              Fluttertoast.showToast(
                                  msg: AppLocalizations.of(context)
                                      .translate('check_connectivity'));
                            }
                          },
                          child: _isAddingContact
                              ? Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor:
                                  AlwaysStoppedAnimation<Color>(
                                    themeData.colorScheme.onPrimary,
                                  ),
                                ),
                              ),
                              SizedBox(width: 8),
                              Text(
                                AppLocalizations.of(context)
                                    .translate('loading')
                                    .toUpperCase(),
                                style: AppTheme.getTextStyle(
                                    themeData.textTheme.bodyText1,
                                    color:
                                    themeData.colorScheme.onPrimary,
                                    letterSpacing: 0.3),
                              ),
                            ],
                          )
                              : Text(
                            AppLocalizations.of(context)
                                .translate('add_to_contact')
                                .toUpperCase(),
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.bodyText1,
                                color: themeData.colorScheme.onPrimary,
                                letterSpacing: 0.3),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  //dropdown widget for selecting customer
  Widget customerList() {
    return SearchChoices.single(
      underline: Visibility(
        child: Container(),
        visible: false,
      ),
      displayClearIcon: false,
      value: jsonEncode(selectedCustomer),
      items: customerListMap.map<DropdownMenuItem<String>>((Map value) {
        return DropdownMenuItem<String>(
            value: jsonEncode(value),
            child: Container(
              width: MySize.screenWidth! * 0.8,
              child: Text("${value['name']} (${value['mobile'] ?? ' - '})",
                  softWrap: true,
                  maxLines: 5,
                  overflow: TextOverflow.ellipsis,
                  style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                      color: themeData.colorScheme.onBackground)),
            ));
      }).toList(),
      iconEnabledColor: Colors.blue,
      iconDisabledColor: Colors.black,
      onChanged: (newValue) {
        setState(() {
          selectedCustomer = jsonDecode(newValue);
        });
      },
      isExpanded: true,
    );
  }

  selectCustomer() async {
    customerListMap = [
      {'id': 0, 'name': 'select customer', 'mobile': ' - '}
    ];
    List customers = await Contact().get();

    customers.forEach((value) {
      setState(() {
        customerListMap.add({
          'id': value['id'],
          'name': value['name'],
          'mobile': value['mobile']
        });
      });
      if (value['name'] == 'Walk-In Customer') {
        selectedCustomer = {
          'id': value['id'],
          'name': value['name'],
          'mobile': value['mobile']
        };
      }
    });
  }
}

