// // import 'dart:convert';
// //
// // import 'package:flutter/material.dart';
// // import 'package:flutter/services.dart';
// // import 'package:fluttertoast/fluttertoast.dart';
// // import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// //
// // import '../helpers/AppTheme.dart';
// // import '../helpers/SizeConfig.dart';
// // import '../helpers/otherHelpers.dart';
// // import '../locale/MyLocalizations.dart';
// // import '../models/product_model.dart';
// // import '../models/sell.dart';
// // import '../models/sellDatabase.dart';
// // import '../models/system.dart';
// // import '../models/variations.dart';
// // import 'elements.dart';
// //
// // class Cart extends StatefulWidget {
// //   @override
// //   CartState createState() => CartState();
// // }
// //
// // class CartState extends State<Cart> {
// //   bool proceedNext = true, canEditPrice = false, canEditDiscount = false;
// //   int? selectedContactId, editItem, selectedTaxId = 0, sellingPriceGroupId = 0;
// //   double? maxDiscountValue, discountAmount = 0.00;
// //   List cartItems = [];
// //   Map? argument = {};
// //   String symbol = '';
// //   var sellDetail, selectedDiscountType = "fixed";
// //   final discountController = new TextEditingController();
// //   final searchController = new TextEditingController();
// //   var invoiceAmount,
// //       taxListMap = [
// //         {'id': 0, 'name': 'Tax rate', 'amount': 0}
// //       ];
// //   ThemeData themeData = AppTheme.getThemeFromThemeMode(1);
// //   CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(1);
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     getPermission();
// //     setTaxMap();
// //     getDefaultValues();
// //     getSellingPriceGroupId();
// //   }
// //
// //   @override
// //   void didChangeDependencies() {
// //     argument = ModalRoute.of(context)!.settings.arguments as Map;
// //
// //     if (argument!['sellId'] != null) editCart(argument!['sellId']);
// //
// //     super.didChangeDependencies();
// //
// //     cartList();
// //   }
// //
// //   @override
// //   void dispose() {
// //     discountController.dispose();
// //     super.dispose();
// //   }
// //
// //   cartList() async {
// //     cartItems = [];
// //     (argument!['sellId'] != null)
// //         ? cartItems = await SellDatabase().getInCompleteLines(
// //         argument!['locationId'],
// //         sellId: argument!['sellId'])
// //         : cartItems =
// //     await SellDatabase().getInCompleteLines(argument!['locationId']);
// //     if (this.mounted) {
// //       setState(() {
// //         if (editItem == null) {
// //           proceedNext = true;
// //         }
// //       });
// //     }
// //   }
// //
// //   editCart(sellId) async {
// //     sellDetail = await SellDatabase().getSellBySellId(sellId);
// //     selectedTaxId = (sellDetail[0]['tax_rate_id'] != null)
// //         ? sellDetail[0]['tax_rate_id']
// //         : 0;
// //     selectedContactId = sellDetail[0]['contact_id'];
// //     selectedDiscountType = sellDetail[0]['discount_type'];
// //     discountAmount = sellDetail[0]['discount_amount'];
// //     discountController.text = discountAmount.toString();
// //     calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount);
// //     if (this.mounted) {
// //       setState(() {});
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         elevation: 0,
// //         title: Text(AppLocalizations.of(context).translate('cart'),
// //             style: AppTheme.getTextStyle(themeData.textTheme.headline6,
// //                 fontWeight: 600)),
// //         leading: IconButton(
// //             icon: Icon(Icons.arrow_back),
// //             onPressed: () {
// //               (argument!['sellId'] == null)
// //                   ? Navigator.pop(context)
// //                   : Navigator.pushReplacementNamed(context, '/products',
// //                   arguments: Helper().argument(
// //                     sellId: argument!['sellId'],
// //                     locId: argument!['locationId'], products: [],
// //                   ));
// //             }),
// //         actions: [
// //           InkWell(
// //             onTap: () async {
// //               var barcode = await Helper().barcodeScan();
// //               await getScannedProduct(barcode);
// //             },
// //             child: Container(
// //               margin: EdgeInsets.only(
// //                   right: MySize.size16!,
// //                   bottom: MySize.size8!,
// //                   top: MySize.size8!),
// //               decoration: BoxDecoration(
// //                 color: themeData.backgroundColor,
// //                 borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
// //                 boxShadow: [
// //                   BoxShadow(
// //                     color: themeData.cardTheme.shadowColor!.withAlpha(48),
// //                     blurRadius: 3,
// //                     offset: Offset(0, 1),
// //                   )
// //                 ],
// //               ),
// //               padding:
// //               EdgeInsets.only(left: MySize.size12!, right: MySize.size12!),
// //               child: Icon(
// //                 MdiIcons.barcode,
// //                 color: themeData.colorScheme.primary,
// //               ),
// //             ),
// //           ),
// //           searchDropdown()
// //         ],
// //       ),
// //       body: SingleChildScrollView(
// //         child: Column(children: <Widget>[
// //           Container(
// //               height: MySize.safeHeight! * 0.65,
// //               color: customAppTheme.bgLayer1,
// //               child: (cartItems.length > 0)
// //                   ? itemList()
// //                   : Center(
// //                   child: Text(AppLocalizations.of(context)
// //                       .translate('add_item_to_cart')))),
// //           Divider(),
// //           Column(
// //             children: <Widget>[
// //               Container(
// //                 padding: EdgeInsets.only(
// //                     left: MySize.size24!, right: MySize.size24!),
// //                 child: Row(
// //                   mainAxisAlignment: MainAxisAlignment.end,
// //                   children: <Widget>[
// //                     Text(
// //                         AppLocalizations.of(context).translate('sub_total') +
// //                             ' : ',
// //                         style: AppTheme.getTextStyle(
// //                           themeData.textTheme.subtitle1,
// //                           fontWeight: 700,
// //                           color: themeData.colorScheme.onBackground,
// //                         )),
// //                     Text(symbol + Helper().formatCurrency(calculateSubTotal()),
// //                         style: AppTheme.getTextStyle(
// //                           themeData.textTheme.subtitle1,
// //                           fontWeight: 700,
// //                           color: themeData.colorScheme.onBackground,
// //                         )),
// //                   ],
// //                 ),
// //               )
// //             ],
// //           ),
// //           Container(
// //             padding:
// //             EdgeInsets.only(left: MySize.size24!, right: MySize.size24!),
// //             child: Row(
// //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //               children: <Widget>[
// //                 Text(
// //                   AppLocalizations.of(context).translate('discount') + ' : ',
// //                   style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
// //                       color: themeData.colorScheme.onBackground,
// //                       fontWeight: 600,
// //                       muted: true),
// //                 ),
// //                 discount(),
// //                 Expanded(
// //                   child: Container(
// //                     height: MySize.size50,
// //                     child: TextFormField(
// //                       controller: discountController,
// //                       decoration: InputDecoration(
// //                         prefix: Text((selectedDiscountType == 'fixed') ? symbol : ''),
// //                         labelText: AppLocalizations.of(context).translate('discount_amount'),
// //                         border: themeData.inputDecorationTheme.border,
// //                         enabledBorder: themeData.inputDecorationTheme.border,
// //                         focusedBorder: themeData.inputDecorationTheme.focusedBorder,
// //                       ),
// //                       style: AppTheme.getTextStyle(
// //                           themeData.textTheme.subtitle2,
// //                           fontWeight: 400,
// //                           letterSpacing: -0.2),
// //                       textAlign: TextAlign.end,
// //                       inputFormatters: [
// //                         FilteringTextInputFormatter(RegExp(r'^(\d+)?\.?\d{0,2}'), allow: true)
// //                       ],
// //                       keyboardType: TextInputType.number,
// //                       onChanged: (value) {
// //                         setState(() {
// //                           discountAmount = Helper().validateInput(value);
// //                           print('Cart: Updated discount_amount: $discountAmount'); // Add logging
// //                           if (maxDiscountValue != null && discountAmount! > maxDiscountValue!) {
// //                             Fluttertoast.showToast(
// //                                 msg: AppLocalizations.of(context)
// //                                     .translate('discount_error_message') +
// //                                     " $maxDiscountValue");
// //                             proceedNext = false;
// //                           } else {
// //                             proceedNext = true;
// //                           }
// //                         });
// //                       },
// //                     ),
// //                   ),
// //                 )
// //               ],
// //             ),
// //           ),
// //           Container(
// //             padding:
// //             EdgeInsets.only(left: MySize.size24!, right: MySize.size24!),
// //             child: Row(
// //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //               children: <Widget>[
// //                 Text(
// //                   AppLocalizations.of(context).translate('tax') + ' : ',
// //                   style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
// //                       color: themeData.colorScheme.onBackground,
// //                       fontWeight: 600,
// //                       muted: true),
// //                 ),
// //                 taxes(),
// //                 Text(
// //                   AppLocalizations.of(context).translate('total') + ' : ',
// //                   style: AppTheme.getTextStyle(
// //                     themeData.textTheme.subtitle1,
// //                     fontWeight: 700,
// //                     color: themeData.colorScheme.onBackground,
// //                   ),
// //                 ),
// //                 Text(
// //                     symbol +
// //                         Helper().formatCurrency(calculateSubtotal(selectedTaxId,
// //                             selectedDiscountType, discountAmount)),
// //                     style: AppTheme.getTextStyle(
// //                       themeData.textTheme.subtitle1,
// //                       fontWeight: 700,
// //                       color: themeData.colorScheme.onBackground,
// //                       letterSpacing: 0,
// //                     ))
// //               ],
// //             ),
// //           ),
// //         ]),
// //       ),
// //       bottomNavigationBar: Visibility(
// //         visible: (cartItems.length > 0 && proceedNext == true),
// //         child: cartBottomBar(
// //             '/customer',
// //             AppLocalizations.of(context).translate('customer'),
// //             context,
// //             Helper().argument(
// //                 locId: argument!['locationId'],
// //                 taxId: selectedTaxId,
// //                 discountType: selectedDiscountType,
// //                 discountAmount: discountAmount,
// //                 invoiceAmount: calculateSubtotal(
// //                     selectedTaxId, selectedDiscountType, discountAmount),
// //                 sellId: argument!['sellId'],
// //                 isQuotation: argument!['is_quotation'],
// //                 customerId:
// //                 (argument!['sellId'] != null) ? selectedContactId : null, products: [])),
// //       ),
// //     );
// //   }
// //
// //   //filter dropdown
// //   Widget searchDropdown() {
// //     return Container(
// //       margin: EdgeInsets.only(right: MySize.size10!, top: MySize.size8!),
// //       width: MySize.screenWidth! * 0.45,
// //       child: TextFormField(
// //         style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
// //             letterSpacing: 0, fontWeight: 500),
// //         decoration: InputDecoration(
// //           hintText: AppLocalizations.of(context).translate('search'),
// //           hintStyle: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
// //               letterSpacing: 0, fontWeight: 500),
// //           border: OutlineInputBorder(
// //               borderRadius: BorderRadius.all(
// //                 Radius.circular(MySize.size16!),
// //               ),
// //               borderSide: BorderSide.none),
// //           enabledBorder: OutlineInputBorder(
// //               borderRadius: BorderRadius.all(
// //                 Radius.circular(MySize.size16!),
// //               ),
// //               borderSide: BorderSide.none),
// //           focusedBorder: OutlineInputBorder(
// //               borderRadius: BorderRadius.all(
// //                 Radius.circular(MySize.size16!),
// //               ),
// //               borderSide: BorderSide.none),
// //           filled: true,
// //           fillColor: themeData.colorScheme.background,
// //           prefixIcon: Icon(
// //             MdiIcons.magnify,
// //             size: MySize.size22,
// //             color: themeData.colorScheme.onBackground.withAlpha(150),
// //           ),
// //           isDense: true,
// //           contentPadding: EdgeInsets.only(right: MySize.size16!),
// //         ),
// //         textCapitalization: TextCapitalization.sentences,
// //         controller: searchController,
// //         onEditingComplete: () async {
// //           await getSearchItemList(searchController.text)
// //               .then((value) => itemDialog(value));
// //           FocusScope.of(context).requestFocus(FocusNode());
// //         },
// //       ),
// //     );
// //   }
// //
// //   //show items dialog list
// //   itemDialog(List items) {
// //     showDialog(
// //       barrierDismissible: true,
// //       context: context,
// //       builder: (BuildContext context) {
// //         return AlertDialog(
// //           backgroundColor: customAppTheme.bgLayer1,
// //           content: Container(
// //             color: customAppTheme.bgLayer1,
// //             height: MySize.screenHeight! * 0.8,
// //             width: MySize.screenWidth! * 0.8,
// //             child: ListView.builder(
// //                 shrinkWrap: true,
// //                 itemCount: (items.length != 0) ? items.length : 0,
// //                 itemBuilder: ((context, index) {
// //                   return Card(
// //                     elevation: 4,
// //                     margin: EdgeInsets.all(MySize.size4!),
// //                     child: ListTile(
// //                       title: Text(items[index]['display_name']),
// //                       trailing: Column(
// //                         crossAxisAlignment: CrossAxisAlignment.end,
// //                         children: <Widget>[
// //                           Text(
// //                             symbol +
// //                                 Helper()
// //                                     .formatCurrency(items[index]['unit_price']),
// //                             style: AppTheme.getTextStyle(
// //                                 themeData.textTheme.bodyText2,
// //                                 fontWeight: 700,
// //                                 letterSpacing: 0),
// //                           ),
// //                           Container(
// //                             width: MySize.size80,
// //                             decoration: BoxDecoration(
// //                                 color: themeData.colorScheme.primary,
// //                                 borderRadius: BorderRadius.all(
// //                                     Radius.circular(MySize.size4!))),
// //                             padding: EdgeInsets.only(
// //                                 left: MySize.size6!,
// //                                 right: MySize.size8!,
// //                                 top: MySize.size2!,
// //                                 bottom: MySize.getScaledSizeHeight(3.5)),
// //                             child: Row(
// //                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                               children: <Widget>[
// //                                 Icon(
// //                                   MdiIcons.stocking,
// //                                   color: themeData.colorScheme.onPrimary,
// //                                   size: MySize.size12,
// //                                 ),
// //                                 Container(
// //                                   margin: EdgeInsets.only(left: MySize.size4!),
// //                                   child: Text(
// //                                       Helper().formatQuantity(
// //                                           items[index]['stock_available']),
// //                                       style: AppTheme.getTextStyle(
// //                                           themeData.textTheme.caption,
// //                                           fontSize: 11,
// //                                           color:
// //                                           themeData.colorScheme.onPrimary,
// //                                           fontWeight: 600)),
// //                                 ),
// //                               ],
// //                             ),
// //                           ),
// //                         ],
// //                       ),
// //                       onTap: () async {
// //                         Fluttertoast.showToast(
// //                             msg: AppLocalizations.of(context)
// //                                 .translate('added_to_cart'));
// //                         await Sell().addToCart(items[index],
// //                             argument != null ? argument!['sellId'] : null);
// //                         setState(() {
// //                           cartList();
// //                         });
// //                       },
// //                     ),
// //                   );
// //                 })),
// //           ),
// //         );
// //       },
// //     );
// //   }
// //
// //   //get search items list
// //   Future<List> getSearchItemList(String searchText) async {
// //     List products = [];
// //     var price;
// //     await Variations()
// //         .get(
// //         locationId: argument!['locationId'],
// //         offset: 0,
// //         inStock: true,
// //         searchTerm: '$searchText')
// //         .then((value) {
// //       value.forEach((element) {
// //         if (element['selling_price_group'] != null) {
// //           jsonDecode(element['selling_price_group']).forEach((element) {
// //             if (element['key'] == sellingPriceGroupId) {
// //               price = element['value'];
// //             }
// //           });
// //         }
// //         setState(() {
// //           products.add(ProductModel().product(element, price));
// //         });
// //       });
// //     });
// //     return products;
// //   }
// //
// //   //set selling price group Id
// //   getSellingPriceGroupId() async {
// //     await System().get('location').then((value) {
// //       value.forEach((element) {
// //         if (element['id'] == argument!['locationId'] &&
// //             element['selling_price_group_id'] != null) {
// //           sellingPriceGroupId =
// //               int.parse(element['selling_price_group_id'].toString());
// //         }
// //       });
// //     });
// //   }
// //
// //   //add product to cart after scanning barcode
// //   getScannedProduct(String barcode) async {
// //     await Variations()
// //         .get(
// //         locationId: argument!['locationId'],
// //         offset: 0,
// //         barcode: barcode,
// //         searchTerm: '')
// //         .then((value) async {
// //       if (value.length > 0) {
// //         var price;
// //         var product;
// //         if (value[0]['selling_price_group'] != null) {
// //           jsonDecode(value[0]['selling_price_group']).forEach((element) {
// //             if (element['key'] == sellingPriceGroupId) {
// //               price = element['value'];
// //             }
// //           });
// //         }
// //         setState(() {
// //           product = ProductModel().product(value[0], price);
// //         });
// //         if (product != null && product['stock_available'] > 0) {
// //           Fluttertoast.showToast(
// //               msg: AppLocalizations.of(context).translate('added_to_cart'));
// //           await Sell().addToCart(
// //               product, (argument != null) ? argument!['sellId'] : null);
// //           cartList();
// //         } else {
// //           Fluttertoast.showToast(msg: "Out of Stock");
// //         }
// //       } else {
// //         Fluttertoast.showToast(msg: "No product found");
// //       }
// //     });
// //   }
// //
// //   Widget itemList() {
// //     int themeType = 1;
// //     ThemeData themeData;
// //     CustomAppTheme customAppTheme;
// //     themeData = AppTheme.getThemeFromThemeMode(themeType);
// //     customAppTheme = AppTheme.getCustomAppTheme(themeType);
// //
// //     return ListView.builder(
// //       shrinkWrap: true,
// //       itemCount: cartItems.length,
// //       padding: EdgeInsets.only(
// //         top: MySize.size16!,
// //       ),
// //       itemBuilder: (context, index) {
// //         return Padding(
// //             padding: EdgeInsets.only(
// //                 left: MySize.size8!,
// //                 right: MySize.size8!,
// //                 bottom: MySize.size8!),
// //             child: Container(
// //               decoration: BoxDecoration(
// //                 boxShadow: [
// //                   BoxShadow(
// //                       blurRadius: MySize.size8!,
// //                       color: customAppTheme.shadowColor,
// //                       offset: Offset(0, MySize.size4!))
// //                 ],
// //               ),
// //               child: Container(
// //                 clipBehavior: Clip.antiAlias,
// //                 decoration: BoxDecoration(
// //                     boxShadow: [
// //                       BoxShadow(
// //                           color: themeData.cardTheme.shadowColor!.withAlpha(10),
// //                           blurRadius: MySize.size16!)
// //                     ],
// //                     color: customAppTheme.bgLayer1,
// //                     borderRadius:
// //                     BorderRadius.all(Radius.circular(MySize.size16!))),
// //                 padding: EdgeInsets.only(right: MySize.size16!),
// //                 child: Column(
// //                   children: [
// //                     Container(
// //                       alignment: Alignment.topLeft,
// //                       padding: EdgeInsets.all(MySize.size8!),
// //                       child: Text(
// //                         cartItems[index]['name'],
// //                         overflow: (editItem == index)
// //                             ? TextOverflow.visible
// //                             : TextOverflow.ellipsis,
// //                         style: AppTheme.getTextStyle(
// //                             themeData.textTheme.bodyText1,
// //                             color: themeData.colorScheme.onBackground,
// //                             fontWeight: 600),
// //                       ),
// //                     ),
// //                     Row(
// //                       children: <Widget>[
// //                         Expanded(
// //                           child: Container(
// //                             // height: MySize.safeHeight *
// //                             //     (editItem == index ? 0.37 : 0.15),
// //                             margin: EdgeInsets.only(left: MySize.size20!),
// //                             child: Column(
// //                               children: [
// //                                 Row(
// //                                   children: <Widget>[
// //                                     Expanded(
// //                                         child: Column(
// //                                             mainAxisAlignment:
// //                                             MainAxisAlignment.spaceEvenly,
// //                                             crossAxisAlignment:
// //                                             CrossAxisAlignment.start,
// //                                             children: <Widget>[
// //                                               Text(
// //                                                 symbol +
// //                                                     Helper().formatCurrency(
// //                                                         cartItems[index]
// //                                                         ['unit_price']),
// //                                                 style: AppTheme.getTextStyle(
// //                                                     themeData.textTheme.bodyText1,
// //                                                     color: themeData
// //                                                         .colorScheme.onBackground,
// //                                                     fontWeight: 600,
// //                                                     letterSpacing: -0.2,
// //                                                     muted: true),
// //                                               ),
// //                                               Row(
// //                                                   mainAxisAlignment:
// //                                                   MainAxisAlignment
// //                                                       .spaceBetween,
// //                                                   children: [
// //                                                     Text(AppLocalizations.of(context)
// //                                                         .translate('total') +
// //                                                         ' : ' +
// //                                                         symbol +
// //                                                         Helper().formatCurrency((double.parse(
// //                                                             calculateInlineUnitPrice(
// //                                                                 cartItems[index]
// //                                                                 [
// //                                                                 'unit_price'],
// //                                                                 cartItems[index]
// //                                                                 [
// //                                                                 'tax_rate_id'],
// //                                                                 cartItems[index]
// //                                                                 [
// //                                                                 'discount_type'],
// //                                                                 cartItems[index]
// //                                                                 [
// //                                                                 'discount_amount'])) *
// //                                                             cartItems[index]
// //                                                             ['quantity']))),
// //                                                   ]),
// //                                               Row(
// //                                                 children: [
// //                                                   IconButton(
// //                                                       icon: Icon(
// //                                                         MdiIcons.pencil,
// //                                                         size: MySize.size20,
// //                                                       ),
// //                                                       color: themeData
// //                                                           .colorScheme.onBackground,
// //                                                       onPressed: () {
// //                                                         setState(() {
// //                                                           (editItem == index)
// //                                                               ? editItem = null
// //                                                               : editItem = index;
// //                                                         });
// //                                                       }),
// //                                                   IconButton(
// //                                                       icon: Icon(MdiIcons.delete,
// //                                                           size: MySize.size20),
// //                                                       color: themeData
// //                                                           .colorScheme.onBackground,
// //                                                       onPressed: () {
// //                                                         showDialog(
// //                                                           barrierDismissible: true,
// //                                                           context: context,
// //                                                           builder: (BuildContext
// //                                                           context) {
// //                                                             return AlertDialog(
// //                                                               title: Row(
// //                                                                 children: <Widget>[
// //                                                                   Padding(
// //                                                                     padding: EdgeInsets
// //                                                                         .all(MySize
// //                                                                         .size5!),
// //                                                                     child: Icon(
// //                                                                       MdiIcons
// //                                                                           .alertCircle,
// //                                                                       color: Colors
// //                                                                           .black,
// //                                                                     ),
// //                                                                   ),
// //                                                                   Text(
// //                                                                     AppLocalizations.of(
// //                                                                         context)
// //                                                                         .translate(
// //                                                                         'delete_item_message'),
// //                                                                     style: AppTheme.getTextStyle(
// //                                                                         themeData
// //                                                                             .textTheme
// //                                                                             .headline6,
// //                                                                         color: themeData
// //                                                                             .colorScheme
// //                                                                             .onBackground,
// //                                                                         fontWeight:
// //                                                                         600),
// //                                                                     textAlign:
// //                                                                     TextAlign
// //                                                                         .center,
// //                                                                   ),
// //                                                                 ],
// //                                                               ),
// //                                                               actions: <Widget>[
// //                                                                 TextButton(
// //                                                                     onPressed: () {
// //                                                                       (argument!['sellId'] ==
// //                                                                           null)
// //                                                                           ? SellDatabase().delete(
// //                                                                           cartItems[index]
// //                                                                           [
// //                                                                           'variation_id'],
// //                                                                           cartItems[index]
// //                                                                           [
// //                                                                           'product_id'])
// //                                                                           : SellDatabase().delete(
// //                                                                           cartItems[index]
// //                                                                           [
// //                                                                           'variation_id'],
// //                                                                           cartItems[index]
// //                                                                           [
// //                                                                           'product_id'],
// //                                                                           sellId:
// //                                                                           argument!['sellId']);
// //                                                                       editItem =
// //                                                                       null;
// //                                                                       cartList();
// //                                                                       Navigator.pop(
// //                                                                           context);
// //                                                                     },
// //                                                                     child: Text(AppLocalizations.of(
// //                                                                         context)
// //                                                                         .translate(
// //                                                                         'yes'))),
// //                                                                 TextButton(
// //                                                                     onPressed: () {
// //                                                                       Navigator.pop(
// //                                                                           context);
// //                                                                     },
// //                                                                     child: Text(AppLocalizations.of(
// //                                                                         context)
// //                                                                         .translate(
// //                                                                         'no')))
// //                                                               ],
// //                                                             );
// //                                                           },
// //                                                         );
// //                                                       })
// //                                                 ],
// //                                               )
// //                                             ])),
// //                                     Container(
// //                                         alignment: Alignment.centerRight,
// //                                         width: MySize.screenWidth! * 0.25,
// //                                         height: MySize.screenHeight! * 0.05,
// //                                         child: (editItem != index)
// //                                             ? Text(
// //                                             "${AppLocalizations.of(context).translate('quantity')}:${cartItems[index]['quantity'].toString()}")
// //                                             : TextFormField(
// //                                           controller: (editItem != index)
// //                                               ? TextEditingController(
// //                                               text: cartItems[index]
// //                                               ['quantity']
// //                                                   .toString())
// //                                               : null,
// //                                           initialValue:
// //                                           (editItem == index)
// //                                               ? cartItems[index]
// //                                           ['quantity']
// //                                               .toString()
// //                                               : null,
// //                                           inputFormatters: [
// //                                             FilteringTextInputFormatter(
// //                                                 RegExp(
// //                                                     r'^(\d+)?\.?\d{0,2}'),
// //                                                 allow: true)
// //                                           ],
// //                                           keyboardType: TextInputType
// //                                               .numberWithOptions(
// //                                               decimal: true),
// //                                           textAlign: TextAlign.end,
// //                                           decoration: InputDecoration(
// //                                             labelText: AppLocalizations
// //                                                 .of(context)
// //                                                 .translate('quantity'),
// //                                           ),
// //                                           onChanged: (newQuantity) {
// //                                             if (newQuantity != "" &&
// //                                                 double.parse(
// //                                                     newQuantity) >
// //                                                     0) {
// //                                               if (!proceedNext)
// //                                                 proceedNext = true;
// //                                               if (cartItems[index][
// //                                               'stock_available'] >=
// //                                                   double.parse(
// //                                                       newQuantity)) {
// //                                                 SellDatabase().update(
// //                                                     cartItems[index]
// //                                                     ['id'],
// //                                                     {
// //                                                       'quantity':
// //                                                       double.parse(
// //                                                           newQuantity)
// //                                                     });
// //                                                 cartList();
// //                                               } else {
// //                                                 Fluttertoast.showToast(
// //                                                     msg: "${cartItems[index]['stock_available']}" +
// //                                                         AppLocalizations.of(
// //                                                             context)
// //                                                             .translate(
// //                                                             'stock_available'));
// //                                               }
// //                                             } else if (newQuantity ==
// //                                                 "") {
// //                                               setState(() {
// //                                                 proceedNext = false;
// //                                               });
// //                                               Fluttertoast.showToast(
// //                                                   msg: AppLocalizations
// //                                                       .of(context)
// //                                                       .translate(
// //                                                       'please_enter_a_valid_quantity'));
// //                                             }
// //                                           },
// //                                         )),
// //                                     Container(
// //                                       margin:
// //                                       EdgeInsets.only(left: MySize.size24!),
// //                                       child: Column(
// //                                         mainAxisAlignment:
// //                                         MainAxisAlignment.spaceEvenly,
// //                                         children: <Widget>[
// //                                           InkWell(
// //                                             onTap: () {
// //                                               if (cartItems[index]
// //                                               ['stock_available'] >
// //                                                   cartItems[index]
// //                                                   ['quantity']) {
// //                                                 SellDatabase().update(
// //                                                     cartItems[index]['id'], {
// //                                                   'quantity': cartItems[index]
// //                                                   ['quantity'] +
// //                                                       1
// //                                                 });
// //                                                 cartList();
// //                                               } else {
// //                                                 var stockAvailable =
// //                                                 cartItems[index]
// //                                                 ['stock_available'];
// //                                                 Fluttertoast.showToast(
// //                                                     msg: "$stockAvailable" +
// //                                                         AppLocalizations.of(
// //                                                             context)
// //                                                             .translate(
// //                                                             'stock_available'));
// //                                               }
// //                                             },
// //                                             child: Container(
// //                                               padding:
// //                                               EdgeInsets.all(MySize.size6!),
// //                                               decoration: BoxDecoration(
// //                                                   shape: BoxShape.circle,
// //                                                   color:
// //                                                   customAppTheme.bgLayer3,
// //                                                   boxShadow: [
// //                                                     BoxShadow(
// //                                                         color: themeData
// //                                                             .cardTheme
// //                                                             .shadowColor!
// //                                                             .withAlpha(8),
// //                                                         blurRadius:
// //                                                         MySize.size8!)
// //                                                   ]),
// //                                               child: Icon(
// //                                                 MdiIcons.plus,
// //                                                 size: MySize.size20,
// //                                                 color: themeData
// //                                                     .colorScheme.onBackground,
// //                                               ),
// //                                             ),
// //                                           ),
// //                                           InkWell(
// //                                             onTap: () {
// //                                               if (cartItems[index]['quantity'] >
// //                                                   1) {
// //                                                 SellDatabase().update(
// //                                                     cartItems[index]['id'], {
// //                                                   'quantity': cartItems[index]
// //                                                   ['quantity'] -
// //                                                       1
// //                                                 });
// //                                                 cartList();
// //                                               }
// //                                             },
// //                                             child: Container(
// //                                               padding:
// //                                               EdgeInsets.all(MySize.size6!),
// //                                               decoration: BoxDecoration(
// //                                                   shape: BoxShape.circle,
// //                                                   color:
// //                                                   customAppTheme.bgLayer3,
// //                                                   boxShadow: [
// //                                                     BoxShadow(
// //                                                         color: themeData
// //                                                             .cardTheme
// //                                                             .shadowColor!
// //                                                             .withAlpha(10),
// //                                                         blurRadius:
// //                                                         MySize.size8!)
// //                                                   ]),
// //                                               child: Icon(
// //                                                 MdiIcons.minus,
// //                                                 size: MySize.size20,
// //                                                 color: themeData
// //                                                     .colorScheme.onBackground,
// //                                               ),
// //                                             ),
// //                                           ),
// //                                         ],
// //                                       ),
// //                                     ),
// //                                   ],
// //                                 ),
// //                                 Visibility(
// //                                     visible: (editItem == index),
// //                                     child: edit(cartItems[index])),
// //                               ],
// //                             ),
// //                           ),
// //                         )
// //                       ],
// //                     ),
// //                   ],
// //                 ),
// //               ),
// //             ));
// //       },
// //     );
// //   }
// //
// //   //edit cart item
// //   Widget edit(index) {
// //     return Container(
// //       child: Column(
// //         children: <Widget>[
// //           Row(
// //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: <Widget>[
// //               (canEditPrice)
// //                   ? SizedBox(
// //                 width: MySize.size160,
// //                 height: MySize.size50,
// //                 child: TextFormField(
// //                     initialValue: index['unit_price'].toStringAsFixed(2),
// //                     decoration: InputDecoration(
// //                       prefix: Text(symbol),
// //                       labelText: AppLocalizations.of(context)
// //                           .translate('unit_price'),
// //                       border: themeData.inputDecorationTheme.border,
// //                       enabledBorder:
// //                       themeData.inputDecorationTheme.border,
// //                       focusedBorder:
// //                       themeData.inputDecorationTheme.focusedBorder,
// //                     ),
// //                     style: AppTheme.getTextStyle(
// //                         themeData.textTheme.subtitle2,
// //                         fontWeight: 400,
// //                         letterSpacing: -0.2),
// //                     textAlign: TextAlign.end,
// //                     inputFormatters: [
// //                       FilteringTextInputFormatter.allow(
// //                           RegExp(r'^(\d+)?\.?\d{0,2}'))
// //                     ],
// //                     keyboardType: TextInputType.number,
// //                     onChanged: (newValue) {
// //                       double value = Helper().validateInput(newValue);
// //                       SellDatabase()
// //                           .update(index['id'], {'unit_price': '$value'});
// //                       cartList();
// //                     }),
// //               )
// //                   : Container(),
// //               (canEditDiscount)
// //                   ? Column(
// //                 crossAxisAlignment: CrossAxisAlignment.end,
// //                 children: <Widget>[
// //                   Text(AppLocalizations.of(context)
// //                       .translate('discount_type') +
// //                       ' : '),
// //                   inLineDiscount(index),
// //                 ],
// //               )
// //                   : Container(),
// //             ],
// //           ),
// //           Row(
// //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //             children: <Widget>[
// //               (canEditDiscount)
// //                   ? SizedBox(
// //                 width: MySize.size160,
// //                 height: MySize.size50,
// //                 child: TextFormField(
// //                     initialValue: index['discount_amount'].toString(),
// //                     decoration: InputDecoration(
// //                       prefix: Text(symbol),
// //                       labelText: AppLocalizations.of(context)
// //                           .translate('discount_amount'),
// //                       border: themeData.inputDecorationTheme.border,
// //                       enabledBorder:
// //                       themeData.inputDecorationTheme.border,
// //                       focusedBorder:
// //                       themeData.inputDecorationTheme.focusedBorder,
// //                     ),
// //                     style: AppTheme.getTextStyle(
// //                         themeData.textTheme.subtitle2,
// //                         fontWeight: 400,
// //                         letterSpacing: -0.2),
// //                     textAlign: TextAlign.end,
// //                     inputFormatters: [
// //                       // ignore: deprecated_member_use
// //                       FilteringTextInputFormatter(
// //                           RegExp(r'^(\d+)?\.?\d{0,2}'),
// //                           allow: true)
// //                     ],
// //                     keyboardType: TextInputType.number,
// //                     onChanged: (newValue) {
// //                       double value = Helper().validateInput(newValue);
// //                       SellDatabase().update(
// //                           index['id'], {'discount_amount': '$value'});
// //                       cartList();
// //                     }),
// //               )
// //                   : Container(),
// //               Column(
// //                 crossAxisAlignment: CrossAxisAlignment.end,
// //                 children: [
// //                   Text(AppLocalizations.of(context).translate('tax') + ' : '),
// //                   inLineTax(index),
// //                 ],
// //               ),
// //             ],
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// //
// //   setTaxMap() {
// //     System().get('tax').then((value) {
// //       value.forEach((element) {
// //         taxListMap.add({
// //           'id': element['id'],
// //           'name': element['name'],
// //           'amount': double.parse(element['amount'].toString())
// //         });
// //       });
// //     });
// //   }
// //
// //   //inLine tax widget
// //   Widget inLineTax(index) {
// //     //['tax_rate_id'], index['variation_id']
// //     //taxId, varId
// //     return DropdownButtonHideUnderline(
// //       child: DropdownButton(
// //           dropdownColor: themeData.backgroundColor,
// //           icon: Icon(
// //             Icons.arrow_drop_down,
// //           ),
// //           value: (index['tax_rate_id'] != null) ? index['tax_rate_id'] : 0,
// //           items: taxListMap.map<DropdownMenuItem<int>>((Map value) {
// //             return DropdownMenuItem<int>(
// //                 value: value['id'],
// //                 child: Text(
// //                   value['name'],
// //                   softWrap: true,
// //                   overflow: TextOverflow.ellipsis,
// //                 ));
// //           }).toList(),
// //           onChanged: (newValue) {
// //             SellDatabase().update(index['id'],
// //                 {'tax_rate_id': (newValue == 0) ? null : newValue});
// //             cartList();
// //           }),
// //     );
// //   }
// //
// //   //inLine discount widget
// //   Widget inLineDiscount(index) {
// //     return DropdownButtonHideUnderline(
// //       child: DropdownButton(
// //           dropdownColor: themeData.backgroundColor,
// //           icon: Icon(
// //             Icons.arrow_drop_down,
// //           ),
// //           value: index['discount_type'],
// //           items: <String>['fixed', 'percentage']
// //               .map<DropdownMenuItem<String>>((String value) {
// //             return DropdownMenuItem<String>(
// //               value: value,
// //               child: Text(value),
// //             );
// //           }).toList(),
// //           onChanged: (newValue) {
// //             SellDatabase().update(index['id'], {'discount_type': '$newValue'});
// //             cartList();
// //           }),
// //     );
// //   }
// //
// //   //discount widget
// //   Widget discount() {
// //     return DropdownButtonHideUnderline(
// //       child: DropdownButton(
// //           dropdownColor: themeData.backgroundColor,
// //           icon: Icon(
// //             Icons.arrow_drop_down,
// //           ),
// //           value: selectedDiscountType,
// //           items: <String>['fixed', 'percentage']
// //               .map<DropdownMenuItem<String>>((String value) {
// //             return DropdownMenuItem<String>(
// //               value: value,
// //               child: Text(value),
// //             );
// //           }).toList(),
// //           onChanged: (newValue) {
// //             setState(() {
// //               selectedDiscountType = newValue.toString();
// //               calculateSubtotal(
// //                   selectedTaxId, selectedDiscountType, discountAmount);
// //             });
// //           }),
// //     );
// //   }
// //
// //   //dropdown tax widget
// //   Widget taxes() {
// //     return DropdownButtonHideUnderline(
// //       child: DropdownButton(
// //           dropdownColor: themeData.backgroundColor,
// //           icon: Icon(
// //             Icons.arrow_drop_down,
// //           ),
// //           value: selectedTaxId,
// //           items: taxListMap.map<DropdownMenuItem<int>>((Map value) {
// //             return DropdownMenuItem<int>(
// //                 value: value['id'],
// //                 child: Text(
// //                   value['name'],
// //                   softWrap: true,
// //                   overflow: TextOverflow.ellipsis,
// //                 ));
// //           }).toList(),
// //           onChanged: (newValue) {
// //             setState(() {
// //               selectedTaxId = int.parse(newValue.toString());
// //             });
// //           }),
// //     );
// //   }
// //
// //   //calculate inline total
// //   String calculateInlineUnitPrice(price, taxId, discountType, discountAmount) {
// //     double subTotal;
// //     var taxAmount;
// //     taxListMap.forEach((value) {
// //       if (value['id'] == taxId) {
// //         taxAmount = value['amount'];
// //       }
// //     });
// //     if (taxAmount == null) {
// //       taxAmount = 0;
// //     }
// //     if (discountType == 'fixed') {
// //       var unitPrice = price - discountAmount;
// //       subTotal = unitPrice + (unitPrice * taxAmount / 100);
// //     } else {
// //       var unitPrice = price - (price * discountAmount / 100);
// //       subTotal = unitPrice + (unitPrice * taxAmount / 100);
// //     }
// //     return subTotal.toString();
// //   }
// //
// //   //calculate subTotal
// //   double calculateSubTotal() {
// //     var subTotal = 0.0;
// //     cartItems.forEach((element) {
// //       subTotal += (double.parse(calculateInlineUnitPrice(
// //           element['unit_price'],
// //           element['tax_rate_id'],
// //           element['discount_type'],
// //           element['discount_amount'])) *
// //           element['quantity']);
// //     });
// //     return subTotal;
// //   }
// //
// //   //calculate total
// //   double calculateSubtotal(taxId, discountType, discountAmount) {
// //     double subTotal = calculateSubTotal();
// //     var finalTotal;
// //     var taxAmount;
// //     taxListMap.forEach((value) {
// //       if (value['id'] == taxId) {
// //         taxAmount = value['amount'];
// //       }
// //     });
// //
// //     if (taxAmount == null) {
// //       taxAmount = 0;
// //     }
// //     if (discountType == 'fixed') {
// //       var total = subTotal - discountAmount;
// //       finalTotal = total + (total * taxAmount / 100);
// //     } else {
// //       var total = subTotal - (subTotal * discountAmount / 100);
// //       finalTotal = total + (total * taxAmount / 100);
// //     }
// //     invoiceAmount = finalTotal;
// //     return finalTotal;
// //   }
// //
// //   //fetch default discount and tax from database
// //   getDefaultValues() async {
// //     var businessDetails = await System().get('business');
// //     await Helper().getFormattedBusinessDetails().then((value) {
// //       symbol = "${value['symbol']} ";
// //     });
// //     var userDetails = await System().get('loggedInUser');
// //     setState(() {
// //       if (userDetails['max_sales_discount_percent'] != null)
// //         maxDiscountValue =
// //             double.parse(userDetails['max_sales_discount_percent']);
// //     });
// //     if (sellDetail == null && businessDetails[0]['default_sales_tax'] != null) {
// //       setState(() {
// //         selectedTaxId =
// //             int.parse(businessDetails[0]['default_sales_tax'].toString());
// //       });
// //     }
// //     if (sellDetail == null &&
// //         businessDetails[0]['default_sales_discount'] != null) {
// //       setState(() {
// //         selectedDiscountType = 'percentage';
// //         discountAmount =
// //             double.parse(businessDetails[0]['default_sales_discount']);
// //         discountController.text = discountAmount.toString();
// //         print('getDefaultValues: Default discount_amount: $discountAmount'); // Add logging
// //         if (maxDiscountValue != null && discountAmount! > maxDiscountValue!) {
// //           Fluttertoast.showToast(
// //               msg: AppLocalizations.of(context)
// //                   .translate('discount_error_message') +
// //                   " $maxDiscountValue");
// //           proceedNext = false;
// //         }
// //       });
// //     }
// //   }
// //   //Fetch permission from database
// //   getPermission() async {
// //     canEditPrice =
// //     await Helper().getPermission("edit_product_price_from_pos_screen");
// //     canEditDiscount =
// //     await Helper().getPermission("edit_product_discount_from_pos_screen");
// //   }
// // }
// //
// //
// //

import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:dev/pages/login.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import '../helpers/AppTheme.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/otherHelpers.dart';
import '../helpers/context_manager.dart';
import '../locale/MyLocalizations.dart';
import '../apis/sell.dart';
import '../models/contact_model.dart';
import '../models/product_model.dart';
import '../models/sell.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import '../models/variations.dart';
import '../helpers/FirebaseTableLockService.dart';
import 'Tables.dart';
import 'elements.dart';

class Cart extends StatefulWidget {
  const Cart({super.key});

  @override
  CartState createState() => CartState();
}

//For Discount Limit Format
class DiscountLimitFormatter extends TextInputFormatter {
  final double max;

  DiscountLimitFormatter(this.max);

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue,
      TextEditingValue newValue,
      ) {
    // Allow empty input
    if (newValue.text.isEmpty) return newValue;

    try {
      final value = double.parse(newValue.text);
      if (value <= max) {
        return newValue;
      }
    } catch (_) {
      // ignore parse error and prevent invalid input
    }

    // Block input if over the limit
    return oldValue;
  }
}

class CartState extends State<Cart> {
  // Add this at the top of your CartState class
  String? _tableName;
  bool _isShipping = false;

  bool proceedNext = false, canEditPrice = false, canEditDiscount = false;
  int? selectedContactId, selectedTaxId = 0, sellingPriceGroupId = 0;
  int? editItem;
  double? maxDiscountValue, discountAmount = 0.0;
  List cartItems = [];
  Map? argument = {};
  int? sellId;
  int? selectedLocationId;
  int? res_table_id; // Added to store res_table_id
  int? is_shipping; // Added to store is_shipping
  String symbol = '';
  var sellDetail;
  String selectedDiscountType = "fixed";
  bool _isdiscount_amountEdited = false;
  final TextEditingController discountController = TextEditingController();
  final TextEditingController searchController = TextEditingController();

  // Track unsaved changes
  bool _hasUnsavedChanges = false;
  double _originalTotal = 0.0;

  // Track intentional cart deletions to prevent auto-restore
  bool _isIntentionalDeletion = false;

  //for perticuler product discount
  // final TextEditingController productdiscountController = TextEditingController();
  String selectedProductDiscountType = "fixed";

  //new added
  List<TextEditingController> quantityControllers = [];

  final List<Map<String, dynamic>> taxListMap = [
    {'id': 0, 'name': 'Tax rate', 'amount': 0}
  ];
  late final ThemeData themeData;
  late final CustomAppTheme customAppTheme;

  @override
  void initState() {
    super.initState();
    themeData = AppTheme.getThemeFromThemeMode(1);
    customAppTheme = AppTheme.getCustomAppTheme(1);
    getPermission();
    setTaxMap();
    getDefaultValues();
    getSellingPriceGroupId();

    //new changes add
    initQuantityControllers();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      cartList();
    });
  }

  //new added
  void initQuantityControllers() {
    quantityControllers = cartItems.map<TextEditingController>((item) {
      return TextEditingController(text: item['quantity'].toString());
    }).toList();
  }

  // Method to check for unsaved changes
  Future<bool> _checkForUnsavedChanges() async {
    if (sellId == null || sellId == 0) return false;
    print("data::");
    try {
      var originalSale = await SellDatabase().getSellBySellId(sellId!);
      if (originalSale.isNotEmpty) {
        var originalInvoiceAmount = originalSale[0]['invoice_amount'] ?? 0.0;
        var currentTotal = calculateSubTotal();

        // Check if there are any unsaved changes
        return (currentTotal - originalInvoiceAmount).abs() > 0.01;
      }
    } catch (e) {
      debugPrint('Error checking for unsaved changes: $e');
      log('Error checking for unsaved changes: $e');
    }
    return false;
  }

  // Method to save the original state when cart is loaded
  Future<void> _saveOriginalState() async {
    if (sellId != null && sellId != 0) {
      try {
        var originalSale = await SellDatabase().getSellBySellId(sellId!);
        if (originalSale.isNotEmpty) {
          _originalTotal = originalSale[0]['invoice_amount'] ?? 0.0;
          _hasUnsavedChanges = false;
        }
      } catch (e) {
        debugPrint('Error saving original state: $e');
      }
    }
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    argument =
        Map.from((ModalRoute.of(context)!.settings.arguments as Map?) ?? {});
    debugPrint('Cart: Received arguments: $argument');

    // Try to get context from arguments first, then fallback to saved context
    Map<String, dynamic>? contextData = argument?.cast<String, dynamic>();
    if (contextData == null ||
        contextData.isEmpty ||
        contextData['sellId'] == null ||
        contextData['locationId'] == null) {
      // Try to get saved context
      contextData = await ContextManager.getValidContext();
      if (contextData != null) {
        debugPrint('Cart: Using saved context: $contextData');
        // Update the argument with context data for consistency
        argument = contextData;
      }
    }

    // Normalize: support both 'locId' and 'locationId' without changing other code
    if (argument != null &&
        argument!['locationId'] == null &&
        argument!['locId'] != null) {
      argument!['locationId'] = argument!['locId'];
    }

    if (argument == null ||
        argument!['sellId'] == null ||
        argument!['locationId'] == null) {
      debugPrint('Cart: Invalid or missing arguments');
      debugPrint('Error: argument map is null in didChangeDependencies');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('invalid_arguments') ??
            'Invalid arguments',
        toastLength: Toast.LENGTH_SHORT,
      );
      Navigator.pop(context); // Go back if arguments are invalid
      return;
    }

    sellId = int.tryParse(argument!['sellId'].toString()) ?? 0;
    selectedLocationId = int.tryParse(
        (argument!['locationId'] ?? argument!['locId'] ?? '0')
            .toString()) ??
        0;

    res_table_id = argument!['res_table_id'];
    is_shipping = argument!['is_shipping'] ?? 0;

    //for display selected table name or shipping
    _tableName = argument!['tableName']; // Capture the table name
    _isShipping = is_shipping == 1; // Set shipping flag

    debugPrint(
        'Cart: Initialized with sellId $sellId, locationId $selectedLocationId, res_table_id: $res_table_id, is_shipping: $is_shipping');
    //debugPrint('Cart: Initialized with sellId $sellId, locationId $selectedLocationId');

    debugPrint('didChangeDependencies: Argument map: $argument');
    if (argument!['sellId'] != null) {
      editCart(argument!['sellId']);
    }
    cartList();
  }

  @override
  void dispose() {
    discountController.dispose();
    searchController.dispose();
    super.dispose();
  }

  // Save cart data before navigation to preserve cart state
  Future<void> saveCartDataBeforeNavigation() async {
    if (sellId != null && sellId! > 0) {
      try {
        Map<String, dynamic> cartData = {
          'cartItems': cartItems,
          'res_table_id': res_table_id,
          'is_shipping': is_shipping,
          'tableName': _tableName,
          'discountType': selectedDiscountType,
          'discountAmount': discountAmount,
          'taxId': selectedTaxId,
          'selectedContactId': selectedContactId,
          'sellingPriceGroupId': sellingPriceGroupId,
        };

        await Helper.saveCartData(sellId!, cartData);
        debugPrint('Cart data saved before navigation for sellId: $sellId');

        // // Update the sell record with discount information
        // await updateSellRecordWithDiscount();
      } catch (e) {
        debugPrint('Error saving cart data before navigation: $e');
      }
    }
  }

  // Update the sell record with discount information
  Future<void> updateSellRecordWithDiscount() async {
    if (sellId != null && sellId! > 0) {
      try {
        // Calculate the base total with discount (excluding tip and shipping)
        double baseTotal = calculateSubtotal(
            selectedTaxId, selectedDiscountType, discountAmount ?? 0.0);

        // Get tip and shipping charges from the current cart data
        double tipAmount = 0.0;
        double shippingCharges = 0.0;

        // Get tip and shipping from the sell record if available
        try {
          List<Map<String, dynamic>> sellRecords =
          await SellDatabase().getSellBySellId(sellId!);
          if (sellRecords.isNotEmpty) {
            tipAmount = sellRecords.first['tip_amount']?.toDouble() ?? 0.0;
            shippingCharges =
                sellRecords.first['shipping_charges']?.toDouble() ?? 0.0;
          }
        } catch (e) {
          debugPrint('Cart: Error getting tip and shipping charges: $e');
        }

        // Calculate total amount including tip and shipping charges
        // This ensures consistency with updateInvoiceAmountFromCart method
        double totalAmountWithTipAndShipping =
            baseTotal + tipAmount + shippingCharges;

        // Update the sell record with discount information and final total
        await SellDatabase().updateSells(sellId!, {
          'discount_amount': discountAmount ?? 0.0,
          'discount_type': selectedDiscountType,
          'invoice_amount':
          totalAmountWithTipAndShipping, // Include tip and shipping for consistency
          'pending_amount': totalAmountWithTipAndShipping,
        });

        debugPrint(
            'Cart: Updated sell record - sellId=$sellId, discountAmount=${discountAmount ?? 0.0}, discountType=$selectedDiscountType, baseTotal=$baseTotal, tip=$tipAmount, shipping=$shippingCharges, totalAmount=$totalAmountWithTipAndShipping');
      } catch (e) {
        debugPrint('Cart: Error updating sell record with discount: $e');
      }
    }
  }

  // Clear cart data when sale is completed
  Future<void> clearCartDataAfterCompletion() async {
    if (sellId != null && sellId! > 0) {
      try {
        await Helper.removeCartData(sellId!);
        debugPrint('Cart data cleared after completion for sellId: $sellId');
      } catch (e) {
        debugPrint('Error clearing cart data after completion: $e');
      }
    }
  }

  // Future<void> handleMissingCartData(int sellId) async {
  //   try {
  //     // Try to load saved cart data
  //     Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId);
  //
  //     if (savedCartData != null) {
  //       debugPrint('handleMissingCartData: Restoring cart from saved data for sellId: $sellId');
  //
  //       // Update res_table_id and is_shipping from saved data
  //       res_table_id = savedCartData['res_table_id'];
  //       is_shipping = savedCartData['is_shipping'];
  //       _tableName = savedCartData['tableName'];
  //       _isShipping = is_shipping == 1;
  //
  //       // Restore other cart settings
  //       selectedDiscountType = savedCartData['discountType'] ?? 'fixed';
  //       discountAmount = savedCartData['discountAmount']?.toDouble() ?? 0.0;
  //       selectedTaxId = savedCartData['taxId'] ?? 0;
  //       discountController.text = discountAmount?.toStringAsFixed(2) ?? '0.00';
  //
  //       // Restore cart items from saved data
  //       if (savedCartData['cartItems'] != null && savedCartData['cartItems'].isNotEmpty) {
  //         debugPrint('handleMissingCartData: Restoring ${savedCartData['cartItems'].length} cart items');
  //
  //         // Clear existing cart items
  //         await SellDatabase().deleteSellLineBySellId(sellId);
  //
  //         // Add saved items back to cart
  //         for (var item in savedCartData['cartItems']) {
  //           await SellDatabase().store({
  //             'sell_id': sellId,
  //             'product_id': item['product_id'],
  //             'variation_id': item['variation_id'],
  //             'quantity': item['quantity'],
  //             'unit_price': item['unit_price'],
  //             'tax_rate_id': item['tax_rate_id'],
  //             'discount_amount': item['discount_amount'] ?? 0.0,
  //             'discount_type': item['discount_type'] ?? 'fixed',
  //             'note': item['note'] ?? '',
  //             'is_completed': 0,
  //             'product_order_category': item['product_order_category'] ?? 'BAR',
  //             'res_table_id': res_table_id,
  //             'is_shipping': is_shipping,
  //           });
  //         }
  //       }
  //
  //       // Refresh cart items
  //       await cartList();
  //
  //       calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount);
  //       if (mounted) {
  //         setState(() {});
  //       }
  //     } else {
  //       debugPrint('handleMissingCartData: No saved cart data found for sellId: $sellId');
  //       Fluttertoast.showToast(
  //         msg: AppLocalizations.of(context).translate('no_items_found_for_sale'),
  //         toastLength: Toast.LENGTH_SHORT,
  //       );
  //     }
  //   } catch (e) {
  //     debugPrint('Error in handleMissingCartData: $e');
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context).translate('error_loading_cart_data'),
  //       toastLength: Toast.LENGTH_SHORT,
  //     );
  //   }
  // }
  // In Cart.dart, modify the handleMissingCartData method

  Future<void> handleMissingCartData(int sellId) async {
    try {
      // CRITICAL: Get res_table_id from database sale record first to ensure consistency
      var sellRecord = await SellDatabase().getSellBySellId(sellId);
      int? dbResTableId;
      int dbIsShipping = 0;

      if (sellRecord.isNotEmpty) {
        dbResTableId = sellRecord[0]['res_table_id'];
        dbIsShipping = sellRecord[0]['is_shipping'] ?? 0;
        debugPrint(
            'handleMissingCartData: Got res_table_id=$dbResTableId, is_shipping=$dbIsShipping from database');
      }

      // Try to load saved cart data
      Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId);

      if (savedCartData != null) {
        debugPrint(
            'handleMissingCartData: Restoring cart from saved data for sellId: $sellId');

        // CRITICAL: Use database res_table_id if available, otherwise use saved data
        res_table_id = dbResTableId ?? savedCartData['res_table_id'];
        is_shipping = dbIsShipping != 0 ? dbIsShipping : (savedCartData['is_shipping'] ?? 0);
        _tableName = savedCartData['tableName'];
        _isShipping = is_shipping == 1;

        debugPrint(
            'handleMissingCartData: Using res_table_id=$res_table_id, is_shipping=$is_shipping');

        // Restore other cart settings
        selectedDiscountType = savedCartData['discountType'] ?? 'fixed';
        discountAmount = savedCartData['discountAmount']?.toDouble() ?? 0.0;
        selectedTaxId = savedCartData['taxId'] ?? 0;
        discountController.text = discountAmount?.toStringAsFixed(2) ?? '0.00';

        // Restore cart items from saved data
        if (savedCartData['cartItems'] != null &&
            savedCartData['cartItems'].isNotEmpty) {
          debugPrint(
              'handleMissingCartData: Restoring ${savedCartData['cartItems'].length} cart items');

          // Clear existing cart items for this sellId
          await SellDatabase().deleteSellLineBySellId(sellId);

          // Add saved items back to cart with CORRECT res_table_id from database
          for (var item in savedCartData['cartItems']) {
            await SellDatabase().store({
              'sell_id': sellId,
              'product_id': item['product_id'],
              'variation_id': item['variation_id'],
              'quantity': item['quantity'],
              'unit_price': item['unit_price'],
              'tax_rate_id': item['tax_rate_id'],
              'discount_amount': item['discount_amount'] ?? 0.0,
              'discount_type': item['discount_type'] ?? 'fixed',
              'note': item['note'] ?? '',
              'is_completed': 0,
              'product_order_category': item['product_order_category'] ?? 'BAR',
              'res_table_id': res_table_id, // Use database res_table_id, not saved data
              'is_shipping': is_shipping, // Use database is_shipping, not saved data
            });
          }
        }

        // Ensure no duplicate items in cart
        await SellDatabase().ensureNoDuplicateCartItems(sellId, res_table_id);

        // CRITICAL: Update saved cart data with correct res_table_id from database
        // This ensures future restorations use the correct value
        Map<String, dynamic> updatedCartData = {
          ...savedCartData,
          'res_table_id': res_table_id,
          'is_shipping': is_shipping,
        };
        await Helper.saveCartData(sellId, updatedCartData);
        debugPrint(
            'handleMissingCartData: Updated saved cart data with res_table_id=$res_table_id, is_shipping=$is_shipping');

        // Refresh cart items
        await cartList();

        calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount);
        if (mounted) {
          setState(() {});
        }
      } else {
        debugPrint(
            'handleMissingCartData: No saved cart data found for sellId: $sellId');

        // Try to fetch from API if no saved data found
        await fetchSaleDataFromAPI(sellId);
      }
    } catch (e) {
      debugPrint('Error in handleMissingCartData: $e');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_loading_cart_data'),
        toastLength: Toast.LENGTH_SHORT,
      );
    }
  }

  Future<void> fetchSaleDataFromAPI(int sellId) async {
    try {
      // Get sell details to find transaction_id
      var sellDetails = await SellDatabase().getSellBySellId(sellId);
      if (sellDetails.isEmpty || sellDetails[0]['transaction_id'] == null) {
        debugPrint(
            'fetchSaleDataFromAPI: No transaction_id found for sellId: $sellId');
        return;
      }

      // Check connectivity
      if (!await Helper().checkConnectivity()) {
        debugPrint('fetchSaleDataFromAPI: No internet connection');
        return;
      }

      debugPrint(
          'fetchSaleDataFromAPI: Fetching sale data from API for transaction_id: ${sellDetails[0]['transaction_id']}');

      // Show loading dialog
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Center(
          child: AlertDialog(
            content: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
                SizedBox(width: 20),
                Text(AppLocalizations.of(context).translate('loading'),
                    style: TextStyle(color: Colors.black)),
              ],
            ),
          ),
        ),
      );

      // Fetch sale details from API
      List specificSales =
      await SellApi().getSpecifiedSells([sellDetails[0]['transaction_id']]);

      if (specificSales.isNotEmpty) {
        var element = specificSales[0];

        // Delete existing lines to avoid duplicates
        await SellDatabase().deleteSellLineBySellId(sellId);

        // Store fresh lines from API with is_completed: 0 for editing
        for (var value in element['sell_lines']) {
          await SellDatabase().store({
            'sell_id': sellId,
            'product_id': value['product_id'],
            'variation_id': value['variation_id'],
            'quantity': value['quantity'],
            'unit_price': value['unit_price_before_discount'],
            'tax_rate_id': value['tax_id'],
            'discount_amount': value['line_discount_amount'],
            'discount_type': value['line_discount_type'],
            'note': value['sell_line_note'],
            'is_completed': 0, // Mark as incomplete/editable
            'product_order_category': value['product_order_category'] ?? 'BAR',
            'res_table_id': sellDetails[0]['res_table_id'] ?? res_table_id,
            'is_shipping': sellDetails[0]['is_shipping'] ?? 0,
          });
        }

        // Update res_table_id and is_shipping from sell details
        res_table_id = sellDetails[0]['res_table_id'];
        is_shipping = sellDetails[0]['is_shipping'] ?? 0;
        _tableName = argument?['tableName'];
        _isShipping = is_shipping == 1;

        // Update other settings from sell details
        selectedDiscountType = sellDetails[0]['discount_type'] ?? 'fixed';
        discountAmount = sellDetails[0]['discount_amount']?.toDouble() ?? 0.0;
        selectedTaxId = sellDetails[0]['tax_rate_id'] ?? 0;
        discountController.text = discountAmount?.toStringAsFixed(2) ?? '0.00';

        // Close loading dialog
        Navigator.pop(context);

        // Refresh cart items
        await cartList();

        calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount);
        if (mounted) {
          setState(() {});
        }

        Fluttertoast.showToast(
            msg: AppLocalizations.of(context)
                .translate('sale_data_loaded_from_server'));
      } else {
        Navigator.pop(context);
        debugPrint('fetchSaleDataFromAPI: No data received from API');
      }
    } catch (e) {
      if (Navigator.canPop(context)) {
        Navigator.pop(context);
      }
      debugPrint('Error in fetchSaleDataFromAPI: $e');
      Fluttertoast.showToast(
          msg: AppLocalizations.of(context)
              .translate('error_loading_sale_data'));
    }
  }

  Future<void> cartList() async {
    try {
      argument = ModalRoute.of(context)!.settings.arguments as Map?;
      selectedLocationId =
          int.tryParse(argument?['locationId']?.toString() ?? '0') ?? 0;

      cartItems = [];
      final locationId =
          int.tryParse(argument!['locationId']?.toString() ?? '0') ?? 0;
      final sellId = int.tryParse(argument!['sellId']?.toString() ?? '');

      // CRITICAL: Get res_table_id from database first to ensure consistency
      if (sellId != null && sellId != 0) {
        var sellRecord = await SellDatabase().getSellBySellId(sellId);
        if (sellRecord.isNotEmpty) {
          res_table_id = sellRecord[0]['res_table_id'];
          is_shipping = sellRecord[0]['is_shipping'] ?? 0;
          debugPrint(
              'Cart.cartList: Got res_table_id=$res_table_id, is_shipping=$is_shipping from database for sellId=$sellId');

          // Update arguments to match database
          argument!['res_table_id'] = res_table_id;
          argument!['is_shipping'] = is_shipping;
        } else {
          res_table_id = argument?['res_table_id'];
          is_shipping = argument?['is_shipping'] ?? 0;
        }
      } else {
        res_table_id = argument?['res_table_id'];
        is_shipping = argument?['is_shipping'] ?? 0;
      }

      debugPrint(
          'Cart: Initialized with sellId $sellId, locationId $selectedLocationId, res_table_id: $res_table_id');
      //await SellDatabase().verifySellData(sellId!);

      if (sellId != 0) {
        await SellDatabase().verifySellData(sellId!);

        // FIXED: When editing, include both completed (existing) and incomplete (new) items
        // Use getSellLineBySellId with includeCompleted: true to get all products
        List<Map> allItems = await SellDatabase().getSellLineBySellId(
          sellId!,
          res_table_id: res_table_id,
          includeCompleted: true, // Include both existing (completed) and new (incomplete) items
        );

        debugPrint('Cart: Loaded ${allItems.length} total items (including completed) for sellId: $sellId, res_table_id: $res_table_id');

        // FIXED: Enrich items with variation data (name, display_name) from variations table
        // getSellLineBySellId doesn't join with variations, so we need to enrich the data
        List<Map> enrichedItems = [];
        final sellDb = SellDatabase();
        final db = await sellDb.database;

        for (var item in allItems) {
          try {
            // Get variation data to enrich the item
            var variationData = await db.query(
              'variations',
              where: 'variation_id = ?',
              whereArgs: [item['variation_id']],
              limit: 1,
            );

            if (variationData.isNotEmpty) {
              // Enrich item with variation data
              Map<String, dynamic> enrichedItem = Map<String, dynamic>.from(item);
              enrichedItem['name'] = (variationData[0]['display_name'] ?? variationData[0]['name'] ?? '').toString();
              enrichedItem['display_name'] = (variationData[0]['display_name'] ?? variationData[0]['name'] ?? '').toString();
              enrichedItem['sell_price_inc_tax'] = variationData[0]['sell_price_inc_tax'] ?? item['unit_price'] ?? 0.0;
              enrichedItem['sub_sku'] = (variationData[0]['sub_sku'] ?? '').toString();
              enrichedItems.add(enrichedItem);
            } else {
              // If variation not found, use item as-is but add empty name fields to prevent null errors
              Map<String, dynamic> enrichedItem = Map<String, dynamic>.from(item);
              enrichedItem['name'] = enrichedItem['name']?.toString() ?? '';
              enrichedItem['display_name'] = enrichedItem['display_name']?.toString() ?? '';
              enrichedItems.add(enrichedItem);
            }
          } catch (e) {
            debugPrint('Cart: Error enriching item ${item['variation_id']}: $e');
            // Add item with safe defaults to prevent null errors
            Map<String, dynamic> enrichedItem = Map<String, dynamic>.from(item);
            enrichedItem['name'] = enrichedItem['name']?.toString() ?? '';
            enrichedItem['display_name'] = enrichedItem['display_name']?.toString() ?? '';
            enrichedItems.add(enrichedItem);
          }
        }

        // When editing, show all items (both existing completed items and new incomplete items)
        // Filter to prioritize incomplete items, but include completed items too
        List<Map> incompleteItems = enrichedItems.where((item) => item['is_completed'] == 0).toList();
        List<Map> completedItems = enrichedItems.where((item) => item['is_completed'] == 1).toList();

        debugPrint('Cart: Found ${incompleteItems.length} incomplete items and ${completedItems.length} completed items');

        // Combine both incomplete and completed items for editing
        cartItems = [...incompleteItems, ...completedItems];

        // If still no items, try getInCompleteLines as fallback
        if (cartItems.isEmpty) {
          cartItems = await SellDatabase().getInCompleteLines(selectedLocationId!,
              sellId: sellId, resTableId: res_table_id);
          debugPrint('Cart: Fallback to getInCompleteLines returned ${cartItems.length} items');
        }

        print(">>>>>>>>${cartItems.length}:::${res_table_id}");
        // If no cart items found, try to restore from saved data or fetch from API
        // BUT: Skip restoration if the cart is intentionally empty (due to user deletion)
        if (cartItems.isEmpty && sellId != null && !_isIntentionalDeletion) {
          await handleMissingCartData(sellId);
          return;
        }

        // Reset the intentional deletion flag after processing
        if (_isIntentionalDeletion) {
          _isIntentionalDeletion = false;
          debugPrint(
              'Cart: Reset intentional deletion flag after processing empty cart');
        }
      } else {
        cartItems = await SellDatabase().getInCompleteLines(selectedLocationId!,
            resTableId: res_table_id); //res_table_id added
      }
      debugPrint(
          'Cart.cartList: Loaded ${cartItems.length} items for sellId $sellId, res_table_id $res_table_id: ${jsonEncode(cartItems)}');

      // Unlock table in Firebase if cart becomes empty (all products deleted)
      final tableIdForUnlock = res_table_id;
      final locationIdForUnlock = selectedLocationId;
      if (cartItems.isEmpty && tableIdForUnlock != null && tableIdForUnlock > 0 && (is_shipping == null || is_shipping == 0) && locationIdForUnlock != null && locationIdForUnlock > 0) {
        try {
          await FirebaseTableLockService().unlockTable(
            tableId: tableIdForUnlock,
            locationId: locationIdForUnlock,
          );
          debugPrint('Cart: Unlocked table $tableIdForUnlock in Firebase - cart is empty');
        } catch (e) {
          debugPrint('Cart: Error unlocking table in Firebase: $e');
        }
      }

      // Save original state when cart is loaded
      if (sellId != null && sellId != 0) {
        await _saveOriginalState();
      }

      // //new added
      // quantityControllers = List.generate(cartItems.length, (index) {
      //   return TextEditingController(
      //     text: cartItems[index]['quantity'].toString(),
      //   );
      // });
      if (quantityControllers.length != cartItems.length) {
        quantityControllers = List.generate(cartItems.length, (index) {
          return TextEditingController(
            text: cartItems[index]['quantity'].toString(),
          );
        });
      } else {
        // Only update the text if needed
        for (int i = 0; i < cartItems.length; i++) {
          if (quantityControllers[i].text !=
              cartItems[i]['quantity'].toString()) {
            quantityControllers[i].text = cartItems[i]['quantity'].toString();
          }
        }
      }

      if (mounted) {
        setState(() {
          if (editItem == null) {
            proceedNext = true;
          }
        });
      }
    } catch (e) {
      debugPrint('Error in cartList: $e');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_loading_cart') ??
            'Error loading cart',
        toastLength: Toast.LENGTH_SHORT,
      );
    }
  }

  // Future<void> editCart(int sellId) async {
  //   try {
  //     sellDetail = await SellDatabase().getSellBySellId(sellId);
  //     debugPrint(
  //         'editCart: Fetched sellDetail for sellId: $sellId, data: $sellDetail');
  //     if (sellDetail.isNotEmpty) {
  //       selectedTaxId = sellDetail[0]['tax_rate_id'] ?? 0;
  //       selectedContactId = sellDetail[0]['contact_id'];
  //       selectedDiscountType = sellDetail[0]['discount_type'] ?? 'fixed';
  //       discountAmount = sellDetail[0]['discount_amount']?.toDouble() ?? 0.0;
  //       discountController.text = discountAmount?.toStringAsFixed(2) ?? '0.00';
  //       calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount);
  //       if (mounted) {
  //         setState(() {});
  //       }
  //     } else {
  //       debugPrint('editCart: No sell data found for sellId: $sellId');
  //     }
  //   } catch (e) {
  //     debugPrint('Error in editCart: $e');
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context).translate('error_loading_sell') ??
  //           'Error loading sell details',
  //       toastLength: Toast.LENGTH_SHORT,
  //     );
  //   }
  // }
// In Cart.dart, modify the editCart method

  // Future<void> editCart(int sellId) async {
  //   try {
  //     sellDetail = await SellDatabase().getSellBySellId(sellId);
  //     debugPrint(
  //         'editCart: Fetched sellDetail for sellId: $sellId, data: $sellDetail');
  //
  //     if (sellDetail.isNotEmpty) {
  //       selectedTaxId = sellDetail[0]['tax_rate_id'] ?? 0;
  //       selectedContactId = sellDetail[0]['contact_id'];
  //       selectedDiscountType = sellDetail[0]['discount_type'] ?? 'fixed';
  //       discountAmount = sellDetail[0]['discount_amount']?.toDouble() ?? 0.0;
  //       discountController.text = discountAmount?.toStringAsFixed(2) ?? '0.00';
  //
  //       // Try to load saved cart data
  //       Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId);
  //
  //       if (savedCartData != null) {
  //         debugPrint('editCart: Loaded saved cart data for sellId: $sellId');
  //
  //         // Restore cart items from saved data
  //         if (savedCartData['cartItems'] != null) {
  //           // Clear existing cart items
  //           await SellDatabase().deleteSellLineBySellId(sellId);
  //
  //           // Add saved items back to cart
  //           for (var item in savedCartData['cartItems']) {
  //             await SellDatabase().store({
  //               'sell_id': sellId,
  //               'product_id': item['product_id'],
  //               'variation_id': item['variation_id'],
  //               'quantity': item['quantity'],
  //               'unit_price': item['unit_price'],
  //               'tax_rate_id': item['tax_rate_id'],
  //               'discount_amount': item['discount_amount'] ?? 0.0,
  //               'discount_type': item['discount_type'] ?? 'fixed',
  //               'note': item['note'] ?? '',
  //               'is_completed': 0,
  //               'product_order_category': item['product_order_category'] ?? 'BAR',
  //               'res_table_id': savedCartData['res_table_id'],
  //             });
  //           }
  //         }
  //
  //         // Restore other cart settings
  //         selectedDiscountType = savedCartData['discountType'] ?? 'fixed';
  //         discountAmount = savedCartData['discountAmount']?.toDouble() ?? 0.0;
  //         selectedTaxId = savedCartData['taxId'] ?? 0;
  //         discountController.text = discountAmount?.toStringAsFixed(2) ?? '0.00';
  //
  //         // Update res_table_id and is_shipping from saved data
  //         res_table_id = savedCartData['res_table_id'];
  //         is_shipping = savedCartData['is_shipping'];
  //         _tableName = savedCartData['tableName'];
  //         _isShipping = is_shipping == 1;
  //       }
  //
  //       // Refresh cart items
  //       await cartList();
  //
  //       calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount);
  //       if (mounted) {
  //         setState(() {});
  //       }
  //     } else {
  //       debugPrint('editCart: No sell data found for sellId: $sellId');
  //     }
  //   } catch (e) {
  //     debugPrint('Error in editCart: $e');
  //     Fluttertoast.showToast(
  //       msg: AppLocalizations.of(context).translate('error_loading_sell') ??
  //           'Error loading sell details',
  //       toastLength: Toast.LENGTH_SHORT,
  //     );
  //   }
  // }
// In Cart.dart, modify the editCart method

  Future<void> editCart(int sellId) async {
    try {
      sellDetail = await SellDatabase().getSellBySellId(sellId);
      debugPrint(
          'editCart: Fetched sellDetail for sellId: $sellId, data: $sellDetail');

      if (sellDetail.isNotEmpty) {
        selectedTaxId = sellDetail[0]['tax_rate_id'] ?? 0;
        selectedContactId = sellDetail[0]['contact_id'];
        selectedDiscountType = sellDetail[0]['discount_type'] ?? 'fixed';
        discountAmount = sellDetail[0]['discount_amount']?.toDouble() ?? 0.0;
        discountController.text = discountAmount?.toStringAsFixed(2) ?? '0.00';
        // Reset the discount field edit flag when loading quotation for update
        _isdiscount_amountEdited = true;

        // CRITICAL: Get res_table_id from database sale record to ensure consistency
        int? dbResTableId = sellDetail[0]['res_table_id'];
        int dbIsShipping = sellDetail[0]['is_shipping'] ?? 0;

        if (dbResTableId != null) {
          res_table_id = dbResTableId;
          is_shipping = dbIsShipping;
          _isShipping = dbIsShipping == 1;
          debugPrint(
              'editCart: Updated res_table_id=$res_table_id, is_shipping=$is_shipping from database');

          // Update arguments to match database
          if (argument != null) {
            argument!['res_table_id'] = res_table_id;
            argument!['is_shipping'] = is_shipping;
          }
        }

        // FIXED: Always check for existing sell lines (both completed and incomplete) using database res_table_id
        final existingItems = await SellDatabase().getSellLineBySellId(
          sellId,
          res_table_id: res_table_id,
          includeCompleted: true, // Include both existing (completed) and new (incomplete) items
        );

        // If we have existing items, use them and skip API/saved data restore
        if (existingItems.isNotEmpty) {
          debugPrint(
              'editCart: Existing DB lines found (${existingItems.length} total, including completed); using existing data');

          // Refresh cart items to show all items (both completed and incomplete)
          await cartList();

          calculateSubtotal(
              selectedTaxId, selectedDiscountType, discountAmount);
          if (mounted) setState(() {});
          return;
        }

        debugPrint(
            'editCart: No existing DB lines found, will try to restore from saved data or API');

        // Try to load saved cart data
        Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId);

        if (savedCartData != null) {
          debugPrint('editCart: Loaded saved cart data for sellId: $sellId');

          // CRITICAL: Use database res_table_id (already set above), not saved data
          // res_table_id and is_shipping are already set from database above
          _tableName = savedCartData['tableName'];
          _isShipping = is_shipping == 1;

          debugPrint(
              'editCart: Using res_table_id=$res_table_id, is_shipping=$is_shipping from database (not saved data)');

          // Restore other cart settings
          selectedDiscountType = savedCartData['discountType'] ?? 'fixed';
          discountAmount = savedCartData['discountAmount']?.toDouble() ?? 0.0;
          selectedTaxId = savedCartData['taxId'] ?? 0;
          discountController.text =
              discountAmount?.toStringAsFixed(2) ?? '0.00';

          // Restore cart items from saved data
          if (savedCartData['cartItems'] != null &&
              savedCartData['cartItems'].isNotEmpty) {
            debugPrint(
                'editCart: Restoring ${savedCartData['cartItems'].length} cart items');

            // Clear existing cart items
            await SellDatabase().deleteSellLineBySellId(sellId);

            // Add saved items back to cart with CORRECT res_table_id from database
            for (var item in savedCartData['cartItems']) {
              await SellDatabase().store({
                'sell_id': sellId,
                'product_id': item['product_id'],
                'variation_id': item['variation_id'],
                'quantity': item['quantity'],
                'unit_price': item['unit_price'],
                'tax_rate_id': item['tax_rate_id'],
                'discount_amount': item['discount_amount'] ?? 0.0,
                'discount_type': item['discount_type'] ?? 'fixed',
                'note': item['note'] ?? '',
                'is_completed': 0,
                'product_order_category':
                item['product_order_category'] ?? 'BAR',
                'res_table_id': res_table_id, // Use database res_table_id, not saved data
                'is_shipping': is_shipping, // Use database is_shipping, not saved data
              });
            }
          }
        } else {
          debugPrint('editCart: No saved cart data found for sellId: $sellId');

          // Try to fetch from API if no saved data found
          await fetchSaleDataFromAPI(sellId);
        }

        // Ensure no duplicate items in cart
        await SellDatabase().ensureNoDuplicateCartItems(sellId, res_table_id);

        // CRITICAL: Update saved cart data with correct res_table_id from database
        // This ensures future restorations use the correct value
        if (savedCartData != null) {
          Map<String, dynamic> updatedCartData = {
            ...savedCartData,
            'res_table_id': res_table_id,
            'is_shipping': is_shipping,
          };
          await Helper.saveCartData(sellId, updatedCartData);
          debugPrint(
              'editCart: Updated saved cart data with res_table_id=$res_table_id, is_shipping=$is_shipping');
        }

        // Refresh cart items
        await cartList();

        calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount);
        if (mounted) {
          setState(() {});
        }
      } else {
        debugPrint('editCart: No sell data found for sellId: $sellId');
      }
    } catch (e) {
      debugPrint('Error in editCart: $e');
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('error_loading_sell') ??
            'Error loading sell details',
        toastLength: Toast.LENGTH_SHORT,
      );
    }
  }

  getPermission() async {
    canEditPrice =
    await Helper().getPermission("edit_product_price_from_pos_screen");
    canEditDiscount =
    await Helper().getPermission("edit_product_discount_from_pos_screen");
    debugPrint(
        'getPermission: canEditPrice=$canEditPrice, canEditDiscount=$canEditDiscount');
  }

  Future<void> setTaxMap() async {
    try {
      final taxes = await System().get('tax_rate',
          int.tryParse(argument?['locationId']?.toString() ?? '0') ?? 0);
      if (mounted) {
        setState(() {
          taxListMap.clear();
          taxListMap.add({'id': 0, 'name': 'Tax rate', 'amount': 0});
          for (var element in taxes) {
            taxListMap.add({
              'id': element['id'],
              'name': element['name'],
              'amount': element['amount'],
            });
          }
          debugPrint('setTaxMap: Loaded ${taxListMap.length} tax rates');
        });
      }
    } catch (e) {
      debugPrint('Error in setTaxMap: $e');
    }
  }

  Future<void> getDefaultValues() async {
    try {
      final value = await Helper().getFormattedBusinessDetails();
      if (mounted) {
        setState(() {
          symbol = value['symbol'] ?? '';
          debugPrint('getDefaultValues: Currency symbol set to $symbol');
        });
      }
    } catch (e) {
      debugPrint('Error in getDefaultValues: $e');
    }
  }

  Future<void> getSellingPriceGroupId() async {
    try {
      final value = await System().get('location');
      final locationId =
          int.tryParse(argument!['locationId']?.toString() ?? '0') ?? 0;
      for (var element in value) {
        if (element['id'] == locationId &&
            element['selling_price_group_id'] != null) {
          sellingPriceGroupId =
              int.parse(element['selling_price_group_id'].toString());
          debugPrint(
              'getSellingPriceGroupId: Set sellingPriceGroupId to $sellingPriceGroupId for locationId: $locationId');
        }
      }
    } catch (e) {
      debugPrint('Error in getSellingPriceGroupId: $e');
    }
  }

  Future<int?> getDefaultCustomerId() async {
    List customers = await Contact().get();
    for (var value in customers) {
      if (value['name'] == 'Walk-In Customer') {
        return value['id'];
      }
    }
    Fluttertoast.showToast(
        msg: AppLocalizations.of(context)
            .translate('no_walk_in_customer_found') ??
            'No Walk-In Customer found');
    return null;
  }

  // addQuotation() async {
  //   debugPrint(
  //       'addQuotation: Starting for sellId=$sellId, res_table_id=$res_table_id');
  //   var contactId = await getDefaultCustomerId();
  //   if (contactId == null) return;
  //   String transactionDate =
  //   DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now());
  //   Map sell = await Sell().createSell(
  //     changeReturn: 0.00,
  //     transactionDate: transactionDate,
  //     pending: calculateSubtotal(
  //         selectedTaxId, selectedDiscountType, discountAmount),
  //     shippingCharges: 0.00,
  //     shippingDetails: '',
  //     invoiceNo:
  //     USERID.toString() + "_" + DateFormat('yMdHm').format(DateTime.now()),
  //     contactId: contactId,
  //     discountAmount: discountAmount,
  //     discountType: selectedDiscountType,
  //     invoiceAmount: calculateSubtotal(
  //         selectedTaxId, selectedDiscountType, discountAmount),
  //     locId: selectedLocationId,
  //     saleStatus: 'draft',
  //     sellId: sellId,
  //     taxId: selectedTaxId,
  //     tip_amount: 0.00,
  //     isQuotation: 1,
  //     res_table_id: res_table_id,
  //   );
  //   debugPrint('addQuotation: Created sell map: ${jsonEncode(sell)}');
  //   // Navigate to Customer screen with isQuotationFlow flag
  //   Navigator.pushNamed(context, '/customer',
  //       arguments: Helper().argument(
  //         res_table_id: res_table_id ?? 0,
  //         is_shipping: is_shipping ?? (res_table_id == 0 ? 1 : 0),
  //         tableName: argument!['tableName'], // Pass the table name
  //         locId: argument!['locationId'],
  //         taxId: selectedTaxId,
  //         discountType: selectedDiscountType,
  //         discountAmount: discountAmount,
  //         invoiceAmount: calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount),
  //         sellId: argument!['sellId'],
  //         isQuotation: 1,
  //         customerId: sellId != null ? selectedContactId : null,
  //         clearFields: null,
  //         isQuotationFlow: true, // Add this flag
  //         products: cartItems
  //             .map((item) => {
  //           'product_id': item['product_id'],
  //           'variation_id': item['variation_id'],
  //           'quantity': item['quantity'],
  //           'unit_price': item['unit_price'],
  //           'tax_rate_id': item['tax_rate_id'],
  //           'discount_amount': item['discount_amount'] ?? 0.0,
  //           'discount_type': item['discount_type'] ?? 'fixed',
  //           'note': item['note'] ?? '',
  //           'product_order_category':
  //           item['product_order_category'] ?? 'BAR',
  //         })
  //             .toList(),
  //       ));
  //   //confirmDialog(sell);
  // }
  // Apply all pending discount changes to database
  Future<void> applyPendingDiscountChanges() async {
    try {
      debugPrint(
          'applyPendingDiscountChanges: Applying cart-level discount changes');

      // Apply cart-level discount changes
      await updateSellRecordWithDiscount();

      // Apply product-level discount changes for all cart items
      for (var item in cartItems) {
        debugPrint(
            'applyPendingDiscountChanges: Applying product discount for item ${item['id']}');

        // Get current discount values from the UI controllers or item data
        double discountAmount = 0.0;
        String discountType = item['discount_type'] ?? 'fixed';

        // Check if we have a controller for this item with updated values
        if (_discountControllers.containsKey(item['id'])) {
          String controllerText = _discountControllers[item['id']]!.text;
          if (controllerText.isNotEmpty) {
            discountAmount = Helper().validateInput(controllerText);
          }
        } else if (item['discount_amount'] != null) {
          discountAmount =
              double.tryParse(item['discount_amount'].toString()) ?? 0.0;
        }

        // Update the database with current discount values
        await SellDatabase().update(item['id'], {
          'discount_amount': discountAmount,
          'discount_type': discountType,
        });
      }

      debugPrint(
          'applyPendingDiscountChanges: All discount changes applied successfully');
    } catch (e) {
      debugPrint(
          'applyPendingDiscountChanges: Error applying discount changes: $e');
    }
  }

  addQuotation() async {
    debugPrint(
        'addQuotation: Starting for sellId=$sellId, res_table_id=$res_table_id');

    var contactId = await getDefaultCustomerId();
    if (contactId == null) return;

    String transactionDate =
    DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now());

    // Determine if we're updating an existing quotation or creating a new one
    bool isUpdating = argument?['is_quotation'] == 1 && sellId != null;

    Map sell = await Sell().createSell(
      changeReturn: 0.00,
      transactionDate: transactionDate,
      pending: calculateSubtotal(
          selectedTaxId, selectedDiscountType, discountAmount),
      shippingCharges: 0.00,
      shippingDetails: '',
      invoiceNo: isUpdating
          ? sellDetail[0]
      ['invoice_no'] // Keep existing invoice number when updating
          : USERID.toString() +
          "_" +
          DateFormat('yMdHm').format(DateTime.now()),
      contactId: contactId,
      discountAmount: discountAmount,
      discountType: selectedDiscountType,
      invoiceAmount: calculateSubtotal(
          selectedTaxId, selectedDiscountType, discountAmount),
      locId: selectedLocationId,
      saleStatus: 'draft',
      sellId: sellId,
      taxId: selectedTaxId,
      tip_amount: 0.00,
      isQuotation: 1,
      res_table_id: res_table_id,
      is_shipping: is_shipping ?? (res_table_id == 0 ? 1 : 0),
    );

    debugPrint(
        'addQuotation: ${isUpdating ? 'Updating' : 'Creating'} quotation: ${jsonEncode(sell)}');

    // // Apply all pending discount changes before saving
    // if (isUpdating) {
    //   await applyPendingDiscountChanges();
    // }

    // Save cart data before navigation
    await saveCartDataBeforeNavigation();

    // Navigate to Customer screen
    Navigator.pushNamed(context, '/customer',
        arguments: Helper().argument(
          res_table_id: res_table_id ?? 0,
          is_shipping: is_shipping ?? (res_table_id == 0 ? 1 : 0),
          isShipping: (is_shipping ?? (res_table_id == 0 ? 1 : 0)) ==
              1, // Add isShipping flag
          tableName: argument!['tableName'],
          locId: argument!['locationId'],
          taxId: selectedTaxId,
          discountType: selectedDiscountType,
          discountAmount: discountAmount,
          invoiceAmount: calculateSubtotal(
              selectedTaxId, selectedDiscountType, discountAmount),
          sellId: argument!['sellId'],
          isQuotation: 1,
          customerId: sellId != null ? selectedContactId : null,
          clearFields: null,
          isQuotationFlow: true,
          products: cartItems
              .map((item) => {
            'product_id': item['product_id'],
            'variation_id': item['variation_id'],
            'quantity': item['quantity'],
            'unit_price': item['unit_price'],
            'tax_rate_id': item['tax_rate_id'],
            'discount_amount': item['discount_amount'] ?? 0.0,
            'discount_type': item['discount_type'] ?? 'fixed',
            'note': item['note'] ?? '',
            'product_order_category':
            item['product_order_category'] ?? 'BAR',
          })
              .toList(),
        ));
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Check if there are unsaved changes
        bool hasUnsavedChanges = await _checkForUnsavedChanges();

        if (hasUnsavedChanges) {
          // Show confirmation dialog for unsaved changes
          bool shouldDiscard = await showDialog(
            context: context,
            barrierDismissible: false,
            builder: (BuildContext context) {
              return AlertDialog(
                backgroundColor: customAppTheme.bgLayer1,
                title: Text(
                  AppLocalizations.of(context).translate('unsaved_changes'),
                  style: AppTheme.getTextStyle(
                    themeData.textTheme.headline6,
                    color: themeData.colorScheme.onBackground,
                    fontWeight: 700,
                  ),
                ),
                content: Text(
                  AppLocalizations.of(context)
                      .translate('unsaved_changes_message'),
                  style: AppTheme.getTextStyle(
                    themeData.textTheme.subtitle1,
                    color: themeData.colorScheme.onBackground,
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: Text(
                      AppLocalizations.of(context).translate('cancel'),
                      style:
                      TextStyle(color: themeData.colorScheme.primary),
                    ),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    child: Text(
                      AppLocalizations.of(context).translate('discard'),
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                ],
              );
            },
          ) ??
              false;

          if (!shouldDiscard) {
            return false; // User cancelled, don't navigate back
          }

          // User confirmed discarding changes, clean up temporary data
          if (sellId != null && sellId != 0) {
            try {
              // Delete temporary cart items (is_completed = 0)
              await SellDatabase()
                  .deleteIncompleteSellLines(sellId!, res_table_id);
              debugPrint(
                  'Cart: Cleaned up temporary cart data for sellId: $sellId, res_table_id: $res_table_id');

              // Check if cart is now empty after discarding (check ALL items, including completed)
              List<Map> remainingCartItems = await SellDatabase()
                  .getSellLineBySellId(sellId!, res_table_id: res_table_id, includeCompleted: true);

              debugPrint(
                  'Cart: After discard - remainingCartItems count: ${remainingCartItems.length} for sellId: $sellId');

              if (remainingCartItems.isEmpty) {
                debugPrint(
                    'Cart: Cart is completely empty after discard for sellId: $sellId, deleting order and unlocking table');

                // Delete the empty order
                await SellDatabase().deleteSell(sellId!);
                debugPrint('Cart: Deleted empty order $sellId');

                // Clear cart data
                if (res_table_id != null) {
                  final cartKey = res_table_id.toString();
                  AppConstants.cartData[cartKey] = null;
                  await ShareInt().setMap(jsonEncode(AppConstants.cartData));
                  debugPrint('Cart: Cleared cart data for table $res_table_id');
                }

                // Unlock table in Firebase if it's a table (not shipping)
                final tableId = res_table_id;
                final locationId = selectedLocationId;
                debugPrint(
                    'Cart: Checking unlock conditions - tableId: $tableId, locationId: $locationId, is_shipping: $is_shipping');

                if (tableId != null && tableId > 0 &&
                    (is_shipping == null || is_shipping == 0) &&
                    locationId != null && locationId > 0) {
                  try {
                    await FirebaseTableLockService().unlockTable(
                      tableId: tableId,
                      locationId: locationId,
                    );
                    debugPrint('Cart: ✅ Successfully unlocked table $tableId in Firebase after discarding and clearing cart');
                  } catch (e) {
                    debugPrint('Cart: ❌ Error unlocking table $tableId in Firebase: $e');
                  }
                } else {
                  debugPrint(
                      'Cart: Skipping unlock - tableId: $tableId, locationId: $locationId, is_shipping: $is_shipping');
                }
              } else {
                // Cart still has items (completed items)
                debugPrint(
                    'Cart: Cart still has ${remainingCartItems.length} items after discard (including completed items) - table will remain locked');
              }
            } catch (e) {
              debugPrint('Cart: Error cleaning up temporary data: $e');
            }
          } else {
            // No sellId, but if we have a table, unlock it
            final tableId = res_table_id;
            final locationId = selectedLocationId;
            if (tableId != null && tableId > 0 &&
                (is_shipping == null || is_shipping == 0) &&
                locationId != null && locationId > 0) {
              try {
                await FirebaseTableLockService().unlockTable(
                  tableId: tableId,
                  locationId: locationId,
                );
                debugPrint('Cart: Unlocked table $tableId in Firebase after discarding (no sellId)');
              } catch (e) {
                debugPrint('Cart: Error unlocking table in Firebase: $e');
              }
            }
          }

          // Navigate directly to Sales Screen when discarding changes
          // Navigator.pop(context, '/products');
          Navigator.pop(context, '/tables');
          return false; // Prevent default back navigation since we're navigating manually
        }

        // No unsaved changes, allow normal back navigation
        if (sellId == null) {
          return true; // Allow back navigation
        } else {
          // Save cart data before navigation
          await saveCartDataBeforeNavigation();
          // Use pop instead of pushReplacementNamed to maintain proper navigation stack
          return true; // Allow default back navigation
        }
      },
      child: SafeArea(
        top: false,
        bottom: true,
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            title: Text(AppLocalizations.of(context).translate('cart'),
                style: AppTheme.getTextStyle(themeData.textTheme.headline6,
                    fontWeight: 600)),
            leading: IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () async {
                  // Check if there are unsaved changes
                  bool hasUnsavedChanges = await _checkForUnsavedChanges();

                  if (hasUnsavedChanges) {
                    // Show confirmation dialog for unsaved changes
                    bool shouldDiscard = await showDialog(
                      context: context,
                      barrierDismissible: false,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          backgroundColor: customAppTheme.bgLayer1,
                          title: Text(
                            AppLocalizations.of(context)
                                .translate('unsaved_changes'),
                            style: AppTheme.getTextStyle(
                              themeData.textTheme.headline6,
                              color: themeData.colorScheme.onBackground,
                              fontWeight: 700,
                            ),
                          ),
                          content: Text(
                            AppLocalizations.of(context)
                                .translate('unsaved_changes_message'),
                            style: AppTheme.getTextStyle(
                              themeData.textTheme.subtitle1,
                              color: themeData.colorScheme.onBackground,
                            ),
                          ),
                          actions: [
                            TextButton(
                              onPressed: () =>
                                  Navigator.of(context).pop(false),
                              child: Text(
                                AppLocalizations.of(context)
                                    .translate('cancel'),
                                style: TextStyle(
                                    color: themeData.colorScheme.primary),
                              ),
                            ),
                            TextButton(
                              onPressed: () =>
                                  Navigator.of(context).pop(true),
                              child: Text(
                                AppLocalizations.of(context)
                                    .translate('discard'),
                                style: TextStyle(color: Colors.red),
                              ),
                            ),
                          ],
                        );
                      },
                    ) ??
                        false;

                    if (!shouldDiscard) {
                      return; // User cancelled, don't navigate back
                    }

                    // User confirmed discarding changes, clean up temporary data
                    if (sellId != null && sellId != 0) {
                      try {
                        // Delete temporary cart items (is_completed = 0)
                        await SellDatabase()
                            .deleteIncompleteSellLines(sellId!, res_table_id);
                        debugPrint(
                            'Cart: Cleaned up temporary cart data for sellId: $sellId, res_table_id: $res_table_id');

                        // Check if cart is now empty after discarding (check ALL items, including completed)
                        List<Map> remainingCartItems = await SellDatabase()
                            .getSellLineBySellId(sellId!, res_table_id: res_table_id, includeCompleted: true);

                        debugPrint(
                            'Cart: After discard - remainingCartItems count: ${remainingCartItems.length} for sellId: $sellId');

                        if (remainingCartItems.isEmpty) {
                          debugPrint(
                              'Cart: Cart is completely empty after discard for sellId: $sellId, deleting order and unlocking table');

                          // Delete the empty order
                          await SellDatabase().deleteSell(sellId!);
                          debugPrint('Cart: Deleted empty order $sellId');

                          // Clear cart data
                          if (res_table_id != null) {
                            final cartKey = res_table_id.toString();
                            AppConstants.cartData[cartKey] = null;
                            await ShareInt().setMap(jsonEncode(AppConstants.cartData));
                            debugPrint('Cart: Cleared cart data for table $res_table_id');
                          }

                          // Unlock table in Firebase if it's a table (not shipping)
                          final tableId = res_table_id;
                          final locationId = selectedLocationId;
                          debugPrint(
                              'Cart: Checking unlock conditions - tableId: $tableId, locationId: $locationId, is_shipping: $is_shipping');

                          if (tableId != null && tableId > 0 &&
                              (is_shipping == null || is_shipping == 0) &&
                              locationId != null && locationId > 0) {
                            try {
                              await FirebaseTableLockService().unlockTable(
                                tableId: tableId,
                                locationId: locationId,
                              );
                              debugPrint('Cart: ✅ Successfully unlocked table $tableId in Firebase after discarding and clearing cart');
                            } catch (e) {
                              debugPrint('Cart: ❌ Error unlocking table $tableId in Firebase: $e');
                            }
                          } else {
                            debugPrint(
                                'Cart: Skipping unlock - tableId: $tableId, locationId: $locationId, is_shipping: $is_shipping');
                          }
                        } else {
                          // Cart still has items (completed items)
                          debugPrint(
                              'Cart: Cart still has ${remainingCartItems.length} items after discard (including completed items) - table will remain locked');
                        }
                      } catch (e) {
                        debugPrint(
                            'Cart: Error cleaning up temporary data: $e');
                      }
                    } else {
                      // No sellId, but if we have a table, unlock it
                      final tableId = res_table_id;
                      final locationId = selectedLocationId;
                      if (tableId != null && tableId > 0 &&
                          (is_shipping == null || is_shipping == 0) &&
                          locationId != null && locationId > 0) {
                        try {
                          await FirebaseTableLockService().unlockTable(
                            tableId: tableId,
                            locationId: locationId,
                          );
                          debugPrint('Cart: Unlocked table $tableId in Firebase after discarding (no sellId)');
                        } catch (e) {
                          debugPrint('Cart: Error unlocking table in Firebase: $e');
                        }
                      }
                    }

                    // Navigate directly to Sales Screen when discarding changes
                    // Navigator.pop(context, '/products');
                    Navigator.pop(context, '/tables');
                    return; // Exit early since we're navigating to sales
                  }

                  // No unsaved changes, proceed with normal navigation
                  // Save cart data before navigation if sellId exists
                  if (sellId != null) {
                    await saveCartDataBeforeNavigation();

                    // Check if cart is empty and unlock table if needed
                    try {
                      List<Map> allCartItems = await SellDatabase()
                          .getSellLineBySellId(sellId!, res_table_id: res_table_id, includeCompleted: true);

                      if (allCartItems.isEmpty) {
                        debugPrint('Cart: Cart is empty on normal back navigation, checking if table should be unlocked');

                        // Delete the empty order
                        await SellDatabase().deleteSell(sellId!);
                        debugPrint('Cart: Deleted empty order $sellId on normal back navigation');

                        // Clear cart data
                        if (res_table_id != null) {
                          final cartKey = res_table_id.toString();
                          AppConstants.cartData[cartKey] = null;
                          await ShareInt().setMap(jsonEncode(AppConstants.cartData));
                          debugPrint('Cart: Cleared cart data for table $res_table_id on normal back navigation');
                        }

                        // Unlock table in Firebase if it's a table (not shipping)
                        final tableId = res_table_id;
                        final locationId = selectedLocationId;
                        if (tableId != null && tableId > 0 &&
                            (is_shipping == null || is_shipping == 0) &&
                            locationId != null && locationId > 0) {
                          try {
                            await FirebaseTableLockService().unlockTable(
                              tableId: tableId,
                              locationId: locationId,
                            );
                            debugPrint('Cart: ✅ Successfully unlocked table $tableId in Firebase on normal back navigation (cart was empty)');
                          } catch (e) {
                            debugPrint('Cart: ❌ Error unlocking table $tableId in Firebase on normal back navigation: $e');
                          }
                        }
                      }
                    } catch (e) {
                      debugPrint('Cart: Error checking cart on normal back navigation: $e');
                    }
                  } else {
                    // No sellId, but check if we should unlock table
                    final tableId = res_table_id;
                    final locationId = selectedLocationId;
                    if (tableId != null && tableId > 0 &&
                        (is_shipping == null || is_shipping == 0) &&
                        locationId != null && locationId > 0) {
                      try {
                        await FirebaseTableLockService().unlockTable(
                          tableId: tableId,
                          locationId: locationId,
                        );
                        debugPrint('Cart: ✅ Unlocked table $tableId in Firebase on normal back navigation (no sellId)');
                      } catch (e) {
                        debugPrint('Cart: ❌ Error unlocking table $tableId in Firebase on normal back navigation: $e');
                      }
                    }
                  }

                  // Use pop to maintain proper navigation stack
                  Navigator.pop(context);
                }),
            actions: [
              InkWell(
                onTap: () async {
                  var barcode = await Helper().barcodeScan();
                  await getScannedProduct(barcode);
                },
                child: Container(
                  margin: EdgeInsets.only(
                      right: MySize.size16!,
                      bottom: MySize.size8!,
                      top: MySize.size8!),
                  decoration: BoxDecoration(
                    color: themeData.backgroundColor,
                    borderRadius:
                    BorderRadius.all(Radius.circular(MySize.size16!)),
                    boxShadow: [
                      BoxShadow(
                        color: themeData.cardTheme.shadowColor!.withAlpha(48),
                        blurRadius: 3,
                        offset: Offset(0, 1),
                      )
                    ],
                  ),
                  padding: EdgeInsets.only(
                      left: MySize.size12!, right: MySize.size12!),
                  child: Icon(
                    MdiIcons.barcode,
                    color: themeData.colorScheme.primary,
                  ),
                ),
              ),
              searchDropdown()
            ],
          ),
          body: Column(children: [
            SizedBox(
              height: 10,
            ),
            // Add a more prominent indicator below the app bar
            if (_tableName != null || _isShipping)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                color: themeData.primaryColor.withOpacity(0.1),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _isShipping
                          ? Icons.local_shipping
                          : Icons.table_restaurant,
                      color: themeData.primaryColor,
                    ),
                    SizedBox(width: 8),
                    Text(
                      _isShipping
                          ? (AppLocalizations.of(context)
                          .translate('shipping_order') ??
                          'Shipping Order')
                          : '$_tableName',
                      style: TextStyle(
                        color: themeData.primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            SizedBox(height: 2),
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                    height: MySize.safeHeight! * 0.65,
                    color: customAppTheme.bgLayer1,
                    child: (cartItems.length > 0)
                        ? Padding(
                      padding: const EdgeInsets.only(bottom: 20.0),
                      child: itemList(),
                    )
                        : Center(
                        child: Text(AppLocalizations.of(context)
                            .translate('add_item_to_cart')))),
              ),
            ),
            Divider(),
            Column(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(
                      left: MySize.size24!, right: MySize.size24!),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Text(
                          AppLocalizations.of(context).translate('sub_total') +
                              ' : ',
                          style: AppTheme.getTextStyle(
                            themeData.textTheme.subtitle1,
                            fontWeight: 700,
                            color: themeData.colorScheme.onBackground,
                          )),
                      Text(
                          symbol + Helper().formatCurrency(calculateSubTotal()),
                          style: AppTheme.getTextStyle(
                            themeData.textTheme.subtitle1,
                            fontWeight: 700,
                            color: themeData.colorScheme.onBackground,
                          )),
                    ],
                  ),
                )
              ],
            ),
            Container(
              padding:
              EdgeInsets.only(left: MySize.size24!, right: MySize.size24!),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    AppLocalizations.of(context).translate('discount') + ' : ',
                    style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
                        color: themeData.colorScheme.onBackground,
                        fontWeight: 600,
                        muted: true),
                  ),
                  discount(),
                  Expanded(
                    child: Container(
                      height: MySize.size50,
                      child: TextFormField(
                        controller: discountController,
                        decoration: InputDecoration(
                          prefix: Text(
                              (selectedDiscountType == 'fixed') ? symbol : ''),
                          labelText: AppLocalizations.of(context)
                              .translate('discount_amount'),
                          border: themeData.inputDecorationTheme.border,
                          enabledBorder: themeData.inputDecorationTheme.border,
                          focusedBorder:
                          themeData.inputDecorationTheme.focusedBorder,
                        ),
                        style: AppTheme.getTextStyle(
                          themeData.textTheme.subtitle2,
                          fontWeight: 400,
                          letterSpacing: -0.2,
                        ),
                        textAlign: TextAlign.end,
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'^\d*\.?\d{0,2}')),
                          if (selectedDiscountType == 'fixed')
                            DiscountLimitFormatter(calculateSubTotal())
                          else
                            DiscountLimitFormatter(
                                100), // Limit percentage to 100
                        ],
                        keyboardType: TextInputType.number,
                        onTap: () {
                          if (!_isdiscount_amountEdited) {
                            discountController.clear();
                            _isdiscount_amountEdited = true;
                          }
                        },
                        onChanged: (value) {
                          if (mounted) {
                            setState(() {
                              // Handle empty or null values properly
                              if (value.isEmpty || value.trim().isEmpty) {
                                discountAmount = 0.0;
                              } else {
                                discountAmount = Helper().validateInput(value);
                              }
                              debugPrint(
                                  'Cart: Updated discount_amount: $discountAmount');

                              double amountBeforeCartDiscount =
                              calculateSubtotal(
                                selectedTaxId,
                                selectedDiscountType,
                                0.0,
                              );

                              bool isValid = true;

                              if (selectedDiscountType == 'fixed') {
                                if (discountAmount! >
                                    amountBeforeCartDiscount) {
                                  isValid = false;
                                  Fluttertoast.showToast(
                                    msg: AppLocalizations.of(context).translate(
                                        'invalid_discount_exceeds_total'),
                                    toastLength: Toast.LENGTH_SHORT,
                                  );
                                }
                              } else if (selectedDiscountType == 'percentage') {
                                if (discountAmount! > 100) {
                                  isValid = false;
                                  Fluttertoast.showToast(
                                    msg: AppLocalizations.of(context).translate(
                                        'invalid_discount_exceeds_100'),
                                    toastLength: Toast.LENGTH_SHORT,
                                  );
                                }
                              }

                              if (isValid && isFinalTotalNegative()) {
                                isValid = false;
                                Fluttertoast.showToast(
                                  msg: AppLocalizations.of(context)
                                      .translate('invalid_total'),
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              }

                              proceedNext = isValid && !isFinalTotalNegative();
                            });

                            // Note: Discount will be applied only when Update Quotation/Draft button is clicked
                            // No immediate database update for quotations/drafts
                          }
                        },
                      ),
                    ),
                  )
                ],
              ),
            ),
            Container(
              padding:
              EdgeInsets.only(left: MySize.size24!, right: MySize.size24!),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    AppLocalizations.of(context).translate('tax') + ' : ',
                    style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
                        color: themeData.colorScheme.onBackground,
                        fontWeight: 600,
                        muted: true),
                  ),
                  taxes(),
                  Text(
                    AppLocalizations.of(context).translate('total') + ' : ',
                    style: AppTheme.getTextStyle(
                      themeData.textTheme.subtitle1,
                      fontWeight: 700,
                      color: themeData.colorScheme.onBackground,
                    ),
                  ),
                  Text(
                      symbol +
                          Helper().formatCurrency(calculateSubtotal(
                              selectedTaxId,
                              selectedDiscountType,
                              discountAmount)),
                      style: AppTheme.getTextStyle(
                        themeData.textTheme.subtitle1,
                        fontWeight: 700,
                        color: themeData.colorScheme.onBackground,
                        letterSpacing: 0,
                      ))
                ],
              ),
            ),
          ]),
          bottomNavigationBar: cartItems.isNotEmpty && proceedNext
              ? Row(
            // mainAxisAlignment: argument?['is_quotation'] == null
            //     ? MainAxisAlignment.spaceAround
            //     : MainAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Visibility(
              //   visible: argument?['is_quotation'] == null,
              //   child: ElevatedButton(
              //     onPressed: addQuotation,
              //     style: ElevatedButton.styleFrom(
              //       backgroundColor: themeData.colorScheme.primary,
              //       shape: RoundedRectangleBorder(
              //           borderRadius: BorderRadius.circular(40.0)),
              //       minimumSize: Size(150, 40), // Consistent width and height
              //       padding:
              //       EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              //     ),
              //     child: Text(
              //       AppLocalizations.of(context).translate('add_quotation'),
              //       style: AppTheme.getTextStyle(
              //         Theme.of(context).textTheme.bodyText1,
              //         color: Theme.of(context).colorScheme.surface,
              //         fontWeight: 600,
              //       ),
              //     ),
              //   ),
              // ),
              // Replace the current Visibility widget with this:
              Visibility(
                visible: argument?['is_quotation'] == null ||
                    argument?['is_quotation'] == 1,
                child: ElevatedButton(
                  onPressed: addQuotation,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeData.colorScheme.primary,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40.0)),
                    minimumSize: Size(150, 40),
                    padding:
                    EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  ),
                  child: Text(
                    // Change text based on whether we're editing or creating
                    argument?['is_quotation'] == 1
                        ? AppLocalizations.of(context)
                        .translate('update_quotation')
                        : AppLocalizations.of(context)
                        .translate('add_quotation'),
                    style: AppTheme.getTextStyle(
                      Theme.of(context).textTheme.bodyText1,
                      color: Theme.of(context).colorScheme.surface,
                      fontWeight: 600,
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              ElevatedButton(
                onPressed: proceedNext
                    ? () async {
                  // Save cart data before navigation
                  print("object 111111");
                  await saveCartDataBeforeNavigation();
                  print("object 222222");
                  await _checkForUnsavedChanges();
                  print("object 333333");
                  Navigator.pushNamed(context, '/customer',
                      arguments: Helper().argument(
                        res_table_id: res_table_id ?? 0,
                        is_shipping: is_shipping ??
                            (res_table_id == 0 ? 1 : 0),
                        isShipping: (is_shipping ??
                            (res_table_id == 0 ? 1 : 0)) ==
                            1, // Add isShipping flag
                        tableName:
                        _tableName, // Pass table name forward
                        locId: argument!['locationId'],
                        taxId: selectedTaxId,
                        discountType: selectedDiscountType,
                        discountAmount: discountAmount,
                        invoiceAmount: calculateSubtotal(
                            selectedTaxId,
                            selectedDiscountType,
                            discountAmount),
                        sellId: argument!['sellId'],
                        isQuotation: argument!['is_quotation'],
                        customerId: sellId != null
                            ? selectedContactId
                            : null,
                        products: cartItems
                            .map((item) => {
                          'product_id': item['product_id'],
                          'variation_id':
                          item['variation_id'],
                          'quantity': item['quantity'],
                          'unit_price': item['unit_price'],
                          'tax_rate_id':
                          item['tax_rate_id'],
                          'discount_amount':
                          item['discount_amount'] ??
                              0.0,
                          'discount_type':
                          item['discount_type'] ??
                              'fixed',
                          'note': item['note'] ?? '',
                          'product_order_category': item[
                          'product_order_category'] ??
                              'BAR',
                        })
                            .toList(),
                        clearFields: null,
                      ));
                  print("object 333333");
                }
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: proceedNext
                      ? themeData.colorScheme.primary
                      : themeData.colorScheme.primary.withOpacity(0.5),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40.0)),
                  minimumSize:
                  Size(150, 40), // Consistent width and height
                  padding:
                  EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                ),
                child: Text(
                  AppLocalizations.of(context).translate('place_order'),
                  style: AppTheme.getTextStyle(
                    Theme.of(context).textTheme.bodyText1,
                    color: Theme.of(context).colorScheme.surface,
                    fontWeight: 600,
                  ),
                ),
              ),
            ],
          )
              : SizedBox.shrink(),
          // bottomNavigationBar: Visibility(
          //     visible: (cartItems.length > 0 && proceedNext == true),
          //     child: cartBottomBar(
          //         '/customer',
          //         AppLocalizations.of(context).translate('customer'),
          //         context,
          //         Helper().argument(
          //           res_table_id: res_table_id,
          //           is_shipping: is_shipping,
          //
          //           locId: argument!['locationId'],
          //           taxId: selectedTaxId,
          //           discountType: selectedDiscountType,
          //           discountAmount: discountAmount,
          //           invoiceAmount: calculateSubtotal(selectedTaxId, selectedDiscountType, discountAmount),
          //           sellId: argument!['sellId'],
          //           isQuotation: argument!['is_quotation'],
          //           customerId: (argument!['sellId'] != null) ? selectedContactId : null,
          //           products: cartItems.map((item) => {
          //             'product_id': item['product_id'],
          //             'variation_id': item['variation_id'],
          //             'quantity': item['quantity'],
          //             'unit_price': item['unit_price'],
          //             'tax_rate_id': item['tax_rate_id'],
          //             'discount_amount': item['discount_amount'] ?? 0.0,
          //             'discount_type': item['discount_type'] ?? 'fixed',
          //             'note': item['note'] ?? '',
          //             'product_order_category': item['product_order_category'] ?? 'BAR',
          //           }).toList(),
          //         )
          //     )
          // )
        ),
      ),
    );
  }

  Widget searchDropdown() {
    return Container(
      margin: EdgeInsets.only(right: MySize.size10!, top: MySize.size8!),
      width: MySize.screenWidth! * 0.45,
      child: TextFormField(
        style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
            letterSpacing: 0, fontWeight: 500),
        decoration: InputDecoration(
          hintText: AppLocalizations.of(context).translate('search'),
          hintStyle: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
              letterSpacing: 0, fontWeight: 500),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
              borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
              borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
              borderSide: BorderSide.none),
          filled: true,
          fillColor: themeData.colorScheme.background,
          prefixIcon: Icon(
            MdiIcons.magnify,
            size: MySize.size22,
            color: themeData.colorScheme.onBackground.withAlpha(150),
          ),
          isDense: true,
          contentPadding: EdgeInsets.only(right: MySize.size16!),
        ),
        textCapitalization: TextCapitalization.sentences,
        controller: searchController,
        onEditingComplete: () async {
          await getSearchItemList(searchController.text)
              .then((value) => itemDialog(value));
          FocusScope.of(context).requestFocus(FocusNode());
        },
      ),
    );
  }

  itemDialog(List items) {
    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: customAppTheme.bgLayer1,
          content: Container(
            color: customAppTheme.bgLayer1,
            height: MySize.screenHeight! * 0.8,
            width: MySize.screenWidth! * 0.8,
            child: ListView.builder(
                shrinkWrap: true,
                itemCount: (items.length != 0) ? items.length : 0,
                itemBuilder: ((context, index) {
                  return Card(
                    elevation: 4,
                    margin: EdgeInsets.all(MySize.size4!),
                    child: ListTile(
                      title: Text(items[index]['display_name']?.toString() ?? items[index]['name']?.toString() ?? 'Unknown Product'),
                      trailing: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: <Widget>[
                          Text(
                            symbol +
                                Helper()
                                    .formatCurrency(items[index]['unit_price']),
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.bodyText2,
                                fontWeight: 700,
                                letterSpacing: 0),
                          ),
                          Container(
                            width: MySize.size80,
                            decoration: BoxDecoration(
                                color: themeData.colorScheme.primary,
                                borderRadius: BorderRadius.all(
                                    Radius.circular(MySize.size4!))),
                            padding: EdgeInsets.only(
                                left: MySize.size6!,
                                right: MySize.size8!,
                                top: MySize.size2!,
                                bottom: MySize.getScaledSizeHeight(3.5)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Icon(
                                  MdiIcons.stocking,
                                  color: themeData.colorScheme.onPrimary,
                                  size: MySize.size12,
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: MySize.size4!),
                                  child: Text(
                                      Helper().formatQuantity(
                                          items[index]['stock_available']),
                                      style: AppTheme.getTextStyle(
                                          themeData.textTheme.caption,
                                          fontSize: 11,
                                          color:
                                          themeData.colorScheme.onPrimary,
                                          fontWeight: 600)),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      onTap: () async {
                        ScaffoldMessenger.of(context).hideCurrentSnackBar();

                        Fluttertoast.showToast(
                            msg: AppLocalizations.of(context)
                                .translate('added_to_cart'));

                        Timer(Duration(milliseconds: 250), () {
                          Fluttertoast.cancel();
                        });

                        await Sell().addToCart(
                            items[index], argument?['sellId'], res_table_id,
                            is_shipping: is_shipping);
                        if (mounted) {
                          setState(() {
                            cartList();
                          });
                        }
                      },
                    ),
                  );
                })),
          ),
        );
      },
    );
  }

  Future<List> getSearchItemList(String searchText) async {
    List products = [];
    var price;
    await Variations()
        .get(
        locationId: argument!['locationId'],
        offset: 0,
        inStock: true,
        searchTerm: '$searchText')
        .then((value) {
      value.forEach((element) {
        if (element['selling_price_group'] != null) {
          jsonDecode(element['selling_price_group']).forEach((element) {
            if (element['key'] == sellingPriceGroupId) {
              price = element['value'];
            }
          });
        }
        if (mounted) {
          setState(() {
            products.add(ProductModel().product(element, price));
          });
        }
      });
    });
    debugPrint(
        'getSearchItemList: Found ${products.length} products for search: $searchText');
    return products;
  }

  getScannedProduct(String barcode) async {
    await Variations()
        .get(
        locationId: argument!['locationId'],
        offset: 0,
        barcode: barcode,
        searchTerm: '')
        .then((value) async {
      if (value.length > 0) {
        var price;
        var product;
        if (value[0]['selling_price_group'] != null) {
          jsonDecode(value[0]['selling_price_group']).forEach((element) {
            if (element['key'] == sellingPriceGroupId) {
              price = element['value'];
            }
          });
        }
        if (mounted) {
          setState(() {
            product = ProductModel().product(value[0], price);
          });
        }
        if (product != null && product['stock_available'] > 0) {
          ScaffoldMessenger.of(context).hideCurrentSnackBar();

          Fluttertoast.showToast(
              msg: AppLocalizations.of(context).translate('added_to_cart'));
          Timer(Duration(milliseconds: 250), () {
            Fluttertoast.cancel();
          });
          await Sell().addToCart(product, argument?['sellId'], res_table_id,
              is_shipping: is_shipping);
          cartList();
        } else {
          Fluttertoast.showToast(
              msg: AppLocalizations.of(context).translate("out_of_stock"));
        }
      } else {
        Fluttertoast.showToast(
            msg: AppLocalizations.of(context).translate("no_products_found"));
      }
    });
  }

  // for final total is negative or not
  bool isFinalTotalNegative() {
    double finalTotal = calculateSubtotal(
      selectedTaxId,
      selectedDiscountType,
      discountAmount ?? 0.0,
    );
    return finalTotal < 0;
  }

  double calculateSubTotal() {
    double total = 0.0;
    for (var item in cartItems) {
      //new added
      double itemPrice = item['unit_price'] ?? 0.0;
      double quantity = item['quantity'] ?? 0;

      total += (item['unit_price'] ?? 0.0) * (item['quantity'] ?? 0);
    }
    debugPrint('calculateSubTotal: Total=$total');
    return total;
  }

  //new added for item discount
  double calculateTotalItemDiscounts() {
    double totalDiscounts = 0.0;
    for (var item in cartItems) {
      double itemPrice = item['unit_price'] ?? 0.0;
      double quantity = item['quantity'] ?? 0;
      double discountAmount = item['discount_amount'] ?? 0.0;
      String discountType = item['discount_type'] ?? 'fixed';

      if (discountType == 'fixed') {
        totalDiscounts += discountAmount * quantity;
      } else {
        totalDiscounts += (itemPrice * discountAmount / 100) * quantity;
      }
    }
    return totalDiscounts;
  }

  double calculateSubtotal(
      int? taxId, String discountType, double? discountAmount) {
    double subtotal = calculateSubTotal();

    double itemDiscounts = calculateTotalItemDiscounts(); //new added

    double taxAmount = 0.0;
    double discount = discountAmount ?? 0.0;

    // Apply item discounts first
    double amountAfterItemDiscounts = subtotal - itemDiscounts;

    // Apply cart-level discount (multiplicative for percentage)
    double amountAfterCartDiscount;
    if (discountType == 'fixed') {
      amountAfterCartDiscount = amountAfterItemDiscounts - discount;
    } else {
      amountAfterCartDiscount = amountAfterItemDiscounts * (1 - discount / 100);
    }

    if (taxId != null && taxId != 0) {
      for (var tax in taxListMap) {
        if (tax['id'] == taxId) {
          // Calculate tax on the amount after applying discounts, not on the original subtotal
          taxAmount = amountAfterCartDiscount * (tax['amount'] / 100);
          break;
        }
      }
    }

    // if (discountType == 'percentage') {
    //   discount = subtotal * (discount / 100);
    // }

    //double finalTotal = subtotal + taxAmount - totalDiscount;
    double finalTotal = amountAfterCartDiscount + taxAmount;
    debugPrint(
        'calculateSubtotal: Subtotal=$subtotal, ItemDiscounts=$itemDiscounts, CartDiscount=$discount, AmountAfterDiscounts=$amountAfterCartDiscount, Tax=$taxAmount, Final (total)=$finalTotal');
    return finalTotal;
  }

  Widget discount() {
    return DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        dropdownColor: themeData.colorScheme.background,
        icon: const Icon(Icons.arrow_drop_down),
        value: selectedDiscountType,
        items: const <String>['fixed', 'percentage']
            .map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(value: value, child: Text(value));
        }).toList(),
        onChanged: (newValue) {
          if (newValue == null) return;
          if (mounted) {
            setState(() {
              selectedDiscountType = newValue;
              discountController.text =
                  discountAmount?.toStringAsFixed(2) ?? '0.00';
              // Reset the edit flag when discount type changes to prevent clearing
              _isdiscount_amountEdited = true;
              calculateSubtotal(
                  selectedTaxId, selectedDiscountType, discountAmount);
              debugPrint('discount: Updated discountType to $newValue');
            });

            // Note: Discount type change will be applied only when Update Quotation/Draft button is clicked
            // No immediate database update for quotations/drafts
          }
        },
      ),
    );
  }

  Widget taxes() {
    return DropdownButtonHideUnderline(
      child: DropdownButton<int>(
        dropdownColor: themeData.colorScheme.background,
        icon: const Icon(Icons.arrow_drop_down),
        value: selectedTaxId,
        items: taxListMap.map<DropdownMenuItem<int>>((Map value) {
          return DropdownMenuItem<int>(
            value: value['id'],
            child: Text(
              value['name'],
              style: AppTheme.getTextStyle(
                themeData.textTheme.bodyMedium,
                fontWeight: 600,
                color: themeData.colorScheme.onBackground,
              ),
            ),
          );
        }).toList(),
        onChanged: (newValue) {
          if (newValue == null) return;
          if (mounted) {
            setState(() {
              selectedTaxId = newValue;
              calculateSubtotal(
                  selectedTaxId, selectedDiscountType, discountAmount);
              debugPrint('taxes: Updated taxId to $newValue');
            });
          }
        },
      ),
    );
  }

  Widget itemList() {
    int themeType = 1;
    ThemeData themeData;
    CustomAppTheme customAppTheme;
    themeData = AppTheme.getThemeFromThemeMode(themeType);
    customAppTheme = AppTheme.getCustomAppTheme(themeType);

    return ListView.builder(
      shrinkWrap: true,
      itemCount: cartItems.length,
      padding: EdgeInsets.only(top: MySize.size16!),
      itemBuilder: (context, index) {
        return Padding(
            padding: EdgeInsets.only(
                left: MySize.size8!,
                right: MySize.size8!,
                bottom: MySize.size8!),
            child: Container(
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                      blurRadius: MySize.size8!,
                      color: customAppTheme.shadowColor,
                      offset: Offset(0, MySize.size4!))
                ],
              ),
              child: Container(
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                          color: themeData.cardTheme.shadowColor!.withAlpha(10),
                          blurRadius: MySize.size16!)
                    ],
                    color: customAppTheme.bgLayer1,
                    borderRadius:
                    BorderRadius.all(Radius.circular(MySize.size16!))),
                padding: EdgeInsets.only(right: MySize.size16!),
                child: Column(
                  children: [
                    Container(
                      alignment: Alignment.topLeft,
                      padding: EdgeInsets.all(MySize.size8!),
                      child: Text(
                        cartItems[index]['name']?.toString() ?? cartItems[index]['display_name']?.toString() ?? 'Unknown Product',
                        overflow: (editItem == index)
                            ? TextOverflow.visible
                            : TextOverflow.ellipsis,
                        style: AppTheme.getTextStyle(
                            themeData.textTheme.bodyText1,
                            color: themeData.colorScheme.onBackground,
                            fontWeight: 600),
                      ),
                    ),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.only(left: MySize.size20!),
                            child: Column(
                              children: [
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Column(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                              symbol +
                                                  Helper().formatCurrency(
                                                      cartItems[index]
                                                      ['unit_price']),
                                              style: AppTheme.getTextStyle(
                                                  themeData.textTheme.bodyText1,
                                                  color: themeData
                                                      .colorScheme.onBackground,
                                                  fontWeight: 600,
                                                  letterSpacing: -0.2,
                                                  muted: true),
                                            ),
                                            Row(
                                                mainAxisAlignment:
                                                MainAxisAlignment
                                                    .spaceBetween,
                                                children: [
                                                  Text(AppLocalizations.of(
                                                      context)
                                                      .translate('total') +
                                                      ' : ' +
                                                      symbol +
                                                      Helper().formatCurrency((double.parse(calculateInlineUnitPrice(
                                                          cartItems[index][
                                                          'unit_price'],
                                                          cartItems[index][
                                                          'tax_rate_id'],
                                                          cartItems[index][
                                                          'discount_type'],
                                                          cartItems[index][
                                                          'discount_amount'])) *
                                                          cartItems[index]
                                                          ['quantity']))),
                                                ]),
                                            Row(
                                              children: [
                                                IconButton(
                                                    icon: Icon(MdiIcons.pencil,
                                                        size: MySize.size20),
                                                    color: themeData.colorScheme
                                                        .onBackground,
                                                    onPressed: () {
                                                      if (mounted) {
                                                        setState(() {
                                                          editItem =
                                                          (editItem ==
                                                              index)
                                                              ? null
                                                              : index;
                                                          debugPrint(
                                                              'itemList: Toggled editItem to $editItem');
                                                        });
                                                      }
                                                    }),
                                                IconButton(
                                                    icon: Icon(MdiIcons.delete,
                                                        size: MySize.size20),
                                                    color: themeData.colorScheme
                                                        .onBackground,
                                                    onPressed: () {
                                                      confirmDelete(
                                                          context, index);
                                                    })
                                              ],
                                            )
                                          ]),
                                    ),
                                    // Container(
                                    //     alignment: Alignment.centerRight,
                                    //     width: MySize.screenWidth! * 0.25,
                                    //     height: MySize.screenHeight! * 0.05,
                                    //     child: (editItem != index)
                                    //         ? Text(
                                    //         "${AppLocalizations.of(context).translate('quantity')}:${cartItems[index]['quantity'].toString()}")
                                    //         : TextFormField(
                                    //       // controller: (editItem != index) ? TextEditingController(text: cartItems[index]['quantity'].toString()) : null,
                                    //       // initialValue: (editItem == index) ? cartItems[index]['quantity'].toString() : null,
                                    //
                                    //       //new added
                                    //       controller:
                                    //       quantityControllers[index],
                                    //       inputFormatters: [
                                    //         FilteringTextInputFormatter(
                                    //             RegExp(
                                    //                 r'^(\d+)?\.?\d{0,2}'),
                                    //             allow: true)
                                    //       ],
                                    //       keyboardType: TextInputType
                                    //           .numberWithOptions(
                                    //           decimal: true),
                                    //       textAlign: TextAlign.end,
                                    //       decoration: InputDecoration(
                                    //         labelText: AppLocalizations
                                    //             .of(context)
                                    //             .translate('quantity'),
                                    //       ),
                                    //       onChanged: (newQuantity) {
                                    //         if (newQuantity != "" &&
                                    //             double.parse(
                                    //                 newQuantity) >
                                    //                 0) {
                                    //           if (!proceedNext)
                                    //             proceedNext = true;
                                    //           if (cartItems[index][
                                    //           'stock_available'] >=
                                    //               double.parse(
                                    //                   newQuantity)) {
                                    //             SellDatabase().update(
                                    //                 cartItems[index]
                                    //                 ['id'],
                                    //                 {
                                    //                   'quantity':
                                    //                   double.parse(
                                    //                       newQuantity)
                                    //                 });
                                    //             cartList();
                                    //           } else {
                                    //             Fluttertoast.showToast(
                                    //                 msg: "${cartItems[index]['stock_available']}" +
                                    //                     AppLocalizations.of(
                                    //                         context)
                                    //                         .translate(
                                    //                         'stock_available'));
                                    //           }
                                    //         } else if (newQuantity ==
                                    //             "") {
                                    //           if (mounted) {
                                    //             setState(() {
                                    //               proceedNext = false;
                                    //             });
                                    //           }
                                    //           Fluttertoast.showToast(
                                    //               msg: AppLocalizations
                                    //                   .of(context)
                                    //                   .translate(
                                    //                   'please_enter_a_valid_quantity'));
                                    //         }
                                    //       },
                                    //     )),
                                    Container(
                                        alignment: Alignment.centerRight,
                                        width: MySize.screenWidth! * 0.25,
                                        height: MySize.screenHeight! * 0.05,
                                        child: (editItem != index)
                                            ? Text(
                                            "${AppLocalizations.of(context).translate('quantity')}:${cartItems[index]['quantity'].toString()}")
                                            : TextFormField(
                                          controller:
                                          quantityControllers[index],
                                          inputFormatters: [
                                            FilteringTextInputFormatter
                                                .allow(RegExp(
                                                r'^\d*\.?\d{0,2}')),
                                          ],
                                          keyboardType: TextInputType
                                              .numberWithOptions(
                                            decimal: true,
                                          ),
                                          textAlign: TextAlign.end,
                                          decoration: InputDecoration(
                                            labelText: AppLocalizations
                                                .of(context)
                                                .translate('quantity'),
                                            border: OutlineInputBorder(),
                                            contentPadding:
                                            EdgeInsets.symmetric(
                                                horizontal: 8.0,
                                                vertical: 4.0),
                                          ),
                                          onChanged: (newQuantity) {
                                            if (newQuantity.isNotEmpty) {
                                              // Allow empty input during editing
                                              if (newQuantity == ".") {
                                                // Handle case where user just types a dot
                                                return;
                                              }

                                              try {
                                                double quantityValue =
                                                double.parse(
                                                    newQuantity);

                                                if (quantityValue > 0) {
                                                  if (!proceedNext) {
                                                    setState(() {
                                                      proceedNext = true;
                                                    });
                                                  }

                                                  if (cartItems[index][
                                                  'stock_available'] >=
                                                      quantityValue) {
                                                    SellDatabase().update(
                                                        cartItems[index]
                                                        ['id'],
                                                        {
                                                          'quantity':
                                                          quantityValue
                                                        });
                                                    // Don't call cartList() here to avoid rebuilding during typing
                                                  } else {
                                                    Fluttertoast.showToast(
                                                        msg: "${cartItems[index]['stock_available']}" +
                                                            AppLocalizations.of(
                                                                context)
                                                                .translate(
                                                                'stock_available'));
                                                  }
                                                } else {
                                                  Fluttertoast.showToast(
                                                      msg: AppLocalizations
                                                          .of(context)
                                                          .translate(
                                                          'please_enter_a_valid_quantity'));
                                                }
                                              } catch (e) {
                                                // Invalid input, do nothing or show message
                                                debugPrint(
                                                    'Invalid quantity input: $newQuantity');
                                              }
                                            } else {
                                              // Empty input - allow user to clear the field
                                              setState(() {
                                                proceedNext = false;
                                              });
                                            }
                                          },
                                          onEditingComplete: () {
                                            // Only refresh the cart when editing is complete
                                            cartList();
                                            FocusScope.of(context)
                                                .requestFocus(
                                                FocusNode());
                                          },
                                          onTap: () {
                                            // Select all text when tapped for easy editing
                                            quantityControllers[index]
                                                .selection =
                                                TextSelection(
                                                  baseOffset: 0,
                                                  extentOffset:
                                                  quantityControllers[
                                                  index]
                                                      .text
                                                      .length,
                                                );
                                          },
                                        )),
                                    Container(
                                      margin:
                                      EdgeInsets.only(left: MySize.size24!),
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                        children: <Widget>[
                                          InkWell(
                                            onTap: () {
                                              if (cartItems[index]
                                              ['stock_available'] >
                                                  cartItems[index]
                                                  ['quantity']) {
                                                SellDatabase().update(
                                                    cartItems[index]['id'], {
                                                  'quantity': cartItems[index]
                                                  ['quantity'] +
                                                      1
                                                });
                                                cartList();
                                              } else {
                                                var stockAvailable =
                                                cartItems[index]
                                                ['stock_available'];
                                                Fluttertoast.showToast(
                                                    msg: "$stockAvailable" +
                                                        AppLocalizations.of(
                                                            context)
                                                            .translate(
                                                            'stock_available'));
                                              }
                                            },
                                            child: Container(
                                              padding:
                                              EdgeInsets.all(MySize.size6!),
                                              decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color:
                                                  customAppTheme.bgLayer3,
                                                  boxShadow: [
                                                    BoxShadow(
                                                        color: themeData
                                                            .cardTheme
                                                            .shadowColor!
                                                            .withAlpha(8),
                                                        blurRadius:
                                                        MySize.size8!)
                                                  ]),
                                              child: Icon(
                                                MdiIcons.plus,
                                                size: MySize.size20,
                                                color: themeData
                                                    .colorScheme.onBackground,
                                              ),
                                            ),
                                          ),
                                          InkWell(
                                            onTap: () {
                                              if (cartItems[index]['quantity'] >
                                                  1) {
                                                SellDatabase().update(
                                                    cartItems[index]['id'], {
                                                  'quantity': cartItems[index]
                                                  ['quantity'] -
                                                      1
                                                });
                                                cartList();
                                              }
                                            },
                                            child: Container(
                                              padding:
                                              EdgeInsets.all(MySize.size6!),
                                              decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color:
                                                  customAppTheme.bgLayer3,
                                                  boxShadow: [
                                                    BoxShadow(
                                                        color: themeData
                                                            .cardTheme
                                                            .shadowColor!
                                                            .withAlpha(10),
                                                        blurRadius:
                                                        MySize.size8!)
                                                  ]),
                                              child: Icon(
                                                MdiIcons.minus,
                                                size: MySize.size20,
                                                color: themeData
                                                    .colorScheme.onBackground,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                Visibility(
                                    visible: (editItem == index),
                                    child: edit(cartItems[index])),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ));
      },
    );
  }

// Outside your widget class (stateful widget assumed)
  Map<int, TextEditingController> _discountControllers = {};

  Widget edit(index) {
    // Get or create controller
    if (!_discountControllers.containsKey(index['id'])) {
      _discountControllers[index['id']] = TextEditingController(
        text: index['discount_amount'] > 0
            ? index['discount_amount'].toStringAsFixed(2)
            : '',
      );
    }

    TextEditingController perproductdiscountController =
    _discountControllers[index['id']]!;

    return Container(
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              (canEditPrice)
                  ? SizedBox(
                width: MySize.size160,
                height: MySize.size50,
                child: TextFormField(
                  initialValue: index['unit_price'].toStringAsFixed(2),
                  decoration: InputDecoration(
                    prefix: Text(symbol),
                    labelText: AppLocalizations.of(context)
                        .translate('unit_price'),
                    border: themeData.inputDecorationTheme.border,
                    enabledBorder: themeData.inputDecorationTheme.border,
                    focusedBorder:
                    themeData.inputDecorationTheme.focusedBorder,
                  ),
                  style: AppTheme.getTextStyle(
                      themeData.textTheme.subtitle2,
                      fontWeight: 400,
                      letterSpacing: -0.2),
                  textAlign: TextAlign.end,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(
                        RegExp(r'^(\d+)?\.?\d{0,2}'))
                  ],
                  keyboardType: TextInputType.number,
                  onChanged: (newValue) {
                    double value = Helper().validateInput(newValue);
                    SellDatabase()
                        .update(index['id'], {'unit_price': value});
                    cartList();
                    debugPrint(
                        'edit: Updated unit_price to $value for sell_line id: ${index['id']}');
                  },
                ),
              )
                  : Container(),
              (canEditDiscount)
                  ? Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(AppLocalizations.of(context)
                      .translate('discount_type') +
                      ' : '),
                  inLineDiscount(index),
                ],
              )
                  : Container(),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              if (canEditDiscount)
                SizedBox(
                  width: MySize.size160,
                  height: MySize.size50,
                  child: TextFormField(
                    controller: perproductdiscountController,
                    decoration: InputDecoration(
                      prefix: Text(symbol),
                      labelText: AppLocalizations.of(context)
                          .translate('discount_amount'),
                      border: themeData.inputDecorationTheme.border,
                      enabledBorder: themeData.inputDecorationTheme.border,
                      focusedBorder:
                      themeData.inputDecorationTheme.focusedBorder,
                    ),
                    style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
                        fontWeight: 400, letterSpacing: -0.2),
                    textAlign: TextAlign.end,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(
                          RegExp(r'^(\d+)?\.?\d{0,2}'))
                    ],
                    keyboardType: TextInputType.number,
                    onChanged: (newValue) {
                      double value = Helper().validateInput(newValue);
                      proceedNext = true;

                      bool isInvalid = false;
                      String errorMsg = '';

                      if (index['discount_type'] == 'fixed' &&
                          value > index['unit_price']) {
                        isInvalid = true;
                        errorMsg = AppLocalizations.of(context)
                            .translate('invalid_discount_exceeds_total');
                      }

                      if (index['discount_type'] == 'percentage' &&
                          value > 100) {
                        isInvalid = true;
                        errorMsg = AppLocalizations.of(context)
                            .translate('invalid_discount_exceeds_100');
                      }

                      if (isInvalid) {
                        // Reset text field
                        perproductdiscountController.text = '0';

                        // Keep cursor at end
                        perproductdiscountController.selection =
                            TextSelection.fromPosition(
                              TextPosition(
                                  offset: perproductdiscountController.text.length),
                            );

                        // Update DB to 0 only if not editing quotation/draft
                        if (argument?['is_quotation'] != 1) {
                          SellDatabase()
                              .update(index['id'], {'discount_amount': 0});
                        }
                        cartList();

                        // Show toast
                        Fluttertoast.showToast(
                          msg: AppLocalizations.of(context)
                              .translate("errorMsg"),
                          toastLength: Toast.LENGTH_SHORT,
                        );

                        return;
                      }

                      // ✅ If valid input
                      // Only update database immediately if not editing quotation/draft
                      if (argument?['is_quotation'] != 1) {
                        SellDatabase()
                            .update(index['id'], {'discount_amount': value});
                      }
                      cartList();
                    },
                  ),
                ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(AppLocalizations.of(context).translate('tax') + ' : '),
                  inLineTax(index),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget inLineTax(index) {
    return DropdownButtonHideUnderline(
      child: DropdownButton(
          dropdownColor: themeData.backgroundColor,
          icon: Icon(Icons.arrow_drop_down),
          value: (index['tax_rate_id'] != null) ? index['tax_rate_id'] : 0,
          items: taxListMap.map<DropdownMenuItem<int>>((Map value) {
            return DropdownMenuItem<int>(
                value: value['id'],
                child: Text(value['name'],
                    softWrap: true, overflow: TextOverflow.ellipsis));
          }).toList(),
          onChanged: (newValue) {
            SellDatabase().update(index['id'],
                {'tax_rate_id': (newValue == 0) ? null : newValue});
            cartList();
            debugPrint(
                'inLineTax: Updated tax_rate_id to $newValue for sell_line id: ${index['id']}');
          }),
    );
  }

  Widget inLineDiscount(index) {
    return DropdownButtonHideUnderline(
      child: DropdownButton(
          dropdownColor: themeData.backgroundColor,
          icon: Icon(Icons.arrow_drop_down),
          value: index['discount_type'],
          items: <String>['fixed', 'percentage']
              .map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(value: value, child: Text(value));
          }).toList(),
          onChanged: (newValue) {
            // Only update database immediately if not editing quotation/draft
            if (argument?['is_quotation'] != 1) {
              SellDatabase().update(index['id'], {'discount_type': newValue});
            }
            cartList();
            debugPrint(
                'inLineDiscount: Updated discount_type to $newValue for sell_line id: ${index['id']}');
          }),
    );
  }

  String calculateInlineUnitPrice(price, taxId, discountType, discountAmount) {
    double unitPrice = price ?? 0.0;
    double taxAmount = 0.0;

    // Apply item-level discount
    double priceAfterDiscount;
    if (discountType == 'fixed') {
      priceAfterDiscount = unitPrice - (discountAmount ?? 0.0);
    } else {
      priceAfterDiscount = unitPrice * (1 - (discountAmount ?? 0.0) / 100);
    }

    // Apply tax
    if (taxId != null && taxId != 0) {
      for (var tax in taxListMap) {
        if (tax['id'] == taxId) {
          taxAmount = priceAfterDiscount * (tax['amount'] / 100);
          break;
        }
      }
    }

    double subTotal = priceAfterDiscount + taxAmount;
    debugPrint(
        'calculateInlineUnitPrice: price=$price, taxId=$taxId, discountType=$discountType, discountAmount=$discountAmount, subTotal=$subTotal');
    return subTotal.toString();
  }

  void confirmDelete(BuildContext context, int index) {
    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Icon(MdiIcons.alert, color: Colors.red, size: MySize.size50),
        content: Text(
          AppLocalizations.of(context).translate('are_you_sure') ??
              'Are you sure?',
          textAlign: TextAlign.center,
          style: AppTheme.getTextStyle(
            themeData.textTheme.bodyLarge,
            color: themeData.colorScheme.onBackground,
            fontWeight: 600,
            muted: true,
          ),
        ),
        actions: <Widget>[
          TextButton(
              onPressed: () async {
                // Set flag to indicate intentional deletion
                _isIntentionalDeletion = true;
                debugPrint(
                    'Cart: Set intentional deletion flag before deleting product');

                (argument!['sellId'] == null)
                    ? await SellDatabase().delete(
                    cartItems[index]['variation_id'],
                    cartItems[index]['product_id'])
                    : await SellDatabase().delete(
                    cartItems[index]['variation_id'],
                    cartItems[index]['product_id'],
                    sellId: argument!['sellId']);
                editItem = null;
                await cartList();

                // Check if cart is now empty and unlock table


                final tableIdAfterDelete = res_table_id;
                final locationIdAfterDelete = selectedLocationId;
                if (cartItems.isEmpty && tableIdAfterDelete != null && tableIdAfterDelete > 0 && (is_shipping == null || is_shipping == 0) && locationIdAfterDelete != null && locationIdAfterDelete > 0) {
                  try {
                    await FirebaseTableLockService().unlockTable(
                      tableId: tableIdAfterDelete,
                      locationId: locationIdAfterDelete,
                    );
                    debugPrint('Cart: Unlocked table $tableIdAfterDelete in Firebase after deleting last product');
                  } catch (e) {
                    debugPrint('Cart: Error unlocking table in Firebase: $e');
                  }
                }

                // Trigger UI update after cart refresh
                if (mounted) {
                  setState(() {});
                }

                Navigator.pop(context);
              },
              child: Text(AppLocalizations.of(context).translate('yes'))),
          TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(AppLocalizations.of(context).translate('no')))
        ],
      ),
    );
  }
}




