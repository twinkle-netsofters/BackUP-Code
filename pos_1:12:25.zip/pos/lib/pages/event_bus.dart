import 'dart:async';

// Simple event bus for communication between screens
class EventBus {
  static final EventBus _instance = EventBus._internal();
  factory EventBus() => _instance;
  EventBus._internal();

  final StreamController<dynamic> _streamController = StreamController<dynamic>.broadcast();

  Stream<dynamic> get stream => _streamController.stream;

  void fire(dynamic event) {
    _streamController.add(event);
  }

  void dispose() {
    _streamController.close();
  }
}

// Events
class SaleCompletedEvent {}
class QuotationCreatedEvent {}
class DraftSavedEvent {}

// In event_bus.dart, add these new events:
class SaleFinalizedEvent {
  final double amount;

  SaleFinalizedEvent(this.amount);
}

class DraftFinalizedEvent {
  final double amount;

  DraftFinalizedEvent(this.amount);
}

class QuotationFinalizedEvent {
  final double amount;

  QuotationFinalizedEvent(this.amount);
}

class CustomerPaymentEvent {
  final double amount;
  final String paymentMethod;
  final int customerId;

  CustomerPaymentEvent(this.amount, this.paymentMethod, this.customerId);
}

class TableAvailabilityChangedEvent {
  final int? tableId;
  final bool isShipping;
  final bool isAvailable;

  TableAvailabilityChangedEvent({
    this.tableId,
    required this.isShipping,
    required this.isAvailable,
  });
}