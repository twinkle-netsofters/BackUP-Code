import 'dart:async';
import 'package:flutter/material.dart';
import '../models/sellDatabase.dart';
import '../models/invoice.dart';
import '../locale/MyLocalizations.dart';

class InvoiceGenerator {
// Function to generate an invoice for a given sellId
  static Future<String> generateInvoiceWithData({
    required int sellId,
    required BuildContext context,
  }) async {
    try {
      print(
          'InvoiceGenerator: Starting invoice generation for sellId: $sellId');

// Fetch sell data with timeout
      List sells = await SellDatabase()
          .getSellBySellId(sellId)
          .timeout(Duration(seconds: 10), onTimeout: () {
        throw TimeoutException('Failed to fetch sell data within 10 seconds');
      });

      print(
          'InvoiceGenerator: Fetched sell data: ${sells.isNotEmpty ? sells[0] : 'Empty'}');

      if (sells.isEmpty || sells[0] is! Map<String, dynamic>) {
        throw Exception('Sell not found or invalid format for ID: $sellId');
      }

// Extract taxId from sell data
      int? taxId = sells[0]['tax_rate_id'];
      print('InvoiceGenerator: Tax ID: $taxId');

// Generate invoice with timeout
      InvoiceFormatter formatter = InvoiceFormatter();
      String invoiceHtml = await formatter
          .generateInvoice(sellId, taxId, context)
          .timeout(Duration(seconds: 10), onTimeout: () {
        throw TimeoutException('Invoice generation timed out after 10 seconds');
      });

      print('InvoiceGenerator: Invoice HTML generated successfully');
      return invoiceHtml;
    } catch (e, stackTrace) {
      print('InvoiceGenerator: Error generating invoice: $e');
      print('InvoiceGenerator: Stack trace: $stackTrace');
      return '''
        <section class="invoice print_section" id="receipt_section">
          <meta charset="UTF-8">
          <p>${AppLocalizations.of(context).translate('error_generating_invoice') ?? 'Error generating invoice'}</p>
        </section>
      ''';
    }
  }
}
