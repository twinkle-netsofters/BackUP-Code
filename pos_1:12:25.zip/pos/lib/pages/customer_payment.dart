import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:search_choices/search_choices.dart';

import '../apis/contact_payment.dart';
import '../helpers/AppTheme.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/otherHelpers.dart';
import '../locale/MyLocalizations.dart';
import '../models/contact_model.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import '../models/paymentDatabase.dart';
import 'event_bus.dart';

class ContactPayment extends StatefulWidget {
  @override
  _ContactPaymentState createState() => _ContactPaymentState();
}

class _ContactPaymentState extends State<ContactPayment> {
  final _formKey = GlobalKey<FormState>();
  int selectedCustomerId = 0;
  List<Map<String, dynamic>> customerListMap = [],
      paymentAccounts = [],
      paymentMethods = [],
      locationListMap = [
        {'id': 0, 'name': 'set location'}
      ];
  Map<String, dynamic> selectedLocation = {'id': 0, 'name': 'set location'},
      selectedCustomer = {'id': 0, 'name': 'select customer', 'mobile': ' - '};
  String due = '0.00';
  Map<String, dynamic> selectedPaymentAccount = {'id': null, 'name': "None"},
      selectedPaymentMethod = {
        'name': 'name',
        'value': 'value',
        'account_id': null
      };

  String symbol = '';
  var payingAmount = new TextEditingController();
  bool isLoading = false;

  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
  CustomAppTheme customAppTheme = AppTheme.getCustomAppTheme(themeType);

  @override
  void initState() {
    super.initState();
    selectCustomer();
    setPaymentDetails();
    setLocationMap();
    Helper().syncCallLogs();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Refresh due amount when screen is resumed (e.g., after making payments elsewhere)
    if (selectedCustomerId != 0) {
      _refreshCustomerDue();
    }
  }

  /// Refresh customer due amount from local database (correctly excludes change returns)
  Future<void> _refreshCustomerDue() async {
    try {
      debugPrint('_refreshCustomerDue: Calculating due amount for customer $selectedCustomerId');

      // Calculate due amount locally using the same logic as home screen
      // This ensures change returns are properly excluded
      double calculatedDue = await _calculateCustomerDueFromLocalDatabase(selectedCustomerId);

      // Format to ensure proper decimal places
      due = calculatedDue.toStringAsFixed(2);
      setState(() {});
      debugPrint('_refreshCustomerDue: Final due amount for customer $selectedCustomerId: $due');

      // Also try to sync with server if connected (for consistency)
      if (await Helper().checkConnectivity()) {
        try {
          await ContactPaymentApi()
              .getCustomerDue(selectedCustomerId)
              .then((value) async {
            if (value != null && value['data'] != null && value['data'].isNotEmpty) {
              var sellDueValue = value['data'][0]['sell_due'];
              if (sellDueValue != null) {
                double apiDueAmount = double.tryParse(sellDueValue.toString()) ?? 0.0;
                debugPrint('_refreshCustomerDue: API due amount: $apiDueAmount, Local due amount: $calculatedDue');

                // If there's a significant difference, log it for debugging
                if ((apiDueAmount - calculatedDue).abs() > 0.01) {
                  debugPrint('_refreshCustomerDue: WARNING - API and local calculations differ significantly');
                }
              }
            }
          });
        } catch (e) {
          debugPrint('_refreshCustomerDue: Error syncing with API: $e');
          // Continue with local calculation even if API fails
        }
      }
    } catch (e) {
      debugPrint('Error refreshing customer due: $e');
      // On error, ensure due is set to a safe value
      due = '0.00';
      setState(() {});
    }
  }

  /// Calculate total partial payments made by a customer from local database
  Future<double> _calculateCustomerPartialPayments(int customerId) async {
    try {
      debugPrint('_calculateCustomerPartialPayments: Starting calculation for customer $customerId');

      // Get all sales for this customer from local database
      final List allSells = await SellDatabase().getSells(all: true);
      debugPrint('_calculateCustomerPartialPayments: Found ${allSells.length} total sales in database');

      final List customerSales = allSells
          .where((s) => (s['contact_id'] == customerId) &&
          (s['is_quotation'] == 0) &&
          (s['status'] != 'draft') &&
          (s['sale_status'] != 'draft'))
          .toList();

      debugPrint('_calculateCustomerPartialPayments: Found ${customerSales.length} sales for customer $customerId');

      double totalPartialPayments = 0.0;

      // For each sale, get the payments made and sum them up
      for (var sale in customerSales) {
        final int saleId = sale['id'];
        debugPrint('_calculateCustomerPartialPayments: Processing sale ID $saleId');

        try {
          final List<Map<String, dynamic>> payments = await PaymentDatabase().get(saleId);
          debugPrint('_calculateCustomerPartialPayments: Found ${payments.length} payments for sale $saleId');

          for (var payment in payments) {
            double paymentAmount = 0.0;
            if (payment['amount'] != null) {
              paymentAmount = (payment['amount'] is num)
                  ? (payment['amount'] as num).toDouble()
                  : double.tryParse(payment['amount'].toString()) ?? 0.0;
            }
            debugPrint('_calculateCustomerPartialPayments: Payment amount: $paymentAmount');
            totalPartialPayments += paymentAmount;
          }
        } catch (e) {
          debugPrint('_calculateCustomerPartialPayments: Error getting payments for sale $saleId: $e');
          // Continue processing other sales even if one fails
          continue;
        }
      }

      debugPrint('_calculateCustomerPartialPayments: Customer $customerId has made total partial payments: $totalPartialPayments');
      return totalPartialPayments;
    } catch (e) {
      debugPrint('Error calculating customer partial payments: $e');
      return 0.0;
    }
  }

  /// Calculate customer due amount from local database (same logic as home screen)
  /// This correctly excludes change returns from the due calculation
  Future<double> _calculateCustomerDueFromLocalDatabase(int customerId) async {
    try {
      debugPrint('_calculateCustomerDueFromLocalDatabase: Starting calculation for customer $customerId');

      // Get all sales for this customer from local database
      final List allSells = await SellDatabase().getSells(all: true);
      final List customerSales = allSells
          .where((s) => (s['contact_id'] == customerId) &&
          (s['is_quotation'] == 0) &&
          (s['status'] != 'draft') &&
          (s['sale_status'] != 'draft'))
          .toList();

      debugPrint('_calculateCustomerDueFromLocalDatabase: Found ${customerSales.length} sales for customer $customerId');

      double totalDueAmount = 0.0;

      // Calculate due amount using pending_amount (same as home screen logic)
      for (var sale in customerSales) {
        final int saleId = sale['id'];

        // Get pending amount (this is the correct due amount for this sale)
        double pendingAmount = 0.0;
        if (sale['pending_amount'] != null) {
          pendingAmount = (sale['pending_amount'] is num)
              ? (sale['pending_amount'] as num).toDouble()
              : double.tryParse(sale['pending_amount'].toString()) ?? 0.0;
        }

        totalDueAmount += pendingAmount;
        debugPrint('_calculateCustomerDueFromLocalDatabase: Sale $saleId - Pending Amount: $pendingAmount');
      }

      debugPrint('_calculateCustomerDueFromLocalDatabase: Customer $customerId - Total Due Amount: $totalDueAmount');
      return totalDueAmount;
    } catch (e) {
      debugPrint('Error calculating customer due from local database: $e');
      return 0.0;
    }
  }

  /// Calculate the actual due amount by comparing total invoice amounts vs total payments
  Future<double> _calculateActualCustomerDue(int customerId) async {
    try {
      debugPrint('_calculateActualCustomerDue: Starting calculation for customer $customerId');

      // Get all sales for this customer from local database
      final List allSells = await SellDatabase().getSells(all: true);
      final List customerSales = allSells
          .where((s) => (s['contact_id'] == customerId) &&
          (s['is_quotation'] == 0) &&
          (s['status'] != 'draft') &&
          (s['sale_status'] != 'draft'))
          .toList();

      debugPrint('_calculateActualCustomerDue: Found ${customerSales.length} sales for customer $customerId');

      double totalInvoiceAmount = 0.0;
      double totalPayments = 0.0;

      // Calculate total invoice amounts and payments
      for (var sale in customerSales) {
        final int saleId = sale['id'];

        // Get invoice amount
        double invoiceAmount = 0.0;
        if (sale['invoice_amount'] != null) {
          invoiceAmount = (sale['invoice_amount'] is num)
              ? (sale['invoice_amount'] as num).toDouble()
              : double.tryParse(sale['invoice_amount'].toString()) ?? 0.0;
        }
        totalInvoiceAmount += invoiceAmount;

        debugPrint('_calculateActualCustomerDue: Sale $saleId - Invoice: $invoiceAmount');

        // Get payments for this sale
        try {
          final List<Map<String, dynamic>> payments = await PaymentDatabase().get(saleId);

          for (var payment in payments) {
            double paymentAmount = 0.0;
            if (payment['amount'] != null) {
              paymentAmount = (payment['amount'] is num)
                  ? (payment['amount'] as num).toDouble()
                  : double.tryParse(payment['amount'].toString()) ?? 0.0;
            }
            totalPayments += paymentAmount;
            debugPrint('_calculateActualCustomerDue: Sale $saleId - Payment: $paymentAmount');
          }
        } catch (e) {
          debugPrint('_calculateActualCustomerDue: Error getting payments for sale $saleId: $e');
          continue;
        }
      }

      double actualDue = totalInvoiceAmount - totalPayments;
      debugPrint('_calculateActualCustomerDue: Customer $customerId - Total Invoice: $totalInvoiceAmount, Total Payments: $totalPayments, Actual Due: $actualDue');

      // Return the actual due amount (can be negative if customer has overpaid)
      return actualDue;
    } catch (e) {
      debugPrint('Error calculating actual customer due: $e');
      return 0.0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      bottom: true,
      child: Scaffold(
        appBar: AppBar(
          elevation: 0.0,
          title: Text(AppLocalizations.of(context).translate('contact_payment'),
              style: AppTheme.getTextStyle(themeData.textTheme.headline6,
                  fontWeight: 600)),
        ),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(MySize.size10!),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  customerList(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        children: [
                          Text(
                            AppLocalizations.of(context)
                                .translate('due')
                                .toUpperCase(),
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.subtitle1,
                                fontWeight: 600,
                                letterSpacing: -0.2),
                          ),
                          // Padding(padding: EdgeInsets.symmetric(vertical: MySize.size4)),
                          Text(
                            Helper().formatCurrency(due),
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.headline5,
                                fontWeight: 600,
                                letterSpacing: -0.2),
                          ),
                        ],
                      )
                    ],
                  ),
                  Padding(padding: EdgeInsets.symmetric(vertical: MySize.size4!)),
                  Visibility(
                    visible: (selectedCustomerId != 0),
                    child: Column(
                      children: [
                        TextFormField(
                            decoration: InputDecoration(
                              prefix: Text(symbol),
                              labelText: AppLocalizations.of(context)
                                  .translate('payment_amount'),
                              border: themeData.inputDecorationTheme.border,
                              enabledBorder:
                              themeData.inputDecorationTheme.border,
                              focusedBorder:
                              themeData.inputDecorationTheme.focusedBorder,
                            ),
                            controller: payingAmount,
                            validator: (newValue) {
                              if (newValue == '' || double.parse(newValue!) < 0.01) {
                                return AppLocalizations.of(context)
                                    .translate('enter_valid_payment_amount');
                              }

                              double dueAmount = double.tryParse(due.toString()) ?? 0.0;
                              double paymentAmount = double.parse(newValue);

                              // If due amount is negative (customer has credit), don't allow payments
                              if (dueAmount < 0.0) {
                                return 'Customer has a credit balance of ${dueAmount.abs().toStringAsFixed(2)}. No payment needed.';
                              }

                              // If due amount is zero, don't allow payments
                              if (dueAmount == 0.0) {
                                return 'Customer has no outstanding balance.';
                              }

                              // Don't allow payment more than due amount
                              if (paymentAmount > dueAmount) {
                                return AppLocalizations.of(context)
                                    .translate('enter_valid_payment_amount');
                              }

                              return null;
                            },
                            textAlign: TextAlign.end,
                            style: AppTheme.getTextStyle(
                                themeData.textTheme.subtitle2,
                                fontWeight: 400,
                                letterSpacing: -0.2),
                            inputFormatters: [
                              // ignore: deprecated_member_use
                              FilteringTextInputFormatter(
                                  RegExp(r'^(\d+)?\.?\d{0,2}'),
                                  allow: true)
                            ],
                            keyboardType: TextInputType.number,
                            onChanged: (value) {}),
                        Padding(
                          padding: EdgeInsets.all(MySize.size10!),
                          child: Row(
                            children: <Widget>[
                              Text(
                                AppLocalizations.of(context)
                                    .translate('location') +
                                    ' : ',
                                style: AppTheme.getTextStyle(
                                    themeData.textTheme.headline6,
                                    fontWeight: 700,
                                    letterSpacing: -0.2),
                              ),
                              locations(),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(MySize.size10!),
                          child: paymentOptions(),
                        ),
                        Padding(
                          padding: EdgeInsets.all(MySize.size10!),
                          child: paymentAccount(),
                        ),
                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: themeData.colorScheme.primary,
                        ),
                        onPressed: isLoading ? null : () async {
                          await onSubmit();
                        },
                        child: isLoading
                            ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  themeData.colorScheme.onPrimary,
                                ),
                              ),
                            ),
                            SizedBox(width: 8),
                            Text(
                              AppLocalizations.of(context).translate('processing'),
                              style: AppTheme.getTextStyle(
                                  themeData.textTheme.headline6,
                                  color: themeData.colorScheme.onPrimary,
                                  fontWeight: 700,
                                  letterSpacing: -0.2),
                            ),
                          ],
                        )
                            : Text(
                          AppLocalizations.of(context).translate('submit'),
                          style: AppTheme.getTextStyle(
                              themeData.textTheme.headline6,
                              color: themeData.colorScheme.onPrimary,
                              fontWeight: 700,
                              letterSpacing: -0.2),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  onSubmit() async {
    // Prevent multiple submissions
    if (isLoading) {
      debugPrint('onSubmit: Already processing payment, ignoring duplicate submission');
      return;
    }

    debugPrint('onSubmit: Starting payment submission process');
    setState(() {
      isLoading = true;
    });

    try {
      if (await Helper().checkConnectivity()) {
        if (_formKey.currentState!.validate()) {
          if (selectedLocation['id'] != 0) {
            Map<String, dynamic> paymentMap = {
              "contact_id": selectedCustomerId,
              "amount": double.parse(payingAmount.text),
              "method": selectedPaymentMethod['name'],
              "account_id": selectedPaymentMethod['account_id'],
              "paid_on": DateFormat("yyyy-MM-dd hh:mm:ss")
                  .format(DateTime.now())
                  .toString(),
            };

            debugPrint('Sending payment to server: $paymentMap');

            await ContactPaymentApi()
                .postContactPayment(paymentMap)
            //.then((value) {
                .then((value) async {
              debugPrint('Payment sent to server successfully. Response status: $value');

              // Check if the payment was successfully processed
              // Accept both 200 (OK) and 201 (Created) as success responses
              if (value == null || (value != 200 && value != 201)) {
                debugPrint('Error: Payment was not processed successfully. Status: $value');
                Fluttertoast.showToast(
                    msg: 'Payment failed. Please try again or check with administrator.');
                return;
              }

              debugPrint('Payment processed successfully with status: $value');

              // Update local DB so Recent Sales reflects latest pending amounts
              await _applyPaymentToLocalRecentSales(
                  contactId: selectedCustomerId,
                  paidAmount: double.tryParse(payingAmount.text) ?? 0.0);

              // Store the customer payment in PaymentDatabase for payment details widget
              await _storeCustomerPaymentInDatabase(
                contactId: selectedCustomerId,
                paidAmount: double.tryParse(payingAmount.text) ?? 0.0,
                paymentMethod: selectedPaymentMethod['name'],
                accountId: selectedPaymentMethod['account_id'],
              );

              // Wait a moment for server to process the payment
              await Future.delayed(Duration(milliseconds: 500));

              // Refresh customer due amount from server after payment
              await _refreshCustomerDue();
              debugPrint('Refreshed customer due amount after payment');

              // Fire event to notify home screen about the payment
              EventBus().fire(CustomerPaymentEvent(
                double.tryParse(payingAmount.text) ?? 0.0,
                selectedPaymentMethod['name'],
                selectedCustomerId,
              ));

              Navigator.popUntil(context, ModalRoute.withName('/home'));
              Fluttertoast.showToast(
                  msg: AppLocalizations.of(context)
                      .translate('payment_successful'));
            });
          } else {
            Fluttertoast.showToast(
                msg: AppLocalizations.of(context)
                    .translate('error_invalid_location'));
          }
        }
      } else {
        Fluttertoast.showToast(
            msg: AppLocalizations.of(context).translate('check_connectivity'));
      }
    } catch (e) {
      // Handle any errors that might occur during payment processing
      Fluttertoast.showToast(
          msg: AppLocalizations.of(context).translate('payment_failed') ?? 'Payment failed. Please try again.');
    } finally {
      // Always reset loading state
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> _applyPaymentToLocalRecentSales({
    required int contactId,
    required double paidAmount,
  }) async {
    try {
      if (paidAmount <= 0) return;

      // Fetch all sells and filter by contact
      final List allSells = await SellDatabase().getSells(all: true);
      final List relevant = allSells
          .where((s) => (s['contact_id'] == contactId) &&
          (s['is_quotation'] == 0) &&
          (s['status'] != 'draft') &&
          (s['sale_status'] != 'draft'))
          .toList()
        ..sort((a, b) => (b['id'] as int).compareTo(a['id'] as int));

      // Debug logging to verify filtering is working correctly
      debugPrint('_applyPaymentToLocalRecentSales: Found ${allSells.length} total sales for contact $contactId');
      debugPrint('_applyPaymentToLocalRecentSales: After filtering (excluding drafts and quotations): ${relevant.length} sales');
      for (var sale in relevant) {
        debugPrint('_applyPaymentToLocalRecentSales: Processing sale ID ${sale['id']} - status: ${sale['status']}, sale_status: ${sale['sale_status']}, is_quotation: ${sale['is_quotation']}');
      }

      double remaining = paidAmount;
      for (final sale in relevant) {
        if (remaining <= 0) break;
        final int saleId = sale['id'];
        final double invoice = (sale['invoice_amount'] is num)
            ? (sale['invoice_amount'] as num).toDouble()
            : double.tryParse('${sale['invoice_amount']}') ?? 0.0;
        final double pending = (sale['pending_amount'] is num)
            ? (sale['pending_amount'] as num).toDouble()
            : double.tryParse('${sale['pending_amount']}') ?? 0.0;

        if (pending <= 0) continue;

        final double applied = remaining >= pending ? pending : remaining;
        final double newPending = (pending - applied);

        await SellDatabase().updateSells(saleId, {
          'pending_amount': newPending,
        });

        remaining -= applied;
      }
    } catch (e) {
      // Silent fail to avoid disrupting payment flow
    }
  }


  Future<void> _storeCustomerPaymentInDatabase({
    required int contactId,
    required double paidAmount,
    required String paymentMethod,
    int? accountId,
  }) async {
    try {
      if (paidAmount <= 0) return;

      // Find the most recent sale for this customer to link the payment
      final List allSells = await SellDatabase().getSells(all: true);
      final List relevant = allSells
          .where((s) => (s['contact_id'] == contactId) &&
          (s['is_quotation'] == 0) &&
          (s['status'] != 'draft') &&
          (s['sale_status'] != 'draft'))
          .toList()
        ..sort((a, b) => (b['id'] as int).compareTo(a['id'] as int));

      if (relevant.isNotEmpty) {
        // Use the most recent sale to link the payment
        final int saleId = relevant.first['id'];

        // Create a payment record for the customer payment
        Map<String, dynamic> paymentRecord = {
          'sell_id': saleId,
          'method': paymentMethod,
          'amount': paidAmount,
          'note': 'Customer payment for outstanding balance',
          'account_id': accountId,
          'is_return': 0,
          'received_amount': paidAmount,
          'change_return': 0.0,
          'card_details': null,
        };

        // Store in PaymentDatabase
        await PaymentDatabase().store(paymentRecord);
      } else {
        // If no sales found, create a special entry with sell_id = 0 to represent customer payments
        // This ensures the payment appears in the payment details widget
        Map<String, dynamic> paymentRecord = {
          'sell_id': 0, // Special ID for customer payments without sales
          'method': paymentMethod,
          'amount': paidAmount,
          'note': 'Customer payment for outstanding balance',
          'account_id': accountId,
          'is_return': 0,
          'received_amount': paidAmount,
          'change_return': 0.0,
          'card_details': null,
        };

        // Store in PaymentDatabase
        await PaymentDatabase().store(paymentRecord);
      }
    } catch (e) {
      // Silent fail to avoid disrupting payment flow
      print('Error storing customer payment in database: $e');
    }
  }

  //dropdown widget for selecting customer
  Widget customerList() {
    return Column(
      children: [
        Text(
          AppLocalizations.of(context).translate('select_customer') + ' : ',
          style: AppTheme.getTextStyle(themeData.textTheme.headline6,
              fontWeight: 700, letterSpacing: -0.2),
        ),
        SearchChoices.single(
          underline: Visibility(
            child: Container(),
            visible: false,
          ),
          displayClearIcon: false,
          value: jsonEncode(selectedCustomer),
          items: customerListMap.map<DropdownMenuItem<String>>((Map value) {
            return DropdownMenuItem<String>(
                value: jsonEncode(value),
                child: Container(
                  width: MySize.screenWidth! * 0.8,
                  child: Text("${value['name']} (${value['mobile'] ?? ' - '})",
                      softWrap: true,
                      maxLines: 5,
                      overflow: TextOverflow.ellipsis,
                      style: AppTheme.getTextStyle(
                          themeData.textTheme.bodyText2,
                          color: themeData.colorScheme.onBackground)),
                ));
          }).toList(),
          // value: customerListMap[0],
          iconEnabledColor: Colors.blue,
          iconDisabledColor: Colors.black,
          onChanged: (value) async {
            setState(() {
              selectedCustomer = jsonDecode(value);
            });
            var newValue = selectedCustomer['id'];
            if (newValue != 0) {
              showDialog(
                barrierDismissible: false,
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    content: Row(
                      children: [
                        CircularProgressIndicator(),
                        Container(
                            margin: EdgeInsets.only(left: 5),
                            child: Text(AppLocalizations.of(context)
                                .translate('loading'))),
                      ],
                    ),
                  );
                },
              );

              // Calculate due amount locally (same logic as home screen)
              // This ensures change returns are properly excluded
              double calculatedDue = await _calculateCustomerDueFromLocalDatabase(newValue);

              // Format to ensure proper decimal places
              due = calculatedDue.toStringAsFixed(2);
              setState(() {
                selectedCustomerId = newValue;
                _formKey.currentState!.reset();
              });
              debugPrint('Customer selection: Final due amount for customer $newValue: $due');

              // Also try to sync with server if connected (for consistency)
              if (await Helper().checkConnectivity()) {
                try {
                  await ContactPaymentApi()
                      .getCustomerDue(newValue)
                      .then((value) async {
                    if (value != null && value['data'] != null && value['data'].isNotEmpty) {
                      var sellDueValue = value['data'][0]['sell_due'];
                      if (sellDueValue != null) {
                        double apiDueAmount = double.tryParse(sellDueValue.toString()) ?? 0.0;
                        debugPrint('Customer selection: API due amount: $apiDueAmount, Local due amount: $calculatedDue');

                        // If there's a significant difference, log it for debugging
                        if ((apiDueAmount - calculatedDue).abs() > 0.01) {
                          debugPrint('Customer selection: WARNING - API and local calculations differ significantly');
                        }
                      }
                    }
                  });
                } catch (e) {
                  debugPrint('Customer selection: Error syncing with API: $e');
                  // Continue with local calculation even if API fails
                }
              }

              Navigator.pop(context);
            }
          },
          isExpanded: true,
        )
      ],
    );
  }

  Widget locations() {
    return PopupMenuButton(
        onSelected: (item) {
          setState(() {
            selectedLocation = item as Map<String, dynamic>;
            setPaymentDetails().then((value) {
              selectedPaymentMethod = paymentMethods[0];
              selectedPaymentAccount = paymentAccounts[0];
              paymentAccounts.forEach((element) {
                if (selectedPaymentMethod['account_id'] == element['id']) {
                  selectedPaymentAccount = element;
                }
              });
            });
          });
        },
        itemBuilder: (BuildContext context) {
          return locationListMap.map((Map value) {
            return PopupMenuItem(
              value: value,
              height: MySize.size36!,
              child: Text(value['name'],
                  style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                      color: themeData.colorScheme.onBackground)),
            );
          }).toList();
        },
        color: themeData.backgroundColor,
        child: Container(
          padding: EdgeInsets.only(
              left: MySize.size12!,
              right: MySize.size12!,
              top: MySize.size8!,
              bottom: MySize.size8!),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
            color: customAppTheme.bgLayer1,
            border: Border.all(color: customAppTheme.bgLayer3, width: 1),
          ),
          child: Row(
            children: <Widget>[
              Text(
                selectedLocation['name'],
                style: AppTheme.getTextStyle(
                  themeData.textTheme.bodyText1,
                  color: themeData.colorScheme.onBackground,
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: MySize.size4!),
                child: Icon(
                  MdiIcons.chevronDown,
                  size: MySize.size22,
                  color: themeData.colorScheme.onBackground,
                ),
              )
            ],
          ),
        ));
  }

  selectCustomer() async {
    customerListMap = [
      {'id': 0, 'name': 'select customer', 'mobile': ' - '}
    ];
    await Contact().get().then((value) {
      value.forEach((Map<String, dynamic> element) {
        setState(() {
          customerListMap.add({
            'id': element['id'],
            'name': element['name'],
            'mobile': element['mobile']
          });
        });
      });
    });
  }

  setLocationMap() async {
    locationListMap = [];
    await System().get('location').then((value) {
      value.forEach((element) {
        setState(() {
          locationListMap.add({
            'id': element['id'],
            'name': element['name'],
          });
        });
      });
    });
  }

  setPaymentDetails() async {
    await Helper().getFormattedBusinessDetails().then((value) {
      setState(() {
        symbol = value['symbol'];
      });
    });
    List payments =
    await System().get('payment_method', selectedLocation['id']);
    paymentAccounts = [
      {'id': null, 'name': "None"}
    ];
    await System().getPaymentAccounts().then((value) {
      List<String> accIds = [];
      value.forEach((element) {
        payments.forEach((payment) {
          if ((payment['account_id'].toString() == element['id'].toString()) &&
              !accIds.contains(element['id'].toString())) {
            accIds.add(element['id'].toString());
            paymentAccounts.add({'id': element['id'], 'name': element['name']});
          }
        });
      });
    });
    paymentMethods = [];
    payments.forEach((element) {
      setState(() {
        paymentMethods.add({
          'name': element['name'],
          'value': element['label'],
          'account_id': (element['account_id'] != null)
              ? int.parse(element['account_id'].toString())
              : null
        });
      });
    });
    // Debug: Print available payment methods
    print('Available payment methods: $paymentMethods');
  }

  //contact payment widget
  Widget paymentOptions() {
    return Row(
      children: <Widget>[
        Text(
          AppLocalizations.of(context).translate('payment_method') + ' : ',
          style: AppTheme.getTextStyle(themeData.textTheme.headline6,
              fontWeight: 700, letterSpacing: -0.2),
        ),
        PopupMenuButton(
          onSelected: (item) async {
            setState(() {
              selectedPaymentMethod = item as Map<String, dynamic>;
              selectedPaymentAccount = paymentAccounts[0];
              paymentAccounts.forEach((element) {
                if (selectedPaymentMethod['account_id'] == element['id']) {
                  selectedPaymentAccount = element;
                }
              });
            });

            // Check if Card payment method is selected and show card details dialog
            print('Selected payment method: ${selectedPaymentMethod}');
            print('Payment method name: ${selectedPaymentMethod['name']}');
            print('Payment method value: ${selectedPaymentMethod['value']}');

            // Check multiple variations of card payment methods
            String name = selectedPaymentMethod['name']?.toString().toLowerCase() ?? '';
            String value = selectedPaymentMethod['value']?.toString().toLowerCase() ?? '';

            if (name.contains('card') ||
                name.contains('credit') ||
                name.contains('debit') ||
                value.contains('card') ||
                value.contains('credit') ||
                value.contains('debit')) {
              print('Card payment method detected, showing dialog...');
              await showCardDetailsDialog();
            } else {
              print('Not a card payment method');
            }

          },
          itemBuilder: (BuildContext context) {
            return paymentMethods.map((Map value) {
              return PopupMenuItem(
                value: value,
                height: MySize.size36!,
                child: Text(value['value'],
                    style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                        color: themeData.colorScheme.onBackground)),
              );
            }).toList();
          },
          color: themeData.backgroundColor,
          child: Container(
            padding: EdgeInsets.only(
                left: MySize.size12!,
                right: MySize.size12!,
                top: MySize.size8!,
                bottom: MySize.size8!),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
              color: customAppTheme.bgLayer1,
              border: Border.all(color: customAppTheme.bgLayer3, width: 1),
            ),
            child: Row(
              children: <Widget>[
                Text(
                  selectedPaymentMethod['value'],
                  style: AppTheme.getTextStyle(
                    themeData.textTheme.bodyText1,
                    color: themeData.colorScheme.onBackground,
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: MySize.size4!),
                  child: Icon(
                    MdiIcons.chevronDown,
                    size: MySize.size22,
                    color: themeData.colorScheme.onBackground,
                  ),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }

  //payment account widget
  Widget paymentAccount() {
    return Row(
      children: <Widget>[
        Text(
          AppLocalizations.of(context).translate('payment_account') + ' : ',
          style: AppTheme.getTextStyle(themeData.textTheme.headline6,
              fontWeight: 700, letterSpacing: -0.2),
        ),
        PopupMenuButton(
          onSelected: (item) {
            Map<String, dynamic> selectedItem = item as Map<String, dynamic>;
            setState(() {
              selectedPaymentAccount = item;
              selectedPaymentMethod['account_id'] = selectedItem['id'];
            });
          },
          itemBuilder: (BuildContext context) {
            return paymentAccounts.map((Map value) {
              return PopupMenuItem(
                value: value,
                height: MySize.size36!,
                child: Text(value['name'],
                    style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                        color: themeData.colorScheme.onBackground)),
              );
            }).toList();
          },
          color: themeData.backgroundColor,
          child: Container(
            padding: EdgeInsets.only(
                left: MySize.size12!,
                right: MySize.size12!,
                top: MySize.size8!,
                bottom: MySize.size8!),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
              color: customAppTheme.bgLayer1,
              border: Border.all(color: customAppTheme.bgLayer3, width: 1),
            ),
            child: Row(
              children: <Widget>[
                Text(
                  selectedPaymentAccount['name'],
                  style: AppTheme.getTextStyle(
                    themeData.textTheme.bodyText1,
                    color: themeData.colorScheme.onBackground,
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: MySize.size4!),
                  child: Icon(
                    MdiIcons.chevronDown,
                    size: MySize.size22,
                    color: themeData.colorScheme.onBackground,
                  ),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }

  // Show card details dialog when Card payment method is selected
  Future<void> showCardDetailsDialog() async {
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return CardDetailsDialog(
          onSave: (Map<String, dynamic> cardDetails) {
            setState(() {
              // Store card details in the selected payment method
              selectedPaymentMethod['card_details'] = cardDetails;
            });
          },
        );
      },
    );
  }
}

// Card Details Dialog Widget
class CardDetailsDialog extends StatefulWidget {
  final Function(Map<String, dynamic>) onSave;

  const CardDetailsDialog({
    Key? key,
    required this.onSave,
  }) : super(key: key);

  @override
  _CardDetailsDialogState createState() => _CardDetailsDialogState();
}

class _CardDetailsDialogState extends State<CardDetailsDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController cardNumberController;
  late final TextEditingController cardHolderNameController;
  late final TextEditingController cardTransactionNumberController;
  late final TextEditingController cardTypeController;
  late final TextEditingController cardMonthController;
  late final TextEditingController cardYearController;
  late final TextEditingController cardSecurityController;

  @override
  void initState() {
    super.initState();
    cardNumberController = TextEditingController();
    cardHolderNameController = TextEditingController();
    cardTransactionNumberController = TextEditingController();
    cardTypeController = TextEditingController();
    cardMonthController = TextEditingController();
    cardYearController = TextEditingController();
    cardSecurityController = TextEditingController();
  }

  @override
  void dispose() {
    cardNumberController.dispose();
    cardHolderNameController.dispose();
    cardTransactionNumberController.dispose();
    cardTypeController.dispose();
    cardMonthController.dispose();
    cardYearController.dispose();
    cardSecurityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeData = Theme.of(context);

    return AlertDialog(
      title: Text(
        'Enter Card Details',
        style: AppTheme.getTextStyle(themeData.textTheme.headline6, fontWeight: 600),
      ),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: cardNumberController,
                decoration: InputDecoration(
                  labelText: 'Card Number',
                ),
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(16),
                ],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Card number is required';
                  }
                  if (value.length != 15 && value.length != 16) {
                    return 'Card number must be 15 or 16 digits';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: cardHolderNameController,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context).translate('card_holder_name'),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context).translate('card_holder_name_required');
                  }
                  if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(value)) {
                    return AppLocalizations.of(context).translate('card_holder_name_invalid');
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: cardTransactionNumberController,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context).translate('card_transaction_number'),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context).translate('transaction_number_required');
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: cardTypeController.text.isNotEmpty ? cardTypeController.text : null,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context).translate('card_type'),
                  prefixIcon: Icon(Icons.credit_card, color: Colors.blueAccent),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                icon: Icon(Icons.keyboard_arrow_down_rounded, color: Colors.blueAccent),
                dropdownColor: Colors.white,
                style: TextStyle(color: Colors.black87, fontSize: 16),
                items: ['Visa', 'MasterCard', 'American Express', 'Discover']
                    .map((type) => DropdownMenuItem(
                  value: type,
                  child: Text(type, style: TextStyle(fontWeight: FontWeight.w500)),
                ))
                    .toList(),
                onChanged: (value) {
                  cardTypeController.text = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context).translate('card_type_required');
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: cardMonthController.text.isNotEmpty ? cardMonthController.text : null,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context).translate('card_month'),
                  prefixIcon: Icon(Icons.calendar_today_rounded, color: Colors.blueAccent),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                icon: Icon(Icons.keyboard_arrow_down_rounded, color: Colors.blueAccent),
                dropdownColor: Colors.white,
                style: TextStyle(fontSize: 16, color: Colors.black87),
                items: List.generate(12, (index) => (index + 1).toString().padLeft(2, '0'))
                    .map((month) => DropdownMenuItem(
                  value: month,
                  child: Text(month, style: TextStyle(fontWeight: FontWeight.w500)),
                ))
                    .toList(),
                onChanged: (value) {
                  cardMonthController.text = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context).translate('card_month_required');
                  }
                  int? month = int.tryParse(value);
                  if (month == null || month < 1 || month > 12) {
                    return AppLocalizations.of(context).translate('card_month_invalid');
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: cardYearController.text.isNotEmpty ? cardYearController.text : null,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context).translate('card_year'),
                  prefixIcon: Icon(Icons.calendar_today_rounded, color: Colors.blueAccent),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                icon: Icon(Icons.keyboard_arrow_down_rounded, color: Colors.blueAccent),
                style: TextStyle(fontSize: 16, color: Colors.black87),
                dropdownColor: Colors.white,
                items: List.generate(11, (index) {
                  final year = DateTime.now().year + index;
                  return DropdownMenuItem(
                    value: year.toString(),
                    child: Text(year.toString(), style: TextStyle(fontWeight: FontWeight.w500)),
                  );
                }),
                onChanged: (value) {
                  cardYearController.text = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context).translate('card_year_required');
                  }
                  int? year = int.tryParse(value);
                  int currentYear = DateTime.now().year;
                  if (year == null || year < currentYear) {
                    return AppLocalizations.of(context).translate('card_year_invalid');
                  }
                  if (cardMonthController.text.isNotEmpty) {
                    int? month = int.tryParse(cardMonthController.text);
                    if (month != null && year == currentYear && month < DateTime.now().month) {
                      return AppLocalizations.of(context).translate('card_expired');
                    }
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: cardSecurityController,
                decoration: InputDecoration(
                  labelText: AppLocalizations.of(context).translate('card_security'),
                ),
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(4),
                ],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppLocalizations.of(context).translate('card_security_required');
                  }
                  if (value.length < 3 || value.length > 4) {
                    return AppLocalizations.of(context).translate('card_security_invalid');
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(AppLocalizations.of(context).translate('cancel')),
        ),
        TextButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              widget.onSave({
                'card_number': cardNumberController.text,
                'card_holder_name': cardHolderNameController.text,
                'card_transaction_number': cardTransactionNumberController.text,
                'card_type': cardTypeController.text,
                'card_month': cardMonthController.text,
                'card_year': cardYearController.text,
                'card_security': cardSecurityController.text,
              });
              Navigator.pop(context);
            }
          },
          child: Text(AppLocalizations.of(context).translate('ok')),
        ),
      ],
    );
  }
}

