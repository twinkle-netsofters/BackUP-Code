// // import 'dart:convert';
// //
// // import 'package:badges/badges.dart' as badges;
// // import 'package:badges/badges.dart';
// // import 'package:cached_network_image/cached_network_image.dart';
// // import 'package:flutter/material.dart';
// // import 'package:fluttertoast/fluttertoast.dart';
// // import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// //
// // import '../helpers/AppTheme.dart';
// // import '../helpers/SizeConfig.dart';
// // import '../helpers/generators.dart';
// // import '../helpers/otherHelpers.dart';
// // import '../locale/MyLocalizations.dart';
// // import '../models/product_model.dart';
// // import '../models/sell.dart';
// // import '../models/system.dart';
// // import '../models/variations.dart';
// // import 'elements.dart';
// //
// // class Products extends StatefulWidget {
// //   @override
// //   _ProductsState createState() => _ProductsState();
// // }
// //
// // class _ProductsState extends State<Products> {
// //   List products = [];
// //   static int themeType = 1;
// //   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
// //   bool changeLocation = false,
// //       changePriceGroup = false,
// //       canChangeLocation = true,
// //       canMakeSell = false,
// //       inStock = true,
// //       gridView = false,
// //       canAddSell = false,
// //       canViewProducts = false,
// //       usePriceGroup = true;
// //
// //   int selectedLocationId = 0,
// //       categoryId = 0,
// //       subCategoryId = 0,
// //       brandId = 0,
// //       cartCount = 0,
// //       sellingPriceGroupId = 0,
// //       offset = 0;
// //   int? byAlphabets, byPrice;
// //
// //   List<DropdownMenuItem<int>> _categoryMenuItems = [],
// //       _subCategoryMenuItems = [],
// //       _brandsMenuItems = [];
// //   List<DropdownMenuItem<bool>> _priceGroupMenuItems = [];
// //   Map? argument;
// //   List<Map<String, dynamic>> locationListMap = [
// //     {'id': 0, 'name': 'set location', 'selling_price_group_id': 0}
// //   ];
// //
// //   String symbol = '';
// //   final searchController = TextEditingController();
// //   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
// //   final _formKey = GlobalKey<FormState>();
// //   ScrollController _scrollController = new ScrollController();
// //
// //   @override
// //   void dispose() {
// //     searchController.dispose();
// //     _scrollController.dispose();
// //     super.dispose();
// //   }
// //
// //   @override
// //   initState() {
// //     super.initState();
// //     getPermission();
// //     _scrollController.addListener(() {
// //       if (_scrollController.position.pixels ==
// //           _scrollController.position.maxScrollExtent) {
// //         productList();
// //       }
// //     });
// //     setLocationMap();
// //     categoryList();
// //     subCategoryList(categoryId);
// //     brandList();
// //     Helper().syncCallLogs();
// //   }
// //
// //   @override
// //   Future<void> didChangeDependencies() async {
// //     argument = ModalRoute.of(context)!.settings.arguments as Map?;
// //     //Arguments sellId & locationId is send from edit.
// //     if (argument != null) {
// //       Future.delayed(Duration(milliseconds: 200), () {
// //         if (this.mounted) {
// //           setState(() {
// //             selectedLocationId = argument!['locationId'];
// //             canChangeLocation = false;
// //           });
// //         }
// //       });
// //     } else {
// //       canChangeLocation = true;
// //     }
// //     await setInitDetails(selectedLocationId);
// //     super.didChangeDependencies();
// //   }
// //
// //   //Set location & product
// //   setInitDetails(selectedLocationId) async {
// //     //check subscription
// //     var activeSubscriptionDetails = await System().get('active-subscription');
// //     if (activeSubscriptionDetails.length > 0) {
// //       setState(() {
// //         canMakeSell = true;
// //       });
// //     } else {
// //       Fluttertoast.showToast(
// //           msg: AppLocalizations.of(context).translate('no_subscription_found'));
// //     }
// //     await Helper().getFormattedBusinessDetails().then((value) {
// //       symbol = value['symbol'] + ' ';
// //     });
// //     await setDefaultLocation(selectedLocationId);
// //     products = [];
// //     offset = 0;
// //     productList();
// //   }
// //
// //   //Fetch permission from database
// //   getPermission() async {
// //     if (await Helper().getPermission("direct_sell.access")) {
// //       canAddSell = true;
// //     }
// //     if (await Helper().getPermission("product.view")) {
// //       canViewProducts = true;
// //     }
// //   }
// //
// //   //set selling Price Group Id
// //   findSellingPriceGroupId(locId) {
// //     if (usePriceGroup) {
// //       locationListMap.forEach((element) {
// //         if (element['id'] == selectedLocationId &&
// //             element['selling_price_group_id'] != null) {
// //           sellingPriceGroupId =
// //               int.parse(element['selling_price_group_id'].toString());
// //         } else if (element['id'] == selectedLocationId &&
// //             element['selling_price_group_id'] == null) {
// //           sellingPriceGroupId = 0;
// //         }
// //       });
// //     } else {
// //       sellingPriceGroupId = 0;
// //     }
// //   }
// //
// //   //set product list
// //   productList() async {
// //     offset++;
// //     //check last sync, if difference is 10 minutes then sync again.
// //     String? lastSync = await System().getProductLastSync();
// //     final date2 = DateTime.now();
// //     if (lastSync == null ||
// //         (date2.difference(DateTime.parse(lastSync)).inMinutes > 10)) {
// //       if (await Helper().checkConnectivity()) {
// //         await Variations().refresh();
// //         await System().insertProductLastSyncDateTimeNow();
// //       }
// //     }
// //
// //     findSellingPriceGroupId(selectedLocationId);
// //     await Variations()
// //         .get(
// //         brandId: brandId,
// //             categoryId: categoryId,
// //             subCategoryId: subCategoryId,
// //             inStock: inStock,
// //             locationId: selectedLocationId,
// //             searchTerm: searchController.text,
// //             offset: offset,
// //             byAlphabets: byAlphabets,
// //             byPrice: byPrice)
// //         .then((element) {
// //       element.forEach((product) {
// //         var price;
// //         if (product['selling_price_group'] != null) {
// //           jsonDecode(product['selling_price_group']).forEach((element) {
// //             if (element['key'] == sellingPriceGroupId) {
// //               price = double.parse(element['value'].toString());
// //             }
// //           });
// //         }
// //         setState(() {
// //           products.add(ProductModel().product(product, price));
// //         });
// //       });
// //     });
// //   }
// //
// //   categoryList() async {
// //     List categories = await System().getCategories();
// //
// //     _categoryMenuItems.add(
// //       DropdownMenuItem(
// //         child: Text(AppLocalizations.of(context).translate('select_category')),
// //         value: 0,
// //       ),
// //     );
// //
// //     for (var category in categories) {
// //       _categoryMenuItems.add(
// //         DropdownMenuItem(
// //           child: Text(category['name']),
// //           value: category['id'],
// //         ),
// //       );
// //     }
// //   }
// //
// //   subCategoryList(parentId) async {
// //     List subCategories = await System().getSubCategories(parentId);
// //     _subCategoryMenuItems = [];
// //     _subCategoryMenuItems.add(
// //       DropdownMenuItem(
// //         child:
// //             Text(AppLocalizations.of(context).translate('select_sub_category')),
// //         value: 0,
// //       ),
// //     );
// //     subCategories.forEach((element) {
// //       _subCategoryMenuItems.add(
// //         DropdownMenuItem(
// //           child: Text(jsonDecode(element['value'])['name']),
// //           value: jsonDecode(element['value'])['id'],
// //         ),
// //       );
// //     });
// //   }
// //
// //   brandList() async {
// //     List brands = await System().getBrands();
// //
// //     _brandsMenuItems.add(
// //       DropdownMenuItem(
// //         child: Text(AppLocalizations.of(context).translate('select_brand')),
// //         value: 0,
// //       ),
// //     );
// //
// //     for (var brand in brands) {
// //       _brandsMenuItems.add(
// //         DropdownMenuItem(
// //           child: Text(brand['name']),
// //           value: brand['id'],
// //         ),
// //       );
// //     }
// //   }
// //
// //   priceGroupList() async {
// //     setState(() {
// //       _priceGroupMenuItems = [];
// //       _priceGroupMenuItems.add(
// //         DropdownMenuItem(
// //           child: Text(AppLocalizations.of(context)
// //               .translate('no_price_group_selected')),
// //           value: false,
// //         ),
// //       );
// //
// //       locationListMap.forEach((element) {
// //         if (element['id'] == selectedLocationId &&
// //             element['selling_price_group_id'] != null) {
// //           _priceGroupMenuItems.add(
// //             DropdownMenuItem(
// //               child: Text(AppLocalizations.of(context)
// //                   .translate('default_price_group')),
// //               value: true,
// //             ),
// //           );
// //         }
// //       });
// //     });
// //   }
// //
// //   Future<String> getCartItemCount({isCompleted, sellId}) async {
// //     var counts =
// //         await Sell().cartItemCount(isCompleted: isCompleted, sellId: sellId);
// //     setState(() {
// //       cartCount = int.parse(counts);
// //     });
// //     return counts;
// //   }
// //
// //   double findAspectRatio(double width) {
// //     //Logic for aspect ratio of grid view
// //     return (width / 2 - MySize.size24!) / ((width / 2 - MySize.size24!) + 60);
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     themeData = Theme.of(context);
// //
// //     return SafeArea(
// //       child: Scaffold(
// //         key: _scaffoldKey,
// //         resizeToAvoidBottomInset: false,
// //         backgroundColor: themeData.backgroundColor,
// //         endDrawer: _filterDrawer(),
// //         appBar: AppBar(
// //           elevation: 0,
// //           title: Text(AppLocalizations.of(context).translate('products'),
// //               style: AppTheme.getTextStyle(themeData.textTheme.headline6,
// //                   fontWeight: 600)),
// //           leading: null,
// //           actions: <Widget>[
// //             locations(),
// //             badges.Badge(
// //               // badgeColor: themeData.colorScheme.error,
// //               // shape: BadgeShape.circle,
// //               // borderRadius: BorderRadius.circular(MySize.size20!),
// //               // toAnimate: true,
// //               position: BadgePosition.topStart(start: 5.0, top: 5.0),
// //               badgeContent: FutureBuilder(
// //                   future: (argument != null && argument!['sellId'] != null)
// //                       ? getCartItemCount(sellId: argument!['sellId'])
// //                       : getCartItemCount(isCompleted: 0),
// //                   builder: (context, AsyncSnapshot<String> snapshot) {
// //                     if (snapshot.hasData) {
// //                       return Center(
// //                         child: Text('${snapshot.data}',
// //                             style: TextStyle(color: Colors.white)),
// //                       );
// //                     } else
// //                       return Center(
// //                         child: Text("0", style: TextStyle(color: Colors.white)),
// //                       );
// //                   }),
// //               child: IconButton(
// //                   icon: Icon(Icons.shopping_cart),
// //                   onPressed: () {
// //                     if (argument != null) {
// //                       Navigator.pushReplacementNamed(context, '/cart',
// //                           arguments: Helper().argument(
// //                               locId: argument!['locationId'],
// //                               sellId: argument!['sellId'], products: []));
// //                     } else {
// //                       if (selectedLocationId != 0 && cartCount > 0) {
// //                         Navigator.pushNamed(context, '/cart',
// //                             arguments:
// //                                 Helper().argument(locId: selectedLocationId, products: []));
// //                       }
// //
// //                       if (cartCount == 0) {
// //                         Fluttertoast.showToast(
// //                             msg: AppLocalizations.of(context)
// //                                 .translate('no_items_added_to_cart'));
// //                       }
// //                     }
// //                   }),
// //             )
// //           ],
// //         ),
// //         body: (canViewProducts)
// //             ? ListView(
// //                 physics: ClampingScrollPhysics(),
// //                 controller: _scrollController,
// //                 padding: EdgeInsets.all(0),
// //                 children: [
// //                   Visibility(
// //                       visible: (selectedLocationId != 0),
// //                       child: filter(
// //                         _scaffoldKey,
// //                       )),
// //                   (selectedLocationId == 0)
// //                       ? Center(
// //                           child: Column(
// //                             mainAxisAlignment: MainAxisAlignment.center,
// //                             children: [
// //                               Icon(Icons.location_on),
// //                               Text(AppLocalizations.of(context)
// //                                   .translate('please_set_a_location')),
// //                             ],
// //                           ),
// //                         )
// //                       : _productsList(),
// //                 ],
// //               )
// //             : Center(
// //                 child: Text(
// //                   AppLocalizations.of(context).translate('unauthorised'),
// //                   style: TextStyle(color: Colors.black),
// //                 ),
// //               ),
// //         bottomNavigationBar: Visibility(
// //             visible: argument == null,
// //             child: posBottomBar('products', context)),
// //       ),
// //     );
// //   }
// //
// //   Widget _filterDrawer() {
// //     return Container(
// //       width: MediaQuery.of(context).size.width * 0.8,
// //       padding: EdgeInsets.only(bottom: MySize.size14!),
// //       color: themeData.backgroundColor,
// //       child: SingleChildScrollView(
// //         child: Column(
// //           crossAxisAlignment: CrossAxisAlignment.start,
// //           children: <Widget>[
// //             Container(
// //               padding:
// //                   EdgeInsets.only(top: MySize.size24!, bottom: MySize.size24!),
// //               alignment: Alignment.center,
// //               child: Center(
// //                 child: Text(
// //                   AppLocalizations.of(context).translate('sort'),
// //                   style: AppTheme.getTextStyle(themeData.textTheme.subtitle1,
// //                       fontWeight: 700, color: themeData.colorScheme.primary),
// //                 ),
// //               ),
// //             ),
// //             Column(
// //               crossAxisAlignment: CrossAxisAlignment.start,
// //               children: [
// //                 Row(
// //                   children: [
// //                     InkWell(
// //                       onTap: () async {
// //                         setState(() {
// //                           if (byAlphabets == null) {
// //                             byAlphabets = 0;
// //                           } else if (byAlphabets == 0) {
// //                             byAlphabets = 1;
// //                           } else {
// //                             byAlphabets = null;
// //                           }
// //                         });
// //                         products = [];
// //                         offset = 0;
// //                         productList();
// //                       },
// //                       child: Container(
// //                         margin: EdgeInsets.only(left: MySize.size16!),
// //                         decoration: BoxDecoration(
// //                           color: themeData.backgroundColor,
// //                           borderRadius:
// //                               BorderRadius.all(Radius.circular(MySize.size16!)),
// //                           boxShadow: [
// //                             BoxShadow(
// //                               color: themeData.cardTheme.shadowColor!
// //                                   .withAlpha(48),
// //                               blurRadius: (byAlphabets != null) ? 5 : 0,
// //                               offset: (byAlphabets != null)
// //                                   ? Offset(3, 3)
// //                                   : Offset(0, 0),
// //                             )
// //                           ],
// //                           // : null,
// //                         ),
// //                         padding: EdgeInsets.all(MySize.size12!),
// //                         child: Row(
// //                           children: [
// //                             Text(
// //                               "A",
// //                               style: AppTheme.getTextStyle(
// //                                   themeData.textTheme.subtitle1,
// //                                   fontWeight: 700,
// //                                   color: (byAlphabets != null)
// //                                       ? themeData.colorScheme.primary
// //                                       : Colors.grey),
// //                             ),
// //                             Icon(
// //                               (byAlphabets == 1)
// //                                   ? MdiIcons.arrowLeftBold
// //                                   : MdiIcons.arrowRightBold,
// //                               color: (byAlphabets != null)
// //                                   ? themeData.colorScheme.primary
// //                                   : Colors.grey,
// //                               size: 22,
// //                             ),
// //                             Text(
// //                               "Z",
// //                               style: AppTheme.getTextStyle(
// //                                   themeData.textTheme.subtitle1,
// //                                   fontWeight: 700,
// //                                   color: (byAlphabets != null)
// //                                       ? themeData.colorScheme.primary
// //                                       : Colors.grey),
// //                             ),
// //                           ],
// //                         ),
// //                       ),
// //                     ),
// //                     InkWell(
// //                       onTap: () async {
// //                         setState(() {
// //                           if (byPrice == null) {
// //                             byPrice = 0;
// //                           } else if (byPrice == 0) {
// //                             byPrice = 1;
// //                           } else {
// //                             byPrice = null;
// //                           }
// //                         });
// //                         products = [];
// //                         offset = 0;
// //                         productList();
// //                       },
// //                       child: Container(
// //                         margin: EdgeInsets.only(left: MySize.size16!),
// //                         decoration: BoxDecoration(
// //                           color: themeData.backgroundColor,
// //                           borderRadius:
// //                               BorderRadius.all(Radius.circular(MySize.size16!)),
// //                           boxShadow: [
// //                             BoxShadow(
// //                               color: themeData.cardTheme.shadowColor!
// //                                   .withAlpha(48),
// //                               blurRadius: (byPrice != null) ? 5 : 0,
// //                               offset: (byPrice != null)
// //                                   ? Offset(3, 3)
// //                                   : Offset(0, 0),
// //                             )
// //                           ],
// //                           // : null,
// //                         ),
// //                         padding: EdgeInsets.all(MySize.size12!),
// //                         child: Row(
// //                           children: [
// //                             Text(
// //                               AppLocalizations.of(context).translate('price'),
// //                               style: AppTheme.getTextStyle(
// //                                   themeData.textTheme.subtitle1,
// //                                   fontWeight: 700,
// //                                   color: (byPrice != null)
// //                                       ? themeData.colorScheme.primary
// //                                       : Colors.grey),
// //                             ),
// //                             Icon(
// //                               (byPrice == 1)
// //                                   ? MdiIcons.arrowDownBold
// //                                   : MdiIcons.arrowUpBold,
// //                               color: (byPrice != null)
// //                                   ? themeData.colorScheme.primary
// //                                   : Colors.grey,
// //                               size: 22,
// //                             ),
// //                           ],
// //                         ),
// //                       ),
// //                     ),
// //                   ],
// //                 ),
// //                 Divider(),
// //               ],
// //             ),
// //             Container(
// //               alignment: Alignment.center,
// //               child: Center(
// //                 child: Text(
// //                   AppLocalizations.of(context).translate('filter'),
// //                   style: AppTheme.getTextStyle(themeData.textTheme.subtitle1,
// //                       fontWeight: 700, color: themeData.colorScheme.primary),
// //                 ),
// //               ),
// //             ),
// //             Column(
// //               crossAxisAlignment: CrossAxisAlignment.start,
// //               children: <Widget>[
// //                 Container(
// //                     padding: EdgeInsets.only(
// //                         left: MySize.size16!, right: MySize.size16!),
// //                     child: CheckboxListTile(
// //                       title: Text(
// //                           AppLocalizations.of(context).translate('in_stock')),
// //                       controlAffinity: ListTileControlAffinity.leading,
// //                       value: inStock,
// //                       onChanged: (newValue) {
// //                         setState(() {
// //                           inStock = newValue!;
// //                         });
// //                         products = [];
// //                         offset = 0;
// //                         productList();
// //                       },
// //                     )),
// //                 Divider(),
// //                 Container(
// //                   padding: EdgeInsets.only(
// //                       left: MySize.size16!,
// //                       right: MySize.size16!,
// //                       top: MySize.size16!),
// //                   child: Text(
// //                     AppLocalizations.of(context).translate('categories'),
// //                     style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
// //                         fontWeight: 600, letterSpacing: 0),
// //                   ),
// //                 ),
// //                 Container(
// //                   padding: EdgeInsets.only(
// //                       left: MySize.size16!,
// //                       right: MySize.size16!,
// //                       top: MySize.size8!),
// //                   child: DropdownButtonHideUnderline(
// //                     child: DropdownButton(
// //                         isExpanded: true,
// //                         dropdownColor: themeData.backgroundColor,
// //                         icon: Icon(
// //                           Icons.arrow_drop_down,
// //                         ),
// //                         value: categoryId,
// //                         items: _categoryMenuItems,
// //                         onChanged: (int? newValue) {
// //                           setState(() {
// //                             subCategoryId = 0;
// //                             categoryId = newValue!;
// //                             subCategoryList(categoryId);
// //                           });
// //
// //                           products = [];
// //                           offset = 0;
// //                           productList();
// //                         }),
// //                   ),
// //                 ),
// //                 Divider(),
// //                 Container(
// //                   padding: EdgeInsets.only(
// //                       left: MySize.size16!,
// //                       right: MySize.size16!,
// //                       top: MySize.size16!),
// //                   child: Text(
// //                     AppLocalizations.of(context).translate('sub_categories'),
// //                     style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
// //                         fontWeight: 600, letterSpacing: 0),
// //                   ),
// //                 ),
// //                 Container(
// //                   padding: EdgeInsets.only(
// //                       left: MySize.size16!,
// //                       right: MySize.size16!,
// //                       top: MySize.size8!),
// //                   child: DropdownButtonHideUnderline(
// //                     child: DropdownButton(
// //                         isExpanded: true,
// //                         dropdownColor: themeData.backgroundColor,
// //                         icon: Icon(
// //                           Icons.arrow_drop_down,
// //                         ),
// //                         value: subCategoryId,
// //                         items: _subCategoryMenuItems,
// //                         onChanged: (int? newValue) {
// //                           setState(() {
// //                             subCategoryId = newValue!;
// //                           });
// //
// //                           products = [];
// //                           offset = 0;
// //                           productList();
// //                         }),
// //                   ),
// //                 ),
// //                 Divider(),
// //                 Container(
// //                   padding: EdgeInsets.only(
// //                       left: MySize.size16!,
// //                       right: MySize.size16!,
// //                       top: MySize.size16!),
// //                   child: Text(
// //                     AppLocalizations.of(context).translate('brands'),
// //                     style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
// //                         fontWeight: 600, letterSpacing: 0),
// //                   ),
// //                 ),
// //                 Container(
// //                   padding: EdgeInsets.only(
// //                       left: MySize.size16!, right: MySize.size16!, top: 0),
// //                   child: DropdownButtonHideUnderline(
// //                     child: DropdownButton(
// //                         isExpanded: true,
// //                         dropdownColor: themeData.backgroundColor,
// //                         icon: Icon(
// //                           Icons.arrow_drop_down,
// //                         ),
// //                         value: brandId,
// //                         items: _brandsMenuItems,
// //                         onChanged: (int? newValue) {
// //                           setState(() {
// //                             brandId = newValue!;
// //                           });
// //                           products = [];
// //                           offset = 0;
// //                           productList();
// //                         }),
// //                   ),
// //                 ),
// //                 Divider()
// //               ],
// //             ),
// //             Container(
// //               alignment: Alignment.center,
// //               child: Center(
// //                 child: Text(
// //                   AppLocalizations.of(context).translate('group_prices'),
// //                   style: AppTheme.getTextStyle(themeData.textTheme.subtitle1,
// //                       fontWeight: 700, color: themeData.colorScheme.primary),
// //                 ),
// //               ),
// //             ),
// //             Container(
// //               padding: EdgeInsets.only(
// //                   left: MySize.size16!, right: MySize.size16!, top: 0),
// //               child: DropdownButtonHideUnderline(
// //                 child: DropdownButton(
// //                     isExpanded: true,
// //                     dropdownColor: themeData.backgroundColor,
// //                     icon: Icon(
// //                       Icons.arrow_drop_down,
// //                     ),
// //                     value: usePriceGroup,
// //                     items: _priceGroupMenuItems,
// //                     onChanged: (bool? newValue) async {
// //                       await _showCartResetDialogForPriceGroup();
// //                       setState(() {
// //                         usePriceGroup = newValue!;
// //                         if (changePriceGroup) {
// //                           //reset cart items
// //                           Sell().resetCart();
// //                           //reset all filters & search
// //                           brandId = 0;
// //                           categoryId = 0;
// //                           searchController.clear();
// //                           inStock = true;
// //                           cartCount = 0;
// //
// //                           products = [];
// //                           offset = 0;
// //                           productList();
// //                         }
// //                       });
// //                     }),
// //               ),
// //             )
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget filter(_scaffoldKey) {
// //     return Padding(
// //       padding: EdgeInsets.all(MySize.size16!),
// //       child: Row(
// //         children: <Widget>[
// //           Expanded(
// //             child: Form(
// //               key: _formKey,
// //               child: TextFormField(
// //                   style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
// //                       letterSpacing: 0, fontWeight: 500),
// //                   decoration: InputDecoration(
// //                     hintText: AppLocalizations.of(context).translate('search'),
// //                     hintStyle: AppTheme.getTextStyle(
// //                         themeData.textTheme.subtitle2,
// //                         letterSpacing: 0,
// //                         fontWeight: 500),
// //                     border: OutlineInputBorder(
// //                         borderRadius: BorderRadius.all(
// //                           Radius.circular(MySize.size16!),
// //                         ),
// //                         borderSide: BorderSide.none),
// //                     enabledBorder: OutlineInputBorder(
// //                         borderRadius: BorderRadius.all(
// //                           Radius.circular(MySize.size16!),
// //                         ),
// //                         borderSide: BorderSide.none),
// //                     focusedBorder: OutlineInputBorder(
// //                         borderRadius: BorderRadius.all(
// //                           Radius.circular(MySize.size16!),
// //                         ),
// //                         borderSide: BorderSide.none),
// //                     filled: true,
// //                     fillColor: themeData.colorScheme.background,
// //                     prefixIcon: IconButton(
// //                       icon: Icon(
// //                         MdiIcons.magnify,
// //                         size: MySize.size22,
// //                         color:
// //                             themeData.colorScheme.onBackground.withAlpha(150),
// //                       ),
// //                       onPressed: () {},
// //                     ),
// //                     isDense: true,
// //                     contentPadding: EdgeInsets.only(right: MySize.size16!),
// //                   ),
// //                   textCapitalization: TextCapitalization.sentences,
// //                   controller: searchController,
// //                   onEditingComplete: () {
// //                     products = [];
// //                     offset = 0;
// //                     productList();
// //                   }),
// //             ),
// //           ),
// //           InkWell(
// //             onTap: () async {
// //               var barcode = await Helper().barcodeScan();
// //               await getScannedProduct(barcode);
// //             },
// //             child: Container(
// //               margin: EdgeInsets.only(left: MySize.size16!),
// //               decoration: BoxDecoration(
// //                 color: themeData.backgroundColor,
// //                 borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
// //                 boxShadow: [
// //                   BoxShadow(
// //                     color: themeData.cardTheme.shadowColor!.withAlpha(48),
// //                     blurRadius: 3,
// //                     offset: Offset(0, 1),
// //                   )
// //                 ],
// //               ),
// //               padding: EdgeInsets.all(MySize.size12!),
// //               child: Icon(
// //                 MdiIcons.barcode,
// //                 color: themeData.colorScheme.primary,
// //                 size: 22,
// //               ),
// //             ),
// //           ),
// //           InkWell(
// //             onTap: () {
// //               _scaffoldKey.currentState.openEndDrawer();
// //             },
// //             child: Container(
// //               margin: EdgeInsets.only(left: MySize.size16!),
// //               decoration: BoxDecoration(
// //                 color: themeData.backgroundColor,
// //                 borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
// //                 boxShadow: [
// //                   BoxShadow(
// //                     color: themeData.cardTheme.shadowColor!.withAlpha(48),
// //                     blurRadius: 3,
// //                     offset: Offset(0, 1),
// //                   )
// //                 ],
// //               ),
// //               padding: EdgeInsets.all(MySize.size12!),
// //               child: Icon(
// //                 MdiIcons.tune,
// //                 color: themeData.colorScheme.primary,
// //                 size: 22,
// //               ),
// //             ),
// //           ),
// //           InkWell(
// //             onTap: () async {
// //               setState(() {
// //                 gridView = !gridView;
// //               });
// //             },
// //             child: Container(
// //               margin: EdgeInsets.only(left: MySize.size16!),
// //               decoration: BoxDecoration(
// //                 color: themeData.backgroundColor,
// //                 borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
// //                 boxShadow: [
// //                   BoxShadow(
// //                     color: themeData.cardTheme.shadowColor!.withAlpha(48),
// //                     blurRadius: 3,
// //                     offset: Offset(0, 1),
// //                   )
// //                 ],
// //               ),
// //               padding: EdgeInsets.all(MySize.size12!),
// //               child: Icon(
// //                 (gridView) ? MdiIcons.viewList : MdiIcons.viewGrid,
// //                 color: themeData.colorScheme.primary,
// //                 size: 22,
// //               ),
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// //
// //   //add product to cart after scanning barcode
// //   getScannedProduct(String barcode) async {
// //     if (canMakeSell) {
// //       await Variations()
// //           .get(
// //               locationId: selectedLocationId,
// //               barcode: barcode,
// //               offset: 0,
// //               searchTerm: searchController.text)
// //           .then((value) async {
// //         if (canAddSell) {
// //           if (value.length > 0) {
// //             var price;
// //             var product;
// //             if (value[0]['selling_price_group'] != null) {
// //               jsonDecode(value[0]['selling_price_group']).forEach((element) {
// //                 if (element['key'] == sellingPriceGroupId) {
// //                   price = element['value'];
// //                 }
// //               });
// //             }
// //             setState(() {
// //               product = ProductModel().product(value[0], price);
// //             });
// //             if (product != null && product['stock_available'] > 0) {
// //               Fluttertoast.showToast(
// //                   msg: AppLocalizations.of(context).translate('added_to_cart'));
// //               await Sell().addToCart(
// //                   product, argument != null ? argument!['sellId'] : null);
// //               if (argument != null) {
// //                 selectedLocationId = argument!['locationId'];
// //               }
// //             } else {
// //               Fluttertoast.showToast(
// //                   msg:
// //                       "${AppLocalizations.of(context).translate("out_of_stock")}");
// //             }
// //           } else {
// //             Fluttertoast.showToast(
// //                 msg:
// //                     "${AppLocalizations.of(context).translate("no_product_found")}");
// //           }
// //         } else {
// //           Fluttertoast.showToast(
// //               msg:
// //                   "${AppLocalizations.of(context).translate("no_sells_permission")}");
// //         }
// //       });
// //     } else {
// //       Fluttertoast.showToast(
// //           msg: AppLocalizations.of(context).translate('no_subscription_found'));
// //     }
// //   }
// //
// //   Widget _productsList() {
// //     return (products.length == 0)
// //         ? Center(
// //             child: Column(
// //               mainAxisAlignment: MainAxisAlignment.center,
// //               children: [
// //                 Icon(Icons.hourglass_empty),
// //                 Text(AppLocalizations.of(context)
// //                     .translate('no_products_found')),
// //               ],
// //             ),
// //           )
// //         : Container(
// //             child: (gridView)
// //                 ? GridView.builder(
// //               padding: EdgeInsets.only(
// //                         bottom: MySize.size16!,
// //                         left: MySize.size16!,
// //                         right: MySize.size16!),
// //                     shrinkWrap: true,
// //                     physics: ClampingScrollPhysics(),
// //                     itemCount: products.length,
// //                     gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
// //                       crossAxisCount: 2,
// //                       mainAxisSpacing: MySize.size16!,
// //                       crossAxisSpacing: MySize.size16!,
// //                       childAspectRatio:
// //                           findAspectRatio(MediaQuery.of(context).size.width),
// //                     ),
// //                     itemBuilder: (context, index) {
// //                       return InkWell(
// //                         onTap: () async {
// //                           onTapProduct(index);
// //                         },
// //                         child: _ProductGridWidget(
// //                           name: products[index]['display_name'],
// //                           image: products[index]['product_image_url'],
// //                           qtyAvailable: (products[index]['enable_stock'] != 0)
// //                               ? products[index]['stock_available'].toString()
// //                               : '-',
// //                           price: double.parse(
// //                               products[index]['unit_price'].toString()),
// //                           symbol: symbol,
// //                         ),
// //                       );
// //                     },
// //                   )
// //                 : ListView.builder(
// //               shrinkWrap: true,
// //                     physics: ClampingScrollPhysics(),
// //                     itemCount: products.length,
// //                     itemBuilder: (context, index) {
// //                       return InkWell(
// //                         onTap: () async {
// //                           onTapProduct(index);
// //                         },
// //                         child: _ProductListWidget(
// //                           name: products[index]['display_name'],
// //                           image: products[index]['product_image_url'],
// //                           qtyAvailable: (products[index]['enable_stock'] != 0)
// //                               ? products[index]['stock_available'].toString()
// //                               : '-',
// //                           price: double.parse(
// //                               products[index]['unit_price'].toString()),
// //                           symbol: symbol,
// //                         ),
// //                       );
// //                     },
// //                   ),
// //           );
// //   }
// //
// //   //onTap product
// //   onTapProduct(int index) async {
// //     if (canAddSell) {
// //       if (canMakeSell) {
// //         if (products[index]['stock_available'] > 0) {
// //           Fluttertoast.showToast(
// //               msg: AppLocalizations.of(context).translate('added_to_cart'));
// //           await Sell().addToCart(
// //               products[index], argument != null ? argument!['sellId'] : null);
// //           if (argument != null) {
// //             selectedLocationId = argument!['locationId'];
// //           }
// //         } else {
// //           Fluttertoast.showToast(
// //               msg: "${AppLocalizations.of(context).translate("out_of_stock")}");
// //         }
// //       } else {
// //         Fluttertoast.showToast(
// //             msg:
// //                 "${AppLocalizations.of(context).translate("no_sells_permission")}");
// //       }
// //     } else {
// //       Fluttertoast.showToast(
// //           msg: AppLocalizations.of(context).translate('no_subscription_found'));
// //     }
// //   }
// //
// //   setLocationMap() async {
// //     await System().get('location').then((value) async {
// //       value.forEach((element) {
// //         if (element['is_active'].toString() == '1') {
// //           setState(() {
// //             locationListMap.add({
// //               'id': element['id'],
// //               'name': element['name'],
// //               'selling_price_group_id': element['selling_price_group_id']
// //             });
// //           });
// //         }
// //       });
// //       await priceGroupList();
// //     });
// //   }
// //
// //   setDefaultLocation(defaultLocation) {
// //     if (defaultLocation != 0) {
// //       setState(() {
// //         selectedLocationId = defaultLocation;
// //       });
// //     } else if (locationListMap.length == 2) {
// //       setState(() {
// //         selectedLocationId = locationListMap[1]['id'] as int;
// //       });
// //     }
// //   }
// //
// //   Widget locations() {
// //     return DropdownButtonHideUnderline(
// //       child: DropdownButton(
// //           dropdownColor: themeData.backgroundColor,
// //           icon: Icon(
// //             Icons.arrow_drop_down,
// //           ),
// //           value: selectedLocationId,
// //           items: locationListMap.map<DropdownMenuItem<int>>((Map value) {
// //             return DropdownMenuItem<int>(
// //                 value: value['id'],
// //                 child: SizedBox(
// //                   width: MySize.screenWidth! * 0.4,
// //                   child: Text('${value['name']}',
// //                       softWrap: true,
// //                       overflow: TextOverflow.ellipsis,
// //                       maxLines: 2,
// //                       style: TextStyle(fontSize: 15)),
// //                 ));
// //           }).toList(),
// //           onTap: () {
// //             if (locationListMap.length <= 2) {
// //               canChangeLocation = false;
// //             }
// //           },
// //           onChanged: (int? newValue) async {
// //             // show a confirmation if there location is changed.
// //             if (canChangeLocation) {
// //               if (selectedLocationId == newValue) {
// //                 changeLocation = false;
// //               } else if (selectedLocationId != 0) {
// //                 await _showCartResetDialogForLocation();
// //                 await priceGroupList();
// //               } else {
// //                 changeLocation = true;
// //                 await priceGroupList();
// //               }
// //               setState(() {
// //                 if (changeLocation) {
// //                   //reset cart items
// //                   Sell().resetCart();
// //                   selectedLocationId = newValue!;
// //                   //reset all filters & search
// //                   brandId = 0;
// //                   categoryId = 0;
// //                   searchController.clear();
// //                   inStock = true;
// //                   cartCount = 0;
// //
// //                   products = [];
// //                   offset = 0;
// //                   productList();
// //                 }
// //               });
// //             } else {
// //               Fluttertoast.showToast(
// //                   msg: AppLocalizations.of(context)
// //                       .translate('cannot_change_location'));
// //             }
// //           }),
// //     );
// //   }
// //
// //   Future<void> _showCartResetDialogForLocation() async {
// //     await showDialog(
// //       context: context,
// //       builder: (BuildContext context) {
// //         return AlertDialog(
// //           title:
// //               Text(AppLocalizations.of(context).translate('change_location')),
// //           content: Text(AppLocalizations.of(context)
// //               .translate('all_items_in_cart_will_be_remove')),
// //           actions: [
// //             TextButton(
// //                 onPressed: () {
// //                   changeLocation = false;
// //                   Navigator.of(context).pop();
// //                 },
// //                 child: Text(AppLocalizations.of(context).translate('no'))),
// //             TextButton(
// //                 onPressed: () {
// //                   changeLocation = true;
// //                   Navigator.of(context).pop();
// //                 },
// //                 child: Text(AppLocalizations.of(context).translate('yes')))
// //           ],
// //         );
// //       },
// //     );
// //   }
// //
// //   Future<void> _showCartResetDialogForPriceGroup() async {
// //     await showDialog(
// //       context: context,
// //       builder: (BuildContext context) {
// //         return AlertDialog(
// //           title: Text(AppLocalizations.of(context)
// //               .translate('change_selling_price_group')),
// //           content: Text(AppLocalizations.of(context)
// //               .translate('all_items_in_cart_will_be_remove')),
// //           actions: [
// //             TextButton(
// //                 onPressed: () {
// //                   changePriceGroup = false;
// //                   Navigator.of(context).pop();
// //                 },
// //                 child: Text(AppLocalizations.of(context).translate('no'))),
// //             TextButton(
// //                 onPressed: () {
// //                   changePriceGroup = true;
// //                   Navigator.of(context).pop();
// //                 },
// //                 child: Text(AppLocalizations.of(context).translate('yes')))
// //           ],
// //         );
// //       },
// //     );
// //   }
// // }
// //
// // class _ProductGridWidget extends StatefulWidget {
// //   final String? name, image, symbol;
// //   final String? qtyAvailable;
// //   final double? price;
// //
// //   const _ProductGridWidget(
// //       {Key? key,
// //       @required this.name,
// //       @required this.image,
// //       @required this.qtyAvailable,
// //       @required this.price,
// //       @required this.symbol})
// //       : super(key: key);
// //
// //   @override
// //   _ProductGridWidgetState createState() => _ProductGridWidgetState();
// // }
// //
// // class _ProductGridWidgetState extends State<_ProductGridWidget> {
// //   static int themeType = 1;
// //   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     String key = Generator.randomString(10);
// //     themeData = Theme.of(context);
// //     return Container(
// //       decoration: BoxDecoration(
// //         color: themeData.cardTheme.color,
// //         borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
// //         boxShadow: [
// //           BoxShadow(
// //             color: themeData.cardTheme.shadowColor!.withAlpha(12),
// //             blurRadius: 4,
// //             spreadRadius: 2,
// //             offset: Offset(0, 2),
// //           ),
// //         ],
// //       ),
// //       padding: EdgeInsets.all(MySize.size2!),
// //       child: Column(
// //         mainAxisSize: MainAxisSize.min,
// //         mainAxisAlignment: MainAxisAlignment.spaceAround,
// //         children: <Widget>[
// //           Stack(
// //             children: <Widget>[
// //               Hero(
// //                 tag: key,
// //                 child: ClipRRect(
// //                   borderRadius: BorderRadius.only(
// //                       topLeft: Radius.circular(MySize.size8!),
// //                       topRight: Radius.circular(MySize.size8!)),
// //                   child: CachedNetworkImage(
// //                       width: MediaQuery.of(context).size.width,
// //                       height: MySize.size140,
// //                       fit: BoxFit.fitHeight,
// //                       errorWidget: (context, url, error) =>
// //                           Image.asset('assets/images/default_product.png'),
// //                       placeholder: (context, url) =>
// //                           Image.asset('assets/images/default_product.png'),
// //                       imageUrl: widget.image ?? ''),
// //                 ),
// //               ),
// //             ],
// //           ),
// //           Container(
// //             width: MediaQuery.of(context).size.width,
// //             padding: EdgeInsets.only(left: MySize.size2!, right: MySize.size2!),
// //             child: Column(
// //               mainAxisSize: MainAxisSize.min,
// //               crossAxisAlignment: CrossAxisAlignment.start,
// //               children: <Widget>[
// //                 Text(widget.name!,
// //                     overflow: TextOverflow.ellipsis,
// //                     style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
// //                         fontWeight: 500, letterSpacing: 0)),
// //                 Container(
// //                   margin: EdgeInsets.only(top: MySize.size4!),
// //                   child: Row(
// //                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                     children: <Widget>[
// //                       Text(
// //                         widget.symbol! + Helper().formatCurrency(widget.price),
// //                         style: AppTheme.getTextStyle(
// //                             themeData.textTheme.bodyText2,
// //                             fontWeight: 700,
// //                             letterSpacing: 0),
// //                       ),
// //                       Container(
// //                         decoration: BoxDecoration(
// //                             color: themeData.colorScheme.primary,
// //                             borderRadius: BorderRadius.all(
// //                                 Radius.circular(MySize.size4!))),
// //                         padding: EdgeInsets.only(
// //                             left: MySize.size6!,
// //                             right: MySize.size8!,
// //                             top: MySize.size2!,
// //                             bottom: MySize.getScaledSizeHeight(3.5)),
// //                         child: Row(
// //                           children: <Widget>[
// //                             Icon(
// //                               MdiIcons.stocking,
// //                               color: themeData.colorScheme.onPrimary,
// //                               size: MySize.size12,
// //                             ),
// //                             Container(
// //                               margin: EdgeInsets.only(left: MySize.size4!),
// //                               child: (widget.qtyAvailable != '-')
// //                                   ? Text(
// //                                       Helper()
// //                                           .formatQuantity(widget.qtyAvailable),
// //                                       style: AppTheme.getTextStyle(
// //                                           themeData.textTheme.caption,
// //                                           fontSize: 11,
// //                                           color:
// //                                               themeData.colorScheme.onPrimary,
// //                                           fontWeight: 600))
// //                                   : Text('-'),
// //                             ),
// //                           ],
// //                         ),
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }
// //
// // class _ProductListWidget extends StatefulWidget {
// //   final String? name, image, symbol;
// //   final String? qtyAvailable;
// //   final double? price;
// //
// //   const _ProductListWidget(
// //       {Key? key,
// //       @required this.name,
// //       @required this.image,
// //       @required this.qtyAvailable,
// //       @required this.price,
// //       @required this.symbol})
// //       : super(key: key);
// //
// //   @override
// //   _ProductListWidgetState createState() => _ProductListWidgetState();
// // }
// //
// // class _ProductListWidgetState extends State<_ProductListWidget> {
// //   static int themeType = 1;
// //   ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     themeData = Theme.of(context);
// //     return Container(
// //       decoration: BoxDecoration(
// //         color: themeData.cardTheme.color,
// //         borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
// //         boxShadow: [
// //           BoxShadow(
// //             color: themeData.cardTheme.shadowColor!.withAlpha(12),
// //             blurRadius: 4,
// //             spreadRadius: 2,
// //             offset: Offset(0, 2),
// //           ),
// //         ],
// //       ),
// //       padding: EdgeInsets.all(MySize.size8!),
// //       child: ListTile(
// //         leading: ClipRRect(
// //           borderRadius: BorderRadius.circular(MySize.size30!),
// //           child: CachedNetworkImage(
// //               errorWidget: (context, url, error) =>
// //                   Image.asset('assets/images/default_product.png'),
// //               placeholder: (context, url) =>
// //                   Image.asset('assets/images/default_product.png'),
// //               imageUrl: widget.image ?? ''),
// //         ),
// //         title: Text(widget.name!,
// //             style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
// //                 fontWeight: 500, letterSpacing: 0)),
// //         trailing: Column(
// //           mainAxisAlignment: MainAxisAlignment.spaceAround,
// //           children: <Widget>[
// //             Text(
// //               widget.symbol! + Helper().formatCurrency(widget.price),
// //               style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
// //                   fontWeight: 700, letterSpacing: 0),
// //             ),
// //             Container(
// //               width: MySize.size80,
// //               decoration: BoxDecoration(
// //                   color: themeData.colorScheme.primary,
// //                   borderRadius:
// //                       BorderRadius.all(Radius.circular(MySize.size4!))),
// //               padding: EdgeInsets.only(
// //                   left: MySize.size6!,
// //                   right: MySize.size8!,
// //                   top: MySize.size2!,
// //                   bottom: MySize.getScaledSizeHeight(3.5)),
// //               child: Row(
// //                 children: <Widget>[
// //                   Icon(
// //                     MdiIcons.stocking,
// //                     color: themeData.colorScheme.onPrimary,
// //                     size: MySize.size12,
// //                   ),
// //                   Container(
// //                     margin: EdgeInsets.only(left: MySize.size4!),
// //                     child: (widget.qtyAvailable != '-')
// //                         ? Text(Helper().formatQuantity(widget.qtyAvailable),
// //                             style: AppTheme.getTextStyle(
// //                                 themeData.textTheme.caption,
// //                                 fontSize: 11,
// //                                 color: themeData.colorScheme.onPrimary,
// //                                 fontWeight: 600))
// //                         : Text('-'),
// //                   ),
// //                 ],
// //               ),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
// //
// //
//

///Tablet friendly design
import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../helpers/AppTheme.dart';
import '../helpers/Responsive_helper.dart';
import '../helpers/SizeConfig.dart';
import '../helpers/generators.dart';
import '../helpers/otherHelpers.dart';
import '../helpers/context_manager.dart';
import '../locale/MyLocalizations.dart';
import '../models/product_model.dart';
import '../models/sell.dart';
import '../models/sellDatabase.dart';
import '../models/system.dart';
import '../models/variations.dart';
import 'Tables.dart';
import 'elements.dart';
import '../helpers/TableAvailabilityManager.dart';
import '../helpers/FirebaseTableLockService.dart';
import 'event_bus.dart';
import 'package:badges/badges.dart' as badges;
import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Products extends StatefulWidget {
  @override
  _ProductsState createState() => _ProductsState();
}

class _ProductsState extends State<Products>
// with WidgetsBindingObserver
    {
  List products = [];
  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);
  bool changeLocation = false,
      changePriceGroup = false,
      canChangeLocation = true,
      canMakeSell = false,
      inStock = false,
      gridView = false,
      canAddSell = false,
      canViewProducts = false,
      usePriceGroup = true,
      isLoading = false,
      _isLoadingDialogShown = false;

  // Static variable to track if Products screen is already active
  static bool _isProductsScreenActive = false;

  int selectedLocationId = 0,
      categoryId = 0,
      subCategoryId = 0,
      brandId = 0,
      cartCount = 0,
      sellingPriceGroupId = 0,
      offset = 0;
  int? sellId; // Added to store sellId
  int? res_table_id; // Added to store res_table_id
  int? is_shipping; // Added to store is_shipping
  String cartKey = ''; // Added to store cartKey
  int? byAlphabets, byPrice;

  // Track initial cart items when entering product screen
  List<Map<String, dynamic>> _initialCartItems = [];

  List<DropdownMenuItem<int>> _categoryMenuItems = [],
      _subCategoryMenuItems = [],
      _brandsMenuItems = [];
  List<DropdownMenuItem<bool>> _priceGroupMenuItems = [];
  List<Map<String, dynamic>> _categoriesList = [];
  List<Map<String, dynamic>> _subCategoriesList = [];
  Map? argument;
  List<Map<String, dynamic>> locationListMap = [
    {'id': 0, 'name': 'set location', 'selling_price_group_id': 0}
  ];

  // Color scheme for categories - cycling through different colors
  final List<Color> categoryColors = [
    Colors.red,
    Colors.blue,
    Colors.orange,
    Colors.green,
    Colors.purple,
    Colors.teal,
    Colors.pink,
    Colors.indigo,
  ];

  // bool _isCleaningUp = false;
  String symbol = '';
  final searchController = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  ScrollController _scrollController = new ScrollController();

  Timer? _refreshTimer;
  final int _refreshIntervalInSeconds = 60; // Refresh every 60 seconds

  @override
  void dispose() {
    //WidgetsBinding.instance.removeObserver(this);
    _refreshTimer?.cancel(); // Cancel the timer when widget is disposed

    // Restore table/shipping availability when navigating back from products screen
    _restoreTableOrShippingAvailability();

    // Reset Products screen active flag
    _isProductsScreenActive = false;
    debugPrint('Products: Resetting Products screen active flag');

    searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // @override
  // void didChangeAppLifecycleState(AppLifecycleState state) async {
  //   // 🔥 When app goes to background or gets detached, clean up
  //   if (_isCleaningUp) return;
  //   if (state == AppLifecycleState.detached ||
  //       state == AppLifecycleState.inactive ||
  //       state == AppLifecycleState.paused) {
  //     _isCleaningUp = true;
  //     if (argument?['deferredOrderCreation'] == true) {
  //       await _cleanupEmptyDeferredOrder();
  //     }
  //     _isCleaningUp = false;
  //   }
  // }

  @override
  void initState() {
    super.initState();
    // WidgetsBinding.instance.addObserver(this);
    getPermission();

    // Prevent duplicate Products screens from being created
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        // Check if this is a duplicate Products screen
        final currentRoute = ModalRoute.of(context);
        if (currentRoute != null) {
          debugPrint(
              'Products: Screen initialized - Route: ${currentRoute.settings.name}');
        }

        // Check if Products screen is already active
        if (_isProductsScreenActive) {
          debugPrint(
              'Products: Duplicate Products screen detected - preventing navigation');
          // Pop the current screen to prevent duplicate
          Navigator.pop(context);
          return;
        }

        // Mark Products screen as active
        _isProductsScreenActive = true;
        debugPrint('Products: Marking Products screen as active');
      }
    });
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        productList();
      }
      //print('ProductList : ${productList()}');
    });

    // Load essential data first
    setLocationMap();
    Future.microtask(() {
      didChangeData();
    });

    // Load non-essential data in background
    unawaited(Future.wait<void>([
      categoryList(),
      // If categoryId is 0 (All Categories), load all subcategories
      (categoryId == 0) ? loadAllSubCategories() : subCategoryList(categoryId),
      brandList(),
    ]));

    Helper().syncCallLogs();
    // Start auto-refresh timer
    _startAutoRefresh();
  }

  void _startAutoRefresh() {
    _refreshTimer = Timer.periodic(
      Duration(seconds: _refreshIntervalInSeconds),
          (Timer timer) {
        if (mounted) {
          _refreshData();
        }
      },
    );
  }

  Future<void> _refreshData() async {
    setState(() {
      products = [];
      offset = 0;
    });
    await productList();
    await getCartItemCount(sellId: sellId, resTableId: res_table_id);
  }

  Future<void> didChangeData() async {
    argument = ModalRoute.of(context)!.settings.arguments as Map?;
    // Cancel any existing timer
    _refreshTimer?.cancel();

    print('Received arguments: $argument'); // Debug print

    // FIXED: Prioritize arguments from Sales screen over saved context
    Map<String, dynamic>? contextData = argument?.cast<String, dynamic>();

    // If we have valid arguments (especially from Sales screen), use them directly
    if (contextData != null && contextData['sellId'] != null) {
      debugPrint(
          'Products: Using arguments directly (from Sales screen): $contextData');
    } else if (contextData == null || contextData['locationId'] == null) {
      // Only fallback to saved context if we don't have valid arguments
      contextData = await ContextManager.getValidContext();
      if (contextData != null) {
        debugPrint('Products: Using saved context: $contextData');
      }
    }

    if (contextData != null && contextData['locationId'] != null) {
      // FIXED: Only merge context data if we don't already have valid arguments from Sales screen
      if (argument == null) {
        argument = contextData;
      } else if (argument!['sellId'] != null) {
        // If we have arguments with sellId (from Sales screen), don't override them
        // Only merge non-conflicting data
        argument = {
          ...argument!,
          ...contextData,
          // Preserve Sales screen data - CRITICAL: Use argument values, not contextData
          'sellId': argument!['sellId'],
          'res_table_id': argument!['res_table_id'], // Preserve from Sales screen
          'locationId': argument!['locationId'],
          'is_shipping': argument!['is_shipping'] ?? contextData['is_shipping'] ?? 0,
        };
        debugPrint('Products: Preserved Sales screen arguments during merge');
      } else {
        // Merge context data into existing arguments (normal case)
        argument = {...argument!, ...contextData};
      }

      // CRITICAL: Use argument values (which may have been preserved from Sales screen) for state
      setState(() {
        selectedLocationId = argument!['locationId'] ?? contextData!['locationId'];
        sellId = argument!['sellId'] ?? contextData!['sellId']; // This can be null for deferred creation
        res_table_id = argument!['res_table_id'] ?? contextData!['res_table_id']; // Use from arguments first

        // CRITICAL: Ensure is_shipping is properly converted to int (handle both int and dynamic types)
        dynamic isShippingArg = argument!['is_shipping'] ?? contextData!['is_shipping'];
        if (isShippingArg != null) {
          is_shipping = isShippingArg is int ? isShippingArg : (isShippingArg == 1 || isShippingArg == '1' || isShippingArg == true) ? 1 : 0;
        } else {
          is_shipping = 0;
        }

        cartKey = argument!['cartKey'] ?? contextData!['cartKey'] ?? '';
        canChangeLocation = false;
        debugPrint(
            'Products: Set sellId to $sellId, locationId to $selectedLocationId, res_table_id: $res_table_id, is_shipping: $is_shipping (from arg: ${argument!['is_shipping']}, context: ${contextData!['is_shipping']}), cartKey: $cartKey');
        debugPrint(
            'Products: deferredOrderCreation flag = ${argument!['deferredOrderCreation'] ?? contextData!['deferredOrderCreation']}');
      });

      debugPrint('Products: Final argument after merge: $argument');
      debugPrint(
          'Products: Final argument[deferredOrderCreation]: ${argument?['deferredOrderCreation']}');

      // FIXED: For API-only records (sellId exists but record not in local DB), create the sell record
      if (sellId != null && sellId != 0) {
        var existingSellRecord = await SellDatabase().getSellBySellId(sellId!);
        if (existingSellRecord.isEmpty &&
            argument != null &&
            argument!['saleEdit'] == true) {
          debugPrint(
              'Products: Creating sell record for API-only record: $sellId');

          // Create the sell record from API data with minimal required fields
          Map<String, dynamic> sellMap = {
            'id': sellId!,
            'invoice_no': argument!['invoice_no'] ?? 'DRAFT-$sellId',
            'transaction_date': argument!['transaction_date'] ??
                DateTime.now().toIso8601String(),
            'change_return': 0.0,
            'contact_id':
            argument!['customerId'] ?? 1998, // Default walk-in customer
            'invoice_amount': argument!['invoiceAmount']?.toDouble() ?? 0.0,
            'location_id': selectedLocationId,
            'pending_amount': argument!['invoiceAmount']?.toDouble() ?? 0.0,
            'sale_note': argument!['sale_note'] ?? '',
            'sale_status': 'draft',
            'shipping_charges': 0.0,
            'shipping_details': '',
            'staff_note': '',
            'is_quotation': argument!['isQuotation'] == true ? 1 : 0,
            'tip_amount': 0.0,
            'tip_type': 'fixed',
            'discount_amount': argument!['discountAmount']?.toDouble() ?? 0.0,
            'discount_type': argument!['discountType'] ?? 'fixed',
            'res_table_id': res_table_id,
            'is_shipping': is_shipping,
            'is_synced': 0, // Mark as local draft
            'transaction_id': null,
            'invoice_url': null,
          };

          try {
            await SellDatabase().storeSell(sellMap);
            debugPrint(
                'Products: Successfully created sell record for API-only record: $sellId');
          } catch (e) {
            debugPrint(
                'Products: Error creating sell record for API-only record: $e');
            // Don't fail the entire process if sell record creation fails
            // The old data should still be preserved
          }
        }
      }

      // ENHANCED: For existing orders (saleEdit=true), ensure products are loaded from database
      // This handles all navigation scenarios: Sales → Product → Cart → Customer → Back → Cart → Product → Sales
      if (argument != null &&
          argument!['saleEdit'] == true &&
          sellId != null &&
          sellId != 0) {
        debugPrint(
            'Products: Processing existing order - sellId: $sellId, res_table_id: $res_table_id');

        // Check if products array is empty (which happens on re-navigation from any screen)
        List<dynamic> productsFromArgs = argument!['products'] ?? [];
        debugPrint(
            'Products: Products from arguments: ${productsFromArgs.length} items');

        if (productsFromArgs.isEmpty) {
          debugPrint(
              'Products: Products array is empty for existing order $sellId, loading from database');

          // Load products from database for existing order
          List<Map> existingProducts = await SellDatabase().getSellLineBySellId(
              sellId!,
              res_table_id: res_table_id,
              includeCompleted: true);

          debugPrint(
              'Products: Database query returned ${existingProducts.length} products');

          if (existingProducts.isNotEmpty) {
            debugPrint(
                'Products: Loaded ${existingProducts.length} products from database for existing order $sellId');

            // Update the argument with loaded products
            argument!['products'] = existingProducts;

            // Also restore any missing cart data
            await handleMissingCartData(sellId!);

            // ENHANCED: Save the restored products to shared preferences for persistence across navigation
            await _saveProductsToSharedPreferences(sellId!, existingProducts);
          } else {
            debugPrint(
                'Products: No products found in database for existing order $sellId');

            // ENHANCED: Try to load from shared preferences as fallback
            List<Map>? cachedProducts =
            await _loadProductsFromSharedPreferences(sellId!);
            if (cachedProducts != null && cachedProducts.isNotEmpty) {
              debugPrint(
                  'Products: Loaded ${cachedProducts.length} products from cache for existing order $sellId');
              debugPrint(
                  'Products: Using products from arguments: ${productsFromArgs.length} items');
              debugPrint(
                  'Products: First product from args: ${productsFromArgs.isNotEmpty ? productsFromArgs.first : 'None'}');
              argument!['products'] = cachedProducts;
            } else {
              debugPrint(
                  'Products: No cached products found either for existing order $sellId');
            }
          }
        }
        // else {
        //   debugPrint('Products: Using products from arguments: ${productsFromArgs.length} items');
        //   debugPrint('Products: First product from args: ${productsFromArgs.isNotEmpty ? productsFromArgs.first : 'None'}');
        // }
        else {
          debugPrint(
              'Products: Products array already contains ${productsFromArgs.length} items for existing order $sellId');
          debugPrint(
              'Products: Using products from arguments: ${productsFromArgs.length} items');
          debugPrint(
              'Products: First product from args: ${productsFromArgs.isNotEmpty ? productsFromArgs.first : 'None'}');

          // ENHANCED: Save current products to shared preferences for persistence
          await _saveProductsToSharedPreferences(
              sellId!, productsFromArgs.cast<Map>());
        }
      }

      // Capture initial cart items to track what was already saved
      await _captureInitialCartItems();

      // Refresh cart count after setting arguments
      await getCartItemCount(sellId: sellId, resTableId: res_table_id);

      print('Table name: ${contextData['tableName']}'); // Debug print
      print('Is shipping: ${contextData['is_shipping']}'); // Debug print
    } else {
      // Don't automatically create a draft when no arguments are provided
      // This prevents incomplete orders from being auto-saved as drafts
      canChangeLocation = true;
      sellId = null;
      cartKey = 'default';
      debugPrint(
          'Products: No valid context found, not creating automatic draft');
    }

    await setInitDetails(selectedLocationId);
    // Restart the timer
    _startAutoRefresh();

    // In products.dart, in didChangeData():
    print('Arguments received: $argument');
    print('Is shipping: ${argument?['is_shipping']}');
    print('Table name: ${argument?['tableName']}');
  }

  /// Restore table or shipping availability when navigating back from products screen
  Future<void> _restoreTableOrShippingAvailability() async {
    if (argument == null) return;

    final availabilityManager = TableAvailabilityManager();

    if (argument!['is_shipping'] == 1) {
      // This is a shipping order - mark shipping as available
      availabilityManager.markShippingAvailable();
      debugPrint(
          'Products screen: Marked shipping as available (navigating back)');

      // Fire event to notify Tables screen
      EventBus().fire(TableAvailabilityChangedEvent(
        isShipping: true,
        isAvailable: true,
      ));
    } else if (argument!['res_table_id'] != null &&
        argument!['res_table_id'] > 0) {
      final tableId = argument!['res_table_id'] as int;
      final locationId = argument?['locationId'] as int? ?? selectedLocationId;

      // CRITICAL: Check if table is locked in Firebase before marking as available
      if (locationId != null && locationId > 0) {
        try {
          final lockInfo = await FirebaseTableLockService().getTableLockInfo(
            tableId: tableId,
            locationId: locationId,
          );

          final isLockedInFirebase = lockInfo != null;

          if (isLockedInFirebase) {
            // Table is locked in Firebase - do NOT mark as available
            debugPrint(
                'Products screen: Table $tableId is locked in Firebase - NOT marking as available (navigating back)');
            return; // Don't mark as available if locked
          }
        } catch (e) {
          debugPrint('Products screen: Error checking Firebase lock for table $tableId: $e');
          // On error, proceed with marking as available (fallback behavior)
        }
      }

      // This is a table order - mark table as available (only if not locked)
      availabilityManager.markTableAvailable(tableId);
      debugPrint(
          'Products screen: Marked table $tableId as available (navigating back)');

      // Fire event to notify Tables screen
      EventBus().fire(TableAvailabilityChangedEvent(
        tableId: tableId,
        isShipping: false,
        isAvailable: true,
      ));
    }
  }

  /// Capture initial cart items when entering product screen
  Future<void> _captureInitialCartItems() async {
    if (sellId == null || sellId == 0) {
      return;
    }

    try {
      // Get all cart items for this sellId and res_table_id (include completed items for editing)
      List<Map> cartItems = await SellDatabase().getSellLineBySellId(sellId!,
          res_table_id: res_table_id, includeCompleted: true);

      // ENHANCED: If no cart items found in database but we have products in arguments, use those
      if (cartItems.isEmpty &&
          argument != null &&
          argument!['products'] != null) {
        List<dynamic> productsFromArgs = argument!['products'];
        if (productsFromArgs.isNotEmpty) {
          debugPrint(
              'Products: No cart items in database, using products from arguments as initial items');
          cartItems = productsFromArgs.cast<Map<String, dynamic>>();
        }
      }

      // Store the initial cart items to track what was already there
      _initialCartItems = List<Map<String, dynamic>>.from(cartItems);

      debugPrint(
          'Products: Captured ${_initialCartItems.length} initial cart items for sellId: $sellId');
      for (var item in _initialCartItems) {
        debugPrint(
            'Products: Initial item - id: ${item['id']}, product_id: ${item['product_id']}, variation_id: ${item['variation_id']}, is_completed: ${item['is_completed']}');
      }
    } catch (e) {
      debugPrint('Products: Error capturing initial cart items: $e');
    }
  }

  /// Check if a product is already in the cart
  Future<bool> _isProductInCart(Map product) async {
    if (sellId == null || sellId == 0) {
      return false;
    }

    try {
      // Get current cart items for this sellId and res_table_id
      List<Map> currentCartItems = await SellDatabase().getSellLineBySellId(
          sellId!,
          res_table_id: res_table_id,
          includeCompleted: false);

      // Check if this product/variation is already in the cart
      bool exists = currentCartItems.any((item) =>
      item['product_id'] == product['product_id'] &&
          item['variation_id'] == product['variation_id'] &&
          item['res_table_id'] == (res_table_id ?? 0) &&
          item['is_completed'] == 0);

      debugPrint(
          'Products: Checking if product ${product['display_name']} (product_id: ${product['product_id']}, variation_id: ${product['variation_id']}) is in cart: $exists');

      return exists;
    } catch (e) {
      debugPrint('Products: Error checking if product is in cart: $e');
      return false;
    }
  }

  /// Check if there are unsaved changes (newly added items)
  Future<bool> _checkForUnsavedChanges() async {
    if (sellId == null || sellId == 0) {
      return false; // No active session, no changes to check
    }

    try {
      // Get current cart items for this sellId and res_table_id (include completed items for editing)
      List<Map> currentCartItems = await SellDatabase().getSellLineBySellId(
          sellId!,
          res_table_id: res_table_id,
          includeCompleted: true);

      // Check if there are any items that weren't in the initial cart
      // These are the newly added items
      bool hasNewItems = false;

      for (var currentItem in currentCartItems) {
        bool wasInInitialCart = _initialCartItems.any((initialItem) =>
        initialItem['id'] == currentItem['id'] ||
            (initialItem['product_id'] == currentItem['product_id'] &&
                initialItem['variation_id'] == currentItem['variation_id']));

        if (!wasInInitialCart) {
          hasNewItems = true;
          debugPrint(
              'Products: Found new item - id: ${currentItem['id']}, product_id: ${currentItem['product_id']}, variation_id: ${currentItem['variation_id']}');
          break;
        }
      }

      debugPrint(
          'Products: Checking for unsaved changes - sellId: $sellId, res_table_id: $res_table_id, hasNewItems: $hasNewItems');
      debugPrint(
          'Products: Current cart items: ${currentCartItems.length}, Initial cart items: ${_initialCartItems.length}');

      return hasNewItems;
    } catch (e) {
      debugPrint('Products: Error checking for unsaved changes: $e');
      return false; // If there's an error, assume no changes to be safe
    }
  }

  /// Clean up only newly added items while keeping saved items
  Future<void> _cleanupNewlyAddedItems() async {
    if (sellId == null || sellId == 0) {
      return;
    }

    try {
      // Get current cart items
      List<Map> currentCartItems = await SellDatabase()
          .getSellLineBySellId(sellId!, res_table_id: res_table_id);

      // Find items that weren't in the initial cart (newly added items)
      List<int> itemsToDelete = [];

      for (var currentItem in currentCartItems) {
        bool wasInInitialCart = _initialCartItems.any((initialItem) =>
        initialItem['id'] == currentItem['id'] ||
            (initialItem['product_id'] == currentItem['product_id'] &&
                initialItem['variation_id'] == currentItem['variation_id']));

        if (!wasInInitialCart) {
          itemsToDelete.add(currentItem['id']);
          debugPrint(
              'Products: Marking for deletion - id: ${currentItem['id']}, product_id: ${currentItem['product_id']}, variation_id: ${currentItem['variation_id']}');
        }
      }

      // Delete only the newly added items
      if (itemsToDelete.isNotEmpty) {
        final db = await SellDatabase().database;

        String placeholders = itemsToDelete.map((_) => '?').join(',');
        String whereClause = 'id IN ($placeholders)';

        var deletedCount = await db.delete(
          'sell_lines',
          where: whereClause,
          whereArgs: itemsToDelete,
        );

        debugPrint(
            'Products: Deleted $deletedCount newly added items for sellId: $sellId, res_table_id: $res_table_id');
      } else {
        debugPrint(
            'Products: No newly added items to delete for sellId: $sellId, res_table_id: $res_table_id');
      }
    } catch (e) {
      debugPrint('Products: Error cleaning up newly added items: $e');
    }
  }

  /// Clean up empty deferred orders when user navigates back without adding products
  Future<void> _cleanupEmptyDeferredOrder() async {
    if (sellId == null || sellId == 0) {
      return;
    }

    try {
      // Check if the order has any products
      List<Map> cartItems = await SellDatabase()
          .getSellLineBySellId(sellId!, res_table_id: res_table_id);

      if (cartItems.isEmpty) {
        debugPrint(
            'Products: Cleaning up empty deferred order $sellId for table $res_table_id');

        // Delete the empty order
        await SellDatabase().deleteSell(sellId!);

        // Clear cart data
        if (res_table_id != null) {
          final cartKey = res_table_id.toString();
          AppConstants.cartData[cartKey] = null;
          await ShareInt().setMap(jsonEncode(AppConstants.cartData));
        }

        debugPrint('Products: Cleaned up empty deferred order $sellId');
      }
    } catch (e) {
      debugPrint('Products: Error cleaning up empty deferred order: $e');
    }
  }

  /// Handle the case where an order becomes empty after cleanup
  Future<void> _handleEmptyOrderAfterCleanup() async {
    if (sellId == null || sellId == 0 || res_table_id == null) {
      return;
    }

    try {
      // Check if the order has any remaining products
      List<Map> remainingCartItems = await SellDatabase()
          .getSellLineBySellId(sellId!, res_table_id: res_table_id);

      if (remainingCartItems.isEmpty) {
        debugPrint(
            'Products: Order $sellId became empty after cleanup, removing order and freeing table $res_table_id');

        // Delete the empty order
        await SellDatabase().deleteSell(sellId!);

        // Clear cart data to free up the table
        final cartKey = res_table_id.toString();
        AppConstants.cartData[cartKey] = null;
        await ShareInt().setMap(jsonEncode(AppConstants.cartData));

        // Notify Tables screen that this table is now available
        _notifyTableAvailabilityChange(res_table_id!, true);

        debugPrint(
            'Products: Cleaned up empty order $sellId and freed table $res_table_id');
      } else {
        debugPrint(
            'Products: Order $sellId still has ${remainingCartItems.length} items after cleanup, keeping order');
        // Order still has items, so table should remain unavailable
        _notifyTableAvailabilityChange(res_table_id!, false);
      }
    } catch (e) {
      debugPrint('Products: Error handling empty order after cleanup: $e');
    }
  }

  /// Notify Tables screen about table availability changes
  void _notifyTableAvailabilityChange(int tableId, bool isAvailable) {
    try {
      // Use the existing event system to notify Tables screen
      // This ensures the table state is properly updated
      debugPrint(
          'Products: Notifying table availability change - Table $tableId: ${isAvailable ? "available" : "unavailable"}');

      // The Tables screen will pick up this change through its auto-refresh mechanism
      // No additional action needed as the database state has been updated
    } catch (e) {
      debugPrint('Products: Error notifying table availability change: $e');
    }
  }

  /// Determine the correct navigation route based on arguments
  void _navigateBack() {
    argument = ModalRoute.of(context)!.settings.arguments as Map?;
    debugPrint('Products: Back navigation - Arguments: $argument');

    // Always use pop to maintain clean navigation stack
    // This prevents the complex navigation flow you're experiencing
    if (Navigator.canPop(context)) {
      debugPrint(
          'Products: Using Navigator.pop() to maintain clean navigation stack');
      Navigator.pop(context);
    } else {
      // Only use fallback when absolutely necessary
      debugPrint('Products: Cannot pop - using fallback navigation');
      if (argument?['saleEdit'] == true) {
        Navigator.pushReplacementNamed(context, '/sale');
      } else if (argument?['cartKey'] != null ||
          argument?['tableName'] != null) {
        Navigator.pushReplacementNamed(context, '/tables');
      } else {
        Navigator.pushReplacementNamed(context, '/sale');
      }
    }
  }

  /// Handle back navigation with unsaved changes check
  Future<bool> _handleBackNavigation() async {
    // Check if there are unsaved changes
    bool hasUnsavedChanges = await _checkForUnsavedChanges();

    // CLEANUP: If no unsaved changes and this was a deferred creation that never had products added
    if (!hasUnsavedChanges &&
        sellId != null &&
        argument?['deferredOrderCreation'] == true) {
      await _cleanupEmptyDeferredOrder();
    }

    if (hasUnsavedChanges) {
      // Show confirmation dialog for unsaved changes
      bool shouldDiscard = await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: themeData.colorScheme.surface,
            title: Text(
              AppLocalizations.of(context).translate('unsaved_changes'),
              style: AppTheme.getTextStyle(
                themeData.textTheme.headline6,
                color: themeData.colorScheme.onSurface,
                fontWeight: 700,
              ),
            ),
            content: Text(
              AppLocalizations.of(context)
                  .translate('unsaved_changes_message'),
              style: AppTheme.getTextStyle(
                themeData.textTheme.subtitle1,
                color: themeData.colorScheme.onSurface,
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text(
                  AppLocalizations.of(context).translate('cancel'),
                  style: TextStyle(color: themeData.colorScheme.primary),
                ),
              ),
              TextButton(
                onPressed: () {
                  FirebaseFirestore.instance.collection("Table").doc("${res_table_id}").set(
                      {
                        "Status":0
                      });

                  // Unlock table in Firebase when discarding (only for table orders, not shipping)
                  final locationId = argument?['locationId'] as int? ?? selectedLocationId;
                  final tableId = res_table_id;
                  if (tableId != null && tableId > 0 && (is_shipping == null || is_shipping == 0) && locationId != null && locationId > 0) {
                    try {
                      FirebaseTableLockService().unlockTable(
                        tableId: tableId,
                        locationId: locationId,
                      );
                      debugPrint('Products: Unlocked table $tableId in Firebase after discard');
                    } catch (e) {
                      debugPrint('Products: Error unlocking table in Firebase: $e');
                    }
                  }

                  Navigator.of(context).pop(true);
                },
                child: Text(
                  AppLocalizations.of(context).translate('discard'),
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          );
        },
      ) ??
          false;

      if (!shouldDiscard) {
        // User chose to keep changes, ensure table remains unavailable
        if (sellId != null && sellId != 0 && res_table_id != null) {
          _notifyTableAvailabilityChange(res_table_id!, false);
        }
        return false; // User cancelled, don't navigate back
      }

      // User confirmed discarding changes, clean up only newly added items
      if (sellId != null && sellId != 0) {
        try {
          // ENHANCED: For existing orders, be more conservative about cleanup
          if (argument != null && argument!['saleEdit'] == true) {
            debugPrint(
                'Products: Discarding changes for existing order $sellId - preserving original data');

            // For existing orders, only clean up if we have a valid sell record
            var existingSellRecord =
            await SellDatabase().getSellBySellId(sellId!);
            if (existingSellRecord.isNotEmpty) {
              await _cleanupNewlyAddedItems();
              await _handleEmptyOrderAfterCleanup();
              debugPrint(
                  'Products: Cleaned up newly added items for existing order $sellId');
            } else {
              debugPrint(
                  'Products: Sell record not found for existing order $sellId - preserving all data');
              // Don't clean up anything if sell record doesn't exist
              // This preserves the original data from the API
            }
          } else {
            // For new orders, proceed with normal cleanup
            await _cleanupNewlyAddedItems();
            await _handleEmptyOrderAfterCleanup();
            debugPrint(
                'Products: Cleaned up newly added items for new order $sellId');
          }
        } catch (e) {
          debugPrint('Products: Error cleaning up newly added items: $e');
          // Don't fail the entire process - preserve existing data
        }
      }
    }

    // FIXED: Ensure proper table state when navigating back
    if (sellId != null && sellId != 0 && res_table_id != null) {
      // Check if order still has items
      try {
        List<Map> remainingCartItems = await SellDatabase()
            .getSellLineBySellId(sellId!, res_table_id: res_table_id);
        bool hasItems = remainingCartItems.isNotEmpty;
        _notifyTableAvailabilityChange(res_table_id!, !hasItems);
        debugPrint(
            'Products: Navigation back - Table $res_table_id should be ${hasItems ? "unavailable" : "available"}');
      } catch (e) {
        debugPrint(
            'Products: Error checking order state before navigation: $e');
      }
    }

    return true; // Allow navigation
  }

  // @override
  // Future<void> didChangeDependencies() async {
  //
  //   super.didChangeDependencies();
  // }

  // Set location & product
  setInitDetails(selectedLocationId) async {
    var activeSubscriptionDetails = await System().get('active-subscription');
    if (activeSubscriptionDetails.length > 0) {
      setState(() {
        canMakeSell = true;
      });
    } else {
      Fluttertoast.showToast(
          msg: AppLocalizations.of(context).translate('no_subscription_found'));
    }
    await Helper().getFormattedBusinessDetails().then((value) {
      symbol = value['symbol'] + ' ';
    });
    await setDefaultLocation(selectedLocationId);
    products = [];
    offset = 0;
    productList();
    debugPrint(
        'Products: Initializing details for locationId $selectedLocationId, sellId $sellId , res_table_id $res_table_id');
  }

  // Fetch permission from database
  getPermission() async {
    if (await Helper().getPermission("direct_sell.access")) {
      canAddSell = true;
    }
    if (await Helper().getPermission("product.view")) {
      canViewProducts = true;
    }
  }

  // Set selling Price Group Id
  findSellingPriceGroupId(locId) {
    if (usePriceGroup) {
      locationListMap.forEach((element) {
        if (element['id'] == selectedLocationId &&
            element['selling_price_group_id'] != null) {
          sellingPriceGroupId =
              int.parse(element['selling_price_group_id'].toString());
        } else if (element['id'] == selectedLocationId &&
            element['selling_price_group_id'] == null) {
          sellingPriceGroupId = 0;
        }
      });
    } else {
      sellingPriceGroupId = 0;
    }
  }

  // Set product list
  productList() async {
    //print('Product List : ${productList()}');
    // Set loading state when products list is empty (initial load or reset)
    if (products.isEmpty) {
      setState(() {
        isLoading = true;
      });
    }
    offset++;
    String? lastSync = await System().getProductLastSync();
    final date2 = DateTime.now();
    if (lastSync == null ||
        (date2.difference(DateTime.parse(lastSync)).inMinutes > 10)) {
      if (await Helper().checkConnectivity()) {
        await Variations().refresh();
        await System().insertProductLastSyncDateTimeNow();
      }
    }

    findSellingPriceGroupId(selectedLocationId);
    try {
      await Variations()
          .get(
          brandId: brandId,
          categoryId: categoryId,
          subCategoryId: subCategoryId,
          inStock: inStock,
          locationId: selectedLocationId,
          searchTerm: searchController.text,
          offset: offset,
          byAlphabets: byAlphabets,
          byPrice: byPrice)
          .then((element) {
        element.forEach((product) {
          var price;
          if (product['selling_price_group'] != null) {
            jsonDecode(product['selling_price_group']).forEach((element) {
              if (element['key'] == sellingPriceGroupId) {
                price = double.parse(element['value'].toString());
              }
            });
          }
          setState(() {
            products.add(ProductModel().product(product, price));
          });
        });
      });
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  categoryList() async {
    List categories = await System().getCategories();

    // Store raw categories list for chip display
    setState(() {
      _categoriesList = List<Map<String, dynamic>>.from(categories);
    });

    _categoryMenuItems.add(
      DropdownMenuItem(
        child: Text(AppLocalizations.of(context).translate('select_category')),
        value: 0,
      ),
    );

    for (var category in categories) {
      _categoryMenuItems.add(
        DropdownMenuItem(
          child: Text(category['name']),
          value: category['id'],
        ),
      );
    }
  }

  // Method to load all subcategories from all categories
  Future<void> loadAllSubCategories() async {
    System system = System();
    final db = await system.dbProvider.database;
    // Query all subcategories without parentId filter
    var allSubCategories = await db.query(
      'system',
      where: 'key = ?',
      whereArgs: ['sub_categories'],
    );

    setState(() {
      _subCategoriesList = [];
      // Use a Set to track unique subcategory IDs to prevent duplicates
      Set<int> seenIds = {};
      allSubCategories.forEach((element) {
        String valueStr = element['value']?.toString() ?? '';
        if (valueStr.isNotEmpty) {
          var decoded = jsonDecode(valueStr);
          // Inject parent_id from keyId
          if (element['keyId'] != null) {
            decoded['parent_id'] = element['keyId'];
          }
          int subCategoryId = decoded['id'];
          // Only add if we haven't seen this ID before
          if (!seenIds.contains(subCategoryId)) {
            seenIds.add(subCategoryId);
            _subCategoriesList.add(decoded);
          }
        }
      });
    });

    // Also update dropdown menu items
    _subCategoryMenuItems = [];
    _subCategoryMenuItems.add(
      DropdownMenuItem(
        child: Text(AppLocalizations.of(context).translate('select_sub_category')),
        value: 0,
      ),
    );
    allSubCategories.forEach((element) {
      String valueStr = element['value']?.toString() ?? '';
      if (valueStr.isNotEmpty) {
        var decoded = jsonDecode(valueStr);
        int subCategoryId = decoded['id'];
        if (!_subCategoryMenuItems.any((item) => item.value == subCategoryId)) {
          _subCategoryMenuItems.add(
            DropdownMenuItem(
              child: Text(decoded['name']),
              value: subCategoryId,
            ),
          );
        }
      }
    });
  }

  subCategoryList(parentId) async {
    List subCategories = await System().getSubCategories(parentId);

    // Store raw subcategories list for chip display
    setState(() {
      _subCategoriesList = [];
      // Use a Set to track unique subcategory IDs to prevent duplicates
      Set<int> seenIds = {};
      subCategories.forEach((element) {
        String valueStr = element['value']?.toString() ?? '';
        if (valueStr.isNotEmpty) {
          var decoded = jsonDecode(valueStr);
          int subCategoryId = decoded['id'];
          // Only add if we haven't seen this ID before
          if (!seenIds.contains(subCategoryId)) {
            seenIds.add(subCategoryId);
            _subCategoriesList.add(decoded);
          }
        }
      });
    });

    _subCategoryMenuItems = [];
    _subCategoryMenuItems.add(
      DropdownMenuItem(
        child:
        Text(AppLocalizations.of(context).translate('select_sub_category')),
        value: 0,
      ),
    );
    subCategories.forEach((element) {
      String valueStr = element['value']?.toString() ?? '';
      if (valueStr.isNotEmpty) {
        var decoded = jsonDecode(valueStr);
        _subCategoryMenuItems.add(
          DropdownMenuItem(
            child: Text(decoded['name']),
            value: decoded['id'],
          ),
        );
      }
    });
  }

  brandList() async {
    List brands = await System().getBrands();

    _brandsMenuItems.add(
      DropdownMenuItem(
        child: Text(AppLocalizations.of(context).translate('select_brand')),
        value: 0,
      ),
    );

    for (var brand in brands) {
      _brandsMenuItems.add(
        DropdownMenuItem(
          child: Text(brand['name']),
          value: brand['id'],
        ),
      );
    }
  }

  Future<void> priceGroupList() async {
    setState(() {
      _priceGroupMenuItems = [
        DropdownMenuItem(
          child: Text(AppLocalizations.of(context)
              .translate('no_price_group_selected')),
          value: false,
        ),
      ];

      final selectedLocation = locationListMap.firstWhere(
            (element) => element['id'] == selectedLocationId,
        orElse: () => {'selling_price_group_id': null},
      );

      if (selectedLocation['selling_price_group_id'] != null) {
        _priceGroupMenuItems.add(
          DropdownMenuItem(
            child: Text(
                AppLocalizations.of(context).translate('default_price_group')),
            value: true,
          ),
        );
      }

      if (!_priceGroupMenuItems.any((item) => item.value == usePriceGroup)) {
        usePriceGroup = _priceGroupMenuItems.first.value!;
      }
    });
  }

  Future<String> getCartItemCount(
      {isCompleted, sellId, int? resTableId}) async {
    debugPrint(
        'Products.getCartItemCount: Called with sellId=$sellId, resTableId=$resTableId, isCompleted=$isCompleted');

    // For existing sales (when sellId is provided), we need to count both completed and incomplete items
    // This is because the cart items might be completed (is_completed = 1) for existing sales/quotations
    if (sellId != null && sellId != 0) {
      debugPrint(
          'Products.getCartItemCount: Processing existing sale - sellId=$sellId');

      // Use getSellLineBySellId to get all items (both completed and incomplete) for existing sales
      List<Map> cartItems = await SellDatabase().getSellLineBySellId(sellId,
          res_table_id: resTableId ?? res_table_id, includeCompleted: true);

      debugPrint(
          'Products.getCartItemCount: Database query returned ${cartItems.length} cart items');

      // If no items found, try to restore from saved data
      if (cartItems.isEmpty) {
        debugPrint(
            'Products.getCartItemCount: No cart items found for sellId=$sellId, attempting to restore from saved data');
        await handleMissingCartData(sellId);
        // Try again after restoration
        cartItems = await SellDatabase().getSellLineBySellId(sellId,
            res_table_id: resTableId ?? res_table_id, includeCompleted: true);
        debugPrint(
            'Products.getCartItemCount: After restoration, found ${cartItems.length} cart items');
      }

      setState(() {
        cartCount = cartItems.length;
      });

      debugPrint(
          'Products.getCartItemCount: Final cart count for sellId=$sellId: ${cartItems.length}');
      return cartItems.length.toString();
    } else {
      debugPrint('Products.getCartItemCount: Processing new sale');

      // For new sales, use the regular cart count logic
      var counts = await Sell().cartItemCount(
          isCompleted: isCompleted,
          sellId: sellId,
          res_table_id: resTableId ?? res_table_id);
      setState(() {
        cartCount = int.parse(counts);
      });

      debugPrint('Products.getCartItemCount: New sale cart count: $counts');
      return counts;
    }
  }

  Future<void> handleMissingCartData(int sellId) async {
    try {
      // FIXED: First check if the sell record exists in the database
      var sellRecord = await SellDatabase().getSellBySellId(sellId);
      if (sellRecord.isEmpty) {
        debugPrint(
            'Products.handleMissingCartData: Sell record $sellId does not exist in database, skipping cart restoration');
        return;
      }

      // Try to load saved cart data
      Map<String, dynamic>? savedCartData = await Helper.getCartData(sellId);

      if (savedCartData != null) {
        debugPrint(
            'Products.handleMissingCartData: Restoring cart from saved data for sellId: $sellId');

        // Update res_table_id and is_shipping from saved data
        res_table_id = savedCartData['res_table_id'];
        is_shipping = savedCartData['is_shipping'];

        // Restore cart items from saved data
        if (savedCartData['cartItems'] != null &&
            savedCartData['cartItems'].isNotEmpty) {
          debugPrint(
              'Products.handleMissingCartData: Restoring ${savedCartData['cartItems'].length} cart items');

          // Clear existing cart items
          await SellDatabase().deleteSellLineBySellId(sellId);

          // Add saved items back to cart
          for (var item in savedCartData['cartItems']) {
            await SellDatabase().store({
              'sell_id': sellId,
              'product_id': item['product_id'],
              'variation_id': item['variation_id'],
              'quantity': item['quantity'],
              'unit_price': item['unit_price'],
              'tax_rate_id': item['tax_rate_id'],
              'discount_amount': item['discount_amount'] ?? 0.0,
              'discount_type': item['discount_type'] ?? 'fixed',
              'note': item['note'] ?? '',
              'is_completed': 0,
              'product_order_category': item['product_order_category'] ?? 'BAR',
              'res_table_id': savedCartData['res_table_id'] ?? res_table_id,
              'is_shipping': savedCartData['is_shipping'] ?? is_shipping,
            });
          }
        }

        // Ensure no duplicate items in cart
        await SellDatabase().ensureNoDuplicateCartItems(sellId, res_table_id);

        debugPrint(
            'Products.handleMissingCartData: Successfully restored cart data for sellId: $sellId');
      } else {
        // debugPrint('Products.handleMissingCartData: No saved cart data found for sellId: $sellId');
      }
    } catch (e) {
      debugPrint(
          'Products.handleMissingCartData: Error restoring cart data: $e');
    }
  }

  /// Save products to shared preferences for persistence across navigation
  Future<void> _saveProductsToSharedPreferences(
      int sellId, List<Map> products) async {
    try {
      if (products.isNotEmpty) {
        String productsJson = jsonEncode(products);
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('products_$sellId', productsJson);
        debugPrint(
            'Products: Saved ${products.length} products to shared preferences for sellId: $sellId');
      }
    } catch (e) {
      debugPrint('Products: Error saving products to shared preferences: $e');
    }
  }

  /// Load products from shared preferences as fallback
  Future<List<Map>?> _loadProductsFromSharedPreferences(int sellId) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? productsJson = prefs.getString('products_$sellId');
      if (productsJson != null && productsJson.isNotEmpty) {
        List<dynamic> productsList = jsonDecode(productsJson);
        List<Map> products = productsList.cast<Map<String, dynamic>>();
        debugPrint(
            'Products: Loaded ${products.length} products from shared preferences for sellId: $sellId');
        return products;
      }
    } catch (e) {
      debugPrint(
          'Products: Error loading products from shared preferences: $e');
    }
    return null;
  }

  /// Clear products from shared preferences when order is finalized
  Future<void> _clearProductsFromSharedPreferences(int sellId) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.remove('products_$sellId');
      debugPrint(
          'Products: Cleared products from shared preferences for sellId: $sellId');
    } catch (e) {
      debugPrint(
          'Products: Error clearing products from shared preferences: $e');
    }
  }

  double findAspectRatio(double width) {
    return (width / 2 - MySize.size24!) / ((width / 2 - MySize.size24!) + 60);
  }

  @override
  Widget build(BuildContext context) {
    themeData = Theme.of(context);
    return SafeArea(
      bottom: true,
      top: false,
      child: WillPopScope(
        onWillPop: () async {
          bool shouldNavigate = await _handleBackNavigation();
          // if (shouldNavigate) {
          //   Navigator.pushReplacementNamed(context, '/sale');
          // }
          if (shouldNavigate) {
            _navigateBack();
          }
          return false; // We handle navigation manually
        },
        child: Scaffold(
          key: _scaffoldKey,
          resizeToAvoidBottomInset: false,
          backgroundColor: themeData.backgroundColor,
          endDrawer: _filterDrawer(),
          appBar: AppBar(
            elevation: 0,
            title: Text(AppLocalizations.of(context).translate('products'),
                style: AppTheme.getTextStyle(themeData.textTheme.headline6,
                    fontWeight: 600)),
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () async {
                bool shouldNavigate = await _handleBackNavigation();
                // if (shouldNavigate) {
                //   Navigator.pushReplacementNamed(context, '/sale');
                // }
                if (shouldNavigate) {
                  _navigateBack();
                }
              },
            ),
            actions: <Widget>[
              //removed location widget from this
              //locations(),
              Padding(
                padding: const EdgeInsets.only(right: 15.0),
                child: badges.Badge(

                  position: BadgePosition.topStart(start: 2.0, top: 2.0),
                  badgeContent: FutureBuilder<String>(
                    future: getCartItemCount(
                        sellId: sellId, resTableId: res_table_id),
                    builder: (context, AsyncSnapshot<String> snapshot) {
                      if (snapshot.hasData) {
                        int count = int.tryParse(snapshot.data ?? '0') ?? 0;
                        return Text(
                          '$count',
                          style: TextStyle(color: Colors.white),
                        );
                      }
                      return Text("0", style: TextStyle(color: Colors.white));
                    },
                  ),
                  child: IconButton(
                    icon: Icon(Icons.shopping_cart,size: 40),
                    onPressed: () async {
                      print('Tap On CART');
                      if (selectedLocationId != 0) {
                        // CRITICAL: Get res_table_id from database to ensure consistency
                        int? finalResTableId = res_table_id;
                        int finalIsShipping = is_shipping ?? 0;
                        if (sellId != null && sellId != 0) {
                          var sellRecord = await SellDatabase().getSellBySellId(sellId!);
                          if (sellRecord.isNotEmpty) {
                            finalResTableId = sellRecord[0]['res_table_id'];
                            finalIsShipping = sellRecord[0]['is_shipping'] ?? 0;
                            debugPrint(
                                'Products: Got res_table_id=$finalResTableId, is_shipping=$finalIsShipping from database before navigating to Cart');
                          }
                        }

                        // Check if cart has items before navigation using database res_table_id
                        String cartItemCount = await getCartItemCount(
                            sellId: sellId, resTableId: finalResTableId);
                        int count = int.tryParse(cartItemCount) ?? 0;

                        if (count > 0) {
                          Navigator.pushNamed(context, '/cart',
                              arguments: Helper().argument(
                                locId: selectedLocationId,
                                sellId: sellId,
                                //cartKey: cartKey,
                                res_table_id: finalResTableId, // Use database res_table_id
                                is_shipping: finalIsShipping, // Use database is_shipping
                                isShipping:
                                finalIsShipping == 1, // Add isShipping flag
                                tableName: argument?[
                                'tableName'], // Pass the table name forward
                                products: [],
                              ));
                        } else {
                          Fluttertoast.showToast(
                              msg: AppLocalizations.of(context)
                                  .translate('add_item_to_cart'));
                        }
                      } else {
                        Fluttertoast.showToast(
                            msg: AppLocalizations.of(context)
                                .translate('please_set_a_location'));
                      }
                    },
                  ),
                ),
              )
            ],
          ),
          body: Column(children: [
            // Display table/shipping selection
            // CRITICAL: Check both state variable and argument to ensure shipping label appears
            if (argument != null && (
                (res_table_id != null && res_table_id != 0) ||
                    is_shipping == 1 ||
                    (argument!['is_shipping'] != null && (argument!['is_shipping'] == 1 || argument!['is_shipping'] == '1' || argument!['is_shipping'] == true))
            ))
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                color: themeData.primaryColor.withOpacity(0.1),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      (is_shipping == 1 || (argument!['is_shipping'] != null && (argument!['is_shipping'] == 1 || argument!['is_shipping'] == '1' || argument!['is_shipping'] == true)))
                          ? Icons.local_shipping
                          : Icons.table_restaurant,
                      color: themeData.primaryColor,
                    ),
                    SizedBox(width: 8),
                    Text(
                      (is_shipping == 1 || (argument!['is_shipping'] != null && (argument!['is_shipping'] == 1 || argument!['is_shipping'] == '1' || argument!['is_shipping'] == true)))
                          ? (AppLocalizations.of(context)
                          .translate('shipping_order') ??
                          'Shipping Order')
                          : ' ${argument!['tableName'] ?? ''}',
                      style: TextStyle(
                        color: themeData.primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

            // Main content
            Expanded(
              child: (canViewProducts)
                  ? ListView(
                physics: ClampingScrollPhysics(),
                controller: _scrollController,
                padding: EdgeInsets.all(0),
                children: [
                  Visibility(
                      visible: (selectedLocationId != 0),
                      child: filter(
                        _scaffoldKey,
                      )),
                  (selectedLocationId == 0)
                      ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.location_on),
                        Text(AppLocalizations.of(context)
                            .translate('please_set_a_location')),
                      ],
                    ),
                  )
                      : _productsList(),
                ],
              )
                  : Center(
                child: Text(
                  AppLocalizations.of(context).translate('unauthorised'),
                  style: TextStyle(color: Colors.black),
                ),
              ),
            )
          ]),
          bottomNavigationBar: Visibility(
              visible: argument == null,
              child: posBottomBar('products', context)),
        ),
      ),
    );
  }

  // Helper method to build category chip
  Widget _buildCategoryChip({required int id, required String name, required bool isSelected}) {

    Color chipColor = categoryColors[id % categoryColors.length];
    if (id == 0) {
      chipColor = Colors.red; // "All Categories" in red
    }

    return ChoiceChip(
      label: Text(
        name,
        style: AppTheme.getTextStyle(
          themeData.textTheme.bodyText2,
          color: isSelected ? Colors.white : themeData.colorScheme.onBackground,
          fontWeight: isSelected ? 600 : 500,
        ),
      ),
      selected: isSelected,
      selectedColor: chipColor,
      backgroundColor: themeData.backgroundColor,
      side: BorderSide(
        color: isSelected ? chipColor : themeData.colorScheme.onBackground.withOpacity(0.3),
        width: isSelected ? 2.0 : 1.0,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      onSelected: (selected) {
        setState(() {
          subCategoryId = 0;
          categoryId = id;
          if (id != 0) {
            subCategoryList(categoryId);
          } else {
            // Load all subcategories when "All Categories" is selected
            loadAllSubCategories();
          }
        });
        products = [];
        offset = 0;
        productList();
      },
    );
  }

  // Helper method to build subcategory chip
  Widget _buildSubCategoryChip({
    required int id,
    required String name,
    required bool isSelected,
    Color? overrideColor,
  }) {
    // Color scheme for subcategories - cycling through different colors
    final List<Color> subCategoryColors = [
      Colors.yellow,
      Colors.blue,
      Colors.orange,
      Colors.green,
      Colors.purple,
      Colors.teal,
      Colors.pink,
      Colors.indigo,
      Colors.cyan,
      Colors.amber,
    ];

    Color chipColor;
    if (id == 0) {
      chipColor = Colors.red; // "All Sub Categories" in red
    } else if (overrideColor != null) {
      chipColor = overrideColor;
    } else {
      chipColor = subCategoryColors[id % subCategoryColors.length];
    }

    return ChoiceChip(
      label: Text(
        name,
        style: AppTheme.getTextStyle(
          themeData.textTheme.bodyText2,
          color: isSelected ? Colors.white : themeData.colorScheme.onBackground,
          fontWeight: isSelected ? 600 : 500,
        ),
      ),
      selected: isSelected,
      selectedColor: chipColor,
      backgroundColor: themeData.backgroundColor,
      side: BorderSide(
        color: isSelected ? chipColor : themeData.colorScheme.onBackground.withOpacity(0.3),
        width: isSelected ? 2.0 : 1.0,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      onSelected: (selected) {
        setState(() {
          subCategoryId = id;
        });
        products = [];
        offset = 0;
        productList();
      },
    );
  }

  Widget _buildSortChip({
    required String label,
    required bool isSelected,
    required int? sortState,
    required IconData iconAsc,
    required IconData iconDesc,
    required Function(bool) onSelected,
  }) {
    return ChoiceChip(
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: AppTheme.getTextStyle(
              themeData.textTheme.bodyText2,
              color: isSelected ? Colors.white : themeData.colorScheme.onBackground,
              fontWeight: isSelected ? 600 : 500,
            ),
          ),
          if (isSelected && sortState != null) ...[
            SizedBox(width: 4),
            Icon(
              sortState == 1 ? iconDesc : iconAsc,
              color: Colors.white,
              size: 18,
            ),
          ]
        ],
      ),
      selected: isSelected,
      selectedColor: themeData.colorScheme.primary,
      backgroundColor: themeData.backgroundColor,
      side: BorderSide(
        color: isSelected
            ? themeData.colorScheme.primary
            : themeData.colorScheme.onBackground.withOpacity(0.3),
        width: isSelected ? 2.0 : 1.0,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      onSelected: onSelected,
    );
  }

  Widget _filterDrawer() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.8,
      padding: EdgeInsets.only(bottom: MySize.size14!),
      color: themeData.backgroundColor,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              padding:
              EdgeInsets.only(top: MySize.size24!, bottom: MySize.size24!),
              alignment: Alignment.center,
              child: Center(
                child: Text(
                  AppLocalizations.of(context).translate('sort'),
                  style: AppTheme.getTextStyle(themeData.textTheme.subtitle1,
                      fontWeight: 700, color: themeData.colorScheme.primary),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(
                  left: MySize.size16!,
                  right: MySize.size16!,
                  top: MySize.size8!,
                  bottom: MySize.size8!),
              child: Wrap(
                spacing: MySize.size8!,
                runSpacing: MySize.size8!,
                children: [
                  _buildSortChip(
                    label: "A -> Z",
                    isSelected: byAlphabets != null,
                    sortState: byAlphabets,
                    iconAsc: MdiIcons.arrowRightBold, // 0
                    iconDesc: MdiIcons.arrowLeftBold, // 1
                    onSelected: (selected) {
                      setState(() {
                        if (byAlphabets == null) {
                          byAlphabets = 0;
                        } else if (byAlphabets == 0) {
                          byAlphabets = 1;
                        } else {
                          byAlphabets = null;
                        }
                      });
                      products = [];
                      offset = 0;
                      productList();
                    },
                  ),
                  _buildSortChip(
                    label: AppLocalizations.of(context).translate('price'),
                    isSelected: byPrice != null,
                    sortState: byPrice,
                    iconAsc: MdiIcons.arrowUpBold, // 0
                    iconDesc: MdiIcons.arrowDownBold, // 1
                    onSelected: (selected) {
                      setState(() {
                        if (byPrice == null) {
                          byPrice = 0;
                        } else if (byPrice == 0) {
                          byPrice = 1;
                        } else {
                          byPrice = null;
                        }
                      });
                      products = [];
                      offset = 0;
                      productList();
                    },
                  ),
                ],
              ),
            ),
            Divider(),
            Container(
              alignment: Alignment.center,
              child: Center(
                child: Text(
                  AppLocalizations.of(context).translate('filter'),
                  style: AppTheme.getTextStyle(themeData.textTheme.subtitle1,
                      fontWeight: 700, color: themeData.colorScheme.primary),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(
                      left: MySize.size16!,
                      right: MySize.size16!,
                      top: MySize.size8!,
                      bottom: MySize.size8!),
                  child: Wrap(
                    children: [
                      ChoiceChip(
                        label: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              inStock
                                  ? Icons.check_box
                                  : Icons.check_box_outline_blank,
                              color: inStock
                                  ? Colors.white
                                  : themeData.colorScheme.onBackground,
                              size: 20,
                            ),
                            SizedBox(width: 8),
                            Text(
                              AppLocalizations.of(context).translate('in_stock'),
                              style: AppTheme.getTextStyle(
                                themeData.textTheme.bodyText2,
                                color: inStock
                                    ? Colors.white
                                    : themeData.colorScheme.onBackground,
                                fontWeight: inStock ? 600 : 500,
                              ),
                            ),
                          ],
                        ),
                        selected: inStock,
                        selectedColor: themeData.colorScheme.primary,
                        backgroundColor: themeData.backgroundColor,
                        side: BorderSide(
                          color: inStock
                              ? themeData.colorScheme.primary
                              : themeData.colorScheme.onBackground
                              .withOpacity(0.3),
                          width: inStock ? 2.0 : 1.0,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        onSelected: (selected) {
                          setState(() {
                            inStock = !inStock;
                          });
                          products = [];
                          offset = 0;
                          productList();
                        },
                      ),
                    ],
                  ),
                ),
                Divider(),
                // Category Section with Chips
                Container(
                  padding: EdgeInsets.only(
                      left: MySize.size16!,
                      right: MySize.size16!,
                      top: MySize.size16!),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          AppLocalizations.of(context).translate('categories'),
                          style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
                              fontWeight: 600, letterSpacing: 0),
                        ),
                      ),
                      // Icon(
                      //   Icons.arrow_drop_down,
                      //   color: themeData.colorScheme.primary,
                      // ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(
                      left: MySize.size16!,
                      right: MySize.size16!,
                      top: MySize.size8!,
                      bottom: MySize.size8!),
                  child: Wrap(
                    spacing: MySize.size8!,
                    runSpacing: MySize.size8!,
                    children: [
                      // "All Categories" chip
                      _buildCategoryChip(
                        id: 0,
                        name: AppLocalizations.of(context).translate('all') + ' ' +
                            AppLocalizations.of(context).translate('categories'),
                        isSelected: categoryId == 0,
                      ),
                      // Category chips
                      ..._categoriesList.map((category) => _buildCategoryChip(
                        id: category['id'],
                        name: category['name'],
                        isSelected: categoryId == category['id'],
                      )),
                    ],
                  ),
                ),
                Divider(),
                // Subcategory Section with Chips
                Container(
                  padding: EdgeInsets.only(
                      left: MySize.size16!,
                      right: MySize.size16!,
                      top: MySize.size16!),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          AppLocalizations.of(context).translate('sub_categories'),
                          style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
                              fontWeight: 600, letterSpacing: 0),
                        ),
                      ),
                      // Icon(
                      //   Icons.arrow_drop_down,
                      //   color: themeData.colorScheme.primary,
                      // ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(
                      left: MySize.size16!,
                      right: MySize.size16!,
                      top: MySize.size8!,
                      bottom: MySize.size8!),
                  child: Wrap(
                    spacing: MySize.size8!,
                    runSpacing: MySize.size8!,
                    children: [
                      // "All Sub Categories" chip
                      _buildSubCategoryChip(
                        id: 0,
                        name: AppLocalizations.of(context).translate('all') + ' ' +
                            AppLocalizations.of(context).translate('sub_categories'),
                        isSelected: subCategoryId == 0,
                      ),
                      // Subcategory chips - deduplicate by ID to prevent duplicates
                      ..._subCategoriesList
                          .fold<Map<int, Map<String, dynamic>>>(
                        {},
                            (map, subCategory) {
                          if (!map.containsKey(subCategory['id'])) {
                            map[subCategory['id']] = subCategory;
                          }
                          return map;
                        },
                      )
                          .values
                          .map((subCategory) {
                        // Determine color based on selected category
                        Color? categoryColor;
                        if (categoryId != 0) {
                          categoryColor = categoryColors[categoryId % categoryColors.length];
                        } else if (subCategory['parent_id'] != null) {
                          // If "All Categories" is selected, use parent_id to determine color
                          int parentId = subCategory['parent_id'];
                          categoryColor = categoryColors[parentId % categoryColors.length];
                        }

                        return _buildSubCategoryChip(
                          id: subCategory['id'],
                          name: subCategory['name'],
                          isSelected: subCategoryId == subCategory['id'],
                          overrideColor: categoryColor,
                        );
                      }),
                    ],
                  ),
                ),
                Divider(),

                ///We have hid the brand
                // Container(
                //   padding: EdgeInsets.only(
                //       left: MySize.size16!,
                //       right: MySize.size16!,
                //       top: MySize.size16!),
                //   child: Text(
                //     AppLocalizations.of(context).translate('brands'),
                //     style: AppTheme.getTextStyle(themeData.textTheme.bodyText1,
                //         fontWeight: 600, letterSpacing: 0),
                //   ),
                // ),
                // Container(
                //   padding: EdgeInsets.only(
                //       left: MySize.size16!, right: MySize.size16!, top: 0),
                //   child: DropdownButtonHideUnderline(
                //     child: DropdownButton(
                //         isExpanded: true,
                //         dropdownColor: themeData.backgroundColor,
                //         icon: Icon(
                //           Icons.arrow_drop_down,
                //         ),
                //         value: brandId,
                //         items: _brandsMenuItems,
                //         onChanged: (int? newValue) {
                //           setState(() {
                //             brandId = newValue!;
                //           });
                //           products = [];
                //           offset = 0;
                //           productList();
                //         }),
                //   ),
                // ),
                // Divider()
              ],
            ),

            ///We have hid the Group Price
            // Container(
            //   alignment: Alignment.center,
            //   child: Center(
            //     child: Text(
            //       AppLocalizations.of(context).translate('group_prices'),
            //       style: AppTheme.getTextStyle(themeData.textTheme.subtitle1,
            //           fontWeight: 700, color: themeData.colorScheme.primary),
            //     ),
            //   ),
            // ),
            // Container(
            //   padding: EdgeInsets.only(
            //       left: MySize.size16!, right: MySize.size16!, top: 0),
            //   child: DropdownButtonHideUnderline(
            //     child: DropdownButton<bool>(
            //         isExpanded: true,
            //         dropdownColor: themeData.backgroundColor,
            //         icon: Icon(
            //           Icons.arrow_drop_down,
            //         ),
            //         value: usePriceGroup,
            //         items: _priceGroupMenuItems,
            //         onChanged: (bool? newValue) async {
            //           if (newValue != null) {
            //             await _showCartResetDialogForPriceGroup();
            //             setState(() {
            //               usePriceGroup = newValue;
            //               if (changePriceGroup) {
            //                 //Sell().resetCart();
            //                 Sell().resetCartByTable(
            //                     res_table_id, selectedLocationId);
            //                 brandId = 0;
            //                 categoryId = 0;
            //                 searchController.clear();
            //                 inStock = true;
            //                 cartCount = 0;
            //                 products = [];
            //                 offset = 0;
            //                 productList();
            //               }
            //             });
            //           }
            //         }),
            //   ),
            // )
          ],
        ),
      ),
    );
  }

  Widget filter(_scaffoldKey) {
    return Padding(
      padding: EdgeInsets.all(MySize.size16!),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Form(
              key: _formKey,
              child: TextFormField(
                  style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
                      letterSpacing: 0, fontWeight: 500),
                  decoration: InputDecoration(
                    hintText: AppLocalizations.of(context).translate('search'),
                    hintStyle: AppTheme.getTextStyle(
                        themeData.textTheme.subtitle2,
                        letterSpacing: 0,
                        fontWeight: 500),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(MySize.size16!),
                        ),
                        borderSide: BorderSide.none),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(MySize.size16!),
                        ),
                        borderSide: BorderSide.none),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(MySize.size16!),
                        ),
                        borderSide: BorderSide.none),
                    filled: true,
                    fillColor: themeData.colorScheme.background,
                    prefixIcon: IconButton(
                      icon: Icon(
                        MdiIcons.magnify,
                        size: MySize.size22,
                        color:
                        themeData.colorScheme.onBackground.withAlpha(150),
                      ),
                      onPressed: () {},
                    ),
                    isDense: true,
                    contentPadding: EdgeInsets.only(right: MySize.size16!),
                  ),
                  textCapitalization: TextCapitalization.sentences,
                  controller: searchController,
                  onEditingComplete: () {
                    products = [];
                    offset = 0;
                    productList();
                  }),
            ),
          ),
          InkWell(
            onTap: () async {
              var barcode = await Helper().barcodeScan();
              await getScannedProduct(barcode);
            },
            child: Container(
              margin: EdgeInsets.only(left: MySize.size16!),
              decoration: BoxDecoration(
                color: themeData.backgroundColor,
                borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
                boxShadow: [
                  BoxShadow(
                    color: themeData.cardTheme.shadowColor!.withAlpha(48),
                    blurRadius: 3,
                    offset: Offset(0, 1),
                  )
                ],
              ),
              padding: EdgeInsets.all(MySize.size12!),
              child: Icon(
                MdiIcons.barcode,
                color: themeData.colorScheme.primary,
                size: 35,
              ),
            ),
          ),
          InkWell(
            onTap: () {
              _scaffoldKey.currentState!.openEndDrawer();
            },
            child: Container(
              margin: EdgeInsets.only(left: MySize.size16!),
              decoration: BoxDecoration(
                color: themeData.backgroundColor,
                borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
                boxShadow: [
                  BoxShadow(
                    color: themeData.cardTheme.shadowColor!.withAlpha(48),
                    blurRadius: 3,
                    offset: Offset(0, 1),
                  )
                ],
              ),
              padding: EdgeInsets.all(MySize.size12!),
              child: Icon(
                MdiIcons.tune,
                color: themeData.colorScheme.primary,
                size: 35,
              ),
            ),
          ),
          InkWell(
            onTap: () async {
              setState(() {
                gridView = !gridView;
              });
            },
            child: Container(
              margin: EdgeInsets.only(left: MySize.size16!),
              decoration: BoxDecoration(
                color: themeData.backgroundColor,
                borderRadius: BorderRadius.all(Radius.circular(MySize.size16!)),
                boxShadow: [
                  BoxShadow(
                    color: themeData.cardTheme.shadowColor!.withAlpha(48),
                    blurRadius: 3,
                    offset: Offset(0, 1),
                  )
                ],
              ),
              padding: EdgeInsets.all(MySize.size12!),
              child: Icon(
                (gridView) ? MdiIcons.viewList : MdiIcons.viewGrid,
                color: themeData.colorScheme.primary,
                size: 35,
              ),
            ),
          ),
        ],
      ),
    );
  }

  getScannedProduct(String barcode) async {
    if (canMakeSell) {
      await Variations()
          .get(
          locationId: selectedLocationId,
          barcode: barcode,
          offset: 0,
          searchTerm: searchController.text)
          .then((value) async {
        if (canAddSell) {
          if (value.length > 0) {
            var price;
            var product;
            if (value[0]['selling_price_group'] != null) {
              jsonDecode(value[0]['selling_price_group']).forEach((element) {
                if (element['key'] == sellingPriceGroupId) {
                  price = element['value'];
                }
              });
            }
            setState(() {
              product = ProductModel().product(value[0], price);
            });

            bool isOutOfStock = value[0]['enable_stock'] != 0 &&
                (value[0]['stock_available'] == null ||
                    value[0]['stock_available'] <= 0);

            //if (product != null && product['stock_available'] > 0) {
            if (product != null && !isOutOfStock) {
              if (sellId == null) {
                // Only create a draft if user explicitly wants to add a product
                // This prevents auto-creation of incomplete drafts
                debugPrint(
                    'Products: Cannot add product - no active sell session');
                Fluttertoast.showToast(
                  msg: 'Please start a new order first',
                  toastLength: Toast.LENGTH_SHORT,
                );
                return;
              }

              // Check if product is already in cart (especially when coming from sales screen)
              if (sellId != null && sellId != 0) {
                bool isAlreadyInCart = await _isProductInCart(product);
                if (isAlreadyInCart) {
                  ScaffoldMessenger.of(context).hideCurrentSnackBar();

                  Fluttertoast.showToast(
                    msg: AppLocalizations.of(context)
                        .translate('product_already_added'),
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.BOTTOM,
                  );
                  Timer(Duration(milliseconds: 250), () {
                    Fluttertoast.cancel();
                  });
                  return;
                }
              }

              try {
                await Sell().addToCart(product, sellId, res_table_id,
                    is_shipping: is_shipping);

                ScaffoldMessenger.of(context).hideCurrentSnackBar();

                Fluttertoast.showToast(
                  msg: AppLocalizations.of(context).translate('added_to_cart'),
                );
                Timer(Duration(milliseconds: 250), () {
                  Fluttertoast.cancel();
                });
                if (argument != null) {
                  selectedLocationId = argument!['locationId'];
                }
              } catch (e) {
                ScaffoldMessenger.of(context).hideCurrentSnackBar();

                if (e.toString().contains('product_already_added')) {
                  // Message already shown by Sell().addToCart()
                  Timer(Duration(milliseconds: 250), () {
                    Fluttertoast.cancel();
                  });
                }
              }
            } else {
              Fluttertoast.showToast(
                  msg:
                  "${AppLocalizations.of(context).translate("out_of_stock")}");
            }
          } else {
            Fluttertoast.showToast(
                msg:
                "${AppLocalizations.of(context).translate("no_product_found")}");
          }
        } else {
          Fluttertoast.showToast(
              msg:
              "${AppLocalizations.of(context).translate("no_sells_permission")}");
        }
      });
    } else {
      Fluttertoast.showToast(
          msg: AppLocalizations.of(context).translate('no_subscription_found'));
    }
  }

  // Widget _productsList() {
  //   return (products.length == 0)
  //       ? Center(
  //           child: Column(
  //             mainAxisAlignment: MainAxisAlignment.center,
  //             children: [
  //               Icon(Icons.hourglass_empty),
  //               Text(AppLocalizations.of(context)
  //                   .translate('no_products_found')),
  //             ],
  //           ),
  //         )
  //       : Container(
  //           child: (gridView)
  //               ? GridView.builder(
  //                   padding: EdgeInsets.only(
  //                       bottom: MySize.size16!,
  //                       left: MySize.size16!,
  //                       right: MySize.size16!),
  //                   shrinkWrap: true,
  //                   physics: ClampingScrollPhysics(),
  //                   itemCount: products.length,
  //                   gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
  //                     crossAxisCount: 2,
  //                     mainAxisSpacing: MySize.size16!,
  //                     crossAxisSpacing: MySize.size16!,
  //                     childAspectRatio:
  //                         findAspectRatio(MediaQuery.of(context).size.width),
  //                   ),
  //                   // itemBuilder: (context, index) {
  //                   itemBuilder: (context, index) {
  //                     bool isOutOfStock =
  //                         products[index]['enable_stock'] != 0 &&
  //                             products[index]['stock_available'] <= 0;
  //                     return InkWell(
  //                       // onTap: () async {
  //                       onTap: isOutOfStock
  //                           ? null
  //                           : () async {
  //                               onTapProduct(index);
  //                             },
  //                       // Opacity added
  //                       child: Opacity(
  //                         opacity: isOutOfStock ? 0.6 : 1.0,
  //                         child: _ProductGridWidget(
  //                           name: products[index]['display_name'],
  //                           image: products[index]['product_image_url'],
  //                           qtyAvailable: (products[index]['enable_stock'] != 0)
  //                               ? products[index]['stock_available'].toString()
  //                               : '-',
  //                           price: double.parse(
  //                               products[index]['unit_price'].toString()),
  //                           symbol: symbol,
  //                           isOutOfStock: isOutOfStock,
  //                         ),
  //                       ),
  //                     );
  //                   },
  //                 )
  //               : ListView.builder(
  //                   shrinkWrap: true,
  //                   physics: ClampingScrollPhysics(),
  //                   itemCount: products.length,
  //                   itemBuilder: (context, index) {
  //                     return InkWell(
  //                       onTap: () async {
  //                         onTapProduct(index);
  //                       },
  //                       child: _ProductListWidget(
  //                         name: products[index]['display_name'],
  //                         image: products[index]['product_image_url'],
  //                         qtyAvailable: (products[index]['enable_stock'] != 0)
  //                             ? products[index]['stock_available'].toString()
  //                             : '-',
  //                         price: double.parse(
  //                             products[index]['unit_price'].toString()),
  //                         symbol: symbol,
  //                       ),
  //                     );
  //                   },
  //                 ),
  //         );
  // }

  // Helper method to check if device is tablet/desktop in landscape orientation
  // A 20-inch tablet would be >= 900px wide in landscape, so we check both tablet and desktop
  bool _isLargeScreenLandscape(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    final width = MediaQuery.of(context).size.width;
    // Check if it's landscape AND has width >= 600px (tablet or desktop size)
    return orientation == Orientation.landscape && width >= 600;
  }

  // Get cross axis count for grid based on device type and orientation
  int _getCrossAxisCountForGrid(BuildContext context) {
    if (_isLargeScreenLandscape(context)) {
      // For large screens in landscape (tablets and desktops), show more products
      final width = MediaQuery.of(context).size.width;
      if (width >= 1200) {
        return 8; // Very large screens get 8 columns
      } else if (width >= 900) {
        return 6; // Large tablets get 6 columns
      } else {
        return 5; // Smaller tablets in landscape get 5 columns
      }
    }
    return ResponsiveHelper.getCrossAxisCount(
      context,
      mobileCount: 2,
      tabletCount: 3,
      desktopCount: 4,
    );
  }

  // Get main axis spacing for grid
  double _getMainAxisSpacingForGrid(BuildContext context) {
    if (_isLargeScreenLandscape(context)) {
      return MySize.size12!; // Reduced spacing for landscape large screens
    }
    return ResponsiveHelper.getResponsiveSpacing(
      context,
      mobileSpacing: MySize.size20!,
      tabletSpacing: MySize.size24!,
      desktopSpacing: MySize.size28!,
    );
  }

  // Get cross axis spacing for grid
  double _getCrossAxisSpacingForGrid(BuildContext context) {
    if (_isLargeScreenLandscape(context)) {
      return MySize.size12!; // Reduced spacing for landscape large screens
    }
    return ResponsiveHelper.getResponsiveSpacing(
      context,
      mobileSpacing: MySize.size20!,
      tabletSpacing: MySize.size24!,
      desktopSpacing: MySize.size28!,
    );
  }

  // Get child aspect ratio for grid
  double _getChildAspectRatioForGrid(BuildContext context) {
    if (_isLargeScreenLandscape(context)) {
      final width = MediaQuery.of(context).size.width;
      if (width >= 1200) {
        return 0.55; // Smaller aspect ratio for very large screens to show more products
      } else {
        return 0.6; // Smaller aspect ratio for large tablets in landscape
      }
    }
    return ResponsiveHelper.isTablet(context) ? 0.75 : 0.7;
  }

  Widget _productsList() {
    // Show loading dialog when loading
    if (isLoading && !_isLoadingDialogShown) {
      _isLoadingDialogShown = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && isLoading) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) {
              return Center(
                child: AlertDialog(
                  content: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(width: 20),
                      Text(
                        AppLocalizations.of(context).translate('loading'),
                        style: TextStyle(color: Colors.black),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }
      });
      return SizedBox.shrink(); // Return empty widget while loading
    }

    // Dismiss loading dialog when not loading
    if (!isLoading && _isLoadingDialogShown) {
      _isLoadingDialogShown = false;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
      });
    }

    // Show "No Product Data" when no data and not loading
    if (products.length == 0 && !isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.hourglass_empty),
            Text('No Product Data'),
          ],
        ),
      );
    }

    // Show products list when data exists
    return Container(
      child: (gridView)
          ? GridView.builder(
        padding: ResponsiveHelper.getResponsivePadding(
          context,
          mobilePadding: MySize.size16!,
          tabletPadding: MySize.size20!,
          desktopPadding: MySize.size24!,
        ),
        shrinkWrap: true,
        physics: ClampingScrollPhysics(),
        itemCount: products.length,
        gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: _getCrossAxisCountForGrid(context),
          mainAxisSpacing: _getMainAxisSpacingForGrid(context),
          crossAxisSpacing: _getCrossAxisSpacingForGrid(context),
          childAspectRatio: _getChildAspectRatioForGrid(context),
        ),
        itemBuilder: (context, index) {
          // bool isOutOfStock =
          //     products[index]['enable_stock'] != 0 &&
          //         products[index]['stock_available'] <= 0;
          bool isOutOfStock =
              products[index]['enable_stock'] != 0 &&
                  products[index]['stock_available'] <= 0;
          //return InkWell(
          //onTap: () => onTapProduct(index),
          // onTap: isOutOfStock
          //     ? null
          //     : () async {
          //         onTapProduct(index);
          //       },
          //child: _ProductGridWidget(
          return _ProductGridWidget(
            name: products[index]['display_name'],
            image: products[index]['product_image_url'],
            qtyAvailable: (products[index]['enable_stock'] != 0)
                ? products[index]['stock_available'].toString()
                : '-',
            price: double.parse(
                products[index]['unit_price'].toString()),
            symbol: symbol,
            isOutOfStock: isOutOfStock,
            onTap: () => onTapProduct(index),
          );
          //);
        },
      )
          : ListView.builder(
        shrinkWrap: true,
        physics: ClampingScrollPhysics(),
        itemCount: products.length,
        itemBuilder: (context, index) {
          // bool isOutOfStock =
          //     products[index]['enable_stock'] != 0 &&
          //         products[index]['stock_available'] <= 0;
          bool isOutOfStock =
              products[index]['enable_stock'] != 0 &&
                  products[index]['stock_available'] <= 0;
          // return InkWell(
          //   onTap: () => onTapProduct(index),
          // onTap: isOutOfStock
          //     ? null
          //     : () async {
          //         onTapProduct(index);
          //       },
          // child: _ProductListWidget(
          return _ProductListWidget(
            name: products[index]['display_name'],
            image: products[index]['product_image_url'],
            qtyAvailable: (products[index]['enable_stock'] != 0)
                ? products[index]['stock_available'].toString()
                : '-',
            price: double.parse(
                products[index]['unit_price'].toString()),
            symbol: symbol,
            isOutOfStock: isOutOfStock,
            onTap: () => onTapProduct(index),
          );
          // );
        },
      ),
    );
  }

  onTapProduct(int index) async {
    SellDatabase().previosSellRowDelete();

    // Check if product is out of stock
    bool isOutOfStock = products[index]['enable_stock'] != 0 &&
        products[index]['stock_available'] <= 0;

    if (isOutOfStock) {
      Fluttertoast.showToast(
        msg: AppLocalizations.of(context).translate('out_of_stock'),
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
      return;
    }

    // Check if product is already in cart (especially when coming from sales screen)
    if (sellId != null && sellId != 0) {
      bool isAlreadyInCart = await _isProductInCart(products[index]);
      if (isAlreadyInCart) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();

        Fluttertoast.showToast(
          msg: AppLocalizations.of(context).translate('product_already_added'),
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
        Timer(Duration(milliseconds: 250), () {
          Fluttertoast.cancel();
        });
        return;
      }
    }

    // Original logic for in-stock products
    if (canAddSell) {
      if (canMakeSell) {
        // DEFERRED ORDER CREATION: Create order only when user adds first product
        if (sellId == null) {
          debugPrint(
              'Products: sellId is null, checking deferred creation conditions');
          debugPrint(
              'Products: argument[deferredOrderCreation] = ${argument?['deferredOrderCreation']}');
          debugPrint('Products: res_table_id = $res_table_id');
          debugPrint('Products: selectedLocationId = $selectedLocationId');

          // Check if this is a deferred creation scenario
          if (argument?['deferredOrderCreation'] == true &&
              res_table_id != null) {
            try {
              debugPrint(
                  'Products: Creating deferred order for table $res_table_id');

              FirebaseFirestore.instance.collection("Table").doc("${res_table_id}").set(
                  {
                    "Status":1
                  });
              sellId = await Sell().createSellDraft(
                locId: selectedLocationId,
                discountType: '',
                res_table_id: res_table_id,
                is_shipping: is_shipping ?? 0,
              );

              if (sellId != null) {
                // Update cart data
                final cartKey = res_table_id.toString();
                AppConstants.cartData[cartKey] = sellId;
                await ShareInt().setMap(jsonEncode(AppConstants.cartData));

                debugPrint(
                    'Products: Created deferred order $sellId for table $res_table_id');
              }
            } catch (e) {
              debugPrint('Products: Error creating deferred order: $e');
              Fluttertoast.showToast(
                msg: AppLocalizations.of(context)
                    .translate('error_creating_sale'),
              );
              return;
            }
          } else {
            // Only create a draft if user explicitly wants to add a product
            // This prevents auto-creation of incomplete drafts
            debugPrint('Products: Cannot add product - no active sell session');
            Fluttertoast.showToast(
              msg: 'please_start_new_order_first',
              toastLength: Toast.LENGTH_SHORT,
            );
            return;
          }
        }

        try {
          await Sell().addToCart(products[index], sellId, res_table_id,
              is_shipping: is_shipping);

          // Lock table in Firebase when first product is added (only for table orders, not shipping)
          final locationId = argument?['locationId'] as int? ?? selectedLocationId;
          final tableId = res_table_id;
          if (tableId != null && tableId > 0 && (is_shipping == null || is_shipping == 0) && locationId != null && locationId > 0) {
            try {
              final lockSuccess = await FirebaseTableLockService().lockTable(
                tableId: tableId,
                locationId: locationId,
                tableName: argument?['tableName'] as String?,
              );
              if (lockSuccess) {
                debugPrint('Products: Locked table $tableId in Firebase after adding product');
              } else {
                debugPrint('Products: Failed to lock table $tableId in Firebase (may be locked by another user)');
              }
            } catch (e) {
              debugPrint('Products: Error locking table in Firebase: $e');
            }
          }

          ScaffoldMessenger.of(context).hideCurrentSnackBar();

          Fluttertoast.showToast(
              msg: AppLocalizations.of(context).translate('added_to_cart'));
          Timer(Duration(milliseconds: 250), () {
            Fluttertoast.cancel();
          });
          if (argument != null) {
            selectedLocationId = argument!['locationId'];
          }
        } catch (e) {
          if (e.toString().contains('product_already_added')) {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();

            Fluttertoast.showToast(
              msg: AppLocalizations.of(context)
                  .translate('product_already_added'),
            );
            Timer(Duration(milliseconds: 250), () {
              Fluttertoast.cancel();
            });
          }
        }
      } else {
        Fluttertoast.showToast(
            msg:
            "${AppLocalizations.of(context).translate("no_sells_permission")}");
      }
    } else {
      Fluttertoast.showToast(
          msg: AppLocalizations.of(context).translate('no_subscription_found'));
    }
  }

  setLocationMap() async {
    await System().get('location').then((value) async {
      value.forEach((element) {
        if (element['is_active'].toString() == '1') {
          setState(() {
            locationListMap.add({
              'id': element['id'],
              'name': element['name'],
              'selling_price_group_id': element['selling_price_group_id']
            });
          });
        }
      });
      await priceGroupList();
    });
  }

  setDefaultLocation(defaultLocation) {
    if (defaultLocation != 0) {
      setState(() {
        selectedLocationId = defaultLocation;
      });
    } else if (locationListMap.length == 2) {
      setState(() {
        selectedLocationId = locationListMap[1]['id'] as int;
      });
    }
  }

  Widget locations() {
    return DropdownButtonHideUnderline(
      child: DropdownButton(
          dropdownColor: themeData.backgroundColor,
          icon: Icon(
            Icons.arrow_drop_down,
          ),
          value: selectedLocationId,
          items: locationListMap.map<DropdownMenuItem<int>>((Map value) {
            return DropdownMenuItem<int>(
                value: value['id'],
                child: SizedBox(
                  width: MySize.screenWidth! * 0.4,
                  child: Text('${value['name']}',
                      softWrap: true,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                      style: TextStyle(fontSize: 15)),
                ));
          }).toList(),
          onTap: () {
            if (locationListMap.length <= 2) {
              canChangeLocation = false;
            }
          },
          onChanged: (int? newValue) async {
            if (canChangeLocation) {
              if (selectedLocationId == newValue) {
                changeLocation = false;
              } else if (selectedLocationId != 0) {
                await _showCartResetDialogForLocation();
                await priceGroupList();
              } else {
                changeLocation = true;
                await priceGroupList();
              }
              setState(() {
                if (changeLocation) {
                  //Sell().resetCart();
                  Sell().resetCartByTable(res_table_id, newValue);
                  selectedLocationId = newValue!;
                  brandId = 0;
                  categoryId = 0;
                  searchController.clear();
                  inStock = false;
                  cartCount = 0;
                  products = [];
                  offset = 0;
                  productList();
                }
              });
            } else {
              Fluttertoast.showToast(
                  msg: AppLocalizations.of(context)
                      .translate('cannot_change_location'));
            }
          }),
    );
  }

  Future<void> _showCartResetDialogForLocation() async {
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title:
          Text(AppLocalizations.of(context).translate('change_location')),
          content: Text(AppLocalizations.of(context)
              .translate('all_items_in_cart_will_be_remove')),
          actions: [
            TextButton(
                onPressed: () {
                  changeLocation = false;
                  Navigator.of(context).pop();
                },
                child: Text(AppLocalizations.of(context).translate('no'))),
            TextButton(
                onPressed: () {
                  changeLocation = true;
                  Navigator.of(context).pop();
                },
                child: Text(AppLocalizations.of(context).translate('yes')))
          ],
        );
      },
    );
  }

  Future<void> _showCartResetDialogForPriceGroup() async {
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(AppLocalizations.of(context)
              .translate('change_selling_price_group')),
          content: Text(AppLocalizations.of(context)
              .translate('all_items_in_cart_will_be_remove')),
          actions: [
            TextButton(
                onPressed: () {
                  changePriceGroup = false;
                  Navigator.of(context).pop();
                },
                child: Text(AppLocalizations.of(context).translate('no'))),
            TextButton(
                onPressed: () {
                  changePriceGroup = true;
                  Navigator.of(context).pop();
                },
                child: Text(AppLocalizations.of(context).translate('yes')))
          ],
        );
      },
    );
  }
}

class _ProductGridWidget extends StatefulWidget {
  final String? name, image, symbol;
  final String? qtyAvailable;
  final double? price;
  final bool isOutOfStock;
  final VoidCallback onTap;

  const _ProductGridWidget({
    Key? key,
    @required this.name,
    @required this.image,
    @required this.qtyAvailable,
    @required this.price,
    @required this.symbol,
    this.isOutOfStock = false,
    required this.onTap,
  }) : super(key: key);

  @override
  _ProductGridWidgetState createState() => _ProductGridWidgetState();
}

class _ProductGridWidgetState extends State<_ProductGridWidget> {
  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);

  // @override
  // Widget build(BuildContext context) {
  //   String key = Generator.randomString(10);
  //   themeData = Theme.of(context);
  //   return Container(
  //     decoration: BoxDecoration(
  //       color: themeData.cardTheme.color,
  //       borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
  //       boxShadow: [
  //         BoxShadow(
  //           color: themeData.cardTheme.shadowColor!.withAlpha(12),
  //           blurRadius: 4,
  //           spreadRadius: 2,
  //           offset: Offset(0, 2),
  //         ),
  //       ],
  //     ),
  //     padding: EdgeInsets.all(MySize.size2!),
  //     child: Stack(
  //       children: [
  //         Column(
  //           mainAxisSize: MainAxisSize.min,
  //           mainAxisAlignment: MainAxisAlignment.spaceAround,
  //           children: <Widget>[
  //             Stack(
  //               children: <Widget>[
  //                 Hero(
  //                   tag: key,
  //                   child: ClipRRect(
  //                     borderRadius: BorderRadius.only(
  //                         topLeft: Radius.circular(MySize.size8!),
  //                         topRight: Radius.circular(MySize.size8!)),
  //                     child: CachedNetworkImage(
  //                         width: MediaQuery.of(context).size.width,
  //                         height: MySize.size140,
  //                         fit: BoxFit.fitHeight,
  //                         errorWidget: (context, url, error) =>
  //                             Image.asset('assets/images/default_product.png'),
  //                         placeholder: (context, url) =>
  //                             Image.asset('assets/images/default_product.png'),
  //                         imageUrl: widget.image ?? ''),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //             Container(
  //               width: MediaQuery.of(context).size.width,
  //               padding:
  //                   EdgeInsets.only(left: MySize.size2!, right: MySize.size2!),
  //               child: Column(
  //                 mainAxisSize: MainAxisSize.min,
  //                 crossAxisAlignment: CrossAxisAlignment.start,
  //                 children: <Widget>[
  //                   Text(widget.name!,
  //                       overflow: TextOverflow.ellipsis,
  //                       style: AppTheme.getTextStyle(
  //                           themeData.textTheme.subtitle2,
  //                           fontWeight: 500,
  //                           letterSpacing: 0)),
  //                   Container(
  //                     margin: EdgeInsets.only(top: MySize.size4!),
  //                     child: Row(
  //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                       children: <Widget>[
  //                         Text(
  //                           widget.symbol! +
  //                               Helper().formatCurrency(widget.price),
  //                           style: AppTheme.getTextStyle(
  //                               themeData.textTheme.bodyText2,
  //                               fontWeight: 700,
  //                               letterSpacing: 0),
  //                         ),
  //                         Container(
  //                           decoration: BoxDecoration(
  //                               //color: themeData.colorScheme.primary,
  //                               color: widget.isOutOfStock
  //                                   ? Colors.grey
  //                                   : themeData.colorScheme.primary,
  //                               borderRadius: BorderRadius.all(
  //                                   Radius.circular(MySize.size4!))),
  //                           padding: EdgeInsets.only(
  //                               left: MySize.size6!,
  //                               right: MySize.size8!,
  //                               top: MySize.size2!,
  //                               bottom: MySize.getScaledSizeHeight(3.5)),
  //                           child: Row(
  //                             children: <Widget>[
  //                               Icon(
  //                                 MdiIcons.stocking,
  //                                 color: themeData.colorScheme.onPrimary,
  //                                 size: MySize.size12,
  //                               ),
  //                               Container(
  //                                 margin: EdgeInsets.only(left: MySize.size4!),
  //                                 child: (widget.qtyAvailable != '-')
  //                                     ? Text(
  //                                         Helper().formatQuantity(
  //                                             widget.qtyAvailable),
  //                                         style: AppTheme.getTextStyle(
  //                                             themeData.textTheme.caption,
  //                                             fontSize: 11,
  //                                             color: themeData
  //                                                 .colorScheme.onPrimary,
  //                                             fontWeight: 600))
  //                                     : Text('-'),
  //                               ),
  //                             ],
  //                           ),
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                 ],
  //               ),
  //             ),
  //           ],
  //         ),
  //         if (widget.isOutOfStock)
  //           Positioned.fill(
  //             child: Container(
  //               decoration: BoxDecoration(
  //                 color: Colors.black54,
  //                 borderRadius:
  //                     BorderRadius.all(Radius.circular(MySize.size8!)),
  //               ),
  //               child: Center(
  //                 child: Text(
  //                   AppLocalizations.of(context).translate('out_of_stock'),
  //                   style: TextStyle(
  //                     color: Colors.white,
  //                     fontWeight: FontWeight.bold,
  //                     fontSize: 16,
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           ),
  //       ],
  //     ),
  //   );
  // }
  @override
  Widget build(BuildContext context) {
    String key = Generator.randomString(10);
    themeData = Theme.of(context);
    return InkWell(
        onTap: widget.isOutOfStock ? null : widget.onTap,
        child: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.all(Radius.circular(MySize.size12!)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 8,
                    spreadRadius: 0,
                    offset: Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 16,
                    spreadRadius: 0,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  // Product Image with enhanced styling
                  Expanded(
                    flex: 3,
                    child: Stack(
                      children: <Widget>[
                        Hero(
                          tag: key,
                          child: ClipRRect(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(MySize.size12!),
                                topRight: Radius.circular(MySize.size12!)),
                            child: CachedNetworkImage(
                                width: double.infinity,
                                height: double.infinity,
                                fit: BoxFit.cover,
                                errorWidget: (context, url, error) => Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [
                                        Colors.grey[100]!,
                                        Colors.grey[200]!,
                                      ],
                                    ),
                                  ),
                                  child: Center(
                                    child: Icon(
                                      Icons.image_not_supported,
                                      color: Colors.grey[400],
                                      size: 40,
                                    ),
                                  ),
                                ),
                                placeholder: (context, url) => Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [
                                        Colors.grey[100]!,
                                        Colors.grey[200]!,
                                      ],
                                    ),
                                  ),
                                  child: Center(
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor:
                                      AlwaysStoppedAnimation<Color>(
                                        themeData.colorScheme.primary,
                                      ),
                                    ),
                                  ),
                                ),
                                imageUrl: widget.image ?? ''),
                          ),
                        ),
                        // Stock indicator badge
                        Positioned(
                          top: MySize.size8!,
                          right: MySize.size8!,
                          child: Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: MySize.size8!,
                              vertical: MySize.size4!,
                            ),
                            decoration: BoxDecoration(
                              color: widget.isOutOfStock
                                  ? Colors.red.withOpacity(0.9)
                                  : Colors.green.withOpacity(0.9),
                              borderRadius:
                              BorderRadius.circular(MySize.size12!),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 4,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  widget.isOutOfStock
                                      ? MdiIcons.packageVariantClosed
                                      : MdiIcons.stocking,
                                  color: Colors.white,
                                  size: MySize.size12,
                                ),
                                SizedBox(width: MySize.size4!),
                                Text(
                                  widget.isOutOfStock
                                      ? AppLocalizations.of(context)
                                      .translate('out_of_stock')
                                      : (widget.qtyAvailable != '-'
                                      ? Helper().formatQuantity(
                                      widget.qtyAvailable)
                                      : '∞'),
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Product Details
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: EdgeInsets.all(MySize.size12!),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Product Name
                          Text(
                            widget.name!,
                            style: AppTheme.getTextStyle(
                              themeData.textTheme.subtitle1,
                              fontWeight: 600,
                              letterSpacing: 0.2,
                              color: Colors.grey[800],
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          // Price and Add Button Row
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              // Price
                              Text(
                                widget.symbol! +
                                    Helper().formatCurrency(widget.price),
                                style: AppTheme.getTextStyle(
                                  themeData.textTheme.subtitle1,
                                  fontWeight: 700,
                                  letterSpacing: 0,
                                  color: themeData.colorScheme.primary,
                                ),
                              ),
                              // Add to Cart Button
                              Container(
                                decoration: BoxDecoration(
                                  gradient: widget.isOutOfStock
                                      ? LinearGradient(
                                    colors: [
                                      Colors.grey[400]!,
                                      Colors.grey[500]!
                                    ],
                                  )
                                      : LinearGradient(
                                    colors: [
                                      themeData.colorScheme.primary,
                                      themeData.colorScheme.primary
                                          .withOpacity(0.8),
                                    ],
                                  ),
                                  borderRadius:
                                  BorderRadius.circular(MySize.size20!),
                                  boxShadow: widget.isOutOfStock
                                      ? null
                                      : [
                                    BoxShadow(
                                      color: themeData.colorScheme.primary
                                          .withOpacity(0.3),
                                      blurRadius: 8,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    onTap: widget.isOutOfStock
                                        ? null
                                        : widget.onTap,
                                    borderRadius:
                                    BorderRadius.circular(MySize.size20!),
                                    child: Container(
                                      padding: EdgeInsets.symmetric(
                                        horizontal: MySize.size12!,
                                        vertical: MySize.size8!,
                                      ),
                                      child: Icon(
                                        Icons.add,
                                        color: Colors.white,
                                        size: MySize.size16,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Enhanced out of stock overlay
            if (widget.isOutOfStock)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.red.withOpacity(0.15),
                        Colors.red.withOpacity(0.25),
                      ],
                    ),
                    borderRadius:
                    BorderRadius.all(Radius.circular(MySize.size12!)),
                    border: Border.all(
                      color: Colors.red.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  // child: Center(
                  //   child: Container(
                  //     padding: EdgeInsets.symmetric(
                  //       horizontal: MySize.size16!,
                  //       vertical: MySize.size12!,
                  //     ),
                  //     decoration: BoxDecoration(
                  //       color: Colors.red.withOpacity(0.95),
                  //       borderRadius: BorderRadius.circular(MySize.size16!),
                  //       boxShadow: [
                  //         BoxShadow(
                  //           color: Colors.red.withOpacity(0.4),
                  //           blurRadius: 12,
                  //           spreadRadius: 2,
                  //           offset: Offset(0, 4),
                  //         ),
                  //       ],
                  //     ),
                  // child: Column(
                  //   mainAxisSize: MainAxisSize.min,
                  //   children: [
                  //     Container(
                  //       padding: EdgeInsets.all(MySize.size8!),
                  //       decoration: BoxDecoration(
                  //         color: Colors.white.withOpacity(0.2),
                  //         borderRadius: BorderRadius.circular(MySize.size20!),
                  //       ),
                  //       child: Icon(
                  //         MdiIcons.packageVariantClosed,
                  //         color: Colors.white,
                  //         size: MySize.size20,
                  //       ),
                  //     ),
                  //     SizedBox(height: MySize.size8!),
                  //     Text(
                  //       AppLocalizations.of(context)
                  //           .translate('out_of_stock'),
                  //       style: TextStyle(
                  //         color: Colors.white,
                  //         fontWeight: FontWeight.w700,
                  //         fontSize: 12,
                  //         letterSpacing: 0.5,
                  //       ),
                  //       textAlign: TextAlign.center,
                  //     ),
                  //   ],
                  // ),
                  //   ),
                  // ),
                ),
              ),
            // Make whole item non-clickable if out of stock
            if (widget.isOutOfStock)
              Positioned.fill(
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () {
                      Fluttertoast.showToast(
                        msg: AppLocalizations.of(context)
                            .translate('out_of_stock'),
                        backgroundColor: Colors.red,
                        textColor: Colors.white,
                      );
                    },
                  ),
                ),
              ),
          ],
        ));
  }
}

class _ProductListWidget extends StatefulWidget {
  final String? name, image, symbol;
  final String? qtyAvailable;
  final double? price;
  final VoidCallback onTap;
  final bool isOutOfStock;

  const _ProductListWidget({
    Key? key,
    @required this.name,
    @required this.image,
    @required this.qtyAvailable,
    @required this.price,
    @required this.symbol,
    required this.onTap,
    this.isOutOfStock = false,
  }) : super(key: key);

  @override
  _ProductListWidgetState createState() => _ProductListWidgetState();
}

class _ProductListWidgetState extends State<_ProductListWidget> {
  static int themeType = 1;
  ThemeData themeData = AppTheme.getThemeFromThemeMode(themeType);

  @override
  Widget build(BuildContext context) {
    themeData = Theme.of(context);
    return InkWell(
        onTap: widget.isOutOfStock ? null : widget.onTap,
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: MySize.size16!,
            vertical: MySize.size8!,
          ),
          child: Stack(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                  BorderRadius.all(Radius.circular(MySize.size16!)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.08),
                      blurRadius: 8,
                      spreadRadius: 0,
                      offset: Offset(0, 4),
                    ),
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 16,
                      spreadRadius: 0,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(MySize.size16!),
                  child: Row(
                    children: [
                      // Product Image with enhanced styling
                      Container(
                        width: MySize.size100!,
                        height: MySize.size100!,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(MySize.size16!),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 8,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(MySize.size16!),
                          child: CachedNetworkImage(
                            width: double.infinity,
                            height: double.infinity,
                            fit: BoxFit.cover,
                            errorWidget: (context, url, error) => Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Colors.grey[100]!,
                                    Colors.grey[200]!,
                                  ],
                                ),
                              ),
                              child: Center(
                                child: Icon(
                                  Icons.image_not_supported,
                                  color: Colors.grey[400],
                                  size: 32,
                                ),
                              ),
                            ),
                            placeholder: (context, url) => Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Colors.grey[100]!,
                                    Colors.grey[200]!,
                                  ],
                                ),
                              ),
                              child: Center(
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    themeData.colorScheme.primary,
                                  ),
                                ),
                              ),
                            ),
                            imageUrl: widget.image ?? '',
                          ),
                        ),
                      ),
                      SizedBox(width: MySize.size16!),
                      // Product Details
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Product Name
                            Text(
                              widget.name!,
                              style: AppTheme.getTextStyle(
                                themeData.textTheme.subtitle1,
                                fontWeight: 600,
                                letterSpacing: 0.2,
                                color: Colors.grey[800],
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            SizedBox(height: MySize.size8!),
                            // Price
                            Text(
                              widget.symbol! +
                                  Helper().formatCurrency(widget.price),
                              style: AppTheme.getTextStyle(
                                themeData.textTheme.subtitle1,
                                fontWeight: 700,
                                letterSpacing: 0,
                                color: themeData.colorScheme.primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Stock Badge and Add Button Column
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Stock indicator badge
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: MySize.size8!,
                              vertical: MySize.size4!,
                            ),
                            decoration: BoxDecoration(
                              color: widget.isOutOfStock
                                  ? Colors.red.withOpacity(0.9)
                                  : Colors.green.withOpacity(0.9),
                              borderRadius:
                              BorderRadius.circular(MySize.size12!),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 4,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  widget.isOutOfStock
                                      ? MdiIcons.packageVariantClosed
                                      : MdiIcons.stocking,
                                  color: Colors.white,
                                  size: MySize.size12,
                                ),
                                SizedBox(width: MySize.size4!),
                                Text(
                                  widget.isOutOfStock
                                      ? AppLocalizations.of(context)
                                      .translate('out_of_stock')
                                      : (widget.qtyAvailable != '-'
                                      ? Helper().formatQuantity(
                                      widget.qtyAvailable)
                                      : '∞'),
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: MySize.size8!),
                          // Add to Cart Button
                          Container(
                            decoration: BoxDecoration(
                              gradient: widget.isOutOfStock
                                  ? LinearGradient(
                                colors: [
                                  Colors.grey[400]!,
                                  Colors.grey[500]!
                                ],
                              )
                                  : LinearGradient(
                                colors: [
                                  themeData.colorScheme.primary,
                                  themeData.colorScheme.primary
                                      .withOpacity(0.8),
                                ],
                              ),
                              borderRadius:
                              BorderRadius.circular(MySize.size20!),
                              boxShadow: widget.isOutOfStock
                                  ? null
                                  : [
                                BoxShadow(
                                  color: themeData.colorScheme.primary
                                      .withOpacity(0.3),
                                  blurRadius: 8,
                                  offset: Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap:
                                widget.isOutOfStock ? null : widget.onTap,
                                borderRadius:
                                BorderRadius.circular(MySize.size20!),
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: MySize.size16!,
                                    vertical: MySize.size12!,
                                  ),
                                  child: Icon(
                                    Icons.add,
                                    color: Colors.white,
                                    size: MySize.size20,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              // Enhanced out of stock overlay for ListView
              if (widget.isOutOfStock)
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.red.withOpacity(0.15),
                          Colors.red.withOpacity(0.25),
                        ],
                      ),
                      borderRadius:
                      BorderRadius.all(Radius.circular(MySize.size16!)),
                      border: Border.all(
                        color: Colors.red.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ));
  }
}
// child: Center(
//   child: Container(
//     padding: EdgeInsets.symmetric(
//       horizontal: MySize.size16!,
//       vertical: MySize.size12!,
//     ),
//     decoration: BoxDecoration(
//       color: Colors.red.withOpacity(0.95),
//       borderRadius: BorderRadius.circular(MySize.size16!),
//       boxShadow: [
//         BoxShadow(
//           color: Colors.red.withOpacity(0.4),
//           blurRadius: 12,
//           spreadRadius: 2,
//           offset: Offset(0, 4),
//         ),
//       ],
//     ),
// child: Column(
//   mainAxisSize: MainAxisSize.min,
//   children: [
//     Container(
//       padding: EdgeInsets.all(MySize.size8!),
//       decoration: BoxDecoration(
//         color: Colors.white.withOpacity(0.2),
//         borderRadius: BorderRadius.circular(MySize.size20!),
//       ),
//       child: Icon(
//         MdiIcons.packageVariantClosed,
//         color: Colors.white,
//         size: MySize.size20,
//       ),
//     ),
//     SizedBox(height: MySize.size8!),
//     Text(
//       AppLocalizations.of(context)
//           .translate('out_of_stock'),
//       style: TextStyle(
//         color: Colors.white,
//         fontWeight: FontWeight.w700,
//         fontSize: 12,
//         letterSpacing: 0.5,
//       ),
//       textAlign: TextAlign.center,
//     ),
//   ],
// ),
//   ),
// ),
// @override
// Widget build(BuildContext context) {
//   themeData = Theme.of(context);
//   return Padding(
//     padding: const EdgeInsets.only(left: 8.0, right: 8, top: 8),
//     child: Container(
//       decoration: BoxDecoration(
//         color: themeData.cardTheme.color,
//         borderRadius: BorderRadius.all(Radius.circular(MySize.size8!)),
//         boxShadow: [
//           BoxShadow(
//             color: themeData.cardTheme.shadowColor!.withAlpha(12),
//             blurRadius: 4,
//             spreadRadius: 2,
//             offset: Offset(0, 2),
//           ),
//         ],
//       ),
//       padding: EdgeInsets.all(MySize.size8!),
//       child: ListTile(
//         leading: ClipRRect(
//           borderRadius: BorderRadius.circular(MySize.size30!),
//           child: CachedNetworkImage(
//               errorWidget: (context, url, error) =>
//                   Image.asset('assets/images/default_product.png'),
//               placeholder: (context, url) =>
//                   Image.asset('assets/images/default_product.png'),
//               imageUrl: widget.image ?? ''),
//         ),
//         title: Text(widget.name!,
//             style: AppTheme.getTextStyle(themeData.textTheme.subtitle2,
//                 fontWeight: 500, letterSpacing: 0)),
//         trailing: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceAround,
//           children: <Widget>[
//             Text(
//               widget.symbol! + Helper().formatCurrency(widget.price),
//               style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
//                   fontWeight: 700, letterSpacing: 0),
//             ),
//             Container(
//               width: MySize.size80,
//               decoration: BoxDecoration(
//                   // color: themeData.colorScheme.primary,
//                   color: widget.isOutOfStock
//                       ? Colors.red
//                       : themeData.colorScheme.primary,
//                   borderRadius:
//                       BorderRadius.all(Radius.circular(MySize.size4!))),
//               padding: EdgeInsets.only(
//                   left: MySize.size6!,
//                   right: MySize.size8!,
//                   top: MySize.size2!,
//                   bottom: MySize.getScaledSizeHeight(3.5)),
//               child: Row(
//                 children: <Widget>[
//                   Icon(
//                     MdiIcons.stocking,
//                     color: themeData.colorScheme.onPrimary,
//                     size: MySize.size12,
//                   ),
//                   Container(
//                     margin: EdgeInsets.only(left: MySize.size4!),
//                     child: (widget.qtyAvailable != '-')
//                         ? Text(Helper().formatQuantity(widget.qtyAvailable),
//                             style: AppTheme.getTextStyle(
//                                 themeData.textTheme.caption,
//                                 fontSize: 11,
//                                 color: themeData.colorScheme.onPrimary,
//                                 fontWeight: 600))
//                         : Text('-', style: TextStyle(color: Colors.white)),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     ),
//   );
// }
