// import 'dart:async';
// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import '../apis/api.dart';
// import '../apis/system.dart';
// import '../apis/user.dart';
// import '../config.dart';
// import '../helpers/AppTheme.dart';
// import '../helpers/SizeConfig.dart';
// import '../helpers/otherHelpers.dart';
// import '../locale/MyLocalizations.dart';
// import '../models/contact_model.dart';
// import '../models/database.dart';
// import '../models/sellDatabase.dart';
// import '../models/system.dart';
// import '../models/variations.dart';
//
//
//
// // ignore: non_constant_identifier_names
// int? USERID;
//
// class Login extends StatefulWidget {
//   const Login({super.key});
//
//   @override
//   _LoginState createState() => _LoginState();
// }
//
// class _LoginState extends State<Login> {
//   static int themeType = 1;
//   late ThemeData themeData;
//   final _formKey = GlobalKey<FormState>();
//   final usernameController = TextEditingController();
//   final passwordController = TextEditingController();
//   bool isLoading = false;
//   bool _passwordVisible = false;
//
//   @override
//   void initState() {
//     super.initState();
//     themeData = AppTheme.getThemeFromThemeMode(themeType);
//   }
//
//   @override
//   void dispose() {
//     usernameController.dispose();
//     passwordController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     themeData = Theme.of(context);
//     return Scaffold(
//       body: SafeArea(
//         child: ListView(
//           padding: const EdgeInsets.all(0),
//           children: <Widget>[
//             SizedBox(
//               height: MediaQuery.of(context).size.height * 3 / 10,
//               child: Stack(
//                 fit: StackFit.expand,
//                 children: <Widget>[
//                   FittedBox(
//                     fit: BoxFit.fill,
//                     child: CachedNetworkImage(
//                       imageUrl: Config().loginScreen,
//                       placeholder: (context, url) => Transform.scale(
//                         scale: 0.07,
//                         child: const CircularProgressIndicator(),
//                       ),
//                       errorWidget: (context, url, error) =>
//                           Image.asset('assets/images/login.jpg'),
//                     ),
//                   ),
//                   Align(
//                     alignment: Alignment.center,
//                     child: Stack(
//                       children: <Widget>[
//                         Text(
//                           AppLocalizations.of(context).translate('login'),
//                           style: TextStyle(
//                             fontSize: 40,
//                             foreground: Paint()
//                               ..style = PaintingStyle.stroke
//                               ..strokeWidth = 4
//                               ..color = Colors.blue,
//                           ),
//                         ),
//                         Text(
//                           AppLocalizations.of(context).translate('login'),
//                           style: const TextStyle(
//                             fontSize: 40,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Form(
//               key: _formKey,
//               child: Container(
//                 margin: EdgeInsets.only(
//                   left: MySize.size16!,
//                   right: MySize.size16!,
//                   top: MySize.size16!,
//                 ),
//                 child: Card(
//                   elevation: 8,
//                   child: Padding(
//                     padding: EdgeInsets.only(
//                       top: MySize.size12!,
//                       left: MySize.size16!,
//                       right: MySize.size16!,
//                       bottom: MySize.size12!,
//                     ),
//                     child: Column(
//                       children: <Widget>[
//                         TextFormField(
//                           style: AppTheme.getTextStyle(
//                             themeData.textTheme.bodyMedium,
//                             letterSpacing: 0.1,
//                             color: themeData.colorScheme.onBackground,
//                             fontWeight: 500,
//                           ),
//                           decoration: InputDecoration(
//                             hintText:
//                             AppLocalizations.of(context).translate('username'),
//                             hintStyle: AppTheme.getTextStyle(
//                               themeData.textTheme.titleMedium,
//                               letterSpacing: 0.1,
//                               color: themeData.colorScheme.onBackground,
//                               fontWeight: 500,
//                             ),
//                             prefixIcon: const Icon(Icons.lock_outline),
//                           ),
//                           controller: usernameController,
//                           validator: (value) {
//                             if (value == null || value.isEmpty) {
//                               return AppLocalizations.of(context)
//                                   .translate('please_enter_username');
//                             }
//                             return null;
//                           },
//                           autofocus: true,
//                         ),
//                         Container(
//                           margin: EdgeInsets.only(top: MySize.size16!),
//                           child: TextFormField(
//                             keyboardType: TextInputType.visiblePassword,
//                             style: AppTheme.getTextStyle(
//                               themeData.textTheme.bodyMedium,
//                               letterSpacing: 0.1,
//                               color: themeData.colorScheme.onBackground,
//                               fontWeight: 500,
//                             ),
//                             decoration: InputDecoration(
//                               hintText: AppLocalizations.of(context)
//                                   .translate('password'),
//                               hintStyle: AppTheme.getTextStyle(
//                                 themeData.textTheme.titleMedium,
//                                 letterSpacing: 0.1,
//                                 color: themeData.colorScheme.onBackground,
//                                 fontWeight: 500,
//                               ),
//                               prefixIcon: const Icon(Icons.lock_outline),
//                               suffixIcon: IconButton(
//                                 icon: Icon(
//                                   _passwordVisible
//                                       ? MdiIcons.eyeOutline
//                                       : MdiIcons.eyeOffOutline,
//                                 ),
//                                 onPressed: () {
//                                   setState(() {
//                                     _passwordVisible = !_passwordVisible;
//                                   });
//                                 },
//                               ),
//                             ),
//                             obscureText: !_passwordVisible,
//                             controller: passwordController,
//                             validator: (value) {
//                               if (value == null || value.isEmpty) {
//                                 return AppLocalizations.of(context)
//                                     .translate('please_enter_password');
//                               }
//                               return null;
//                             },
//                           ),
//                         ),
//                         Container(
//                           margin: EdgeInsets.only(top: MySize.size16!),
//                           decoration: BoxDecoration(
//                             borderRadius:
//                             BorderRadius.all(Radius.circular(MySize.size24!)),
//                             boxShadow: [
//                               BoxShadow(
//                                 color: themeData.colorScheme.primary,
//                                 blurRadius: 3,
//                                 offset: const Offset(0, 1),
//                               ),
//                             ],
//                           ),
//                           child: TextButton(
//                             style: TextButton.styleFrom(
//                               padding: EdgeInsets.only(
//                                 left: MySize.size64!,
//                                 right: MySize.size64!,
//                                 top: MySize.size10!,
//                                 bottom: MySize.size10!,
//                               ),
//                               shape: RoundedRectangleBorder(
//                                 borderRadius:
//                                 BorderRadius.circular(MySize.size24!),
//                               ),
//                               backgroundColor: themeData.colorScheme.primary,
//                             ),
//                             child: Text(
//                               isLoading
//                                   ? AppLocalizations.of(context).translate('loading')
//                                   : AppLocalizations.of(context).translate('login'),
//                               style: AppTheme.getTextStyle(
//                                 themeData.textTheme.labelLarge,
//                                 fontWeight: 600,
//                                 color: themeData.colorScheme.onPrimary,
//                                 letterSpacing: 0.5,
//                               ),
//                             ),
//                             onPressed: () async {
//                               if (!isLoading &&
//                                   _formKey.currentState!.validate() &&
//                                   await Helper().checkConnectivity()) {
//                                 setState(() {
//                                   isLoading = true;
//                                 });
//
//                                 try {
//                                   final loginResponse = await Api().login(
//                                     usernameController.text,
//                                     passwordController.text,
//                                   );
//
//                                   if (loginResponse == null ||
//                                       !loginResponse.containsKey('success')) {
//                                     throw Exception('Invalid API response');
//                                   }
//
//                                   if (loginResponse['success']) {
//                                     String accessToken = loginResponse['access_token'];
//                                     String refreshToken = loginResponse['refresh_token'] ?? '';
//                                     print('Access Token: $accessToken');
//                                     print('Refresh Token: $refreshToken');
//
//                                     Helper().jobScheduler();
//                                     await showLoadingDialogue();
//                                     await loadAllData(loginResponse);
//                                   } else {
//                                     final errorMsg = loginResponse['message'] ??
//                                         AppLocalizations.of(context)
//                                             .translate('invalid_credentials');
//
//                                     // Log error with line number
//                                     final stackTrace = StackTrace.current;
//                                     final lineNumber = _getLineNumber(stackTrace);
//                                     print(
//                                         'Login Error: $errorMsg at line $lineNumber');
//                                     Fluttertoast.showToast(msg: errorMsg);
//                                   }
//                                 } catch (e, stackTrace) {
//                                   final lineNumber = _getLineNumber(stackTrace);
//                                   print(
//                                       'Login Error: ${e.toString()} at line $lineNumber');
//                                   Fluttertoast.showToast(
//                                     msg: AppLocalizations.of(context)
//                                         .translate('login_failed') +
//                                         ': ${e.toString()}',
//                                   );
//                                 } finally {
//                                   if (mounted) {
//                                     setState(() {
//                                       isLoading = false;
//                                     });
//                                   }
//                                 }
//                               } else if (!await Helper().checkConnectivity()) {
//                                 final stackTrace = StackTrace.current;
//                                 final lineNumber = _getLineNumber(stackTrace);
//                                 print(
//                                     'Login Error: No internet connection at line $lineNumber');
//                                 Fluttertoast.showToast(
//                                   msg: AppLocalizations.of(context)
//                                       .translate('no_internet_connection'),
//                                 );
//                               }
//                             },
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // Helper method to extract line number from stack trace
//   int? _getLineNumber(StackTrace stackTrace) {
//     final lines = stackTrace.toString().split('\n');
//     if (lines.isNotEmpty) {
//       final firstLine = lines[0];
//       final match = RegExp(r'#\d+\s+.*:(\d+):').firstMatch(firstLine);
//       return match != null ? int.tryParse(match.group(1)!) : null;
//     }
//     return null;
//   }
//
//   Future<void> loadAllData(Map loginResponse) async {
//     try {
//       // Show loading toast once
//       Fluttertoast.showToast(
//         msg: AppLocalizations.of(context)
//             .translate('It_may_take_some_more_time_to_load'),
//       );
//
//       final prefs = await SharedPreferences.getInstance();
//       final loggedInUser =
//       await User().get(loginResponse['access_token'] as String);
//
//       if (loggedInUser['id'] == null) {
//         throw Exception('Invalid user data');
//       }
//
//       USERID = loggedInUser['id'] as int;
//       Config.userId = USERID;
//       await prefs.setInt('userId', USERID!);
//       await DbProvider().initializeDatabase(loggedInUser['id']);
//
//       final lastSync = await System().getProductLastSync();
//       final dateNow = DateTime.now();
//
//       await System().empty();
//       await Contact().emptyContact();
//       await System().insertUserDetails(loggedInUser);
//       await System().insertToken(loginResponse['access_token'] as String);
//       await SystemApi().store();
//       await System().insertProductLastSyncDateTimeNow();
//
//       if (prefs.getInt('prevUserId') == null ||
//           prefs.getInt('prevUserId') != prefs.getInt('userId')) {
//         await SellDatabase().deleteSellTables();
//         await Variations().refresh();
//       } else if (lastSync == null ||
//           dateNow.difference(DateTime.parse(lastSync)).inHours > 10) {
//         if (await Helper().checkConnectivity()) {
//           await Variations().refresh();
//           await System().insertProductLastSyncDateTimeNow();
//           await SellDatabase().deleteSellTables();
//         }
//       }
//
//       // Navigate to home and close loading dialog
//       if (mounted) {
//         Navigator.of(context).pushReplacementNamed('/Home');
//       }
//     } catch (e, stackTrace) {
//       final lineNumber = _getLineNumber(stackTrace);
//       print('Data Load Error: ${e.toString()} at line $lineNumber');
//       if (mounted) {
//         Fluttertoast.showToast(
//           msg: AppLocalizations.of(context).translate('data_load_failed') +
//               ': ${e.toString()}',
//         );
//       }
//     } finally {
//       if (mounted) {
//         Navigator.of(context).pop(); // Close loading dialog
//       }
//     }
//   }
//
//   Future<void> showLoadingDialogue() async {
//     return showDialog<void>(
//       context: context,
//       barrierDismissible: false,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           content: Row(
//             children: [
//               const CircularProgressIndicator(),
//               Container(
//                 margin: const EdgeInsets.only(left: 5),
//                 child: Text(
//                   AppLocalizations.of(context).translate('loading_data'),
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
// }