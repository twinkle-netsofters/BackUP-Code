class AppConstants {
  static const String app_name = 'Kavaai';
  static const String androidPackageName = 'com.kavaai.onlineshop';
  static const String iosPackageName = 'com.kavaai.onlineshop';
  static const String baseUrl = 'https://kavaai.com/app/v1/api/';
  static const String chatBaseUrl = 'https://kavaai.com/app/v1/Chat_Api/';
  static const String shareNavigationWebUrl = 'kavaai.com';
  static const String defaultLanguage = 'en';
}
