// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:eshop_multivendor/Helper/Constant.dart';
import 'package:eshop_multivendor/Helper/routes.dart';
import 'package:eshop_multivendor/Model/personalChatHistory.dart';
import 'package:eshop_multivendor/Provider/SettingProvider.dart';
import 'package:eshop_multivendor/Provider/UserProvider.dart';
import 'package:eshop_multivendor/Screen/Dashboard/Dashboard.dart';
import 'package:eshop_multivendor/cubits/personalConverstationsCubit.dart';
import 'package:eshop_multivendor/repository/NotificationRepository.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:eshop_multivendor/Model/message.dart' as msg;

import '../../Helper/String.dart';
import '../../Provider/chatProvider.dart';
import '../../Provider/pushNotificationProvider.dart';
import '../../main.dart';

FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();
FirebaseMessaging messaging = FirebaseMessaging.instance;

class PushNotificationService {
  late BuildContext context;

  PushNotificationService({required this.context});

  Future<void> initialise() async {
    permission();
    FirebaseMessaging.onBackgroundMessage(myBackgroundMessageHandler);
    initLocalNotifications();
    initFirebaseMessaging();
    setDeviceToken();
  }

  void permission() async {
    await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );
    // await messaging.setForegroundNotificationPresentationOptions(
    //   alert: true,
    //   badge: true,
    //   sound: true,
    // );
  }

  void initLocalNotifications() {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('notification');
    const DarwinInitializationSettings initializationSettingsIOS =
        DarwinInitializationSettings();
    const DarwinInitializationSettings initializationSettingsMacOS =
        DarwinInitializationSettings();
    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
      macOS: initializationSettingsMacOS,
    );

    flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse:
          (NotificationResponse notificationResponse) async {
        if (notificationResponse.payload != null) {
          List<String> pay = notificationResponse.payload!.split(',');

          //If the type is chat
          if (pay[0] == 'chat') {
            String payload = notificationResponse.payload ?? '';
            payload = payload.replaceFirst('${pay[0]},', '');

            if (converstationScreenStateKey.currentState?.mounted ?? false) {
              Navigator.of(context).pop();
            }
            final message = msg.Message.fromJson(jsonDecode(payload));

            Routes.navigateToConverstationScreen(
                context: context,
                isGroup: false,
                personalChatHistory: PersonalChatHistory(
                    unreadMsg: '1',
                    opponentUserId: message.fromId,
                    opponentUsername: message.sendersName,
                    image: message.picture));
          } else {
            handleNotificationPayload(pay);
          }
        } else {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          Navigator.push(
            context,
            CupertinoPageRoute(
              builder: (context) => MyApp(sharedPreferences: prefs),
            ),
          );
        }
      },
    );
  }

  void _onTapChatNotification({required RemoteMessage message}) {
    if ((converstationScreenStateKey.currentState?.mounted) ?? false) {
      Navigator.of(context).pop();
    }

    final messages = jsonDecode(message.data['message']) as List;

    if (messages.isEmpty) {
      return;
    }

    final messageDetails =
        msg.Message.fromJson(jsonDecode(json.encode(messages.first)));

    Routes.navigateToConverstationScreen(
        context: context,
        isGroup: false,
        personalChatHistory: PersonalChatHistory(
            unreadMsg: '1',
            opponentUserId: messageDetails.fromId,
            opponentUsername: messageDetails.sendersName,
            image: messageDetails.picture));
  }

  void initFirebaseMessaging() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      handleIncomingMessage(message);
    });

    FirebaseMessaging.onBackgroundMessage(myBackgroundMessageHandler);

    messaging.getInitialMessage().then((RemoteMessage? message) async {
      if ((message?.data['type'] ?? '') == 'chat') {
        _onTapChatNotification(message: message!);
      } else {
        bool back = await Provider.of<SettingProvider>(context, listen: false)
            .getPrefrenceBool(ISFROMBACK);
        if (message != null) {
          if (back) {
            handleNotificationPayload([
              message.data['type'] ?? '',
              message.data['type_id'] ?? '',
              message.data['link'] ?? ''
            ]);
            Provider.of<SettingProvider>(context, listen: false)
                .setPrefrenceBool(ISFROMBACK, false);
          }
        }
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
      if ((message.data['type'] ?? '') == 'chat') {
        _onTapChatNotification(message: message);
      } else {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        handleNotificationPayload([
          message.data['type'] ?? '',
          message.data['type_id'] ?? '',
          message.data['link']
        ]);
        Provider.of<SettingProvider>(context, listen: false)
            .setPrefrenceBool(ISFROMBACK, false);
      }
    });
  }

  void setDeviceToken(
      {bool clearSessionToken = false, SettingProvider? settingProvider}) {
    if (clearSessionToken) {
      settingProvider ??= Provider.of<SettingProvider>(context, listen: false);
      settingProvider.setPrefrence(FCMTOKEN, '');
    }
    messaging.getToken().then((token) async {
      context.read<PushNotificationProvider>().registerToken(token, context);
    });
  }

  Future<void> handleNotificationPayload(List<String> payload) async {
    String type = payload[0];
    String id = payload[1];
    String urlLink = payload[2];

    switch (type) {
      case 'products':
        context
            .read<PushNotificationProvider>()
            .getProduct(id, 0, 0, true, context);
        break;
      case 'categories':
        if (Dashboard.dashboardScreenKey.currentState != null) {
          Dashboard.dashboardScreenKey.currentState!.changeTabPosition(1);
        }
        break;
      case 'wallet':
        Routes.navigateToMyWalletScreen(context);
        break;
      case 'cart':
        Routes.navigateToCartScreen(context, false);
        break;
      case 'order':
      case 'place_order':
        Routes.navigateToMyOrderScreen(context);
        break;
      case 'ticket_message':
        Routes.navigateToChatScreen(context, id, '');
        break;
      case 'ticket_status':
        Routes.navigateToCustomerSupportScreen(context);
        break;
      case 'notification_url':
        try {
          if (await canLaunchUrl(Uri.parse(urlLink))) {
            await launchUrl(Uri.parse(urlLink),
                mode: LaunchMode.externalApplication);
          } else {
            throw 'Could not launch $urlLink';
          }
        } catch (e) {
          throw 'Something went wrong';
        }
        break;
      default:
        Routes.navigateToSplashScreen(context);
    }
  }

  // void handleIncomingMessage(RemoteMessage message) {
  //   UserProvider userProvider =
  //       Provider.of<UserProvider>(context, listen: false);
  //
  //   var data = message.notification!;
  //   var title = data.title?.toString() ?? '';
  //   var body = data.body?.toString() ?? '';
  //   var image = message.data['image'] ?? '';
  //   var type = message.data['type'] ?? '';
  //   var id = message.data['type_id'] ?? '';
  //   var urlLink = message.data['link'] ?? '';
  //
  //   if (type == 'chat') {
  //     /*
  //             [{"id":"267","from_id":"2","to_id":"8","is_read":"1","message":"Geralt of rivia","type":"person","media":"","date_created":"2023-07-19 13:15:26","picture":"dikshita","senders_name":"dikshita","position":"right","media_files":"","text":"Geralt of rivia"}]
  //         */
  //
  //     final messages = jsonDecode(message.data['message']) as List;
  //
  //     String payload = '';
  //     if (messages.isNotEmpty) {
  //       payload = jsonEncode(messages.first);
  //     }
  //
  //     if (converstationScreenStateKey.currentState?.mounted ?? false) {
  //       final state = converstationScreenStateKey.currentState!;
  //       if (state.widget.isGroup) {
  //         if (messages.isNotEmpty) {
  //           if (state.widget.groupDetails?.groupId != messages.first['to_id']) {
  //             // context
  //             //     .read<GroupConverstationsCubit>()
  //             //     .markNewMessageArrivedInGroup(
  //             //         groupId: messages.first['to_id'].toString());
  //             // generateChatLocalNotification(
  //             //     title: title, body: body, payload: payload);
  //           } else {
  //             state.addMessage(
  //                 message: msg.Message.fromJson(Map.from(messages.first)));
  //           }
  //         }
  //       } else {
  //         if (messages.isNotEmpty) {
  //           //
  //           if (state.widget.personalChatHistory?.getOtherUserId() !=
  //               messages.first['from_id']) {
  //             generateChatLocalNotification(
  //                 title: title, body: body, payload: payload);
  //
  //             context
  //                 .read<PersonalConverstationsCubit>()
  //                 .updateUnreadMessageCounter(
  //                   userId: messages.first['from_id'].toString(),
  //                 );
  //           } else {
  //             state.addMessage(
  //                 message: msg.Message.fromJson(Map.from(messages.first)));
  //           }
  //         }
  //       }
  //     } else {
  //       //senders_name
  //       generateChatLocalNotification(
  //           title: title, body: body, payload: payload);
  //
  //       //Update the unread message counter
  //       if (messages.isNotEmpty) {
  //         if (messages.first['type'] == 'person') {
  //           context
  //               .read<PersonalConverstationsCubit>()
  //               .updateUnreadMessageCounter(
  //                 userId: messages.first['from_id'].toString(),
  //               );
  //         } else {}
  //       }
  //     }
  //   } else if (type == 'ticket_status') {
  //     generateSimpleNotification(title, body, type, id, urlLink);
  //     // Routes.navigateToCustomerSupportScreen(context);
  //   } else if (type == 'ticket_message') {
  //     generateSimpleNotification(title, body, type, id, urlLink);
  //     if (CUR_TICK_ID == id &&
  //         context.read<ChatProvider>().chatstreamdata != null) {
  //       var parsedJson = json.decode(message.data['chat']);
  //       parsedJson = parsedJson[0];
  //       Map<String, dynamic> sendata = {
  //         'id': parsedJson[ID],
  //         'title': parsedJson[TITLE],
  //         'message': parsedJson[MESSAGE],
  //         'user_id': parsedJson[USER_ID],
  //         'name': parsedJson[NAME],
  //         'date_created': parsedJson[DATE_CREATED],
  //         'attachments': parsedJson['attachments']
  //       };
  //       var chat = {'data': sendata};
  //       if (parsedJson[USER_ID] != userProvider.userId) {
  //         context
  //             .read<ChatProvider>()
  //             .chatstreamdata!
  //             .sink
  //             .add(jsonEncode(chat));
  //       }
  //     }
  //   } else if (image != null && image != 'null' && image != '') {
  //     generateImageNotification(title, body, image, type, id, urlLink);
  //   } else {
  //     generateSimpleNotification(title, body, type, id, urlLink);
  //   }
  // }
  Future<void> handleIncomingMessage(RemoteMessage message) async {
    UserProvider userProvider =
    Provider.of<UserProvider>(context, listen: false);

    // var data = message.notification;
    // var title = data?.title?.toString() ?? '';
    // var body = data?.body?.toString() ?? '';
    // var image = message.data['image'] ?? '';
    // var type = message.data['type'] ?? '';
    // var id = message.data['type_id'] ?? '';
    // var urlLink = message.data['link'] ?? '';
    // var popup = message.data['popup'] ?? '0';
    // Debug: Print raw message data
    debugPrint('📦 Raw message.data: ${message.data}');
    debugPrint(
        '📦 message.notification?.title: ${message.notification?.title}');
    debugPrint('📦 message.notification?.body: ${message.notification?.body}');

    var image = message.data['image'] ?? '';
    var type =
        message.data['type'] ?? message.notification?.android?.channelId ?? '';
    var id = message.data['type_id'] ?? '';
    var urlLink = message.data['link'] ?? '';
    var popup = message.data['popup']?.toString() ?? '0';

    // For free_cash_added popup, prioritize message.notification over message.data
    String title;
    String body;

    if (type == 'free_cash_added' && popup == '1') {
      // For popup, use notification title/body first, fallback to data
      title = (message.notification?.title ?? '').isNotEmpty
          ? message.notification!.title!
          : ((message.data['title']?.toString() ?? '').isNotEmpty
              ? message.data['title'].toString()
              : 'Notification');

      body = (message.notification?.body ?? '').isNotEmpty
          ? message.notification!.body!
          : ((message.data['body']?.toString() ?? '').isNotEmpty
              ? message.data['body'].toString()
              : 'No message');
    } else {
      // For other notifications, use data first, fallback to notification
      title = (message.data['title']?.toString() ?? '').isNotEmpty
          ? message.data['title'].toString()
          : (message.notification?.title ?? '');

      body = (message.data['body']?.toString() ?? '').isNotEmpty
          ? message.data['body'].toString()
          : (message.notification?.body ?? '');
    }

    debugPrint(
        '📩 Received push => type: $type | popup: $popup | body: "$body" | title: "$title"');

    if (type == 'free_cash_added' && popup == '1') {
      debugPrint('🔔 Showing free cash popup => title: "$title" | body: "$body"');
      
      // Get notification ID from message data (try both 'notification_id' and 'id')
      var notificationId = (message.data['notification_id']?.toString() ?? 
                            message.data['id']?.toString() ?? '').trim();
      
      // Get user ID
      final userId = Provider.of<UserProvider>(context, listen: false).userId ?? '';
      
      // If notification_id is missing, try to fetch it from API
      if (userId.isNotEmpty && notificationId.isEmpty) {
        debugPrint('📡 Notification ID missing in push, fetching from API...');
        try {
          // Wait a bit to ensure backend has processed the notification
          await Future.delayed(const Duration(milliseconds: 500));
          final notifications = await fetchFreeCashNotifications(userId);
          if (notifications.isNotEmpty) {
            // Try to match by amount and expiry_date from push notification
            final pushAmount = message.data['amount']?.toString() ?? '';
            final pushExpiryDate = message.data['expiry_date']?.toString() ?? '';
            
            Map<String, dynamic> matchedNotification;
            if (pushAmount.isNotEmpty || pushExpiryDate.isNotEmpty) {
              // Try to find matching notification
              try {
                matchedNotification = notifications.firstWhere(
                  (notif) {
                    final notifAmount = notif['amount']?.toString() ?? '';
                    final notifExpiryDate = notif['expiry_date']?.toString() ?? '';
                    return (pushAmount.isEmpty || notifAmount == pushAmount) &&
                           (pushExpiryDate.isEmpty || notifExpiryDate == pushExpiryDate);
                  },
                );
              } catch (e) {
                // If no match found, use first unread notification
                matchedNotification = notifications.first;
              }
            } else {
              // If no matching fields, use first unread notification (should be the latest one)
              matchedNotification = notifications.first;
            }
            
            notificationId = (matchedNotification['id']?.toString() ?? 
                             matchedNotification['notification_id']?.toString() ?? '').trim();
            debugPrint('✅ Found notification ID from API: $notificationId');
          }
        } catch (e) {
          debugPrint('❌ Error fetching notification ID: $e');
        }
      }
      
      // If we have both notification_id and userId, use callback version to mark as read
      if (userId.isNotEmpty && notificationId.isNotEmpty) {
        debugPrint('📝 Using callback version with notificationId: $notificationId, userId: $userId');
        _showZeptoPopupWithCallback(
          title: title,
          messageBody: body,
          notificationId: notificationId,
          userId: userId,
        );
      } else {
        // Fallback to simple popup if no ID/userId
        debugPrint('⚠️ Missing notificationId or userId, using simple popup');
        _showZeptoPopup(title: title, messageBody: body);
      }
      return;
    }
    if (type == 'chat') {
      final messages = jsonDecode(message.data['message']) as List;
      String payload = '';
      if (messages.isNotEmpty) {
        payload = jsonEncode(messages.first);
      }

      if (converstationScreenStateKey.currentState?.mounted ?? false) {
        final state = converstationScreenStateKey.currentState!;
        if (state.widget.isGroup) {
          if (messages.isNotEmpty) {
            if (state.widget.groupDetails?.groupId != messages.first['to_id']) {
              // generateChatLocalNotification(title: title, body: body, payload: payload);
            } else {
              state.addMessage(
                  message: msg.Message.fromJson(Map.from(messages.first)));
            }
          }
        } else {
          if (messages.isNotEmpty) {
            if (state.widget.personalChatHistory?.getOtherUserId() !=
                messages.first['from_id']) {
              generateChatLocalNotification(
                  title: title, body: body, payload: payload);
              context
                  .read<PersonalConverstationsCubit>()
                  .updateUnreadMessageCounter(
                userId: messages.first['from_id'].toString(),
              );
            } else {
              state.addMessage(
                  message: msg.Message.fromJson(Map.from(messages.first)));
            }
          }
        }
      } else {
        generateChatLocalNotification(
            title: title, body: body, payload: payload);
        if (messages.isNotEmpty) {
          if (messages.first['type'] == 'person') {
            context
                .read<PersonalConverstationsCubit>()
                .updateUnreadMessageCounter(
              userId: messages.first['from_id'].toString(),
            );
          }
        }
      }
    } else if (type == 'ticket_status') {
      generateSimpleNotification(title, body, type, id, urlLink);
    } else if (type == 'ticket_message') {
      generateSimpleNotification(title, body, type, id, urlLink);
      if (CUR_TICK_ID == id &&
          context.read<ChatProvider>().chatstreamdata != null) {
        var parsedJson = json.decode(message.data['chat']);
        parsedJson = parsedJson[0];
        Map<String, dynamic> sendata = {
          'id': parsedJson[ID],
          'title': parsedJson[TITLE],
          'message': parsedJson[MESSAGE],
          'user_id': parsedJson[USER_ID],
          'name': parsedJson[NAME],
          'date_created': parsedJson[DATE_CREATED],
          'attachments': parsedJson['attachments']
        };
        var chat = {'data': sendata};
        if (parsedJson[USER_ID] != userProvider.userId) {
          context
              .read<ChatProvider>()
              .chatstreamdata!
              .sink
              .add(jsonEncode(chat));
        }
      }
    } else if (image != null && image != 'null' && image != '') {
      generateImageNotification(title, body, image, type, id, urlLink);
    } else {
      generateSimpleNotification(title, body, type, id, urlLink);
    }
  }

  Future<void> generateImageNotification(String title, String msg, String image,
      String type, String id, String url) async {
    var largeIconPath = await _downloadAndSaveImage(image, 'largeIcon');
    var bigPicturePath = await _downloadAndSaveImage(image, 'bigPicture');
    var bigPictureStyleInformation = BigPictureStyleInformation(
      FilePathAndroidBitmap(bigPicturePath),
      hideExpandedLargeIcon: true,
      contentTitle: title,
      htmlFormatContentTitle: true,
      summaryText: msg,
      htmlFormatSummaryText: true,
    );
    var androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'big text channel id',
      'big text channel name',
      channelDescription: 'big text channel description',
      largeIcon: FilePathAndroidBitmap(largeIconPath),
      styleInformation: bigPictureStyleInformation,
      playSound: true,
    );
    var iosDetail = const DarwinNotificationDetails();
    var platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iosDetail,
    );

    await flutterLocalNotificationsPlugin.show(
      0,
      title,
      msg,
      platformChannelSpecifics,
      payload: '$type,$id,$url',
    );
  }

  Future<void> generateSimpleNotification(
      String title, String msg, String type, String id, String url) async {
    var androidPlatformChannelSpecifics = const AndroidNotificationDetails(
      'your channel id',
      'your channel name',
      channelDescription: 'your channel description',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
      playSound: true,
    );
    var iosDetail = const DarwinNotificationDetails();
    var platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iosDetail,
    );
    await flutterLocalNotificationsPlugin.show(
      0,
      title,
      msg,
      platformChannelSpecifics,
      payload: '$type,$id,$url',
    );
  }

  void generateChatLocalNotification(
      {required String title,
      required String body,
      required String payload}) async {
    var androidPlatformChannelSpecifics = const AndroidNotificationDetails(
      'your channel id',
      'your channel name',
      channelDescription: 'your channel description',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
      playSound: true,
    );
    var iosDetail = const DarwinNotificationDetails();
    var platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iosDetail,
    );
    await flutterLocalNotificationsPlugin.show(
      0,
      title,
      body,
      platformChannelSpecifics,
      payload: 'chat,$payload',
    );
  }

  Future<String> _downloadAndSaveImage(String url, String fileName) async {
    var directory = await getApplicationDocumentsDirectory();
    var filePath = '${directory.path}/$fileName';
    var response = await http.get(Uri.parse(url));
    var file = File(filePath);
    await file.writeAsBytes(response.bodyBytes);
    return filePath;
  }

  /// Fetch unread free cash notifications from API
  Future<List<Map<String, dynamic>>> fetchFreeCashNotifications(String userId) async {
    try {
      final parameter = {
        USER_ID: userId,
      };

      debugPrint('📡 Fetching free cash notifications for user: $userId');
      final response = await apiBaseHelper.postAPICall(
        manageFreeCashNotificationsApi,
        parameter,
      );

      if (response != null && response['error'] == false) {
        // Handle different response structures
        dynamic data = response['data'];
        
        // If data is a list, use it directly
        List<dynamic> notificationsList = [];
        if (data is List) {
          notificationsList = data;
        } else if (data is Map && data['notifications'] != null) {
          notificationsList = data['notifications'] is List 
              ? data['notifications'] 
              : [];
        } else if (data != null) {
          // Try to extract as list
          notificationsList = [data];
        }
        
        final notifications = notificationsList
            .map((item) => Map<String, dynamic>.from(item ?? {}))
            .toList();
        
        // Filter only unread notifications
        final unreadNotifications = notifications
            .where((notification) => 
                (notification['notification_read']?.toString() ?? '0') == '0')
            .toList();
        
        debugPrint('📬 Found ${unreadNotifications.length} unread notifications out of ${notifications.length} total');
        return unreadNotifications;
      }
      
      debugPrint('📭 No notifications found or API error');
      return [];
    } catch (e) {
      debugPrint('❌ Error fetching free cash notifications: $e');
      return [];
    }
  }

  /// Mark notification as read
  Future<bool> markNotificationAsRead({
    required String userId,
    required String notificationId,
  }) async {
    try {
      final parameter = {
        USER_ID: userId,
        'notification_id': notificationId,
        'notification_read': '1',
      };

      debugPrint('✅ Marking notification as read: notificationId=$notificationId, userId=$userId');
      final response = await apiBaseHelper.postAPICall(
        manageFreeCashNotificationsApi,
        parameter,
      );

      if (response['error'] == false) {
        debugPrint('✅ Successfully marked notification as read');
        return true;
      }
      
      debugPrint('❌ Failed to mark notification as read: ${response['message']}');
      return false;
    } catch (e) {
      debugPrint('❌ Error marking notification as read: $e');
      return false;
    }
  }

  /// Show free cash notifications sequentially
  Future<void> showFreeCashNotificationsSequentially(String userId) async {
    try {
      final notifications = await fetchFreeCashNotifications(userId);
      
      if (notifications.isEmpty) {
        debugPrint('📭 No unread notifications to show');
        return;
      }

      debugPrint('📬 Showing ${notifications.length} notification(s) sequentially');
      
      // Show notifications one by one
      for (int i = 0; i < notifications.length; i++) {
        final notification = notifications[i];
        final title = notification['title']?.toString() ?? 'Notification';
        final body = notification['body']?.toString() ?? 'No message';
        // Try both 'id' and 'notification_id' fields
        final notificationId = (notification['id']?.toString() ?? 
                                notification['notification_id']?.toString() ?? '').trim();
        
        if (notificationId.isEmpty) {
          debugPrint('⚠️ Skipping notification ${i + 1}: missing ID');
          continue;
        }
        
        debugPrint('📋 Showing notification ${i + 1}/${notifications.length}: id=$notificationId');
        
        // Wait for previous dialog to close (if any)
        if (i > 0) {
          await Future.delayed(const Duration(milliseconds: 300));
        }
        
        // Show popup and wait for user to click OK
        await _showZeptoPopupWithCallback(
          title: title,
          messageBody: body,
          notificationId: notificationId,
          userId: userId,
        );
      }
    } catch (e) {
      debugPrint('❌ Error showing free cash notifications: $e');
    }
  }

  /// Show popup with callback to mark as read
  Future<void> _showZeptoPopupWithCallback({
    required String title,
    required String messageBody,
    required String notificationId,
    required String userId,
  }) async {
    if (navigatorKey.currentContext == null) return;

    final completer = Completer<void>();
    
    showDialog(
      context: navigatorKey.currentContext!,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return _ZeptoPopupDialog(
          title: title,
          messageBody: messageBody,
          onOkPressed: () async {
            // Close the dialog first
            if (Navigator.canPop(context)) {
              Navigator.of(context).pop();
            }
            // Mark notification as read after closing
            await markNotificationAsRead(
              userId: userId,
              notificationId: notificationId,
            );
            completer.complete();
          },
        );
      },
    );
    
    return completer.future;
  }
}

void _showZeptoPopup({required String title, required String messageBody}) {
  if (navigatorKey.currentContext == null) return;

  debugPrint(
      '🎯 _showZeptoPopup called => title: "$title" | messageBody: "$messageBody"');

  // Store values in local variables to avoid any closure issues
  final String dialogTitle = title.isNotEmpty ? title : 'Notification';
  final String dialogBody = messageBody.isNotEmpty ? messageBody : 'No message';

  debugPrint(
      '📋 Dialog values => dialogTitle: "$dialogTitle" | dialogBody: "$dialogBody"');

  showDialog(
    context: navigatorKey.currentContext!,
    barrierDismissible: false,
    builder: (BuildContext context) {
      debugPrint(
          '🔨 Building dialog => title: "$dialogTitle" | body: "$dialogBody"');
      return _ZeptoPopupDialog(
        title: dialogTitle,
        messageBody: dialogBody,
      );
    },
  );
}

class _ZeptoPopupDialog extends StatelessWidget {
  final String title;
  final String messageBody;
  final VoidCallback? onOkPressed;

  const _ZeptoPopupDialog({
    required this.title,
    required this.messageBody,
    this.onOkPressed,
  });

  @override
  Widget build(BuildContext context) {
    debugPrint(
        '🎨 _ZeptoPopupDialog build => title: "$title" | messageBody: "$messageBody"');
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
      elevation: 8,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: Colors.white,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Success Icon with background circle
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.check_circle,
                size: 50,
                color: Colors.green.shade600,
              ),
            ),
            const SizedBox(height: 20),
            // Title
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 16),
            // Message Body
            Text(
              messageBody,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                height: 1.5,
                color: Colors.grey.shade700,
              ),
            ),
            const SizedBox(height: 24),
            // OK Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // If callback exists, it will handle closing the dialog
                  // Otherwise, close it here
                  if (onOkPressed != null) {
                    onOkPressed!();
                  } else {
                    if (Navigator.canPop(context)) {
                      Navigator.of(context).pop();
                    }
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade600,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 2,
                ),
                child: const Text(
                  'OK',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

@pragma('vm:entry-point')
Future<void> myBackgroundMessageHandler(RemoteMessage message) async {
  setPrefrenceBool(ISFROMBACK, true);
  if (message.data['type'].toString() == 'chat') {
    final messages = jsonDecode(message.data['message']) as List;
    NotificationRepository.addChatNotification(
        message: jsonEncode(messages.first));
  }
}
