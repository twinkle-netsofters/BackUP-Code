import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class PhonePePaymentWebView extends StatefulWidget {
  final String url;

  PhonePePaymentWebView({required this.url});

  @override
  _PhonePePaymentWebViewState createState() => _PhonePePaymentWebViewState();
}

class _PhonePePaymentWebViewState extends State<PhonePePaymentWebView> {
  late InAppWebViewController _webViewController;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    // Initialize the WebViewController
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Payment Gateway"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          InAppWebView(
            initialUrlRequest: URLRequest(url: Uri.parse(widget.url)),
            onWebViewCreated: (InAppWebViewController controller) {
              _webViewController = controller;
            },
            initialOptions: InAppWebViewGroupOptions(
              crossPlatform: InAppWebViewOptions(
                javaScriptEnabled:
                    true, // Allow unrestricted JavaScript execution
              ),
            ),
            onLoadStart: (InAppWebViewController controller, Uri? url) {
              setState(() {
                isLoading = true;
              });
            },
            onLoadStop: (InAppWebViewController controller, Uri? url) {
              setState(() {
                isLoading = false;
              });
            },
            onLoadError: (InAppWebViewController controller, Uri? url, int code,
                String message) {
              setState(() {
                isLoading = false;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Error loading page: $message")),
              );
            },
            onProgressChanged:
                (InAppWebViewController controller, int progress) {
              // Optionally, track page load progress here
            },
          ),
          if (isLoading)
            Center(
              child: CircularProgressIndicator(),
            ),
        ],
      ),
    );
  }
}
