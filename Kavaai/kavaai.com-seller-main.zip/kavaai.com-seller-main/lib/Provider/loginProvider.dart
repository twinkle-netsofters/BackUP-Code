import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sellermultivendor/Screen/DashBoard/dashboard.dart';
import '../Helper/ApiBaseHelper.dart';
import '../Screen/Authentication/Login.dart';
import '../Widget/api.dart';
import '../Widget/parameterString.dart';
import '../Widget/sharedPreferances.dart';

class LoginProvider extends ChangeNotifier {
  String? mobile, password, username, id;
  AnimationController? buttonController;

  get getMobilenumber => mobile;
  get getPassword => Password;

  Future<void> getLoginUser(
    BuildContext context,
    GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey,
    Function updateNow,
  ) async {
    var data = {
      Mobile: mobile,
      Password: password,
    };
    
      ApiBaseHelper().postAPICall(getUserLoginApi, data).then((getData) async {
        bool error = getData["error"];
        String? msg = getData["message"];

        if (!error) {
          setSnackbarScafold(scaffoldMessengerKey, context, msg!);
          var data = getData["data"][0];
          id = data[Id];
          username = data[Username];
          mobile = data[Mobile];
          await saveUserDetail(id!, username!, mobile!, getData[TOKEN]);

          setPrefrenceBool(isLogin, true);

          if (context.mounted) {
            Navigator.pushReplacement(
              context,
              CupertinoPageRoute(
                builder: (context) => const Dashboard(),
              ),
            );
          }
        } else {
          await buttonController!.reverse();
          setSnackbarScafold(scaffoldMessengerKey, context, msg!);
          updateNow();
        }
      },
      onError: (error) {
        setSnackbarScafold(scaffoldMessengerKey, context, error.toString());
      },
    );
  }
}
