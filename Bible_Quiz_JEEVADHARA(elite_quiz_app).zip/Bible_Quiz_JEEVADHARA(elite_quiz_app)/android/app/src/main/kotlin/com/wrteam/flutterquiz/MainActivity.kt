package com.twoannsmedia.jeevadharabiblequiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
