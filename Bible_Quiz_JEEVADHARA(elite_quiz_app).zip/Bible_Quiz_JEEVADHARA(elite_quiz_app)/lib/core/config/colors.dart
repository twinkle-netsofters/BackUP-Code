import 'package:flutter/material.dart';

/// Light Theme
const klBackgroundColor = Color(0xfffefefe);
const klCanvasColor = Color(0xcc000000);
const klPageBackgroundColor = Color(0xffF3F7FA);
const klPrimaryColor = Color(0xff4A00E0);
const klPrimaryTextColor = Color(0xff45536d);

/// Dark Theme
const kdBackgroundColor = Color(0xff294261);
const kdCanvasColor = Color(0xccffffff);
const kdPageBackgroundColor = Color(0xff233354);
const kdPrimaryColor = Color(0xff4A00E0);
const kdPrimaryTextColor = Color(0xffffffff);

/// Common
const Color kAddCoinColor = Colors.green;
const Color kBadgeLockedColor = Colors.grey;
const Color kHurryUpTimerColor = Colors.red;
const Color kCorrectAnswerColor = Color(0xFF5DB760);
const Color kWrongAnswerColor = Color(0xFFFF6169);
const Color kPendingColor = Colors.orangeAccent;
