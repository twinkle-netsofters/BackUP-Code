/// Enum representing the different tabs in the bottom navigation bar.
enum NavTabType { home, leaderboard, quizZone, playZone, profile }
