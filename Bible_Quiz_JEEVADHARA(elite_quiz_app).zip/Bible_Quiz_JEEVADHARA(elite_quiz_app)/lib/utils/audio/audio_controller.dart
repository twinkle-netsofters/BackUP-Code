import 'dart:io';

import 'package:audio_session/audio_session.dart';
import 'package:just_audio/just_audio.dart';

/// Controls shared audio session configuration and per-player attributes.
///
/// Ensures that every `AudioPlayer` instance in the app has consistent audio
/// attributes and that the shared [AudioSession] is configured only once.
class AudioController {
  AudioController._();

  static Future<void>? _sessionFuture;

  /// Configures the shared [AudioSession] for game-style audio playback.
  static Future<void> ensureSessionConfigured() {
    return _sessionFuture ??= _configureSession();
  }

  static Future<void> _configureSession() async {
    final session = await AudioSession.instance;

    await session.configure(
      const AudioSessionConfiguration.music(),
    );

    await session.setActive(true);
  }

  /// Applies platform specific attributes to the provided [player].
  static Future<void> configurePlayer(
    AudioPlayer player, {
    bool isEffect = false,
  }) async {
    await ensureSessionConfigured();

    if (Platform.isAndroid) {
      await player.setAndroidAudioAttributes(
        AndroidAudioAttributes(
          usage: isEffect ? AndroidAudioUsage.game : AndroidAudioUsage.media,
          contentType: isEffect
              ? AndroidAudioContentType.sonification
              : AndroidAudioContentType.music,
        ),
      );
    }
  }
}
