import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutterquiz/features/settings/settings_cubit.dart';
import 'package:google_fonts/google_fonts.dart';

class QuestionTextStyles {
  static const double fontBoost = 6;
  static const double minFontSize = 26;

  static double fontSize(
    BuildContext context, {
    double? baseSize,
  }) {
    final resolvedBaseSize = baseSize ??
        context.read<SettingsCubit>().getSettings().playAreaFontSize;

    return (resolvedBaseSize + fontBoost).clamp(
      minFontSize,
      double.infinity,
    );
  }

  static TextStyle primary(
    BuildContext context, {
    Color? color,
    FontWeight fontWeight = FontWeight.w700,
    double? customFontSize,
    double height = 1.125,
  }) {
    return GoogleFonts.nunito(
      textStyle: TextStyle(
        height: height,
        color: color ?? Theme.of(context).colorScheme.onTertiary,
        fontWeight: fontWeight,
        fontSize: customFontSize ?? fontSize(context),
      ),
    );
  }
}

