import 'package:flutter/material.dart';
import 'package:flutterquiz/commons/commons.dart' show QImage;
import 'package:flutterquiz/core/constants/assets_constants.dart';

class AppLogo extends StatelessWidget {
  const AppLogo({super.key});

  @override
  Widget build(BuildContext context) {

    // return const QImage(
    //     imageUrl: Assets.appLogo,

    final size = MediaQuery.of(context).size;

    // return QImage(
    //     imageUrl: Assets.appLogo,
    //     width: size.width * 0.5,
    //     height: size.width * 0.5,
    //     fit: BoxFit.contain,

    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: QImage(
        imageUrl: Assets.appLogo,
        width: size.width * 0.5,
        height: size.width * 0.5,
        fit: BoxFit.contain,
      ),
    );
  }
}
